# God-Emperor Novel 6.0 · Finish Product

Production-oriented Cloudflare Workers + D1 novel/fanfiction platform with OmniPortal federation. Mobile-first, PWA-ready, SEO-ready, and designed for the existing GitHub → Cloudflare Builds workflow.

## 6.0 hardening and completeness
- Self-healing core schema bootstrap plus migrations.
- Ticket ledger for auditable balances.
- Ratings, follows, notifications, reports and admin report moderation API.
- Paginated catalog API with trending-by-7-day-unlocks.
- Public novel/read/fandom SEO rendering, robots.txt, sitemap.xml, legal pages and structured metadata.
- Security response headers including HSTS, nosniff, referrer policy and permissions policy.
- Payment webhook verification upgraded to HMAC-SHA256.
- OmniPortal authorized connector federation, resolver, import jobs and Smart Unlock.
- PWA/service-worker cache versioning.

## Important deployment note
This package is intended to be deployed from the project root. Existing GitHub → Cloudflare Builds can use `npx wrangler deploy`. Do not place the project inside another nested project directory.

## Connector and content rights
Only connect APIs, feeds, catalogs, or content you are authorized to use. OmniPortal does not bypass authentication, robots controls, paywalls, CAPTCHAs, or other access controls.

## Payment
EasyPaisa is configured as the primary manual payment method. Automatic approval requires an official provider integration/webhook and the corresponding Cloudflare secret. Ticket prices should be configured explicitly rather than invented by the application.

## Key routes
`/api/health`, `/api/auth/*`, `/api/novels`, `/api/chapters/*`, `/api/omni/*`, `/api/requests`, `/api/follow`, `/api/rating`, `/api/notifications`, `/api/report`, `/api/admin/*`.
