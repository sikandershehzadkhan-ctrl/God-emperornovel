import test from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import path from "node:path";
import { spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const read = (file) => readFile(path.join(root, file), "utf8");

test("Cloudflare readiness gate never deploys or contacts a remote service", async () => {
  const source = await read("scripts/cloudflare-readiness.mjs");
  assert.doesNotMatch(source, /wrangler\s+deploy|fetch\s*\(/i);
  assert.match(source, /read-only Cloudflare release gate/i);
});

test("staging configuration is isolated from production", async () => {
  const config = await read("wrangler.jsonc");
  assert.match(config, /"name"\s*:\s*"imperial-novel-staging"/);
  assert.match(config, /"database_name"\s*:\s*"imperial-novel-staging"/);
  assert.match(config, /REPLACE_WITH_STAGING_D1_ID/);
  assert.doesNotMatch(config, /god-emperornovel-db/);
});

test("Cloudflare authentication is runtime-isolated and has a D1 adapter source", async () => {
  const route = await read("src/routes/api/auth/$.ts");
  const handler = await read("src/lib/auth/route-handler.ts");
  const server = await read("src/lib/auth/server.ts");
  const cloudflareAuth = await read("src/lib/auth/cloudflare.server.ts");
  const vite = await read("vite.config.ts");
  assert.match(route, /handleAuthRequest\(/);
  assert.match(route, /cloudflare\.server/);
  assert.match(handler, /isCloudflareAuthRuntime\(/);
  assert.match(handler, /return authUnavailableResponse\(\)/);
  assert.match(server, /D1-backed sessions are not implemented/);
  assert.match(cloudflareAuth, /drizzleAdapter/);
  assert.match(cloudflareAuth, /drizzle-orm\/d1/);
  assert.match(vite, /cloudflare-node-auth-disabled\.server\.ts/);
});

test("D1 request bindings are available to both app queries and session verification", async () => {
  const context = await read("src/lib/db/d1-context.ts");
  const verify = await read("src/lib/auth/verify.server.ts");
  const middleware = await read("server/middleware/imperial-d1.ts");
  assert.match(context, /await currentRequestDatabase\(\)/);
  assert.match(context, /await import\("@tanstack\/react-start\/server"\)/);
  assert.match(verify, /cloudflareEnvForRequest\(request\)/);
  assert.match(verify, /createCloudflareAuth/);
  assert.match(middleware, /registerCloudflareEnvRequest\(request, cloudflareEnv\)/);
});

test("D1 auth schema has core tables and session/user relationships", async () => {
  const sql = await read("migrations/d1/0001_auth.sql");
  for (const table of ["user", "session", "account", "verification"]) {
    assert.match(sql, new RegExp(`create table if not exists "${table}"`, "i"));
  }
  assert.match(sql, /"session"\s*\([\s\S]*?"userId"\s+text not null references "user"\s*\("id"\)/i);
  assert.match(sql, /"account"\s*\([\s\S]*?"userId"\s+text not null references "user"\s*\("id"\)/i);
  assert.match(sql, /create index if not exists "session_userId_idx"/i);
});


test("all source checks pass while external release prerequisites remain honestly blocked", async () => {
  const result = spawnSync(process.execPath, ["scripts/cloudflare-readiness.mjs"], {
    cwd: root,
    encoding: "utf8",
  });
  // The command remains non-zero until external Cloudflare/npm prerequisites are fulfilled.
  assert.equal(result.status, 2, result.stdout + result.stderr);
  assert.match(result.stdout, /\[PASS\] Staging D1 configuration is isolated/);
  assert.match(result.stdout, /\[PASS\] Persistent D1-backed Better Auth adapter source/);
  assert.match(result.stdout, /\[PASS\] HTTPS authentication cookies are Secure/);
  assert.match(result.stdout, /\[PASS\] Drizzle dependency pin consistency/);
  assert.match(result.stdout, /Source result: 17\/17 source checks passed; 0 source blocker\(s\)/);
    assert.match(result.stdout, /\[RELEASE BLOCKED\].*integrity metadata/i);
  assert.doesNotMatch(result.stdout, /\[RELEASE BLOCKED\].*staging D1 database ID/i);
});
