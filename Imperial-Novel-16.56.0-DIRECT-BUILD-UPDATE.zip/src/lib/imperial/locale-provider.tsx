import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import en from "../../../locales/starter/en.json";
import ur from "../../../locales/starter/ur.json";
import ar from "../../../locales/starter/ar.json";
import zhCN from "../../../locales/starter/zh-CN.json";
import zhTW from "../../../locales/starter/zh-TW.json";
import es from "../../../locales/starter/es.json";
import fr from "../../../locales/starter/fr.json";
import ptBR from "../../../locales/starter/pt-BR.json";
import hi from "../../../locales/starter/hi.json";
import id from "../../../locales/starter/id.json";
import ja from "../../../locales/starter/ja.json";
import ko from "../../../locales/starter/ko.json";

const dictionaries = { en, ur, ar, "zh-CN": zhCN, "zh-TW": zhTW, es, fr, "pt-BR": ptBR, hi, id, ja, ko } as const;
export type ImperialLocale = keyof typeof dictionaries;
export const IMPERIAL_LOCALES: { value: ImperialLocale; label: string }[] = [
  { value: "en", label: "English" }, { value: "ur", label: "اردو" }, { value: "ar", label: "العربية" },
  { value: "zh-CN", label: "简体中文" }, { value: "zh-TW", label: "繁體中文" }, { value: "es", label: "Español" },
  { value: "fr", label: "Français" }, { value: "pt-BR", label: "Português (Brasil)" }, { value: "hi", label: "हिन्दी" },
  { value: "id", label: "Bahasa Indonesia" }, { value: "ja", label: "日本語" }, { value: "ko", label: "한국어" },
];
type LocaleContextValue = { locale: ImperialLocale; setLocale: (locale: ImperialLocale) => void; t: (key: keyof typeof en.strings) => string };
const LocaleContext = createContext<LocaleContextValue | null>(null);
export function ImperialLocaleProvider({ children }: { children: ReactNode }) {
  const [locale, setLocaleState] = useState<ImperialLocale>("en");
  useEffect(() => {
    try { const saved = localStorage.getItem("imperial_locale") as ImperialLocale | null; if (saved && saved in dictionaries) setLocaleState(saved); } catch { /* Storage may be disabled. */ }
  }, []);
  useEffect(() => {
    const dict = dictionaries[locale];
    document.documentElement.lang = dict.locale;
    document.documentElement.dir = dict.direction;
    try { localStorage.setItem("imperial_locale", locale); } catch { /* Preference remains session-local. */ }
  }, [locale]);
  const value = useMemo<LocaleContextValue>(() => ({
    locale,
    setLocale: (next) => setLocaleState(next),
    t: (key) => (dictionaries[locale].strings[key] || dictionaries.en.strings[key]) as string,
  }), [locale]);
  return <LocaleContext.Provider value={value}>{children}</LocaleContext.Provider>;
}
export function useImperialLocale() {
  const value = useContext(LocaleContext);
  if (!value) throw new Error("useImperialLocale must be used within ImperialLocaleProvider");
  return value;
}
