import { createRootRoute, HeadContent, Scripts } from "@tanstack/react-router";
import { createServerFn } from "@tanstack/react-start";
import { Toaster } from "sonner";
import { AuthProvider } from "@/lib/auth/provider";
import { ImperialLocaleProvider } from "@/lib/imperial/locale-provider";
import { PreviewHostBridge } from "@/components/preview-host-bridge";
import { Shell } from "@/components/layout/shell";
import { CookieConsent } from "@/components/privacy/cookie-consent";
import appCss from "../styles.css?url";

const APP_NAME = "Imperial Novel";

const fetchSessionUser = createServerFn({ method: "GET" }).handler(async () => {
  const { getSessionUser } = await import("@/lib/auth/verify.server");
  const u = await getSessionUser();
  return u ? { id: u.id, email: u.email } : null;
});

export const Route = createRootRoute({
  beforeLoad: async () => ({ sessionUser: await fetchSessionUser() }),
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1, viewport-fit=cover" },
      { title: APP_NAME },
      { name: "theme-color", content: "#050814" },
      {
        name: "description",
        content: "Imperial Novel — Read • Create • Conquer. Discover original, licensed and authorized novels in a cinematic reading realm.",
      },
      { property: "og:site_name", content: APP_NAME },
      { property: "og:type", content: "website" },
      { property: "og:title", content: "Imperial Novel | Read • Create • Conquer" },
      { property: "og:description", content: "Discover original, licensed and authorized novels in a cinematic reading realm." },
      { property: "og:image", content: "https://god-emperornovel.sikandershehzadkhan.workers.dev/og.jpg" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: "Imperial Novel | Read • Create • Conquer" },
      { name: "twitter:description", content: "Discover original, licensed and authorized novels in a cinematic reading realm." },
      { name: "twitter:image", content: "https://god-emperornovel.sikandershehzadkhan.workers.dev/og.jpg" },
    ],
    links: [
      { rel: "icon", type: "image/svg+xml", href: "/favicon.svg" },
      { rel: "stylesheet", href: appCss },
      { rel: "manifest", href: "/__grok/manifest.webmanifest" },
      { rel: "apple-touch-icon", href: "/imperial-crown-icon.png" },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=Cinzel:wght@500;600;700&family=Cormorant+Garamond:wght@500;600;700&family=Outfit:wght@400;500;600;700&family=Source+Serif+4:opsz,wght@8..60,400;8..60,600&display=swap",
      },
    ],
  }),
  component: RootDocument,
  notFoundComponent: NotFoundPage,
});

function RootDocument() {
  return (
    <html lang="en" className="antialiased" suppressHydrationWarning>
      <head>
        <HeadContent />
      </head>
      <body>
        <PreviewHostBridge />
        <AuthProvider>
          <ImperialLocaleProvider>
            <Shell />
          </ImperialLocaleProvider>
          <CookieConsent />
          <Toaster
            theme="dark"
            position="top-center"
            toastOptions={{
              style: {
                background: "#101628",
                border: "1px solid rgba(34,211,238,0.2)",
                color: "#f8fafc",
              },
            }}
          />
        </AuthProvider>
        <Scripts />
      </body>
    </html>
  );
}

function NotFoundPage() {
  return (
    <div className="mx-auto max-w-lg px-4 py-20 text-center">
      <p className="text-[11px] font-semibold tracking-[0.22em] text-cyan uppercase">Imperial Gateway</p>
      <h1 className="font-display mt-3 text-4xl text-fg">We could not find that realm.</h1>
      <p className="mt-3 text-sm text-muted">Check the address or return to the Imperial Novel library.</p>
      <div className="mt-6 flex flex-wrap justify-center gap-2">
        <a href="/" className="cta-primary inline-flex min-h-11 items-center rounded-md px-4 text-sm font-semibold">
          Return Home
        </a>
        <a
          href="/catalog"
          className="cta-explore inline-flex min-h-11 items-center rounded-md px-4 text-sm font-semibold"
        >
          Explore Catalog
        </a>
      </div>
    </div>
  );
}
