# Imperial Novel 16.55.0 — Update 2

## Scope
- Builds on Update 1 (16.54.0).
- Adds a persisted language selector for 12 starter locales.
- Sets the document language and direction for RTL Urdu and Arabic.
- Uses starter dictionaries for primary navigation and the header search placeholder.
- This is partial UI localization, not a claim that every page, email, admin view, reader control, validation message, or novel body is translated.
- No database schema, payment/ticket logic, auth policy, rights workflow, or external integration is intentionally changed.

## Verification status
- Source-level packaging checks: performed by release packaging.
- Typecheck, production build, visual regression, RTL QA, Cloudflare staging deployment: not yet verified in this environment.
- No live Worker or D1 database was changed.

## Rollout
Apply only after Update 1 has been deployed and its core routes verified. Check mobile header fit, persisted language selection, Arabic/Urdu RTL, keyboard accessibility, and fallback to English before production rollout.
