# Imperial Novel 11.0

Responsive Imperial Novel web-novel platform for Cloudflare Workers + D1. This release refines the interface around the approved Imperial character-sheet aesthetic: black, cosmic violet, snow-white, silver and imperial gold.

## UI
- Imperial Novel / Imperial NovelVerse public branding.
- Desktop three-zone layout: Imperial Hall navigation, catalog/content, discovery rail.
- Character artwork integrated into the hero section.
- WTR-Lab-inspired catalog organization without copying its code or visual assets.
- Mobile-first two-column novel cards, dedicated search, touch controls and fixed bottom navigation.
- Mobile navigation: Home, Catalog, Library, OmniPortal, Account.
- Existing authentication, library, requests, tickets, reader, OmniPortal, agent fleet and admin APIs preserved.

## Deployment
GitHub → Cloudflare Workers Builds. Recommended build command:
`unzip -o God-Emperor-Novel-11.0-Imperial-UI.zip`
Deploy command:
`npx wrangler deploy`

The Worker target is `imperial-novel`, using the existing D1 database `god-emperornovel-db`.

## Rights
Only publish or connect content that you own or are authorized to use. OmniPortal does not bypass authentication, paywalls, CAPTCHAs, robots controls or other access controls.
