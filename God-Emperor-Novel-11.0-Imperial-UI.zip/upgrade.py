from pathlib import Path
p=Path('/mnt/data/build110/public/index.html')
s=p.read_text()
s=s.replace('APP_VERSION__','APP_VERSION__')
s=s.replace('10.2.0','11.0.0')
# Add CSS before </style>
css='''
/* Imperial Novel 11.0 experience layer */
:root{--glow:#9d7aff;--gold3:#ffe8a8}
body:after{content:"";position:fixed;inset:auto 0 0;height:180px;pointer-events:none;background:linear-gradient(180deg,transparent,#6f4cc60a);z-index:-1}
.top{box-shadow:0 8px 32px #0006}.brandMark{border-radius:50%;box-shadow:0 0 0 1px #d7ad5422,0 0 28px #8d67ff25}
.heroFrame{isolation:isolate}.heroFrame:before{content:"";position:absolute;inset:0;background:linear-gradient(90deg,#090b12e8 0%,#0e1019d9 42%,#0e101955 72%,#090b1288 100%);z-index:1}.heroArtwork{position:absolute;inset:0;z-index:0;display:flex;justify-content:flex-end;overflow:hidden}.heroArtwork img{height:100%;width:55%;object-fit:cover;object-position:center;opacity:.8;filter:saturate(.9) contrast(1.06);mask-image:linear-gradient(90deg,transparent 0%,#000 42%,#000 100%)}
.heroInner{min-height:310px}.hero h1{letter-spacing:-.035em}.heroLead{max-width:720px}.heroAside{backdrop-filter:blur(10px);box-shadow:0 18px 50px #0005}
.quickBar{display:grid;grid-template-columns:repeat(4,1fr);gap:9px;margin:12px 0}.quickCard{border:1px solid #292e3c;background:linear-gradient(135deg,#141725,#0d1017);border-radius:12px;padding:12px 14px;display:flex;align-items:center;gap:11px}.quickCard .qIcon{font-size:20px}.quickCard b{display:block;font-size:13px}.quickCard span{display:block;color:#7e879a;font-size:10px}.sectionPanel{box-shadow:0 12px 40px #0003}.catalogGrid{grid-template-columns:repeat(5,minmax(0,1fr))}.card .cover{transition:transform .25s}.card:hover .cover{transform:scale(1.025)}.emptyState{padding:35px 15px;text-align:center;border:1px dashed #33394a;border-radius:12px;color:#8a92a5}.emptyState b{display:block;color:#e7eaf1;margin-bottom:4px}.statusDot{display:inline-block;width:7px;height:7px;border-radius:50%;background:#777;margin-right:5px}.statusDot.good{background:#5bd5a4;box-shadow:0 0 10px #5bd5a455}.statusDot.warn{background:#d7ad54}.progressTrack{height:4px;background:#232735;border-radius:99px;overflow:hidden}.progressFill{height:100%;background:linear-gradient(90deg,#8d67ff,#d7ad54);width:0}.readerWrap{position:relative}.readerProgress{position:sticky;top:98px;z-index:4;height:4px;background:#202330;border-radius:99px;margin-bottom:14px;overflow:hidden}.readerProgress span{display:block;height:100%;width:0;background:linear-gradient(90deg,#8d67ff,#d7ad54)}
@media(max-width:1100px){.catalogGrid{grid-template-columns:repeat(4,minmax(0,1fr))}.contentLayout{grid-template-columns:1fr}.desktopRail{display:none}}
@media(max-width:760px){.utility{display:none}.nav{height:60px;gap:8px}.brand{min-width:auto}.brandText small{display:none}.brandText b{font-size:15px}.navlinks{display:none}.searchTop{display:none}.navRight{margin-left:auto}.balance{padding:7px 8px}.hero{padding-top:10px}.heroFrame{min-height:430px}.heroArtwork img{width:100%;height:52%;align-self:flex-start;opacity:.5;mask-image:linear-gradient(180deg,#000 0%,#000 45%,transparent 100%)}.heroFrame:before{background:linear-gradient(180deg,#090b1288 0%,#090b12dd 43%,#090b12f8 68%,#090b12 100%)}.heroInner{grid-template-columns:1fr;padding:28px 20px 20px;min-height:430px;align-content:end}.hero h1{font-size:39px}.heroLead{font-size:14px}.heroAside{display:none}.quickBar{grid-template-columns:1fr 1fr}.catalogGrid{grid-template-columns:repeat(2,minmax(0,1fr));gap:8px}.cover{height:205px}.sectionPad{padding:13px}.sectionHead{align-items:flex-start;flex-direction:column}.tools,.search{width:100%}.fandoms{grid-template-columns:1fr 1fr}.two{grid-template-columns:1fr}.reader{font-size:18px}.readerProgress{top:61px}.mobileBottom{box-shadow:0 -8px 28px #0008}}
@media(min-width:761px){.mobileSearch{display:none}}
'''
s=s.replace('</style>',css+'</style>',1)
# Insert quick bar after genre bar
needle='<div class="wrap genreBar"><div id="genres" class="genreScroll"></div></div>'
quick='''<div class="wrap quickBar">
<div class="quickCard"><span class="qIcon">⚡</span><div><b>Recently Updated</b><span>Fresh chapters first</span></div></div>
<div class="quickCard"><span class="qIcon">🔥</span><div><b>Trending</b><span>Most unlocked this week</span></div></div>
<div class="quickCard"><span class="qIcon">🎟️</span><div><b>Batch Unlocks</b><span>10 · 25 · 50 · 100</span></div></div>
<div class="quickCard"><span class="qIcon">🌐</span><div><b>OmniPortal</b><span>Authorized sources</span></div></div>
</div>'''
s=s.replace(needle,needle+quick)
# Improve catalog section with reset button
s=s.replace('<select id="sort" class="input" onchange="loadBooks()"><option value="updated">Recently updated</option>', '<button class="btn" onclick="resetCatalog()">Reset</button><select id="sort" class="input" onchange="loadBooks()"><option value="updated">Recently updated</option>')
# Replace empty catalog messages
s=s.replace("'<div class=\"muted\">No novels match your search.</div>'", "'<div class=\"emptyState\"><b>No novels found</b>Try another title, author, genre or tag.</div>'")
s=s.replace("'<div class=\"muted\">No novels found.</div>'", "'<div class=\"emptyState\"><b>No novels found</b>Try another genre or search term.</div>'")
# Enhance chapter reader progress and restore save handler safely
old="$('#readerBody').innerHTML=`<div class=\"kicker\">Chapter ${c.chapter_number}</div><h2>${esc(c.title)}</h2><div class=\"readerToolbar\">"
new="$('#readerBody').innerHTML=`<div class=\"kicker\">Chapter ${c.chapter_number}</div><h2>${esc(c.title)}</h2><div class=\"readerProgress\"><span id=\"readerProgressFill\"></span></div><div class=\"readerToolbar\">"
s=s.replace(old,new)
old2="window.onscroll=save"
new2="window.onscroll=()=>{save();const rr=$('#reader'),fill=$('#readerProgressFill');if(rr&&fill){const max=Math.max(1,rr.scrollHeight-rr.clientHeight);fill.style.width=Math.min(100,Math.max(0,rr.scrollTop/max*100))+'%'}}"
s=s.replace(old2,new2)
# Add reset function before loadBooks
anchor='async function loadBooks(){'
fn="function resetCatalog(){$('#search').value='';document.querySelectorAll('.chip').forEach(x=>x.classList.remove('active'));document.querySelector('.chip')?.classList.add('active');$('#sort').value='updated';loadBooks()}\n"
s=s.replace(anchor,fn+anchor,1)
# Footer version
s=s.replace('Version 10.1','Version 11.0').replace('v10.1','v11.0')
p.write_text(s)
