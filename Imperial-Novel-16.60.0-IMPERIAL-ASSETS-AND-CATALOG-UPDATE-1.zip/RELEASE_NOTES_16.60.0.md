# Imperial Novel 16.60.0 — Update 1

## What changed
- Preserves the existing Cloudflare Worker application structure from the 16.24.0 compatible baseline.
- Adds the eight actual novel-cover images from the 16.53 design build as static assets under `public/covers/`.
- Updates the existing frontend image helper to select a matching local cover only when a novel has no stored `cover_url`; stored URLs continue to take precedence.
- Adds the Imperial Novel crest SVG and favicon SVG from the design build.
- Includes the original brand-iteration artwork in `design-reference/brand-iterations/` for continued visual integration, rather than adding arbitrary padding.
- Adds a source-check build command and version marker 16.60.0.
- Removes the obsolete deploy workflow that searched for an old ZIP name, avoiding accidental legacy deployment.

## Validation required before deployment
1. `node --check src/index.js`
2. `node --check public/app.js`
3. `npm run build`
4. Confirm the live Cloudflare Worker and D1 IDs match `wrangler.toml` before any deployment.
5. Test catalog cards, novel pages, chapter reader, sign-in, ticket ledger and manual EasyPaisa approval against staging.

This is an update package, not a claim that the live site has been deployed. No production database migration is included. The newer TanStack/Nitro architecture from 16.53 is not substituted for the current Worker runtime.
