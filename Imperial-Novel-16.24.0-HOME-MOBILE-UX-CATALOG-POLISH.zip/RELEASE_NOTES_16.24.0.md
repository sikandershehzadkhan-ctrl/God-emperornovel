# Imperial Novel 16.24.0

## Home Mobile UX + Catalog Polish

- Reduced excessive bottom whitespace on the Home page.
- Added dynamic single-story catalog behavior on Home.
- Single-story sections now use a deliberate mobile featured-card width instead of leaving an awkward half-grid.
- Preserved multi-story responsive grid behavior.
- Reduced mobile hero vertical footprint while preserving the cinematic Imperial artwork.
- Improved Home section spacing and mobile CTA touch targets.
- Improved Trending/Recently Updated section headings and browse controls.
- Preserved Imperial indigo, violet, gold, obsidian and cosmic visual system.
- Preserved tickets, authentication, D1, library, reader, Author Studio and OmniPortal architecture.
- No database migration or reset.
