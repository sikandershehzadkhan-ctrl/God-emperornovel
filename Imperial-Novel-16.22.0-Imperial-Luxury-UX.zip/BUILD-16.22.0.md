# Imperial Novel 16.22.0

## Base
Built directly from the existing Imperial Novel 16.21.0 project package.

## Included
- Imperial Luxury visual system
- Obsidian + Indigo + Cosmic Purple + Imperial Purple + Electric Purple + Gold + Platinum palette
- Ambient cosmic motion and controlled interaction animation
- Reduced-motion accessibility behavior
- Upgraded global navigation and mobile navigation
- Upgraded homepage hierarchy and discovery entry points
- Dark premium cards/panels/forms/reader surfaces
- Gold prestige states and focus-visible accessibility states
- Existing API, D1, authentication, catalog, reader, community, OmniPortal, Author Studio and admin routes preserved

## Database
No new migration required.

## Deploy
`npx wrangler deploy`
