# Imperial Novel 16.3.1

## Combined Release

This release combines the stable Imperial Novel 16.2.8 backend/admin request-management functionality with the 16.3.0 clean UI layer.

### UI
- Snow-Milk-White primary visual foundation
- Silver structural accents and borders
- Cosmic Violet interactive accents
- Cleaner mobile-first layout
- Refined public home and admin presentation
- Improved responsive navigation and cards

### Backend preserved
- D1 database integration
- Authentication and account roles
- Admin dashboard and protection
- Taxonomy moderation
- Ticket credits and ledger
- Novel request approval/rejection/fulfillment
- Paid request rejection refunds
- Audit logging
- Rights-aware connector registry

### Deployment
- Worker: god-emperornovel
- Deploy command: `npx wrangler deploy`
- Existing D1 binding and backend routes are preserved.
