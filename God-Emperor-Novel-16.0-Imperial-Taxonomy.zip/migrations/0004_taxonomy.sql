CREATE TABLE IF NOT EXISTS taxonomy_suggestions (id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER NOT NULL,type TEXT NOT NULL,name TEXT NOT NULL,slug TEXT NOT NULL,description TEXT DEFAULT '',status TEXT NOT NULL DEFAULT 'pending',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,reviewed_by INTEGER,reviewed_at TEXT);
CREATE TABLE IF NOT EXISTS tag_follows (user_id INTEGER NOT NULL,tag_id INTEGER NOT NULL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(user_id,tag_id));
CREATE INDEX IF NOT EXISTS idx_taxonomy_suggestions_status ON taxonomy_suggestions(status,created_at);
CREATE INDEX IF NOT EXISTS idx_tag_follows_tag ON tag_follows(tag_id);
