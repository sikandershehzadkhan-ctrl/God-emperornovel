# Imperial Novel 16.0

## Community Genres & Tags
- Expanded the master genre and tag taxonomy across fantasy, cultivation, romance, fanfiction, games, anime/manga, drama/TV, science fiction, kingdom/empire building, school, military, politics, supernatural, apocalypse and many more categories.
- Preserved an original normalized taxonomy rather than copying another site's UI, code or protected content.
- Added official/community taxonomy metadata, descriptions and creator attribution.
- Authors and signed-in users can create community tags immediately, with duplicate checks and a daily creation limit.
- Signed-in users can suggest new genres for moderation.
- Added admin review endpoints for genre suggestions.
- Added tag following.
- Added dedicated genre and tag detail pages with catalog links and matching novels.
- Added clean URLs: `/genre/<slug>` and `/tag/<slug>`.
- Existing catalog genre/tag filtering remains compatible.

## Preserved
- Imperial Novel 15.0 multi-page design and luxury icon assets.
- Worker `god-emperornovel` and D1 `god-emperornovel-db`.
- Authentication, library, history, following, tickets, unlocks, comments, ratings, requests, recommendations and rights-aware OmniPortal architecture.
- No bypassing access controls, paywalls, CAPTCHAs, DRM or robots restrictions.
