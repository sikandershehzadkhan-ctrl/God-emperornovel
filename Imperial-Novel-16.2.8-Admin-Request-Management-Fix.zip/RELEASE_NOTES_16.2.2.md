# Imperial Novel 16.2.2

Fixes community taxonomy pending retrieval and duplicate detection; reports database errors instead of masking them.
