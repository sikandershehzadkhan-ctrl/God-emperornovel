# Imperial Novel 16.2.6

## Admin Bootstrap Fix

- Removes the fragile `SETUP_SECRET` initial setup flow.
- On initialization, if users exist but no administrator exists, the oldest user account is promoted to `admin` and marked verified.
- Once an administrator exists, the bootstrap path becomes inert.
- Existing login credentials are preserved.
- Cron trigger and the rest of the 16.2.5 configuration are preserved.
