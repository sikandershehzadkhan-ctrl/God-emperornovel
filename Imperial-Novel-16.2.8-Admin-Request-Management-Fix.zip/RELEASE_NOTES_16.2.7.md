# Imperial Novel 16.2.7

Admin Dashboard release.

- Adds a real mobile-friendly `/admin` dashboard.
- Adds admin navigation for administrator accounts.
- Adds admin user listing and safe ban/unban controls.
- Adds taxonomy moderation controls.
- Adds donation review controls.
- Adds novel request monitoring.
- Adds report moderation controls.
- Adds manual automation-agent controls.
- Adds OmniPortal connector health and duplicate cleanup controls.
- Keeps administrator authorization enforced server-side.
- No setup secret is required.
