# Imperial Novel 16.2.1

Community Genres & Tags submission fix.

- Fixed the community taxonomy form so it explicitly reads and submits form fields on mobile browsers.
- Added client-side 2-80 character validation.
- Normalizes repeated whitespace before submission.
- Shows a friendly submission/error response.
- Keeps moderation and duplicate protection unchanged.
- Fixed server-side whitespace normalization in taxonomy submissions.

This release contains no content from third-party fiction platforms and does not bypass access controls.
