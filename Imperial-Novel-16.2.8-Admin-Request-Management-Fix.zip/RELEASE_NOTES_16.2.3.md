# Imperial Novel 16.2.3

- Fixed community taxonomy INSERT parameter binding.
- Community genre/tag submissions now correctly store name and slug.
- Pending/all taxonomy queries can now return submitted records.
- Version: 16.2.3
