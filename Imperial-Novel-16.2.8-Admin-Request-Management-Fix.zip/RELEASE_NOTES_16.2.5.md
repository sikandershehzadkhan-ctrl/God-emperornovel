# Imperial Novel 16.2.5

## Admin setup secret fix
- Removed the empty `SETUP_SECRET` environment variable from `wrangler.toml`.
- Cloudflare Secret `SETUP_SECRET` can now be used by the Worker without being shadowed by an empty variable.
- Retains the 16.2.4 admin promotion fix for promoting an existing account to `admin`.
