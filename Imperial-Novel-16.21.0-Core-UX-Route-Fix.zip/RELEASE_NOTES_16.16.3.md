# Imperial Novel 16.16.3

- Made OpenAI optional for the agent fleet.
- Added Cloudflare-native deterministic fallback logic for AI-ready agents.
- Omni Orchestrator now reports local specialist routing capability without requiring paid AI credits.
- OpenAI remains an optional enhancement when API credits are available.
- OpenAI 429/insufficient-quota and provider failures now fall back gracefully instead of surfacing an agent error.
- No API key is embedded in source, assets, or GitHub workflow.
