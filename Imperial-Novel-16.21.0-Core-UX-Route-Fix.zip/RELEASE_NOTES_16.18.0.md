# Imperial Novel 16.18.0

## OmniPortal Authorization Workflow
- Added a rights-first connector authorization request and review workflow.
- Connector rights evidence, terms/license URLs, notes, metadata permission, and attribution requirements are persisted.
- Connectors remain disabled until an authorization request is approved.
- Approval requires rights evidence, a terms/license URL, or documented rights notes.
- Rejected requests mark the connector rejected and keep it disabled.
- Approved connectors remain disabled until an administrator explicitly enables them.
- Added an administrator Authorization Review panel with approve/reject actions.
- Existing authorized-only search, health checks, and import protections remain enforced.
- Local Cloudflare agent fleet and Cron automation are preserved.
- OpenAI remains optional.
