# Imperial Novel 16.20.0
## Discovery & Community Upgrade
- Community hub with discovery shortcuts.
- Leaderboard with weekly, monthly and all-time views.
- Tier List discovery page using published catalog rating/activity data.
- Random Novel discovery endpoint and UI.
- Made For You recommendations with guest fallback and signed-in filtering.
- Vote Novels queue using one-vote-per-user request voting.
- Notifications page connected to the existing notification system.
- Mobile-friendly discovery components.
- Preserves the rights-first OmniPortal and existing author/admin systems.
- No third-party scraping or access-control bypass added.
