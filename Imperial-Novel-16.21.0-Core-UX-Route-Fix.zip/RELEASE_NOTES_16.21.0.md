# Imperial Novel 16.21.0 — Core UX & Route Fix

- Fixed server-side route mapping for Community, Leaderboard, Tier List, Random Novel, Made For You, Vote Novels, and Notifications so these pages receive the SPA shell instead of the static 404 page.
- Added dedicated `/trending` route backed by the existing catalog trending API.
- Added `/for-you` as an alias for Made For You.
- Preserved existing D1, OmniPortal, rights-first security, authentication, Author Studio, and admin workflows.
- Updated application version to 16.21.0.
