# Imperial Novel 16.19.0
## AI Author Studio
- Adds Manual, Hybrid and Automatic project modes.
- Adds story-bible/worldbuilding generation with a local zero-cost fallback.
- Adds chapter-generation jobs and continuity-oriented project state.
- If `OPENAI_API_KEY` is configured, the same author workflow can use the configured Responses API model; otherwise it stays local.
- Generated chapters are saved as drafts to a linked owned novel when rights are eligible.
- Adds throughput benchmark storage for public/authorized metadata observations. It does not scrape protected sources or bypass access controls.
- Adds D1 tables for AI projects, jobs, generation runs, provider benchmarks and publishing policy.
