# Imperial Novel 12.0

Responsive Imperial Novel web-novel platform for Cloudflare Workers + D1. This release refines the interface around the approved Imperial character-sheet aesthetic: black, cosmic violet, snow-white, silver and imperial gold.

## UI
- Imperial Novel / Imperial NovelVerse public branding.
- Desktop three-zone layout: Imperial Hall navigation, catalog/content, discovery rail.
- Character artwork integrated into the hero section.
- WTR-Lab-inspired catalog organization without copying its code or visual assets.
- Mobile-first two-column novel cards, dedicated search, touch controls and fixed bottom navigation.
- Mobile navigation: Home, Catalog, Library, OmniPortal, Account.
- Existing authentication, library, requests, tickets, reader, OmniPortal, agent fleet and admin APIs preserved.

## Deployment
GitHub → Cloudflare Workers Builds. Recommended build command:
`unzip -o God-Emperor-Novel-12.0-Imperial-UI.zip`
Deploy command:
`npx wrangler deploy`

The Worker target is `imperial-novel`, using the existing D1 database `god-emperornovel-db`.

## Rights
Only publish or connect content that you own or are authorized to use. OmniPortal does not bypass authentication, paywalls, CAPTCHAs, robots controls or other access controls.


## Imperial Novel 12.0
Full reading-platform experience layer with improved search, reader preferences, rights-aware source presentation, accessibility, responsive controls, and production-safe preservation of the existing D1/auth/catalog systems.

Legal design: the platform is intended for original, licensed, or otherwise authorized content and integrations. It does not bypass paywalls, CAPTCHAs, DRM, authentication, or other access controls.


## 16.3.6 Legal Publishing
The admin dashboard includes a Legal Publishing workflow. Public catalog/novel/reader endpoints expose published works only. New works begin as drafts and publication requires an eligible rights status; non-original/public-domain/licensed/authorized works require rights evidence.


## 16.16.1 security note
16.16.1 uses a one-time first-install oldest-account admin bootstrap only when no administrator exists, then permanently disables that bootstrap path.


## 16.19.0 AI Author Studio
Open `/author` as an author/admin to use Manual, Hybrid or Automatic AI writing projects. The local engine works without a paid AI key. Optional model use is controlled by `OPENAI_API_KEY` and `OPENAI_MODEL`. External provider throughput is recorded only from public/authorized observations; protected-source scraping or access bypass is not part of this build.
