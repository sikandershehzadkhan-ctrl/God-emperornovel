# Imperial Novel 16.61.0 — Visible Mobile Catalog Update

## User-visible changes
- Known launch-catalog titles prefer their bundled local cover art, even when an older external cover URL is stored.
- If a cover image fails to load, catalog cards fall back to the bundled character artwork instead of leaving a broken image.
- On mobile, the home page's single trending result becomes a compact horizontal featured-story card instead of a very tall poster that dominates the screen.
- Multi-story home catalog cards have tighter mobile typography and spacing.
- Subtle image hover treatment is disabled when reduced motion is requested.

## Preserved
- Existing Cloudflare Worker application architecture and API routes.
- Existing D1 migration files; no database migration is added.
- Existing user-supplied cover URLs for titles outside the known launch catalog.

## Validation limits
Syntax/build checks validate the packaged source only. They do not confirm a Cloudflare deployment or live database compatibility. Verify the production Worker name and D1 database binding before deploying.
