# Imperial Novel 16.63.0 — Premium Purple / Cyan / Black Palette

## Brand palette
- Primary: premium imperial purple.
- Accent: luminous cyan / turquoise.
- Foundation: pure black, obsidian, and near-black surfaces.
- Light mode retains bright neutral surfaces with purple and cyan accents.
- Dark mode uses black/obsidian surfaces, purple gradients, and restrained cyan highlights.
- Removes gold and unrelated accent colors from the theme token system and relevant dark-theme overrides.

## Preserved
- Existing Worker architecture and API routes.
- Existing D1 migration files; no schema changes.
- Light/dark theme toggle from 16.62.0.

## Validation
- Run npm run build to check Worker and frontend JavaScript syntax.
- No live deployment is performed by building this archive.
