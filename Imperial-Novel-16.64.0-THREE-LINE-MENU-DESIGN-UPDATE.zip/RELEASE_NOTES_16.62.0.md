# Imperial Novel 16.62.0 — Light and Dark Modes

## User-visible changes
- Adds an accessible Light/Dark toggle to the site header.
- Supports Light and Dark modes across the shell, navigation, panels, catalog cards, form controls, and reader surfaces.
- Dark mode uses an obsidian / midnight-purple palette with restrained violet accents.
- Selected theme persists in localStorage across page navigation and reloads.
- New sessions default to Dark mode; users can switch to Light mode at any time.
- The theme is applied before page rendering to reduce a flash of the wrong theme.

## Compatibility
- Existing Worker/API routes and D1 migration files are preserved.
- No database migration is required; preference is local to this browser/device.

## Validation limits
- `npm run build` checks JavaScript syntax.
- This package does not prove deployment. Verify the production Worker and D1 binding before deploying.
