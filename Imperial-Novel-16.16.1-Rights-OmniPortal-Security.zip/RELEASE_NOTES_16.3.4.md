# Imperial Novel 16.3.4

## Catalog + Reader Experience

- Reworked the Catalog page into a real discovery interface.
- Added search, discovery filters, status filters, genre/tag entry points, result metadata, and page navigation.
- Added richer catalog cards with status, rating, chapter count, genres, and direct Read action.
- Reworked the Reader page with a dedicated reading layout, sticky reader bar, progress indicator, chapter navigation, font controls, and a cleaner locked-chapter experience.
- Locked chapters clearly explain that the authorized unlock is for the reader's account and provide ticket access.
- Preserved the existing 16.3.3 backend, authentication, admin, tickets, requests, taxonomy, history, bookmarks, and rights-aware connector behavior.
- No WTR-Lab branding or assets are included.
