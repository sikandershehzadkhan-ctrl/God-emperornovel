# Imperial Novel 16.3.6

## Legal Publishing + Reader Foundation
- Added protected admin Legal Publishing workflow.
- Added draft/review/published/archived publication status.
- Added rights evidence, notes and verification metadata.
- Public catalog and novel APIs expose only published works.
- Added admin creation of authorized novel drafts and chapters.
- Added explicit rights review before publication.
- Preserved authentication, tickets, catalog, reader, history, library, requests, agents and connector protections.
- No unauthorized scraping, copying, paywall/CAPTCHA/access-control bypassing, or third-party branding.
