# Imperial Novel 16.3.3

Mobile-first UI polish release based on 16.3.2.

- Uses a clean hero crop without the character specification-card clutter.
- Keeps Imperial Novel branding and the existing backend/admin functionality intact.
- Adds compact quick-access cards for Trending, Library, Community Unlock, and OmniPortal.
- Adds a Community Unlock information banner with rights-aware wording.
- Improves mobile hero spacing and readability.
- No WTR-Lab branding or assets intentionally included.
