# Imperial Novel 16.4.0

## Chapter Creation Repair

- Fixed the Admin Publishing Create Chapter form handler.
- Replaced the broken `$()` dependency with native DOM APIs.
- Chapter creation now prevents accidental navigation/submission away from Admin Publishing.
- Added a visible `Creating chapter…` state while saving.
- The form now waits for Publishing and Overview refreshes after a successful chapter save.
- The created chapter ID is shown when returned by the API.
- Errors remain visible in the chapter form instead of silently redirecting.
- Preserves free/ticket-locked chapter selection and ticket cost.
- No unauthorized content-import behavior was added.
