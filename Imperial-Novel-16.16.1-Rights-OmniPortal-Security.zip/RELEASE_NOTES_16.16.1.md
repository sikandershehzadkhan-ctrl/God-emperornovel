# Imperial Novel 16.16.1

## Rights & OmniPortal Security

- Adds rights/provenance records and rights audit logging.
- Keeps OmniPortal connector authorization boundaries.
- First-install administrator bootstrap: when no administrator exists and the bootstrap has never run, the oldest existing account is promoted to `admin` and verified.
- A permanent `first_admin_bootstrap_done` marker prevents repeat promotion.
- Existing application data and role permissions are preserved.
