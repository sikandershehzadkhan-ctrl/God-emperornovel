# Imperial Novel 16.3.2

## Mobile UI Polish
- Reduced mobile hero height and visual dominance.
- Improved hero readability with a stronger lower-page contrast overlay.
- Restored compact Imperial Novel brand text in the mobile header.
- Kept search and account actions accessible on mobile.
- Preserved bottom mobile navigation.
- Preserved the 16.2.8 backend/admin/request-management functionality from the combined package.
- No WTR-Lab branding or assets are intentionally included.

## Rights & Safety
- No paywall, CAPTCHA, robots, or access-control bypass is introduced.
- External provider entries remain registry-only unless authorized.
