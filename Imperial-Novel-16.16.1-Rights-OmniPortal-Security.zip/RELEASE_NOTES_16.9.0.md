# Imperial Novel 16.9.0

## Reader Account & Library
- Added persistent account-synced My Library storage.
- Added Add to Library / Remove from Library controls on novel pages.
- Added Continue Reading using saved reading history.
- Added account-synced bookmarked chapter list.
- Added library, history, and following navigation tabs.
- Preserved existing follow, rating, comment, ticket and reader systems.
- No new D1 migration is required; the library table is created safely by the worker schema bootstrap.
