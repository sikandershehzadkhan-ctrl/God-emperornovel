# Imperial Novel 16.8.0

Reader & Chapter Experience update built from the confirmed 16.7.0 baseline.

- Added reader chapter drawer/table of contents.
- Added chapter bookmark control for signed-in readers, with local fallback for guests.
- Added scroll-based chapter reading progress.
- Preserved server history tracking, unlock flow, previous/next navigation, and font controls.
- Added reader content whitespace preservation for authored chapter text.
- No new database migration required.
- Existing admin publishing, editing, preview, reorder, statistics and deletion features are preserved.
