# Imperial Novel 16.15.0

## Comments, Ratings & Community
- Novel 1-5 star ratings with per-user rating and aggregate statistics.
- Reader comments with login-protected posting.
- Comment replies with parent-child threading.
- Comment likes with toggle behavior.
- Comment reporting for moderation review.
- Admin comment moderation endpoint with visible/hidden/deleted states.
- Admin comment-report queue endpoint.
- Community UI added to novel pages and optimized for mobile.
- Preserves all 16.14.1 catalog/discovery and prior author/reader/admin features.

## Rights & Safety
Community tools do not grant rights to publish third-party content. Existing rights-status controls remain authoritative.
