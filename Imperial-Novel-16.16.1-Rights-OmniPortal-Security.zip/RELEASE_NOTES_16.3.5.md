# Imperial Novel 16.3.5

## Catalog Polish + Rights-Safe First-Novel Experience

- Fixed mobile Catalog title spacing so the page heading is no longer hidden beneath the sticky header.
- Reworked the zero-novel catalog state into a useful first-library experience.
- Added Browse Genres, Browse Tags, and Rights & Copyright actions.
- Added clear rights-safe wording: original, public-domain, properly licensed, or otherwise authorized works only.
- Added an explicit notice that unauthorized copying/importing is not supported.
- Preserved the existing catalog API, filters, pagination, admin/auth, tickets, requests, reader, and rights-aware connector architecture.
- No third-party branding, logos, copied UI assets, paywall bypassing, CAPTCHA bypassing, or unauthorized scraping/importing added.
- Updated catalog cache-busting to app.js?v=16.3.5.
