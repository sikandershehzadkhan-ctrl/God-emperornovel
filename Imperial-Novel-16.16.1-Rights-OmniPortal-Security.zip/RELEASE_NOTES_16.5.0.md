# Imperial Novel 16.5.0

## Chapter Management Upgrade
- Added authenticated admin chapter listing by novel.
- Added safe chapter editing with duplicate-number protection.
- Added permanent chapter deletion with dependent unlock/report cleanup.
- Added mobile-friendly Chapter Management controls to the Admin Publishing page.
- Preserved the 16.4.0 Chapter Creation repair and deployment configuration.
- Bumped APP_VERSION to 16.5.0.
