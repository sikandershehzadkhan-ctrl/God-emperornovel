# Imperial Novel 16.6.0

## Chapter Preview & Navigation
- Added mobile-friendly chapter preview from Chapter Management.
- Added Previous / Next chapter navigation inside the editor.
- Preview shows chapter title, lock state, ticket cost, and ID.
- Keeps existing 16.5.2 edit/save/delete protections intact.
- Built for the Vivo S1 mobile workflow.
