# Imperial Novel 16.13.0

## Author Review Decisions
- Added admin review feedback for author submissions.
- Added Request Changes workflow that returns a novel to draft.
- Authors can see admin feedback in Author Studio and resubmit after revisions.
- Added review timestamps and reviewer tracking.
- Authors receive notifications when a novel is approved/published or changes are requested.
- Existing Chapter Studio, publishing, library, reader, rights and admin functions preserved.
