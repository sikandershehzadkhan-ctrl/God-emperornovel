# Imperial Novel 16.7.0

## Chapter Publishing & Navigation Management
- Added per-chapter Draft/Published status.
- Existing chapters remain published by default for compatibility.
- New chapters are created as Draft unless explicitly published by an administrator.
- Added protected Publish/Unpublish controls.
- Added safe adjacent chapter reordering with atomic temporary numbering.
- Reader APIs now expose only published chapters.
- Previous/Next navigation follows published chapter order.
- Added chapter view, unlock and report statistics.
- Added protected chapter view counting.
- Preserved the working 16.5.2 Edit workflow and 16.6.0 Preview workflow.
- Mobile-friendly admin controls retained.
