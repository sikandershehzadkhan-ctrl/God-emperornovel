Imperial Novel 16.5.1 Edit Fix

- Fixed Chapter Management Edit button appearance so it is visibly enabled.
- Added a mobile-friendly inline Chapter Editor instead of browser prompt dialogs.
- Added Save Changes and Cancel controls.
- Preserves chapter number, title, content, lock state, and ticket cost.
- Keeps admin authentication and existing PATCH endpoint protection.
- Refreshes chapter, publishing, and overview data after save.
