# Imperial Novel 16.16.0

## OmniPortal Rights-First Integration

- Upgraded OmniPortal to rights-first v2.0.
- Added connector rights evidence, terms URL, rights notes and attribution tracking.
- Metadata import is explicitly opt-in and remains disabled unless authorized.
- Full content import is hard-disabled in this release.
- Import requests are metadata-only and never copy source chapters.
- Added rights review ledger and source metadata tables.
- Added admin rights editing controls.
- Added legal-mode notice and metadata import request UI.
- No paywall, DRM, login or access-control bypass functionality.
