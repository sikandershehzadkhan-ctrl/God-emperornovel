# Imperial Novel 16.10.0

## Author Studio
- Added `/author` mobile-first Author Studio.
- Added author-owned novel dashboard, creation, and metadata editing.
- Added author-owned chapter API foundation with draft-only creation/editing.
- Admin accounts retain full author access; ordinary readers cannot access author endpoints.
- Publishing remains subject to the existing rights-review/admin workflow.
- Built from the confirmed working 16.9.0 baseline.
