# Imperial Novel 16.14.1

## Catalog Card Runtime Fix

- Fixed `catalogCard is not defined` on the Catalog page.
- Added a safe mobile-friendly `catalogCard()` renderer.
- Preserved catalog filters, sorting, pagination, genres, tags, search and existing reader/author/admin features.
- Updated application version to 16.14.1.
