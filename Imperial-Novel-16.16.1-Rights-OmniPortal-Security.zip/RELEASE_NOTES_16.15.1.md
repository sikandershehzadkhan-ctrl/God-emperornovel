# Imperial Novel 16.15.1

Repair release for the chapterRow runtime error.

- Restored the shared `chapterRow(ch, id)` renderer used by novel chapter previews and chapter archive pages.
- Preserved all 16.15.0 Comments, Ratings & Community features.
- No database migration required.
