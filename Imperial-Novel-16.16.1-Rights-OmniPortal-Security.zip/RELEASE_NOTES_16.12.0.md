# Imperial Novel 16.12.0

## Author Review & Publishing Workflow

- Authors can submit owned draft novels for admin publication review.
- Submission validates rights status and requires rights evidence for licensed, authorized, and public-domain works.
- Submitted novels move to `review` status and generate notifications for administrator accounts.
- Author Studio shows `Submit for Review` for drafts and an `Under Review` state for submitted novels.
- Existing admin publishing controls remain the authority for final publication decisions.
- Author chapter Preview now works for both drafts and published chapters. Drafts open in a safe preview page; published chapters use the correct chapter number route.
- Existing Author Studio, Chapter Studio, reader, library, tickets, rights checks, and admin controls preserved.
