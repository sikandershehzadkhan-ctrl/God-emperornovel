# Imperial Novel 16.12.1

## Author Studio Loading Fix

- Added a persistent D1 core-schema version marker so initialized production databases use a fast startup path.
- Removed redundant publishing-schema initialization from Author endpoints.
- Added a 20-second client timeout and clearer loading error for Author Studio.
- Preserved the 16.12.0 Author Review workflow and all previous Author/Reader/Admin features.
