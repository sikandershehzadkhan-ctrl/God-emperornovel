# Imperial Novel 16.11.0

- Added Author Chapter Studio.
- Authors can create, edit, preview, publish and unpublish their own chapters.
- Added duplicate chapter-number protection.
- Preserved existing 16.10.0 Author Studio and reader/admin workflows.
