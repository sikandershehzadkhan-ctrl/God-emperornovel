# Imperial Novel 16.14.0

## Platform Discovery & Catalog Expansion
- Expanded catalog filtering: status, type, language, minimum rating, genre, tag and author.
- Added catalog sorting for updated, newest, trending, views, rating and chapter count.
- Improved search UI with direct discovery shortcuts.
- Added public author profile pages at `/author/<slug>` with published works and basic statistics.
- Added `/api/public-authors` for public author discovery.
- Added author filtering to `/api/novels`.
- Published-chapter counts now drive catalog chapter sorting.
- Added mobile-friendly filter controls while preserving the existing reader, library, author and admin systems.
- Cache-busted the application to 16.14.0 and rotated the service-worker cache.

## Rights
Discovery only exposes published novels already permitted by the site's publication workflow. No protected third-party content is imported or copied by this release.
