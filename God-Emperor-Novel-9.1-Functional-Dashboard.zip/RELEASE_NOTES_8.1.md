# NovelVerse OmniPortal 8.1

- Corrected runtime APP_VERSION to 8.1.0.
- Corrected public footer version label.
- Preserves the 21-agent fleet and authorized-provider architecture from 8.0.
- Connector APIs remain rights-aware and require an authorized API/feed.
