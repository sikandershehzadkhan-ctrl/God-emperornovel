# NovelVerse OmniPortal 8.0

- Rebrands the platform to NovelVerse OmniPortal.
- Adds tagline: One Platform · Infinite Worlds · Your Stories.
- Adds Agent Nexus UI and 21-agent registry.
- Adds D1-backed agent registry and run history.
- Adds scheduled deterministic automation for provider health, notifications, catalog stewardship, duplicate review, security signals and analytics.
- AI-ready agents are explicitly marked as requiring an AI/provider capability before claiming full AI execution.
- Keeps provider access rights-aware: no paywall bypassing or unauthorized scraping.
- Adds WTR-Lab, FictionZone and TomatoMTL to the provider registry inherited from 7.0.
