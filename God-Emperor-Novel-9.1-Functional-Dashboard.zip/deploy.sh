#!/usr/bin/env bash
set -e
echo "1) Edit wrangler.toml and replace REPLACE_WITH_YOUR_D1_DATABASE_ID"
echo "2) Run: wrangler d1 create god-emperornovel-db"
echo "3) Run: wrangler d1 migrations apply god-emperornovel-db --remote"
echo "4) Run: wrangler secret put SETUP_SECRET"
echo "5) Run: wrangler deploy"
