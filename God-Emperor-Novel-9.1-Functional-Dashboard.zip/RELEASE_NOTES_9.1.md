# God-Emperor Novel 9.1

Functional dashboard and administration upgrade on the 9.0 foundation.

- Personal user dashboard with library/request quick actions.
- Functional OmniPortal connector administration.
- Provider health checks.
- Duplicate provider cleanup with one canonical record per base URL.
- Rights-aware connector enablement.
- Agent fleet admin view.
- Mobile-first controls for phone deployment and use.

Live provider search/import still requires an authorized API/feed and valid credentials. The platform does not bypass access controls or licenses.
