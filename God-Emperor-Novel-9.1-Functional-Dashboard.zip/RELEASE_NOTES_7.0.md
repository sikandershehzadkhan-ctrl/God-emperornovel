# God-Emperor Novel 7.0

## Provider Registry Expansion
- Added WTR-Lab (wtr-lab.com)
- Added FictionZone (fictionzone.net)
- Added TomatoMTL (tomatomtl.com)
- Existing 17 requested source entries remain supported.
- Provider registry now exposes connection requirements in the UI.
- Registry entries are not represented as live connectors until an authorized API/feed is configured.

## Safety / accuracy
The platform does not claim unrestricted scraping or bypass access controls. Live federated search requires an authorized provider connector.
