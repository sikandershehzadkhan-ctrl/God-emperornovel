# God-Emperor Novel 6.1

## Critical fixes
- Fixed a JavaScript syntax error in the genre renderer that prevented the entire frontend script from executing.
- Sign in, registration, catalog, library, request, Tickets, OmniPortal, novel cards, reader, and account buttons can now execute normally.
- Made the top navigation horizontally scrollable on narrow mobile screens instead of overflowing the viewport.
- Made startup use `Promise.allSettled()` so one optional API failure cannot prevent the rest of the UI from initializing.
- Updated the visible footer version to 6.1.

## Important content note
The D1 catalog is a real database and is intentionally not populated with invented novels. Actual novels must be added through authorized content/import workflows. OmniPortal also requires an authorized connector/API before it can search an external provider.
