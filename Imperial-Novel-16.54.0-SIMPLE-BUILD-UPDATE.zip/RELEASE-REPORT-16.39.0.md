# Imperial Novel 16.39.0 — Atomic tickets and Trend Factory source milestone

## Status

**Not ready for deployment yet.** This milestone closes several source-level correctness and safety gaps, but dependency-backed typecheck/build and real Cloudflare staging authentication/payment checks remain unverified. No GitHub push, Cloudflare deployment, remote migration, or production database operation was performed.

## Implemented in source

### Atomic database operations
- Added a shared `Sql.batch()` API with native transactions for Neon/Postgres and PGLite, and native `D1Database.batch()` for request-bound Cloudflare D1.
- D1 refuses a sequential-write fallback when its native batch API is unavailable.
- EasyPaisa donation review now groups the pending-to-processing transition, profile ticket credit, ticket ledger entry, notification, audit entry, and final approved/rejected status in one transaction. A repeated approval does not credit twice.
- Chapter unlocks now use database triggers to debit tickets and add the ticket ledger row as part of the unlock insert transaction. The trigger aborts on insufficient balance, missing profile, negative cost, or fractional cost. Batch unlocks use one transaction so a failure rolls back the entire batch.
- Manual PKR donation submissions require a whole-number amount between PKR 1 and PKR 1,000,000 and a 4–120 character reference. Author chapter costs are bounded whole numbers.
- Novel publication requires an allowed rights status and at least eight non-whitespace characters of rights evidence at the actual update statement, not only in a separate pre-check.

### Trend Factory
- Added a dedicated `/trend-factory` route, persisted D1 and Postgres/PGLite schema migrations, an admin-only service, and ordered workflow policy tests.
- Workflow: Trend → Analyze → Discover Author → Prepare Invitation → Rights Review → Editorial Review → Link Existing Novel → Published Record.
- Candidate source URLs are metadata only. This feature does not fetch external catalogs, copy chapter text, or send invitations. The linked novel must independently pass Imperial Novel rights and publication review before the workflow record can be marked published.
- Terminal published/rejected records cannot be advanced again.

### Administrator provisioning
- The first account is never promoted based on signup order.
- Initial staging admin setup supports an exact verified Better Auth email (`STAGING_BOOTSTRAP_ADMIN_EMAIL`) or an exact configured user ID. Email lookup errors fail closed. Remove the temporary setting after the admin profile is created and verified.

### Connector honesty
- OmniPortal now explicitly says external provider search/fetching is inactive in this source build. It searches the local Imperial Novel catalog and records metadata-only import requests; it does not claim live external provider execution.
- AI Author Studio remains unavailable without a configured server-side model key. Monetag is not configured or activated in this milestone.

## Verification evidence

| Check | Result | Evidence / limitation |
|---|---|---|
| JavaScript script tests | PASS | 234 passed, 0 failed |
| D1 auth schema tests | PASS | 6 passed, 0 failed |
| Selected source/runtime tests | PASS | 38 passed, 0 failed across the selected files; dependency-heavy identity test omitted because `jose` is not installed |
| D1 adapter tests | PASS | 10 passed, including trigger debit/ledger, insufficient balance, metadata workflow constraints, and atomic rollback |
| Trend Factory policy tests | PASS | Ordered transitions, terminal states, and evidence policy passed |
| Staging config + read-only release-gate tests | PASS | 9 passed, 0 failed |
| Cloudflare source readiness | PASS | 15/15 source checks passed; the command intentionally exits blocked for external prerequisites |
| TypeScript syntax transpilation | PASS | 22 modified TS/TSX files, 0 syntax errors; syntax transpilation is not a typecheck |
| Full `npm test` | NOT VERIFIED | Project dependency installation is unavailable; a direct identity test fails to load missing package `jose` |
| `npm run typecheck` | BLOCKED | Missing `@types/node` and `vite/client` because `node_modules` is absent |
| `npm run build:cloudflare` | NOT VERIFIED | Build dependencies are not installed; no generated Worker smoke test was possible |
| Better Auth + D1 lifecycle | NOT VERIFIED | Requires a real isolated staging Worker/D1 and configured auth/OAuth secrets |
| External connectors / invitation delivery | NOT IMPLEMENTED | Explicitly disabled/not claimed as live; no source crawling or chapter ingestion |
| AI provider / Monetag | NOT CONFIGURED | No provider key or Monetag publisher configuration was supplied; neither is activated |
| Production Worker and D1 | UNCHANGED | No remote production operation was performed |

## External requirements before staging can run

1. Create a separate Cloudflare D1 database for `imperial-novel-staging` and provide its real database UUID to the staging workflow. Never use `god-emperornovel-db`.
2. Configure GitHub Actions secrets/variables for the Cloudflare staging account/token, staging URL, Better Auth secret, and Grok auth client credentials. Optionally set `STAGING_BOOTSTRAP_ADMIN_EMAIL` to the exact verified staging admin email before their Imperial profile is first created.
3. Run the workflow in a network-enabled environment so it refreshes and verifies npm lock metadata, installs dependencies, runs the complete test suite, passes typecheck, builds the Cloudflare Worker, applies only `migrations/d1/`, and deploys only to staging.
4. Test sign-up/sign-in/session persistence/sign-out, admin provisioning, donation approval/rejection, duplicate approval, single and batch unlocks, low-balance rollback, rights review, route authorization, and mobile/desktop smoke tests.
5. Record rollback evidence before considering production deployment. Production deployment remains a separate explicit approval step.

## Release decision

This ZIP is an intermediate source milestone. It is safer and more complete than the previous audit package, but it must **not** be deployed to the live Worker yet. The source-level release gate is green; external staging prerequisites and dependency-backed verification are not.
