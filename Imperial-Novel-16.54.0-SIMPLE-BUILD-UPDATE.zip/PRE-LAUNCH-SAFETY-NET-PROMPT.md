# Imperial Novel — Release Safety-Net Prompt

Use this prompt whenever an AI coding agent proposes an update to the existing Imperial Novel project:

> Continue the existing Imperial Novel codebase. Do not create a replacement app, redesign unrelated working areas, or claim remote changes that you did not perform. Preserve existing user data, authentication, admin permissions, ticket balances, donation references, author ownership, rights checks and production configuration. Never deploy to the production Worker `god-emperornovel` or modify production D1 `god-emperornovel-db` without explicit release approval.
>
> Before changing code, inspect the current source and migrations. Keep secrets server-side, fail closed on missing credentials, do not invent user counts, reviews, testimonials, payments, provider integrations or test results. Do not ingest protected chapter text without permission. Keep Monetag as the only third-party ad network if ads are later enabled, and never enable it before consent and provider setup are verified.
>
> For each change, add focused tests, run the relevant existing tests, run `npm test`, `npm run typecheck`, `npm run lint`, `npm run build:cloudflare`, and `npm run audit:prelaunch` whenever dependencies are available. If a command cannot run, report the exact blocker and do not mark the gate passed. Build and test against a separate staging D1 and staging Worker. Test authorization, failure handling, concurrent ticket/donation operations, mobile layout, keyboard access, SEO metadata and rollback. Never weaken a guardrail to make CI green.
>
> Finish with a truthful release report separating source changes, tests actually passed, checks blocked, external setup still required, and whether any remote resources changed. A ZIP file or source-level test pass alone is not production readiness.
