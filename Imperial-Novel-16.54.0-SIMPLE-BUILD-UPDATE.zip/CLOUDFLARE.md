# Imperial Novel 16.32.2 — Cloudflare staging notes

The live Worker `god-emperornovel` and the live D1 database `god-emperornovel-db` are out of scope. Nothing in this repository deploys to them.

## What runs where

| Target | Database | How it starts |
| --- | --- | --- |
| Local preview and the current Vercel app | Postgres via `DATABASE_URL`, or PGLite when that variable is empty | Default `npm run build` / `npm run dev` |
| Future staging Worker | D1 binding `DB` on a new database | Not deployed from this environment |

The staging Worker config sets `IMPERIAL_DB=d1` and `IMPERIAL_RUNTIME=cloudflare`. With those set, the database backend selector refuses an implicit PGLite fallback. `server/middleware/imperial-d1.ts` binds the D1 handle to the Fetch Request from `event.web.request` (or `event.req.original`), and `src/lib/db/d1-request.ts` resolves the current TanStack Start request before each query. This avoids a process-global mutable database handle. Missing bindings or request context fail closed. The request-isolation path is covered by tests but has not been verified in a generated Worker. **Status note:** this opening overview reflects the original 16.32.x migration stage; version 16.37.0 adds the D1/Drizzle Better Auth adapter source, but full build and staging authentication tests remain outstanding. Do not deploy until the current release gate and lifecycle checks pass.

## Environment

Local and Vercel:

- `DATABASE_URL` — Postgres connection string. Never a D1 URL.
- `XAI_API_KEY` — optional, server only. AI stays unavailable when it is absent.
- Better Auth secrets are injected by the existing auth setup. Do not commit them.

Staging Worker, only after a new database exists:

- Worker name: `imperial-novel-staging`
- D1 binding: `DB`
- Database name: `imperial-novel-staging`
- `database_id`: replace `REPLACE_WITH_STAGING_D1_ID` in `wrangler.jsonc` with the id of that new database
- `IMPERIAL_DB=d1`
- `IMPERIAL_RUNTIME=cloudflare`

Do not reuse `god-emperornovel-db` as the staging binding.

## Local SQLite check

This is not a D1 connection. It applies `migrations/d1` to a file you choose:

`IMPERIAL_D1_FILE=./.data/staging.sqlite node --experimental-strip-types scripts/d1-migrate.mjs`

The script exits if asked to use the production names or a remote database. It does not run during `npm run build`.

## Request binding boundary

`server/middleware/imperial-d1.ts` attaches the D1 handle to the exact Fetch Request using a `WeakMap`; `src/lib/db/d1-request.ts` resolves the current request through TanStack Start. The `AsyncLocalStorage` path remains for isolated adapter tests. Tests cover missing bindings, request binding, and request isolation. This is request-binding groundwork only, not proof of Cloudflare runtime compatibility.

## Authentication boundary

Better Auth in this app is constructed with the `pg` pool or the PGLite Kysely dialect. `src/lib/auth/server.ts` throws if `IMPERIAL_DB=d1` or `IMPERIAL_RUNTIME=cloudflare`, so a Worker cannot silently start with an empty session store. Account migration from the live Worker is a separate phase. Do not match users by email until that phase exists. Passwords and sessions have not been copied.

## Nitro target

Installed Nitro `3.0.260610-beta` provides the `cloudflare-module` preset (Cloudflare Workers module format). The default Vite build keeps `preset: "vercel"`. A Cloudflare build is separate:

`IMPERIAL_RUNTIME=cloudflare IMPERIAL_DB=d1 npm run build:cloudflare`

That build is not a production deploy. `wrangler deploy` is not part of it.

## Rollback

The Vercel/PGLite path is unchanged when `IMPERIAL_RUNTIME` is unset. To leave the staging attempt, do not publish the Worker and do not point DNS at it. The existing public Worker URL keeps serving the current site.

## Authentication route isolation — 16.35.0 (historical)

At 16.35.0, the `/api/auth/*` route returned a structured, non-cacheable HTTP 503 on Cloudflare. Version 16.37.0 supersedes that source design with a separately loaded D1/Drizzle adapter and a build-time alias for the Node/PGLite module. The new path is still unverified in a generated Worker and staging auth lifecycle; missing settings continue to return 503.

## Read-only release gate — 16.36.1

Run `npm run check:cloudflare-readiness` before attempting any Cloudflare staging work. This script reads local source/config only; it does not contact Cloudflare, access D1, or deploy. A non-zero exit is intentional while prerequisites remain unresolved. At 16.37.0, the source adapter is wired, but the placeholder staging database ID and missing npm integrity hash are release blockers. Full build and live auth lifecycle tests remain mandatory. Do not remove the auth guard to obtain a green result.


### Release-gate correction — 16.36.1
The readiness gate uses whitespace-tolerant matching for the staging `database_id` and `database_name` fields. A regression test runs the command against the checked-in staging config and confirms that the placeholder D1 ID is reported as blocked.


## D1 auth schema verification — 16.36.2

The staging auth SQL migration now has an executable SQLite test suite: `npm run test:d1-schema`. It checks that the migration executes, core Better Auth columns exist, email and session tokens are unique, deleting a user cascades to sessions, and reapplying the idempotent migration does not error. This is a local SQLite schema test, not a Cloudflare D1 integration test and not evidence that Better Auth can use this schema. The auth route must remain fail-closed until a supported persistent D1 adapter is implemented and tested.


## D1 auth schema hardening — 16.36.3

The local SQLite schema suite now checks the three lookup indexes, account-to-user foreign-key enforcement, and `PRAGMA foreign_key_check` after valid fixture inserts. These tests validate the migration's SQLite behavior only; they do not prove Better Auth's runtime adapter compatibility. Keep `/api/auth/*` fail-closed on Cloudflare until a supported persistent adapter is implemented and verified.

## Experimental D1 Kysely bridge (16.36.4)

`src/lib/db/d1-kysely-dialect.ts` is an isolated prototype for translating Kysely
SQLite queries onto a request-provided D1 binding. It is **not** the Better Auth
adapter and is intentionally not imported by the auth route. Its transaction
methods throw rather than simulate `BEGIN`/`COMMIT`: Cloudflare D1 provides
atomic `batch()` operations, not a normal interactive SQLite connection. Do not
enable sign-up, OAuth callbacks, account linking, or session writes through this
prototype. Before integration, implement or select a supported adapter with
correct D1 batch/transaction semantics and test the complete auth lifecycle on a
separate staging D1 database.

## 16.36.5 auth-route isolation

The `/api/auth/*` route delegates to `src/lib/auth/route-handler.ts`. The handler evaluates the Cloudflare runtime guard before invoking its injected lazy loader for `src/lib/auth/server.ts`. This is covered by executable tests: Cloudflare requests return a non-cacheable 503 without invoking the loader, while non-Cloudflare requests still invoke the configured auth handler. This protects runtime execution but does not prove the bundler omits every Node-only dependency from the Cloudflare artifact. A complete build and staged runtime test are still required.


## D1 schema drift guard — 16.36.6

`npm run check:d1-auth-schema-parity` compares the four core Better Auth tables in `migrations/d1/0001_auth.sql` with the canonical schema in `migrations/auth/0001_auth.sql` using in-memory SQLite. It checks exact column-name parity for `user`, `session`, `account`, and `verification`. This catches accidental schema drift before an adapter is connected. It does not compare PostgreSQL and SQLite type semantics, prove Better Auth adapter compatibility, or replace staging integration tests.

## D1 Better Auth integration source — 16.37.1 (verification pending)

The Cloudflare auth path now has a separate factory in `src/lib/auth/cloudflare.server.ts`, backed by `better-auth/adapters/drizzle` and `drizzle-orm/d1`, with the explicit schema in `src/lib/auth/d1-schema.ts`. The `/api/auth/*` route selects this module only when the request/runtime identifies Cloudflare and the D1 binding plus required auth settings exist. Missing configuration and initialization errors return a non-cacheable 503; the handler never falls back to PGLite or an in-memory identity.

`npm run build:cloudflare` explicitly enables the client sign-in UI for that build only. `vite.config.ts` aliases `@/lib/auth/server` to `cloudflare-node-auth-disabled.server.ts` for Cloudflare builds, so the Node/PGLite auth server should not be part of the Worker module graph. This is a source/configuration guard and still needs confirmation in a successful generated Worker artifact.

Required Cloudflare settings are `BETTER_AUTH_URL` (the exact HTTPS origin), `BETTER_AUTH_SECRET` (at least 32 characters), `GROK_AUTH_CLIENT_ID`, and `GROK_AUTH_CLIENT_SECRET`. `GROK_AUTH_ISSUER` defaults to `https://auth.grok.me`. Configure secrets with Wrangler secret commands; do not commit values into `wrangler.jsonc` or the repository. Do not set `VITE_AUTH_ENABLED=false` if you intend to test real sign-in.

### Remaining release blockers

1. The `drizzle-orm@0.45.2` package entry is pinned but its npm SRI integrity value could not be fetched because registry DNS/network access failed in this environment. Run a successful online `npm install` to regenerate and verify `package-lock.json` before relying on this lockfile for a release.
2. `wrangler.jsonc` still contains `REPLACE_WITH_STAGING_D1_ID`. Create a separate `imperial-novel-staging` D1 database, set its real ID locally, and apply `migrations/d1/0001_auth.sql` to that staging database only.
3. After dependencies and staging configuration are available, run the full typecheck, `npm run build:cloudflare`, inspect the generated Worker bundle for absence of the Node/PGLite auth server, then test OAuth start/callback, user/account persistence, session creation/read/expiry/revocation, sign-out, and request isolation against staging. Keep the production Worker and database untouched until those tests pass.

This version has not been deployed. The adapter source is integrated, but it is not yet certified production-ready because the dependency lock, full build, and live staging auth lifecycle remain unverified.

### Source readiness versus release prerequisites

`npm run check:cloudflare-readiness` reports static source/configuration checks separately from external release prerequisites. A staging D1 placeholder is acceptable in checked-in source because a real ID must come from the Cloudflare account owner; never fabricate it or substitute the production database. The Drizzle source check validates that the exact dependency version and resolved tarball URL agree across the manifest and lockfile. The lockfile integrity hash must still be regenerated/verified with npm registry access before release. A result of 8/8 source checks does not mean the Worker is deployable: the command exits non-zero while the external D1 ID or lockfile integrity is missing.


## Atomic tickets and Trend Factory — 16.39.0 source milestone

- Cloudflare D1 migrations are in `migrations/d1/`; the generated staging Wrangler config sets `migrations_dir` to that folder. Never point it at the Postgres migrations in the root folder.
- D1 migration `0003_ticket_unlock_atomic.sql` ties ticket debit and ledger insertion to the unlock insert. The Postgres/PGLite equivalent is root migration `0005_ticket_unlock_atomic.sql`.
- D1 migration `0004_trend_factory.sql` creates the admin-only Trend Factory pipeline. The Postgres/PGLite equivalent is root migration `0006_trend_factory.sql`. It stores metadata only, not chapter bodies.
- Donation approval uses the shared atomic batch API and an in-transaction `pending → processing → approved/rejected` transition.
- Staging can bootstrap the initial admin using the optional GitHub Actions variable `STAGING_BOOTSTRAP_ADMIN_EMAIL`, which must match the verified Better Auth email before the Imperial profile is first created. Remove the variable after verifying the role.
- These source changes still require dependency installation, typecheck, Cloudflare build, and real staging authentication/payment/reader tests before deployment is approved. Production is excluded.
