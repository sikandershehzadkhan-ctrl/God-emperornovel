# Imperial Novel 16.40.0 — Release-gate hardening

## Decision

**Not production-ready yet. Do not deploy to the production Worker.** This milestone improves the staging release gate so it cannot silently report success when staging credentials are missing. It does not claim that the Cloudflare Worker has been built or deployed.

## Changes

- The GitHub Actions staging step is limited to a push or manual dispatch on `main`.
- Missing Cloudflare account/token, staging D1 ID, staging base URL, Better Auth secret, or Grok OAuth credentials now fail the staging release step instead of exiting successfully with a notice.
- After deployment and setting secrets, the workflow checks that the staging homepage responds successfully and that `/api/auth/get-session` returns HTTP 200.
- Added four workflow-contract tests for the deploy branch restriction, missing-secret fail-closed behavior, post-deploy smoke checks, and production-target exclusion.
- Preserved staging-only Worker and D1 naming. No production Worker, production D1 database, GitHub repository, or Cloudflare account was accessed or changed in this work.

## Verification

| Check | Result |
|---|---|
| Existing JavaScript script tests | 234 passed before this change |
| New workflow contract tests | 4 passed |
| D1 auth schema tests | 6 passed |
| Selected D1 adapter, context, middleware, bootstrap, and Trend Factory tests | 26 passed |
| Source readiness | 15/15 source checks pass; 2 external release prerequisites remain |
| `npm ci --ignore-scripts --no-audit --no-fund --prefer-online` | Timed out after 120 seconds; no `node_modules` was created |
| Full dependency-backed test suite | Blocked by unavailable package registry/dependencies |
| TypeScript typecheck | Not run successfully; required dependencies are absent |
| Cloudflare Worker build | Not verified |
| Cloudflare staging deployment and HTTP smoke test | Not performed; no Cloudflare credentials or staging database ID are available here |

## Required before production

1. Use registry access in GitHub Actions to refresh/verify the package lock and install dependencies.
2. Supply a real, separately created staging D1 database UUID and the required staging secrets/variables in GitHub Actions. Never use `god-emperornovel-db` for staging.
3. Run the workflow on `main`; require the full test suite, typecheck, Cloudflare build, deployment, and HTTP smoke checks to pass.
4. Perform authenticated staging tests for sign-up/sign-in, session persistence/sign-out, administrator bootstrap, donation approval/rejection and duplicate approval, ticket balance and single/batch unlock rollback, publication rights evidence, and protected routes.
5. Check mobile/desktop performance and logs, then document backup and rollback procedures.
6. Obtain separate explicit approval before any production migration or deployment.

## Release boundary

The source release gate is hardened, but a source ZIP cannot substitute for a generated Worker build and real staging verification. This package is an intermediate release candidate, not a production-ready release.
