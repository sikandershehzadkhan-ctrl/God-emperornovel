# Imperial Novel 16.46.0 — Production Pre-Launch Checklist

## Source changes
- [x] npm registry explicitly configured in CI with bounded fetch retries.
- [x] Lockfile metadata refresh and `npm ci` retry up to three times and fail closed.
- [x] Regression test covers retry and incomplete-install protection.
- [x] Dependency versions remain locked; no fabricated integrity values or arbitrary upgrades.

## Checks completed locally
- [x] Script suite: 259 passed, 0 failed.
- [x] D1 auth schema tests: 6 passed, 0 failed.
- [x] Pre-launch source audit: 28 required assets, 0 route metadata notes.
- [x] Cloudflare source readiness: 16/16 source checks passed; two external prerequisites remain.

## Required before release
- [ ] Network-enabled CI completes lockfile metadata refresh and `npm ci`. Current workspace is blocked by `EAI_AGAIN registry.npmjs.org`.
- [ ] `npm run check:dependencies` confirms all critical packages match lockfile versions.
- [ ] Full `npm test`, `npm run typecheck`, `npm run lint`, `npm audit --audit-level=high`, and `npm run build:cloudflare` pass.
- [ ] Isolated Cloudflare staging D1 and credentials are configured and staging auth, tickets, donation approval, chapter unlocks, rights review, headers and rollback are tested.
- [ ] Performance/accessibility and backup/restore tests pass.

## Safety
Production Worker `god-emperornovel` and production D1 `god-emperornovel-db` remain out of scope. No production deployment or migration is authorized.

**NOT PRODUCTION READY until all required CI and staging checks pass.**
