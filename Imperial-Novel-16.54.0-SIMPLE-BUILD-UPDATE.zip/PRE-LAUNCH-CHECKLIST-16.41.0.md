# Imperial Novel Pre-Launch Checklist (16.41.0)

This is an implementation and evidence checklist, not a claim that every production control has been verified. Mark a control complete only when the stated evidence exists. The live Cloudflare Worker `god-emperornovel` and D1 database `god-emperornovel-db` must remain untouched until a separate release approval.

Legend: **SOURCE** = implemented in repository; **VERIFY** = must be tested in a real build/staging; **BLOCKED** = needs owner credentials, provider setup, or a legal/operational decision.

## Legal, trust and visitor information
- [x] **SOURCE** Privacy policy route exists (`/privacy`); confirm it matches actual deployed data flows before launch (**VERIFY**).
- [x] **SOURCE** Terms route exists (`/terms`); obtain jurisdiction-appropriate legal review before treating it as legal advice (**VERIFY**).
- [x] **SOURCE** Cookie consent/preferences UI defaults optional categories off. No optional provider should load until consent and provider configuration are both present (**VERIFY** browser network behavior).
- [x] **SOURCE** Visitor FAQ route (`/faq`) added and linked in footer.
- [x] **SOURCE** No fabricated testimonials added. Use only attributable, permissioned, genuine testimonials if any are introduced.
- [ ] **BLOCKED** Confirm contact/support and privacy-request process, retention period, account deletion/export process and legal entity/contact details.

## Secrets, identity and access control
- [x] `.env*`, `.dev.vars*`, local DBs and generated artifacts are excluded by `.gitignore` (review actual Git history before launch).
- [ ] **VERIFY** Run secret scanning on repository history and CI (e.g. GitHub secret scanning or a dedicated scanner); rotate any exposed key immediately.
- [x] Source server-only code reads provider secrets from runtime environment, not public Vite variables; **VERIFY** production bundle contains no secrets.
- [ ] **VERIFY/BLOCKED** Set every required environment variable in the deployment platform; fail closed for missing secrets and wrong runtime mode.
- [x] Source includes protected admin gates and explicit bootstrap admin configuration; **VERIFY** with ordinary, author, admin, signed-out and expired-session test accounts.
- [ ] **VERIFY** Confirm password hashing and session/cookie flags through the actual Better Auth configuration and browser response headers. Do not rely on source inspection alone.
- [ ] **VERIFY** Test IDOR/access-control for profiles, chapters, drafts, reports, tickets, donations, admin APIs and connector actions.
- [ ] **VERIFY** Review CORS/Origin/CSRF protections for every mutation endpoint; allow only required origins.
- [x] Security-header middleware source exists; **VERIFY** it is emitted on success, errors, redirects, and static responses in generated Cloudflare Worker.
- [ ] **VERIFY** Ensure production debug mode and verbose stack traces are disabled; scan public routes for exposed source maps, env files, backups and config.
- [ ] **VERIFY** Apply rate limiting/bot protection at the edge and/or storage-backed application layer to sign-in, signup, search, comments, reports, donation submissions and expensive AI endpoints.
- [ ] **VERIFY** Confirm all forms validate on the server, constrain sizes/types, encode output, and have abuse controls; add a post-submit confirmation where the workflow needs it.
- [ ] **VERIFY** Security review XSS/HTML rendering, SQL parameterization, upload validation, open redirects, SSRF, webhook/provider callbacks and error handling.

## HTTPS, database and dependency integrity
- [x] Source security middleware sets HSTS and baseline browser headers; **VERIFY** HTTPS behavior and headers on the actual canonical host. Never enable HSTS includeSubDomains on shared `workers.dev` hosting.
- [ ] **VERIFY** Confirm database binding/credentials, least privilege, backups/export and restore rehearsal. No staging workflow may target production D1.
- [x] Source migrations and schema tests exist; **VERIFY** indexes against real query plans and data volume; add only evidence-backed indexes.
- [ ] **VERIFY** Review transaction/idempotency behavior for ticket purchases, donation approvals and unlocks under concurrent requests and injected failures.
- [ ] **VERIFY** Complete `npm ci`, lockfile integrity checks, dependency vulnerability audit, license review, and remove only demonstrably unused dependencies.
- [ ] **VERIFY** Run full `npm test`, `npm run typecheck`, `npm run lint`, `npm run build:cloudflare`, and generated Worker smoke tests in network-enabled CI.
- [ ] **VERIFY** Load/soak test with realistic traffic and failure cases; set platform-appropriate scaling/quotas. Do not introduce Kubernetes unless justified by measured need.

## SEO, accessibility and performance
- [x] Unique route titles exist for primary pages; add descriptions and social metadata to public pages and validate rendered output (**VERIFY**).
- [x] Root Open Graph/Twitter defaults and image references added; verify the social image is the intended current brand image and crawlers can fetch it.
- [x] Favicon and touch icon assets exist.
- [x] `public/robots.txt` and `public/sitemap.xml` added for public discovery routes. Revisit canonical URLs before changing domain; ensure private/reader routes remain excluded.
- [ ] **BLOCKED** Submit the sitemap in Google Search Console only after confirming domain ownership and canonical domain; confirm robots is not unintentionally blocking public content.
- [ ] **VERIFY** Audit image alt text (empty alt is appropriate only for decorative images), optimize/compress images, responsive sizes and lazy loading.
- [ ] **VERIFY** Measure Core Web Vitals/load speed on mobile and slower networks; check bundle size, caching headers and cache invalidation for personalized/private responses.
- [ ] **VERIFY** Run keyboard, screen-reader, focus-visible, reduced-motion and contrast audits on real pages.
- [x] **SOURCE** Custom not-found page exists; **VERIFY** unknown routes return real HTTP 404 status on the deployed Worker.
- [ ] **VERIFY** Crawl internal links, forms, empty states and submission/thank-you flows; ensure success is not displayed before server confirmation.
- [ ] **VERIFY** Configure privacy-respecting analytics only if chosen, consent-gated, and legally reviewed. No analytics provider is assumed configured by this source change.
- [x] **SOURCE** Clear primary calls to action exist on the home page; validate with usability testing.

## Product-specific release gates
- [ ] **BLOCKED** Real staging D1 database and credentials configured in GitHub Actions; no placeholder IDs.
- [ ] **VERIFY** Cloudflare staging deployment, Better Auth login/session/logout, admin bootstrap and all critical routes pass end-to-end tests.
- [ ] **VERIFY** EasyPaisa manual verification, ticket ledger, purchase idempotency, donation approval, unlock balances and refunds/rejections pass concurrent and failure-injection tests.
- [ ] **VERIFY** Trend Factory rights evidence, review/audit trail, no chapter-body ingestion, and disabled-by-default external connectors are tested.
- [ ] **BLOCKED** Configure Monetag only after consent/legal review and provider account setup; do not enable unrelated ad networks.
- [ ] **BLOCKED** Configure AI Author Studio only with a real server-side key, rate/usage limits, privacy review and graceful unavailable state.
- [ ] **VERIFY** Rollback procedure and recovery/restore rehearsal completed and recorded.
- [ ] **BLOCKED** Production release is explicitly approved after staging evidence is reviewed. No production deploy is authorized by this checklist.

## Design-system/tooling notes
- [x] **SOURCE** Reuse the existing shared UI components and responsive design tokens instead of adding a second component framework.
- [x] **SOURCE** Added `PRE-LAUNCH-SAFETY-NET-PROMPT.md` for future AI-assisted updates and truthful release reporting.
- [ ] **VERIFY** Use frontend design guidelines and accessible component patterns during implementation review. No external MCP/tool server is assumed installed or required for runtime.

## Suggested final CI commands
```sh
npm ci
npm test
npm run typecheck
npm run lint
npm run build:cloudflare
npm run check:cloudflare-readiness
node scripts/prelaunch-audit.mjs
```

A source checklist cannot replace provider configuration, external security testing, legal review, or staging verification. Report the exact failed command and its logs rather than marking a blocked gate complete.
