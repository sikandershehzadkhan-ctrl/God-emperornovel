import assert from "node:assert/strict";
import test from "node:test";
import imperialD1Middleware from "./imperial-d1.ts";
import { queryD1ForRequest } from "../../src/lib/db/d1-context.ts";
import { cloudflareEnvForRequest } from "../../src/lib/auth/cloudflare-context.server.ts";
import type { D1Like } from "../../src/lib/db/d1-sql.ts";

function fakeD1(label: string): D1Like {
  return {
    prepare(sql: string) {
      return {
        bind(...values: unknown[]) {
          return {
            async all<T>() {
              return { results: [{ label, sql, values }] as T[] };
            },
            async run() {
              return { success: true };
            },
          };
        },
      };
    },
  };
}

test("Cloudflare middleware returns 503 when the D1 binding is missing", () => {
  const response = imperialD1Middleware({ context: { cloudflare: { env: {} } } });
  assert.ok(response instanceof Response);
  assert.equal(response.status, 503);
  assert.equal(response.headers.get("cache-control"), "no-store");
});

test("Cloudflare middleware binds D1 to the request and continues routing", async () => {
  const request = new Request("https://imperial-novel-staging.example.test/");
  const result = imperialD1Middleware({
    context: { cloudflare: { env: { DB: fakeD1("middleware-db") } } },
    web: { request },
  });
  assert.equal(result, undefined);
  const rows = await queryD1ForRequest<{ label: string }>(request, "select 1");
  assert.equal(rows[0]?.label, "middleware-db");
});

test("two request objects cannot read each other's D1 binding", async () => {
  const requestA = new Request("https://imperial-novel-staging.example.test/a");
  const requestB = new Request("https://imperial-novel-staging.example.test/b");
  imperialD1Middleware({
    context: { cloudflare: { env: { DB: fakeD1("db-a") } } },
    web: { request: requestA },
  });
  imperialD1Middleware({
    context: { cloudflare: { env: { DB: fakeD1("db-b") } } },
    web: { request: requestB },
  });
  const [a, b] = await Promise.all([
    queryD1ForRequest<{ label: string }>(requestA, "select 1"),
    queryD1ForRequest<{ label: string }>(requestB, "select 1"),
  ]);
  assert.equal(a[0]?.label, "db-a");
  assert.equal(b[0]?.label, "db-b");
});


test("middleware registers the request's Cloudflare auth environment", () => {
  const request = new Request("https://imperial-novel-staging.example.test/account");
  const env = {
    DB: fakeD1("auth-db"),
    BETTER_AUTH_URL: "https://imperial-novel-staging.example.test",
    BETTER_AUTH_SECRET: "a".repeat(48),
  };
  imperialD1Middleware({
    context: { cloudflare: { env } },
    web: { request },
  });
  assert.equal(cloudflareEnvForRequest(request), env);
});

test("middleware registers both Nitro request identities when they differ", async () => {
  const webRequest = new Request("https://imperial-novel-staging.example.test/web");
  const originalRequest = new Request("https://imperial-novel-staging.example.test/original");
  const env = { DB: fakeD1("shared-db"), BETTER_AUTH_URL: "https://imperial-novel-staging.example.test" };
  imperialD1Middleware({
    context: { cloudflare: { env } },
    web: { request: webRequest },
    req: { original: originalRequest },
  });
  assert.equal(cloudflareEnvForRequest(webRequest), env);
  assert.equal(cloudflareEnvForRequest(originalRequest), env);
  const rows = await queryD1ForRequest<{ label: string }>(originalRequest, "select 1");
  assert.equal(rows[0]?.label, "shared-db");
});
