import { defineEventHandler, setResponseHeaders } from "h3";

/** Baseline browser hardening. Keep CSP separately staged until external assets and auth flows are inventoried. */
export default defineEventHandler((event) => {
  setResponseHeaders(event, {
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "SAMEORIGIN",
    "Referrer-Policy": "strict-origin-when-cross-origin",
    "Permissions-Policy": "camera=(), microphone=(), geolocation=(), payment=()",
    "Cross-Origin-Opener-Policy": "same-origin-allow-popups",
    "X-Permitted-Cross-Domain-Policies": "none",
    // Do not use includeSubDomains on shared hosting domains such as workers.dev.
    // Enable HSTS only on HTTPS deployments after confirming the canonical host.
    "Strict-Transport-Security": "max-age=31536000",
    "X-DNS-Prefetch-Control": "off",
    "X-Download-Options": "noopen",
  });
});
