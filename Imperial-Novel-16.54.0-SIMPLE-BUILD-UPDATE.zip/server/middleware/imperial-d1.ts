/**
 * Bind the Cloudflare D1 handle to the incoming Fetch Request.
 *
 * Nitro middleware has no `next()` callback: returning undefined allows the
 * request to continue. Database access later resolves the same Request through
 * TanStack Start's getRequest(). If the runtime/binding/request is absent, fail
 * closed rather than silently opening PGLite.
 */
import { registerImperialD1Request, type D1BindingLike } from "../../src/lib/db/d1-context.ts";
import { registerCloudflareEnvRequest, type CloudflareRequestEnv } from "../../src/lib/auth/cloudflare-context.server.ts";

interface CloudflareEnv {
  DB?: D1BindingLike;
}

interface ImperialD1Event {
  context: {
    cloudflare?: { env?: CloudflareEnv };
  };
  req?: { original?: object };
  web?: { request?: object };
}

function isCloudflareBuild(): boolean {
  return (
    typeof process !== "undefined" &&
    process.env.IMPERIAL_RUNTIME?.trim().toLowerCase() === "cloudflare"
  );
}

export default function imperialD1Middleware(event: ImperialD1Event): Response | undefined {
  const env = event.context.cloudflare?.env;
  const binding = env?.DB;
  const primaryRequest = event.web?.request ?? event.req?.original;

  if (!binding) {
    if (isCloudflareBuild() || event.context.cloudflare) {
      return new Response("Service temporarily unavailable: database binding is not configured.", {
        status: 503,
        headers: {
          "content-type": "text/plain; charset=utf-8",
          "cache-control": "no-store",
        },
      });
    }
    return undefined;
  }

  if (!primaryRequest || typeof primaryRequest !== "object") {
    return new Response("Service temporarily unavailable: request context is not available.", {
      status: 503,
      headers: {
        "content-type": "text/plain; charset=utf-8",
        "cache-control": "no-store",
      },
    });
  }

  // Nitro may expose the incoming Fetch Request through either property. Store
  // both identities when present because TanStack Start's getRequest() must
  // resolve the same object used by this middleware.
  const requests = new Set<object>([primaryRequest]);
  if (event.web?.request && typeof event.web.request === "object") requests.add(event.web.request);
  if (event.req?.original && typeof event.req.original === "object") requests.add(event.req.original);
  const cloudflareEnv = env as CloudflareRequestEnv;
  for (const request of requests) {
    registerImperialD1Request(request, binding);
    registerCloudflareEnvRequest(request, cloudflareEnv);
  }
  return undefined;
}
