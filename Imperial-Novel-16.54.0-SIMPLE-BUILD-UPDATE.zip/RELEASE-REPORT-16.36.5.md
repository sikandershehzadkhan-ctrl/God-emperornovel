# Imperial Novel 16.36.5 — Cloudflare auth-route isolation

## Delivered
- Extracted the `/api/auth/*` runtime decision into `src/lib/auth/route-handler.ts`.
- The handler receives a lazy auth-module loader, checks Cloudflare runtime signals first, and returns a non-cacheable 503 before loading the Node/PGLite auth module.
- Added executable tests for Cloudflare fail-closed behavior, non-Cloudflare handler delegation, and explicit Cloudflare runtime flags.
- Updated route-source tests and the standard test command to cover the new handler.
- Documented the limitation in `CLOUDFLARE.md`.

## Verification
- `node --test 'scripts/**/*.test.mjs'`: **223 passed, 0 failed**.
- `node --experimental-sqlite --test scripts/d1-auth-schema.test.mjs`: **5 passed, 0 failed**.
- New auth route handler + runtime tests: **7 passed, 0 failed**.
- D1 request-context, adapter/backend, middleware, and auth-route handler tests: **19 passed, 0 failed** in the focused run.
- Readiness checker: **4/6 source checks passed**, with the two expected blockers reported (staging database ID and actual D1-backed Better Auth adapter).
- `npm test` reaches the TypeScript test phase, but **2 test files cannot start** because required project dependencies are absent from `node_modules` (`@electric-sql/pglite` and dependencies imported by the affected modules). The script and SQLite schema suites pass; the readiness checker also correctly distinguishes the safe fail-closed route from the still-missing D1 adapter.
- Full TypeScript typecheck and Cloudflare build are **not verified** because dependencies could not be installed in this environment.

## Still blocked
1. A supported persistent Better Auth + Cloudflare D1 adapter with correct transaction semantics and lifecycle integration tests.
2. A real, separate staging D1 database ID in `wrangler.jsonc`.
3. Successful dependency installation, full typecheck, Cloudflare build, and isolated staging verification.

## Production safety
- The Cloudflare auth route remains intentionally fail-closed with HTTP 503.
- No GitHub push, Cloudflare deployment, production migration, or production Worker/database modification was performed.
- Production Worker `god-emperornovel` and D1 database `god-emperornovel-db` were not accessed.
