## 16.48.0 — GitHub / Cloudflare / D1 deployment bundle
- Prepared the hardened source as a repository-root bundle for the existing GitHub Actions → Wrangler → Cloudflare Workers → D1 route.
- Added mobile-friendly deployment instructions and a release checklist.
- Kept the default deployment target isolated to `imperial-novel-staging`; no production Worker, production D1 database, GitHub repository, or account-side secret was changed.
- Source tests: 261 passed; D1 auth schema tests: 6 passed; pre-launch source audit passed; Cloudflare source readiness 17/17.
- Full dependency install/build, typecheck, lint, dependency audit, and real staging verification remain blocked/unverified because registry access failed and staging credentials/database are not available in this environment.

## 16.47.0 — Request-scoped Cloudflare database and auth context
- Fixed application D1 queries to resolve the current TanStack Start request and use the D1 binding registered by Nitro middleware; missing request bindings still fail closed.
- Registered both Nitro request identities when available so app SQL and Better Auth session verification can resolve the same per-request Cloudflare environment.
- Changed server-side session verification to load the D1-backed Better Auth adapter for Cloudflare requests and the Node/PGLite adapter only for non-Cloudflare requests.
- Added regression coverage for per-request database/auth environment registration and expanded the read-only Cloudflare source gate to 17 checks.
- This is not a release certification: full dependency-backed typecheck/build, npm audit, and isolated staging verification remain outstanding. No production deployment or database change was performed.

## 16.46.0 — Resilient dependency recovery
- Added bounded npm registry retries and explicit fail-closed diagnostics in CI.
- Added regression coverage for dependency install retry behavior.
- Full install/build remains pending a network-enabled CI run.

# Changelog

## 16.45.0 — Dependency recovery diagnostics and CI verification

- Added a dependency preflight that checks the critical app/build/typecheck packages are installed and match the committed lockfile, with a clear recovery message when `node_modules` is incomplete.
- CI now runs the dependency preflight immediately after `npm ci` and runs ESLint before the Cloudflare build.
- Added regression tests for missing packages and lockfile-version mismatches.
- This improves detection and prevents misleading build attempts; it does not claim an installation succeeded in an offline workspace. No production deployment or database changes were performed.

---

## 16.44.0 — HTTPS cookie security and release-gate tightening

- Better Auth now sets Secure cookies for HTTPS origins (including staging/production) while retaining local HTTP preview compatibility.
- Cloudflare readiness gate now checks the cookie security invariant.
- Pre-launch audit requires Permissions-Policy and the latest checklist/release report.
- This remains a source milestone: dependency-backed build and deployed staging verification are still required. No production deployment or database change was performed.

---

## 16.43.0 — CI reproducibility and secret-history scan fix

- Fixed GitHub Actions checkout to fetch full history, so the repository-history secret scan can actually run instead of failing on a shallow clone.
- Added a lockfile-refresh verifier that permits npm registry integrity metadata to be added in ephemeral CI while rejecting dependency graph, version, resolution, or existing-integrity changes.
- Added regression tests for lockfile integrity refresh and workflow contracts.
- This is a source/CI hardening milestone, not production certification. The current offline workspace passes all 251 script tests and 6 D1 schema tests, but cannot install app dependencies; two dependency-backed test modules, typecheck, and the Cloudflare build remain blocked.

---

# Imperial Novel 16.42.0 — Security and release-gate completion

- Added a high-confidence secret-pattern scanner for source files and available Git history, with regression tests. CI fails if history is unavailable in its Git checkout.
- Added CI dependency advisory scanning (`npm audit --audit-level=high`).
- Added a lockfile metadata drift gate that restores the committed lockfile and fails if registry resolution would modify it; CI no longer builds from silently refreshed lock metadata.
- Extended the pre-launch source audit to require secret scanning, dependency audit and lockfile drift checks.
- Updated application and seeded version labels to 16.42.0.
- No production deployment, production D1 migration, or remote credential changes were performed.

# Imperial Novel 16.41.0 — Pre-launch checklist and public trust pages

- Added visitor FAQ route and footer links to FAQ and cookie preferences.
- Added default Open Graph and Twitter metadata, robots.txt, and public sitemap.xml.
- Added a comprehensive, status-labelled pre-launch checklist covering the supplied security, SEO, accessibility, performance and operations requirements.
- Added a repeatable source audit command. It does not replace a deployed staging verification.
- No production Worker or production D1 database was changed.

## 16.40.0 — Release-gate hardening (2026-10-12)

- Staging deploy workflow now fails closed when required credentials are missing instead of producing a green deployment step.
- Staging deployment is restricted to pushes or manual dispatches on `main` and remains isolated from the production Worker/database.
- Added post-deploy HTTP smoke checks for the application shell and Better Auth session endpoint.
- Added workflow-contract regression tests.
- This is not production approval: full dependency installation/build and a real isolated staging run remain required.

# Imperial Novel 16.39.0 — Atomic tickets and Trend Factory source milestone

- Added native atomic SQL batches for Postgres, PGLite and request-bound Cloudflare D1.
- Made EasyPaisa approval idempotent and transactional; tied chapter ticket debit and ledger writes to unlock inserts with database triggers.
- Added PKR donation, chapter-cost, and publication-rights evidence validation.
- Added the persisted admin-only Trend Factory workflow and route, with metadata-only discovery and rights-first stage enforcement.
- Added verified-email administrator bootstrap for staging and clearer statements about inactive external connectors/AI/Monetag.
- Source gate passes 15/15 checks. Full dependency-backed test/typecheck/build and real staging auth/payment validation remain blocked; no deployment occurred.

## 16.38.1 — Explicit administrator bootstrap

- Removed first-account-wins administrator assignment from profile creation.
- New profiles receive the admin role only when the authenticated user ID exactly matches `IMPERIAL_BOOTSTRAP_ADMIN_USER_ID`; otherwise they are regular users.
- Added focused tests for absent, mismatched, exact and whitespace-padded bootstrap IDs.
- Documented a staging-only bootstrap procedure and the requirement to remove the temporary setting after the administrator profile is created.
- Passed the explicit bootstrap user ID through the Cloudflare auth environment allowlist without copying database bindings into process environment.
- Existing database roles are not rewritten. No schema, production settings, remote resources, or production data were changed.

# Imperial Novel 16.38.0 — Pre-deployment audit (documentation only)

- Inspected the current source baseline across reader, Author Studio, tickets/EasyPaisa, community, admin/security, Trend Factory and OmniPortal.
- Added a prioritized audit identifying unverified Cloudflare authentication, first-admin bootstrap race risk, non-atomic ticket-credit/unlock flows, missing dedicated Trend Factory workflow, zero external connector search, and payment conversion ambiguity.
- Added an implementation roadmap and staging acceptance tests.
- No runtime source, schema, production data, GitHub repository or Cloudflare resource changed.
- Deployment remains blocked until critical findings are fixed and staging evidence is recorded.

# Imperial Novel 16.36.3 — D1 authentication migration hardening

## Added
- Expanded the local SQLite verification for the staging-only auth schema: checks expected lookup indexes, rejects account rows linked to nonexistent users, and confirms the schema has no foreign-key violations after valid inserts.
- Kept all checks local and deterministic; no remote Cloudflare connection or deployment is involved.

## Not completed
- The persistent Better Auth adapter for request-scoped D1 is still not implemented.
- The staging D1 database ID remains a placeholder.
- Full dependency-backed typecheck/build and Cloudflare staging tests remain unverified.

# Imperial Novel 16.36.2 — D1 authentication schema verification

- Added executable SQLite validation for the staging-only Better Auth D1 migration.
- Tests verify the four core tables and expected columns, unique email/session token constraints, user-to-session cascade deletion, and safe reapplication of the migration.
- Added `npm run test:d1-schema` and included the schema checks in the main `npm test` workflow.
- This verifies SQL schema behavior only. It does not implement the Better Auth D1 adapter or authorize deployment.

# Imperial Novel 16.36.1 — Cloudflare release-gate correction

- Fixed the staging D1 readiness check so the literal `REPLACE_WITH_STAGING_D1_ID` placeholder is reliably detected as blocked.
- Fixed the staging database-name regex to correctly recognize whitespace around JSON separators.
- Added a regression test that executes the real readiness command and asserts it exits non-zero while both the staging ID and D1-backed Better Auth adapter are unresolved.
- Verification: Cloudflare gate/auth tests 18/18 passed; D1 adapter/context/middleware/runtime tests 16/16 passed.
- This is a source-check reliability fix, not D1 authentication completion. No build, staging deployment, GitHub push, or production modification was performed.

# Imperial Novel 16.35.0

## Cloudflare auth isolation (not yet D1 auth)
- Changed `/api/auth/*` to dynamically import the existing Better Auth server only outside Cloudflare.
- Cloudflare auth endpoints now fail closed with a structured, no-store 503 until persistent D1-backed sessions are implemented and verified. No fake user/session fallback is created.
- Added runtime guard tests and updated app version metadata to 16.35.0.
- Script tests: 210/210 passed; focused auth runtime tests: 4/4 passed. Full dependency-backed tests/build remain blocked because npm dependency installation timed out.
- No staging deployment or production Worker/database operation was performed.

# Imperial Novel 16.34.0

Reader experience and advanced catalog discovery refinement. No production Worker or database changes.

## Added
- Catalog filters for author and language using shareable URL query state.
- Minimum rating shortcuts (3+, 4+, and 4.5+) using the existing server catalog filter.
- Reader line-spacing controls with a bounded range and local preference persistence.
- Reader focus mode that keeps a simple exit control available, plus an `F` keyboard shortcut.
- Left/right arrow chapter navigation that ignores text-entry controls and modifier-key shortcuts.
- Reduced-motion support for the reader and discovery interfaces.
- Updated app version metadata to 16.34.0.

## Verification
- Script test suite: 208 passed.
- TypeScript check could not run because installed type packages are missing (`@types/node` and `vite/client`).
- Full app build and browser/device checks remain unverified.
- Better Auth + D1 and staging deployment remain release blockers.

# Imperial Novel 16.32.2

Accessibility contrast refinement on top of the 16.32.1 Cloudflare D1 foundation. No production Worker or database changes.

## Changed
- Darkened primary and explore CTA gradients so white button labels meet WCAG AA text contrast at each authored gradient stop.
- Darkened the cookie-consent primary button gradient to maintain AA contrast.
- Raised subtle text from `#7e8aa3` to `#aab6cc` for stronger readability on the midnight canvas.
- Strengthened high-contrast mode text and boundary tokens.
- Added ten automated contrast regression tests for CTA gradient stops, cookie controls, secondary text, and focus-ring visibility.

## Verification
- Accessibility contrast tests: 10 passed.
- This is a focused palette audit, not a full rendered-page WCAG audit.
- Full typecheck, dependency-backed app build, and Cloudflare Worker verification remain unverified.
- Better Auth + D1 remains a deployment blocker.

# Imperial Novel 16.31.0

Cloudflare staging preparation. The live Worker and the live D1 database were not modified.

## Added
- D1/SQLite SQL translation and a statement adapter that keeps the existing `$1` query style.
- `migrations/d1/` for a new empty staging database. Postgres migrations are unchanged.
- A local SQLite migration command. It is not part of `npm run build` and it refuses `god-emperornovel` and `god-emperornovel-db`.
- `wrangler.jsonc` for a staging Worker named `imperial-novel-staging`, with a placeholder D1 id.
- Opt-in Nitro `cloudflare-module` build via `npm run build:cloudflare`. The default build remains Vercel.
- Adapter tests for parameter binding, migration retry, one-time ticket credit, and weekly view counts.

## Not done
- Better Auth still uses Postgres or PGLite. A Cloudflare process refuses to start auth rather than invent sessions.
- No remote D1 database was created or migrated.
- No production backup was taken, because this environment cannot access the live database.
- Production data was not copied.

# Imperial Novel 16.30.0

Production stabilization. No redesign. No production database reset.

## Fixed
- Production preview can boot PGLite. The bundled server module looks for `pglite.data`, `pglite.wasm`, and `initdb.wasm` beside itself. The build now stages those empty engine sidecars. They are not a copy of application data. A configured `DATABASE_URL` still uses Postgres and never opens them.
- Leaderboard weekly and monthly tabs count `view_events` from the last 7 or 30 days. They no longer relabel lifetime views. Older views are not backfilled.
- Donation approval claims a pending row in one update, so a repeated approval cannot credit tickets twice.
- Version is 16.30.0 in the UI and in `app_settings`.

## Changed
- For You uses shared genres from reading history when that history exists, and says it is not an AI engine.
- Trending states that it sorts by lifetime views, then rating.
- Wide screens keep Trending, For You, and Rankings in the header. The More menu shows those links only below that width.

## Not deployed
- This build was not published onto the Cloudflare Worker `god-emperornovel`. That Worker is a different application, and this sandbox has no safe D1 credential for it.

## Remaining
- OmniPortal connectors stay disabled until rights evidence is approved.
- AI Author Studio requires a server-side `XAI_API_KEY`.
- Account recovery and direct messages are not implemented.
- Weekly and monthly rankings stay empty until novels are opened after this release.

## 16.32.0 — Cloudflare request binding groundwork

- Added request-scoped D1 binding middleware for the Nitro Cloudflare runtime. It uses `event.context.cloudflare.env.DB`, scopes access with `AsyncLocalStorage`, and returns a no-store 503 when a Cloudflare request has no database binding instead of falling back to PGLite.
- Added regression tests for missing request scope, async request scope, and parallel-request isolation.
- Kept the existing Better Auth Cloudflare guard in place. Authentication is not yet D1-compatible, so this change is groundwork only and does not make the application deploy-ready.
- Added no production credentials, IDs, or remote deployment actions.


## 16.32.1 — D1 request binding and test reliability

- Corrected the Nitro middleware contract: it no longer assumes a `next()` callback. The middleware registers the D1 handle against the request and returns control to Nitro routing.
- Added a request-aware SQL entry point that resolves the active TanStack Start Fetch Request for each query. Database handles are not stored in a process-global active binding.
- Added middleware regression coverage for missing D1 binding, request binding, and isolation between concurrent request objects.
- Updated generic OG tests to use isolated fixture directories so the actual Imperial Novel site identity and `public/og.jpg` do not contaminate unrelated tests. Added an assertion for the actual Imperial Novel identity.
- Restored the intended workspace default `VITE_AUTH_ENABLED=false` while preserving explicit deploy-time overrides.
- Corrected the migration-plan test to recognize the actual top-level D1-independent migrations while verifying the auth source directory is not globbed.
- Verification: script tests 198/198 pass; selected D1/context/middleware/sign-in-state/readiness tests 18/18 pass; local SQLite D1 migration applied twice idempotently. Full dependency install, typecheck, Cloudflare build, Better Auth/D1, and generated Worker runtime remain unverified.
- No staging deployment or production Worker/database operation was performed.

## 16.33.0 — WTR-Lab-inspired discovery UX
- Added one-tap catalog shortcuts for freshly updated, completed, long-read, highly rated, original-world and trending selections.
- Added a direct route to the existing random discovery feature.
- Documented inspiration boundaries and future reading-site product patterns without copying code, branding, images or copyrighted chapter content.
- Existing Cloudflare/authentication release blockers remain unchanged.

## 16.36.0 — Cloudflare release gate

- Added a read-only Cloudflare readiness report command that checks staging isolation, D1 request-binding guardrails, auth fail-closed behavior, and presence of the core D1 auth schema.
- Added regression tests proving the release gate does not deploy or access remote services.
- Added an explicit pre-deployment checklist entry for the staging ID and persistent D1-backed Better Auth blocker.
- No production configuration, Worker, database, or secrets were changed.

## 16.36.4 — Experimental D1 Kysely bridge (not enabled)

- Added an isolated Kysely SQLite dialect bridge that executes compiled queries through a supplied D1 binding.
- Added contract tests for query binding and for explicit refusal to fake interactive transactions.
- Kept the Cloudflare auth route fail-closed; this prototype is not wired into Better Auth and does not establish deploy readiness.
- Dependency installation was retried in offline mode and stopped because the npm cache lacks `ajv`; full typecheck/build remain unavailable in this environment.
- No Cloudflare deployment, GitHub push, or production database operation was performed.


## 16.36.5 — Cloudflare auth route isolation tests

- Extracted the auth route's runtime guard into a dependency-light handler with an injected lazy loader.
- Added executable tests proving Cloudflare requests return a non-cacheable 503 without loading the Node/PGLite Better Auth module.
- Added regression coverage for the existing non-Cloudflare handler path and explicit Cloudflare runtime flag.
- This does not implement the D1 Better Auth adapter; the Cloudflare auth route remains intentionally fail-closed.


## 16.36.6 — D1 authentication schema drift guard

- Added an executable parity test comparing the D1 auth migration against the canonical Better Auth migration for the four core auth tables.
- Added `npm run check:d1-auth-schema-parity` for a focused preflight.
- Documented the limits of schema parity: it does not prove adapter, transaction, or Cloudflare runtime compatibility.
- Kept Cloudflare authentication fail-closed and production configuration unchanged.

## 16.37.1 — Cloudflare source gate completion

- Separated static source/configuration checks from external release prerequisites.
- The staging config check now validates isolation and intentionally accepts the safe placeholder; it never invents a Cloudflare D1 ID.
- The Drizzle source check validates exact version and resolved-tarball consistency across package.json and package-lock.json.
- The readiness command now reports all 8 source checks independently, then lists missing registry integrity metadata and the real staging D1 ID as release prerequisites. It remains non-zero until those external prerequisites are fulfilled.
- Updated regression coverage to assert 8/8 source checks pass without misrepresenting the package as deployment-ready.

## 16.37.0 — Cloudflare D1 authentication adapter integration (verification pending)

- Added a Cloudflare-only Better Auth factory using the official Better Auth Drizzle adapter with Drizzle's D1 driver and an explicit SQLite schema for user, session, account, and verification records.
- Added required-setting validation for the D1 binding, `BETTER_AUTH_SECRET`, `BETTER_AUTH_URL`, and the per-app Grok OAuth client credentials. Cloudflare auth remains fail-closed when any required setting is missing or invalid.
- Routed Cloudflare auth requests through a separate lazy-loaded module while preserving the existing Postgres/PGLite auth path for non-Cloudflare runtimes. The opt-in Cloudflare build command explicitly enables the client sign-in UI; normal preview defaults remain unchanged.
- Added a Cloudflare-only Vite alias so the Worker build substitutes a fail-closed stub for the Node/PGLite auth module instead of intentionally bundling that server module.
- Aligned the D1 migration and Drizzle schema on integer-millisecond timestamps and named uniqueness indexes.
- Added source-level adapter/configuration/build-isolation tests and updated the read-only readiness gate.
- Verification: 229 script tests passed; 6 SQLite D1 schema tests passed; 21 focused runtime/D1 tests passed; changed TypeScript files passed syntax transpilation. Full typecheck, package installation, Cloudflare build, and live D1 auth lifecycle remain unverified.
- Blockers: the registry was unreachable so the Drizzle lock entry lacks the npm integrity hash and must be regenerated with a successful online `npm install`; `wrangler.jsonc` still requires a real ID for a separate staging D1 database. No staging deployment, GitHub push, production Worker operation, or production DB operation was performed.

## 16.37.2 — GitHub Actions and Cloudflare staging automation

- Added GitHub Actions CI for pull requests and pushes to `main`.
- Added a Cloudflare build gate: project tests, staging config safety tests, TypeScript typecheck, and Cloudflare build must pass before the staging deployment step runs.
- Added a staging-only generated Wrangler config and tests that reject the known production Worker hostname and placeholder D1 IDs.
- Configured automatic deployment only to the separate `imperial-novel-staging` Worker when required GitHub secrets and variables exist.
- Kept production deployment out of automation until end-to-end staging authentication checks pass.
- Documented required GitHub secrets, OAuth staging callback configuration, and mobile setup steps in `GITHUB-CLOUDFLARE-AUTOMATION.md`.

