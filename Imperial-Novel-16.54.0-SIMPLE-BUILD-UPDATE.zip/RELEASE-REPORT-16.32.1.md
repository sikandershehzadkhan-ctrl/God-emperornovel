# Imperial Novel 16.32.1 — Engineering release report

## Outcome

The source-level D1 request-binding foundation and its tests are updated. **This is not a Cloudflare-deployable release yet.** Better Auth still has no verified D1 adapter in this codebase, and the full dependency-backed build could not be run in this environment.

## Completed

- Corrected Nitro middleware behavior: no assumed `next()` callback.
- Bound each D1 database handle to the exact Fetch Request using a `WeakMap`.
- Added a TanStack Start request-aware D1 SQL entry point; it resolves the current request for every query instead of capturing one request's binding globally.
- Fail-closed behavior when a Cloudflare D1 binding or usable request object is missing.
- Regression coverage for missing binding, request binding, and separation between request objects.
- Fixed script test fixtures to isolate generic Open Graph tests from the actual Imperial Novel identity and public card image.
- Restored the expected local/workspace auth-off setting while preserving explicit environment overrides.
- Corrected the migration-plan test to match the repository's actual migration layout.
- Updated staging and release documentation.
- Created a clean source ZIP without dependency/build output, local database files, or the nested older ZIP.

## Verification evidence

| Check | Result | Notes |
| --- | --- | --- |
| Script tests | PASS | 198 passed, 0 failed |
| Selected D1/context/middleware/sign-in/readiness tests | PASS | 18 passed, 0 failed under Node 22 experimental TS stripping |
| Disposable local SQLite D1 migrations | PASS | First run applied both migrations; second run was idempotent |
| ZIP integrity | PASS | `zipfile.testzip()` returned no errors; 317 entries |
| TypeScript typecheck | BLOCKED | Global `tsc` cannot find `@types/node` and `vite/client` because dependencies are not installed |
| Full dependency install | BLOCKED | `npm ci` timed out; offline install had an uncached package |
| Full `npm test` | NOT VERIFIED | Dependency-backed tests cannot load missing packages such as `jose` and `@tanstack/react-start` |
| Cloudflare build | NOT VERIFIED | Vite and project dependencies are not installed in this environment |
| Generated Worker runtime | NOT VERIFIED | No generated Worker smoke test was possible |
| Better Auth + D1 | BLOCKED | Existing auth module explicitly rejects Cloudflare mode to avoid insecure session fallback |
| Staging deployment | NOT PERFORMED | No authenticated Cloudflare deployment path available |
| Production Worker/database | UNCHANGED BY THIS WORK | No production deploy, migration, or database operation performed |

## Required before any staging deployment

1. Implement a supported Better Auth D1 adapter and ensure session/user/account/verification reads and writes use the request's D1 binding.
2. Confirm the Nitro/TanStack request identity mapping in a real generated Worker.
3. Install dependencies and pass typecheck, the complete test suite, and Cloudflare production build.
4. Provision a separate staging D1 database and configure its actual ID and secrets through the account owner.
5. Run staging route, auth, payment/ticket authorization, migration, and rollback checks.

The live Worker `god-emperornovel` and database `god-emperornovel-db` remain protected and must not be used as staging targets.
