# Imperial Novel 16.51.0 — Launch Readiness Audit Plan

This release starts a structured launch-readiness pass based on the supplied checklist screenshots. It does not claim every item is already fixed or verified.

## Source-level items present for review
- Branded favicon, Imperial crest, Apple touch icon and Open Graph image assets exist in `public/`.
- `public/robots.txt` and `public/sitemap.xml` exist.
- A custom root not-found component exists in `src/routes/__root.tsx`.
- The root layout has shared site metadata; several route files define route-specific metadata.
- The layout has a three-line mobile navigation trigger with `aria-label`, `aria-controls`, `aria-expanded`, Escape-to-close behavior and route-link close behavior.
- A keyboard-accessible skip link now targets the main content region.
- A privacy page and cookie preference controls exist in source.
- Authentication and admin-only UI gates exist in source; server-side authorization still needs route-by-route verification.

## Must be verified before launch
1. **SEO:** inspect rendered HTML for unique title and description on every indexable route; validate canonical URLs, Open Graph absolute URL, sitemap URLs/statuses, robots rules, breadcrumbs and structured data. Confirm domain before changing canonical/sitemap values.
2. **Security:** run dependency and secret scans; review auth/session cookie flags, CSRF and origin checks, XSS-safe rendering, input validation, rate limits, CORS, admin API authorization, upload handling, exposed files and debug settings.
3. **Privacy/legal:** verify privacy and terms accurately describe actual data collection, retention, cookies, analytics and support/payment-reference handling. Do not claim legal compliance without review.
4. **Accessibility:** test keyboard navigation, focus order, contrast, zoom, labels, errors, screen-reader names, menu focus management and reduced-motion settings.
5. **Performance:** measure mobile Core Web Vitals; inspect image sizes and formats, lazy loading, JS bundles, caching, database indexes and slow requests. Load-test safely against staging only.
6. **Reliability:** verify all links/forms/routes, custom 404, redirect behavior, graceful server errors, logging, backups and a documented rollback procedure.
7. **Product flows:** test sign-in, sign-up, reading, bookmarks, author studio, community, Trend Factory rights review, tickets, and pending/approved/rejected manual EasyPaisa verification.
8. **Analytics:** only configure a real provider after privacy review and consent requirements are determined. Never insert fake analytics IDs or testimonials.
9. **Cloudflare:** verify build output, Worker compatibility, D1 binding, migrations, secrets and staging deployment before production.

## Known verification limitation
The current workspace has no installed `node_modules`, and network access to the package registry is unavailable. Therefore a dependency-backed production build, full typecheck/lint, browser test suite and real Cloudflare deployment have not been run here. Do not describe this package as fully production-verified.
