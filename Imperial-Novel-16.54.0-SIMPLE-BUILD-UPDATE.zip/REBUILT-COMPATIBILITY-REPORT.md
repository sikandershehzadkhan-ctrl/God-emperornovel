# Rebuild compatibility report

## Source baseline

The rebuild starts from the hardened Imperial Novel 16.47.0 source and restores Grok-only source files absent from that tree, while excluding stale generated build output, dependencies, transient preview images/logs, and screenshots.

## Compatibility protections

- Cloudflare deployment target remains `imperial-novel-staging`.
- D1 binding is request-scoped and registered for both Nitro request identities when they differ.
- Missing Cloudflare D1 binding fails closed with HTTP 503.
- Better Auth uses the D1/Drizzle adapter on Cloudflare; Node/PGLite auth remains isolated from the Cloudflare bundle.
- Secure cookies are enabled for HTTPS origins.
- Production Worker/database names are rejected by staging safety checks.
- Ticket unlock writes and manual donation approval use database-native atomic batches.
- Trend Factory stays metadata-only and rights-first.

## Status

Source-level checks passed as recorded in `DEPLOYMENT-START-HERE.md`. A complete application build, typecheck, lint, dependency audit, and real staging deployment could not be completed because the npm registry DNS lookup failed in this environment and no Cloudflare staging credentials/database ID are available here. This is therefore a rebuilt staging source bundle, not a fully certified compiled deployment artifact.
