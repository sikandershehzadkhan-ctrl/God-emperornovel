# Imperial Novel 16.32.1 — Security and release checklist

## Current status

**Release status: BLOCKED for Cloudflare deployment.** This release corrects the D1 request-binding foundation and test fixtures, but it does not claim end-to-end Cloudflare compatibility.

- [x] Production Worker and database are explicitly protected by project guardrails.
- [x] Staging `wrangler.jsonc` remains separate and retains its placeholder D1 ID.
- [x] D1 binding is registered against the exact Fetch Request in a `WeakMap`; no process-global active database pointer is used.
- [x] Missing D1 binding or request identity fails closed instead of falling back to PGLite.
- [x] D1 adapter, request-context, middleware, sign-in-state, and readiness tests pass under Node 22 TypeScript stripping (18/18 selected tests).
- [x] Script test suite passes (198/198).
- [x] Local D1 migrations applied to a disposable SQLite file; a second run correctly reported up-to-date.
- [ ] Better Auth D1 adapter and request-bound auth construction are implemented and verified. `src/lib/auth/server.ts` intentionally blocks Cloudflare mode until then.
- [ ] Full dependency installation completes. `npm ci --ignore-scripts --no-audit --no-fund` timed out in this environment.
- [ ] Full TypeScript check, complete dependency-backed test suite, and Cloudflare production build pass.
- [ ] All application SQL statements and D1 schema are validated end-to-end against a generated Worker.
- [ ] Staging database ID and secrets are provisioned by an authorized account owner.
- [ ] Staging Worker smoke tests and rollback rehearsal pass.

## Production protections

Do not deploy this ZIP to `god-emperornovel`. Do not migrate, reset, rename, or bind `god-emperornovel-db` to staging. No production Worker or D1 action was performed during this work.

## Required before staging deployment

1. Implement and verify a supported Better Auth storage adapter for Cloudflare D1, including schema definitions and request-safe binding access.
2. Ensure all auth/session reads and writes use the request's D1 binding, with no PGLite or Postgres fallback in Cloudflare mode.
3. Verify Nitro middleware ordering and Fetch Request identity on the generated Worker runtime.
4. Restore dependencies, then run the complete typecheck, full test suite, Cloudflare build, and route/auth smoke tests.
5. Create a new staging D1 database and configure its real ID only after it exists in the owner's Cloudflare account.
6. Apply `migrations/d1` only to that disposable staging database after reviewing the migration plan.
7. Record a rollback procedure and staging evidence before considering any production migration.

## Test evidence

Script tests:

```sh
node --test 'scripts/**/*.test.mjs'
```

Result: **198 passed, 0 failed**.

Selected D1 and request tests:

```sh
node --experimental-strip-types --test src/lib/db/d1-adapter.test.ts src/lib/db/d1-context.test.ts server/middleware/imperial-d1.test.ts src/lib/auth/sign-in-gate.test.ts src/lib/app-data/readiness-schedule.test.ts
```

Result: **18 passed, 0 failed**. Node reports its built-in TypeScript stripping as experimental.

Disposable SQLite migration check:
- First run applied `0001_auth.sql` and `0002_imperial.sql`.
- Second run reported `up to date`.

The full dependency install timed out. Consequently `npm run typecheck`, the entire `npm test`, `npm run build:cloudflare`, and generated Worker smoke tests remain unverified. This is a real release blocker, not a passing result.
