# Imperial Novel 16.36.0 — Release report

## Delivered
- Added `npm run check:cloudflare-readiness`, a read-only preflight report.
- Added regression tests for staging isolation, fail-closed auth, the core D1 auth schema, and the preflight's no-deploy/no-remote-access behavior.
- Updated Cloudflare staging notes and changelog.

## Test evidence
- Focused regression tests: **17 passed, 0 failed** (`node --test scripts/cloudflare-readiness.test.mjs scripts/cloudflare-auth-route.test.mjs scripts/check-auth-invariant.test.mjs`).
- D1 adapter, request-isolation, middleware, and runtime-mode tests: **16 passed, 0 failed** (`node --experimental-strip-types --test src/lib/db/d1-adapter.test.ts src/lib/db/d1-context.test.ts server/middleware/imperial-d1.test.ts src/lib/auth/runtime-mode.test.ts`).
- Readiness command was executed and correctly exited with status **2**, reporting two blockers:
  1. Staging D1 database ID is still a placeholder.
  2. Persistent D1-backed Better Auth adapter is not implemented.
- Full TypeScript typecheck and Cloudflare build were not run because dependencies are not installed in this working environment. Do not interpret the focused tests as a full app build.

## Status
- Read-only source release gate: PASS.
- Persistent D1-backed Better Auth: BLOCKED.
- Staging D1 database ID: BLOCKED.
- Full typecheck / Cloudflare build: NOT VERIFIED.
- Staging deployment: NOT PERFORMED.
- Production Worker `god-emperornovel` and D1 `god-emperornovel-db`: NOT MODIFIED.
