# Imperial Novel 16.48.0 — pre-launch checklist

- [x] Source package and lockfile present.
- [x] Cloudflare Nitro preset selected by `IMPERIAL_RUNTIME=cloudflare`.
- [x] Staging Worker config generation and staging-only D1 migration directory included.
- [x] GitHub Actions staging workflow included.
- [x] Source script tests: 261 passed.
- [x] D1 auth schema tests: 6 passed.
- [x] Pre-launch source audit: passed.
- [x] Cloudflare source readiness: 17/17.
- [ ] Successful online `npm ci`.
- [ ] All dependency-backed tests pass.
- [ ] TypeScript check passes.
- [ ] ESLint passes.
- [ ] npm audit passes at configured severity.
- [ ] Cloudflare Worker build produces `.output/server/index.mjs` and `.output/public`.
- [ ] Staging D1 created and migrations applied to staging only.
- [ ] Staging auth/session, data isolation, ticket/EasyPaisa, reader and rights-first workflows verified.
- [ ] Production schema compatibility and rollback reviewed separately.

**Release state: NOT YET CERTIFIED.** Do not deploy this source to the live Worker until all unchecked gates pass.
