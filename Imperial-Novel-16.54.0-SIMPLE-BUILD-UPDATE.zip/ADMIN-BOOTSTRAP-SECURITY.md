# Imperial Novel administrator bootstrap security

New profiles never receive administrator privileges merely because they are the first account.

## Recommended staging setup

1. Before the intended administrator first opens an authenticated Imperial Novel page that creates their profile, set the GitHub Actions repository variable `STAGING_BOOTSTRAP_ADMIN_EMAIL` to that account's exact email address.
2. The staging workflow passes this setting to the isolated `imperial-novel-staging` Worker as `IMPERIAL_BOOTSTRAP_ADMIN_EMAIL`.
3. The app grants the initial `admin` role only when Better Auth's stored identity has the same email and Better Auth marks that email as verified. An unverified matching email cannot create the profile until verification is complete.
4. After the intended profile exists and its `admin` role is confirmed, remove `STAGING_BOOTSTRAP_ADMIN_EMAIL` from the GitHub Actions variables and run the staging deployment again. Removing the setting does not downgrade the stored administrator role.
5. Never configure this staging bootstrap variable as part of an unapproved production change.

## Alternative exact-ID setup

`IMPERIAL_BOOTSTRAP_ADMIN_USER_ID` remains supported for environments where the operator already knows the authenticated user ID. It must exactly match the user ID before the Imperial profile is created.

## Safety properties

- No first-account/count-based admin promotion.
- No matching verified identity, no email-based admin bootstrap.
- Lookup failures fail closed and do not grant admin.
- Existing profile roles are not silently changed by bootstrap environment variables.
- Bootstrap is intended for initial provisioning only, not ongoing role management.
