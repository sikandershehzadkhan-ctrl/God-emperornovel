# Imperial Novel deployment method: GitHub → Cloudflare Workers → D1

This bundle is organized for the existing repository `sikandershehzadkhan-ctrl/God-emperornovel` and the GitHub Actions + Wrangler deployment route. The workflow deploys to a separate Cloudflare staging Worker first. This is deliberate: the newer TanStack Start application uses a different server entry point from the older 16.24.0 Worker (`src/index.js`), so replacing the live Worker before validating the new runtime and schema could break the website or its data.

## Included deployment path

1. Upload/merge the *contents* of this archive into the existing GitHub repository root (do not upload this ZIP as a single repository file).
2. Push the reviewed source to `main`.
3. GitHub Actions installs locked dependencies, checks the dependency graph, scans secrets, runs tests/typecheck/lint, builds the Cloudflare Worker, and then deploys only `imperial-novel-staging` when staging-only GitHub secrets and variables are present.
4. The staging workflow applies only `migrations/d1/` to the separately created staging D1 database.
5. Test authentication/session lifecycle, reader routes, ticket unlock transactions, EasyPaisa manual approval, rights review and admin boundaries on staging.
6. Only after those checks pass should a separate production release be prepared and approved.

## Required GitHub Actions secrets

- `CLOUDFLARE_API_TOKEN`
- `CLOUDFLARE_ACCOUNT_ID`
- `STAGING_D1_DATABASE_ID` (must be a separate staging D1 UUID)
- `STAGING_BETTER_AUTH_SECRET` (staging-only, at least 32 characters)
- `STAGING_GROK_AUTH_CLIENT_ID`
- `STAGING_GROK_AUTH_CLIENT_SECRET`

## Required GitHub Actions variables

- `STAGING_BETTER_AUTH_URL` (HTTPS origin for the staging Worker, no path)
- `STAGING_GROK_AUTH_ISSUER` (optional)
- `STAGING_BOOTSTRAP_ADMIN_EMAIL` (optional; only if the staging admin bootstrap is deliberately needed)

The OAuth client must allow the staging callback URL. Do not copy production OAuth secrets into staging unless their allowed origins have been reviewed.

## D1 safety

- The checked-in `wrangler.jsonc` is staging-only and intentionally has a placeholder D1 ID.
- The workflow's generated Wrangler config uses `migrations/d1/` only.
- Do not replace the placeholder with the production database ID.
- Do not run the new D1 migrations against `god-emperornovel-db` until the schema has been compared with the live database and a backup/rollback plan exists.

## Why this does not immediately replace the live Worker

The previous live Worker used `src/index.js` and an older D1 schema. This source uses the built Nitro/TanStack Start entry `.output/server/index.mjs`, Better Auth, and a newer set of D1 migrations. Sharing the same Worker name and D1 binding alone does not make the runtimes or schemas compatible. A real npm install, full build and isolated staging test are release gates, not optional paperwork.

## Local verification commands

```sh
npm ci --no-audit --no-fund
npm run check:dependencies
npm run scan:secrets
npm audit --audit-level=high
npm test
npm run typecheck
npm run lint
npm run build:cloudflare
npm run check:cloudflare-readiness
npm run audit:prelaunch
```

Do not consider the release complete until the build output `.output/server/index.mjs` and `.output/public` exist and the staging Worker passes real HTTP and database/auth tests.
