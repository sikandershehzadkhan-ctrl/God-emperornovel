#!/usr/bin/env node
/**
 * Apply migrations/d1 to a local SQLite file.
 * Does not run during the Vercel build. Does not talk to Cloudflare.
 * Refuses the production Worker name and the production D1 database name.
 */
import { mkdirSync, readdirSync, readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { DatabaseSync } from "node:sqlite";
import { assertSafeD1Target } from "../src/lib/db/backend.ts";
import { applySqliteMigrations } from "../src/lib/db/sqlite-migrate.ts";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const file = process.env.IMPERIAL_D1_FILE?.trim();

assertSafeD1Target({
  workerName: process.env.IMPERIAL_WORKER_NAME || "imperial-novel-staging",
  databaseName: process.env.IMPERIAL_D1_DATABASE_NAME || "imperial-novel-staging",
  databaseId: process.env.IMPERIAL_D1_DATABASE_ID || "REPLACE_WITH_STAGING_D1_ID",
  allowRemote: false,
});

if (process.env.IMPERIAL_D1_ALLOW_REMOTE === "1") {
  console.error("[d1] Remote D1 migration is not authorized from this script.");
  process.exit(1);
}
if (!file) {
  console.error("[d1] Set IMPERIAL_D1_FILE to a local SQLite path. No database was opened.");
  process.exit(1);
}

const dir = join(root, "migrations/d1");
const files = readdirSync(dir)
  .filter((name) => name.endsWith(".sql"))
  .map((name) => ({ name, sql: readFileSync(join(dir, name), "utf8") }));

mkdirSync(dirname(file), { recursive: true });
const db = new DatabaseSync(file);
db.exec("pragma foreign_keys = on");
const applied = applySqliteMigrations(
  {
    exec: (sql) => db.exec(sql),
    query: (text, params = []) => db.prepare(text).all(...params),
  },
  files,
);
db.close();
console.log(applied.length ? `[d1] applied ${applied.join(", ")}` : "[d1] up to date.");
