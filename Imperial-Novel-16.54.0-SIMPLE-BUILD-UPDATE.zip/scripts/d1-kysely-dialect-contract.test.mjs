import test from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const read = (file) => readFile(path.join(root, file), "utf8");

test("experimental D1 Kysely bridge uses SQLite compiler and the request binding", async () => {
  const source = await read("src/lib/db/d1-kysely-dialect.ts");
  assert.match(source, /new SqliteAdapter\(\)/);
  assert.match(source, /new SqliteQueryCompiler\(\)/);
  assert.match(source, /\.prepare\(compiledQuery\.sql\)/);
  assert.match(source, /\.bind\(\.\.\.compiledQuery\.parameters\)/);
});

test("experimental D1 Kysely bridge refuses to fake interactive transactions", async () => {
  const source = await read("src/lib/db/d1-kysely-dialect.ts");
  assert.match(source, /async beginTransaction\(/);
  assert.match(source, /throw new Error\([\s\S]*Interactive transactions are not supported by the D1 Kysely bridge/);
  assert.match(source, /not wired into Better Auth yet/i);
});

test("Cloudflare auth uses the dedicated D1 adapter, not the experimental Kysely bridge", async () => {
  const route = await read("src/routes/api/auth/$.ts");
  const handler = await read("src/lib/auth/route-handler.ts");
  const cloudflareAuth = await read("src/lib/auth/cloudflare.server.ts");
  assert.match(route, /import\("@\/lib\/auth\/cloudflare\.server"\)/);
  assert.match(handler, /return authUnavailableResponse\(\)/);
  assert.match(cloudflareAuth, /drizzleAdapter\(db/);
  assert.match(cloudflareAuth, /from "drizzle-orm\/d1"/);
  assert.doesNotMatch(cloudflareAuth, /d1KyselyDialect/);
});
