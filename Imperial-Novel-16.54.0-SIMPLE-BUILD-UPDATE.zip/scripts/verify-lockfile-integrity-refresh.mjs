#!/usr/bin/env node
/**
 * Allow registry-authenticated integrity metadata to be added to an existing
 * npm lockfile in ephemeral CI, while rejecting any dependency graph drift.
 * This does not edit files; npm owns the refresh and this script verifies it.
 */
import { readFileSync } from 'node:fs';

const [beforePath, afterPath] = process.argv.slice(2);
if (!beforePath || !afterPath) {
  console.error('Usage: node scripts/verify-lockfile-integrity-refresh.mjs <before.json> <after.json>');
  process.exit(2);
}

const parse = (path) => JSON.parse(readFileSync(path, 'utf8'));
const before = parse(beforePath);
const after = parse(afterPath);
const integrityPattern = /^sha(256|384|512)-[A-Za-z0-9+/]+={0,2}(?:\s+sha(256|384|512)-[A-Za-z0-9+/]+={0,2})*$/;
const clone = (value) => JSON.parse(JSON.stringify(value));
const canonicalize = (value) => Array.isArray(value)
  ? value.map(canonicalize)
  : value && typeof value === 'object'
    ? Object.fromEntries(Object.keys(value).sort().map((key) => [key, canonicalize(value[key])]))
    : value;

function removeIntegrity(value) {
  if (Array.isArray(value)) {
    for (const item of value) removeIntegrity(item);
  } else if (value && typeof value === 'object') {
    delete value.integrity;
    for (const child of Object.values(value)) removeIntegrity(child);
  }
  return value;
}

const beforeComparable = removeIntegrity(clone(before));
const afterComparable = removeIntegrity(clone(after));
if (JSON.stringify(canonicalize(beforeComparable)) !== JSON.stringify(canonicalize(afterComparable))) {
  console.error('FAIL: lockfile refresh changed dependency graph or non-integrity metadata. Review and commit a deliberate lockfile update.');
  process.exit(1);
}

const oldPackages = before.packages ?? {};
const newPackages = after.packages ?? {};
const added = [];
for (const [name, oldEntry] of Object.entries(oldPackages)) {
  const next = newPackages[name];
  if (!next) {
    console.error(`FAIL: package disappeared during lockfile refresh: ${name}`);
    process.exit(1);
  }
  if (oldEntry.integrity && oldEntry.integrity !== next.integrity) {
    console.error(`FAIL: existing integrity metadata changed: ${name}`);
    process.exit(1);
  }
  if (!oldEntry.integrity && next.integrity) {
    if (!integrityPattern.test(next.integrity)) {
      console.error(`FAIL: invalid registry integrity metadata for ${name}`);
      process.exit(1);
    }
    added.push(name);
  }
}

const unresolved = Object.entries(newPackages).filter(([name, entry]) =>
  name.startsWith('node_modules/') &&
  typeof entry.resolved === 'string' &&
  entry.resolved.startsWith('https://registry.npmjs.org/') &&
  (!entry.integrity || !integrityPattern.test(entry.integrity))
);
if (unresolved.length) {
  console.error(`FAIL: ${unresolved.length} npm registry package(s) still lack valid integrity metadata: ${unresolved.slice(0, 8).map(([name]) => name).join(', ')}`);
  process.exit(1);
}

console.log(`PASS: dependency graph unchanged; ${added.length} missing integrity record(s) added by npm registry metadata${added.length ? ` (${added.join(', ')})` : ''}.`);
