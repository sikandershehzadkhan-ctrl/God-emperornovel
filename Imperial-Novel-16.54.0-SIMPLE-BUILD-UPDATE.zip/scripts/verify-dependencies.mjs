import { existsSync, readFileSync } from 'node:fs';
import { join, resolve } from 'node:path';

export function inspectDependencies(root = process.cwd(), names = [
  'jose', '@tanstack/react-start', 'vite', '@types/node', 'typescript', 'eslint',
]) {
  const packagePath = join(root, 'package.json');
  const lockPath = join(root, 'package-lock.json');
  if (!existsSync(packagePath) || !existsSync(lockPath)) {
    return { ok: false, errors: ['package.json and package-lock.json must both exist in the project root.'] };
  }
  const pkg = JSON.parse(readFileSync(packagePath, 'utf8'));
  const lock = JSON.parse(readFileSync(lockPath, 'utf8'));
  const errors = [];
  for (const name of names) {
    const declared = pkg.dependencies?.[name] ?? pkg.devDependencies?.[name];
    const locked = lock.packages?.[`node_modules/${name}`];
    if (!declared) {
      errors.push(`${name}: missing from package.json dependencies/devDependencies.`);
      continue;
    }
    if (!locked?.version) {
      errors.push(`${name}: missing from package-lock.json; run npm install with the approved dependency changes, then review the lockfile.`);
      continue;
    }
    const installedPath = join(root, 'node_modules', name, 'package.json');
    if (!existsSync(installedPath)) {
      errors.push(`${name}: not installed (lockfile requires ${locked.version}). Run npm ci in a network-enabled environment.`);
      continue;
    }
    try {
      const installed = JSON.parse(readFileSync(installedPath, 'utf8'));
      if (installed.version !== locked.version) {
        errors.push(`${name}: installed ${installed.version}, lockfile requires ${locked.version}. Run npm ci.`);
      }
    } catch {
      errors.push(`${name}: installed package metadata is unreadable. Remove node_modules and run npm ci.`);
    }
  }
  return { ok: errors.length === 0, errors };
}

if (process.argv[1] && resolve(process.argv[1]) === resolve(new URL(import.meta.url).pathname)) {
  const result = inspectDependencies();
  if (result.ok) {
    console.log('PASS: required application, build, and typecheck dependencies are installed at their locked versions.');
  } else {
    console.error('DEPENDENCY CHECK FAILED: the source lockfile may be correct, but this workspace is not ready to test/build.');
    for (const error of result.errors) console.error(`- ${error}`);
    console.error('Recovery: restore npm registry/network access, then run `npm ci --no-audit --no-fund` and rerun this check.');
    process.exitCode = 1;
  }
}
