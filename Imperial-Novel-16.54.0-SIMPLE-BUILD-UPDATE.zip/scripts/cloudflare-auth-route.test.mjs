import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = (file) => readFile(path.join(root, file), 'utf8');

test('auth route avoids eagerly importing the Node/PGLite auth module', async () => {
  const route = await read('src/routes/api/auth/$.ts');
  assert.doesNotMatch(route, /import\s*\{\s*auth\s*\}\s*from\s*["']@\/lib\/auth\/server["']/);
  assert.match(route, /\(\)\s*=>\s*import\(["']@\/lib\/auth\/server["']\)/);
  assert.match(route, /handleAuthRequest\(/);
});

test('auth route delegates to the tested runtime guard before lazy module loading', async () => {
  const handler = await read('src/lib/auth/route-handler.ts');
  const guardIndex = handler.indexOf('isCloudflareAuthRuntime(context, runtimeValue)');
  const importLoaderIndex = handler.indexOf('await loadNodeAuth()');
  assert.ok(guardIndex >= 0, 'runtime guard exists');
  assert.ok(importLoaderIndex > guardIndex, 'Node auth module loader runs after the guard');
  assert.match(handler, /return authUnavailableResponse\(\)/);
});
