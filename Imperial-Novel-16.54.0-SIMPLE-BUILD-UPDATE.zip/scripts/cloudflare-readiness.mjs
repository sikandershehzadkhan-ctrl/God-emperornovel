#!/usr/bin/env node
/**
 * Read-only Cloudflare release gate. This script never deploys and never connects
 * to Cloudflare. It checks source/config prerequisites and reports blockers.
 */
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import path from "node:path";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const read = (name) => readFileSync(path.join(root, name), "utf8");
const report = [];
const add = (name, ok, detail) => report.push({ name, status: ok ? "PASS" : "BLOCKED", detail });

const wrangler = read("wrangler.jsonc");
const authRoute = read("src/routes/api/auth/$.ts");
const authRouteHandler = read("src/lib/auth/route-handler.ts");
const authServer = read("src/lib/auth/server.ts");
const cloudflareAuth = read("src/lib/auth/cloudflare.server.ts");
const d1Schema = read("src/lib/auth/d1-schema.ts");
const packageJson = JSON.parse(read("package.json"));
const packageLock = JSON.parse(read("package-lock.json"));
const migration = read("migrations/d1/0001_auth.sql");
const middleware = read("server/middleware/imperial-d1.ts");
const d1Context = read("src/lib/db/d1-context.ts");
const authVerify = read("src/lib/auth/verify.server.ts");
const cloudflareContext = read("src/lib/auth/cloudflare-context.server.ts");
const viteConfig = read("vite.config.ts");
const nodeAuthStub = read("src/lib/auth/cloudflare-node-auth-disabled.server.ts");
const sqlLayer = read("src/lib/db.ts");
const d1Sql = read("src/lib/db/d1-sql.ts");
const reader = read("src/lib/imperial/reader.ts");
const unlockMigration = read("migrations/d1/0003_ticket_unlock_atomic.sql");
const unlockPostgresMigration = read("migrations/0005_ticket_unlock_atomic.sql");
const trendService = read("src/lib/imperial/trend-factory.ts");
const trendRoute = read("src/routes/trend-factory.tsx");
const trendMigration = read("migrations/d1/0004_trend_factory.sql");
const trendPostgresMigration = read("migrations/0006_trend_factory.sql");
const adminService = read("src/lib/imperial/admin.ts");
const authorService = read("src/lib/imperial/author.ts");
const ticketService = read("src/lib/imperial/tickets.ts");
const routeTree = read("src/routeTree.gen.ts");
const omniService = read("src/lib/imperial/omni.ts");
const omniRoute = read("src/routes/omniportal.tsx");
const bootstrapRole = read("src/lib/imperial/bootstrap-role.ts");
const bootstrapDb = read("src/lib/imperial/db.ts");
const stagingConfigScript = read("scripts/prepare-cloudflare-staging-config.mjs");
const stagingWorkflow = read(".github/workflows/imperial-novel-cloudflare.yml");

add(
  "Staging Worker target",
  /"name"\s*:\s*"imperial-novel-staging"/.test(wrangler) &&
    !/"name"\s*:\s*"god-emperornovel"/.test(wrangler),
  "wrangler.jsonc targets imperial-novel-staging and not the production Worker."
);
add(
  "Staging D1 configuration is isolated",
  /"name"\s*:\s*"imperial-novel-staging"/.test(wrangler) &&
    /"database_name"\s*:\s*"imperial-novel-staging"/.test(wrangler) &&
    /"database_id"\s*:\s*"REPLACE_WITH_STAGING_D1_ID"/.test(wrangler) &&
    !/god-emperornovel-db/.test(wrangler),
  "Source configuration targets a dedicated staging Worker/database and deliberately retains a safe placeholder rather than inventing an external Cloudflare resource ID."
);
add(
  "D1 request binding guard",
  /registerImperialD1Request\(request, binding\)/.test(middleware) &&
    /status:\s*503/.test(middleware),
  "D1 middleware binds per request and fails closed when the binding is absent."
);
add(
  "Request-scoped D1 reaches application queries",
  /await currentRequestDatabase\(\)/.test(d1Context) &&
    /await import\("@tanstack\/react-start\/server"\)/.test(d1Context) &&
    /registerCloudflareEnvRequest\(request, cloudflareEnv\)/.test(middleware) &&
    /cloudflareEnvForRequest\(request\)/.test(authVerify) &&
    /createCloudflareAuth/.test(authVerify) &&
    /requestEnvironments\.set\(request, env\)/.test(cloudflareContext),
  "The Worker request binds D1 to both database queries and Better Auth session verification; missing bindings fail closed instead of falling back to a shared dev user."
);
add(
  "Runtime-isolated auth routing",
  /handleAuthRequest\(/.test(authRoute) &&
    /import\("@\/lib\/auth\/cloudflare\.server"\)/.test(authRoute) &&
    /isCloudflareAuthRuntime\(context, runtimeValue\)/.test(authRouteHandler) &&
    /await loadCloudflareAuth\(env\)/.test(authRouteHandler) &&
    /D1-backed sessions are not implemented/.test(authServer),
  "Cloudflare lazily loads its D1 auth module; the Node/PGLite module remains isolated and refuses Cloudflare mode."
);
add(
  "Node/PGLite auth excluded from Cloudflare build graph",
  /process\.env\.IMPERIAL_RUNTIME === "cloudflare"/.test(viteConfig) &&
    /find:\s*"@\/lib\/auth\/server"/.test(viteConfig) &&
    /cloudflare-node-auth-disabled\.server\.ts/.test(viteConfig) &&
    /authUnavailableResponse\(\)/.test(nodeAuthStub) &&
    !/from ["']pg["']|from ["']@electric-sql\/pglite["']/.test(nodeAuthStub),
  "The Cloudflare Vite build aliases the legacy Node/PGLite auth module to a fail-closed stub. Confirm the generated Worker bundle after dependency installation."
);
add(
  "HTTPS authentication cookies are Secure",
  /const secureCookies = new URL\(baseURL\)\.protocol === "https:"/.test(cloudflareAuth) &&
    /useSecureCookies: secureCookies/.test(cloudflareAuth) &&
    /defaultCookieAttributes: \{ secure: secureCookies, sameSite: "lax", path: "\/" \}/.test(cloudflareAuth),
  "Deployed HTTPS origins use Secure session cookies; localhost HTTP preview remains available for local testing.",
);

add(
  "Persistent D1-backed Better Auth adapter source",
  /drizzleAdapter\(db,\s*\{\s*provider:\s*"sqlite",\s*schema:\s*d1AuthSchema\s*\}\)/.test(cloudflareAuth) &&
    /from "drizzle-orm\/d1"/.test(cloudflareAuth) &&
    /user:\s*d1User/.test(d1Schema) && /session:\s*d1Session/.test(d1Schema) &&
    /account:\s*d1Account/.test(d1Schema) && /verification:\s*d1Verification/.test(d1Schema),
  "A D1-specific Drizzle schema and Better Auth adapter are now wired in source; runtime/build verification is still required."
);
add(
  "Drizzle dependency pin consistency",
  packageJson.dependencies["drizzle-orm"] === packageLock.packages[""]?.dependencies?.["drizzle-orm"] &&
    packageLock.packages["node_modules/drizzle-orm"]?.version === packageJson.dependencies["drizzle-orm"] &&
    packageLock.packages["node_modules/drizzle-orm"]?.resolved ===
      `https://registry.npmjs.org/drizzle-orm/-/drizzle-orm-${packageJson.dependencies["drizzle-orm"]}.tgz`,
  "package.json, lockfile root dependency, resolved registry tarball, and locked version agree. Registry integrity metadata is checked separately as a release prerequisite, not misclassified as a source-wiring check."
);
add(
  "Core Better Auth D1 schema exists",
  ['"user"', '"session"', '"account"', '"verification"'].every((table) =>
    new RegExp(`create\\s+table\\s+if\\s+not\\s+exists\\s+"?${table.replaceAll('"', '')}"?`, "i").test(migration)
  ),
  "The staging-only SQLite schema includes Better Auth core tables."
);

add(
  "Backend-native atomic batch API",
  /batch\(statements: SqlStatement\[\]\)/.test(sqlLayer) &&
    /pool\.connect\(\)[\s\S]*?begin[\s\S]*?commit[\s\S]*?rollback/i.test(sqlLayer) &&
    /pg\.transaction\(async \(tx\)/.test(sqlLayer) &&
    /batchCurrentD1/.test(sqlLayer) && /db\.batch\(/.test(d1Sql),
  "Postgres, PGLite, and request-bound D1 have explicit all-or-nothing write batches; no sequential-write fallback is permitted."
);
add(
  "Ticket unlock debit is coupled to unlock insert",
  /sql\.batch\(locked\.map/.test(reader) && /sql\.batch\(\[\{/.test(reader) &&
    /RAISE\(ABORT, 'Not enough tickets/.test(unlockMigration) &&
    /RAISE EXCEPTION 'Not enough tickets/.test(unlockPostgresMigration),
  "Database triggers validate ticket balance, debit and ledger the same unlock transaction, and reject insufficient balance."
);
add(
  "Donation approval uses a single idempotent transaction",
  /status = 'processing'/.test(adminService) && /await sql\.batch\(statements\)/.test(adminService) &&
    /Only pending donations can be reviewed/.test(adminService),
  "Donation status transition, ticket ledger, profile credit, notification and audit are committed as one batch."
);
add(
  "Trend Factory is persisted and route-registered",
  /export const createTrendCandidate/.test(trendService) && /export const advanceTrendCandidate/.test(trendService) &&
    /rights_evidence/.test(trendService) && /audit\(sql, context\.userId, "trend_candidate_stage"/.test(trendService) &&
    /audit\(sql, context\.userId, "trend_candidate_created"/.test(trendService) &&
    /metadata only/i.test(trendRoute) && /create table if not exists trend_candidates/i.test(trendMigration) &&
    /CREATE TABLE IF NOT EXISTS trend_candidates/i.test(trendPostgresMigration) &&
    /\/trend-factory/.test(routeTree),
  "A dedicated admin-only, ordered rights-first workflow persists discovery metadata and never imports chapter bodies."
);
add(
  "Publication and ticket inputs fail closed",
  /length\(trim\(coalesce\(rights_evidence/.test(adminService) &&
    /Number\.isSafeInteger\(ticketCost\)/.test(authorService) &&
    /Number\.isSafeInteger\(amount\)/.test(ticketService),
  "Publishing requires eligible rights evidence; chapter costs and manual PKR donation amounts are bounded whole numbers."
);

add(
  "Initial administrator bootstrap is explicit and verified",
  /matchesVerifiedBootstrapAdminEmail/.test(bootstrapDb) &&
    /emailVerified/.test(bootstrapDb) && /emailVerified && account === configured/.test(bootstrapRole) &&
    /IMPERIAL_BOOTSTRAP_ADMIN_EMAIL/.test(cloudflareAuth) &&
    /STAGING_BOOTSTRAP_ADMIN_EMAIL/.test(stagingConfigScript) &&
    /STAGING_BOOTSTRAP_ADMIN_EMAIL/.test(stagingWorkflow),
  "The first admin can be bootstrapped by an exact verified email or exact user ID; no first-account promotion is used."
);

add(
  "External connector capabilities are not overstated",
  /local-catalog-search/.test(omniService) && /searched_connectors: 0/.test(omniService) &&
    /External provider searches remain disabled/.test(omniRoute) &&
    /External fetching is not active in this build/.test(omniService),
  "The UI explicitly states that external search/fetching is inactive; it does not pretend connector adapters are live."
);

console.log("IMPERIAL NOVEL CLOUDFLARE SOURCE READINESS (read-only; no deploy or remote DB access)");
for (const item of report) {
  console.log(`[${item.status}] ${item.name}: ${item.detail}`);
}
const sourceBlockers = report.filter((item) => item.status !== "PASS");
console.log(`\nSource result: ${report.length - sourceBlockers.length}/${report.length} source checks passed; ${sourceBlockers.length} source blocker(s).`);

// External release prerequisites are intentionally separate from source checks:
// do not fabricate a Cloudflare D1 ID or an npm integrity hash when offline.
const drizzleEntry = packageLock.packages["node_modules/drizzle-orm"];
const releasePrerequisites = [];
if (/"database_id"\s*:\s*"REPLACE_WITH_STAGING_D1_ID"/.test(wrangler)) {
  releasePrerequisites.push("A real, separately-created staging D1 database ID must be supplied by the Cloudflare account owner.");
}
if (!drizzleEntry?.integrity || !/^sha(256|384|512)-[A-Za-z0-9+/]+={0,2}(?:\s+sha(256|384|512)-[A-Za-z0-9+/]+={0,2})*$/.test(drizzleEntry.integrity)) {
  releasePrerequisites.push("Regenerate and verify package-lock.json integrity metadata with npm registry access (the current environment cannot resolve registry.npmjs.org).");
}
console.log(`\nExternal release prerequisites: ${releasePrerequisites.length}`);
for (const prerequisite of releasePrerequisites) console.log(`[RELEASE BLOCKED] ${prerequisite}`);
console.log("A passing source result does not prove a successful dependency install, full build, or live staging deployment.");
if (sourceBlockers.length || releasePrerequisites.length) process.exitCode = 2;
