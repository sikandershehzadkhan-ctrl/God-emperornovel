import test from "node:test";
import assert from "node:assert/strict";

/**
 * Focused WCAG 2.2 AA contrast regression checks for Imperial Novel's core palette.
 * This checks authored solid colors and gradient stops, not every rendered component.
 */
const hexRgb = (hex) => {
  const raw = hex.replace("#", "");
  const normalized = raw.length === 3 ? [...raw].map((c) => c + c).join("") : raw;
  if (!/^[0-9a-fA-F]{6}$/.test(normalized)) throw new Error(`Invalid hex color: ${hex}`);
  return [0, 2, 4].map((i) => parseInt(normalized.slice(i, i + 2), 16) / 255);
};
const luminance = (hex) => hexRgb(hex)
  .map((v) => v <= 0.04045 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4)
  .reduce((sum, v, i) => sum + v * [0.2126, 0.7152, 0.0722][i], 0);
const contrast = (a, b) => {
  const [hi, lo] = [luminance(a), luminance(b)].sort((x, y) => y - x);
  return (hi + 0.05) / (lo + 0.05);
};
const checks = [
  ["primary CTA white label on purple stop", "#f8fafc", "#5b21b6", 4.5],
  ["primary CTA white label on indigo stop", "#f8fafc", "#4f46e5", 4.5],
  ["primary CTA white label on blue stop", "#f8fafc", "#1d4ed8", 4.5],
  ["explore CTA white label on emerald stop", "#f8fafc", "#047857", 4.5],
  ["explore CTA white label on deep green stop", "#f8fafc", "#065f46", 4.5],
  ["cookie primary white label on violet stop", "#f8fafc", "#6d28d9", 4.5],
  ["cookie primary white label on blue stop", "#f8fafc", "#1d4ed8", 4.5],
  ["subtle text on main canvas", "#aab6cc", "#050814", 4.5],
  ["muted text on main surface", "#b7c0d4", "#101628", 4.5],
  ["cyan focus ring on main canvas", "#22d3ee", "#050814", 3],
];
for (const [name, foreground, background, minimum] of checks) {
  test(`${name} meets ${minimum}:1 contrast`, () => {
    assert.ok(
      contrast(foreground, background) >= minimum,
      `${name}: ${contrast(foreground, background).toFixed(2)}:1, needs ${minimum}:1`,
    );
  });
}
