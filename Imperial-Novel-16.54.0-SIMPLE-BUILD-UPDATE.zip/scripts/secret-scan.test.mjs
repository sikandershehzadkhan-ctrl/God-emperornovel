import test from 'node:test';
import assert from 'node:assert/strict';
import { findSecretPatterns } from './secret-scan.mjs';

test('secret scanner detects high-confidence token formats', () => {
  assert.deepEqual(findSecretPatterns('token=' + 'ghp_' + 'abcdefghijklmnopqrstuvwxyz0123456789ABCDEFG'), ['github-token']);
  assert.deepEqual(findSecretPatterns('-----BEGIN ' + 'RSA ' + 'PRIVATE KEY-----'), ['private-key']);
  assert.deepEqual(findSecretPatterns('AWS=' + 'AKIA' + '1234567890ABCDEF'), ['aws-access-key-id']);
});

test('secret scanner ignores ordinary configuration and placeholders', () => {
  assert.deepEqual(findSecretPatterns('BETTER_AUTH_SECRET=replace-with-a-random-secret-from-the-platform'), []);
  assert.deepEqual(findSecretPatterns('https://example.invalid/api/auth and VITE_AUTH_ENABLED=true'), []);
});
