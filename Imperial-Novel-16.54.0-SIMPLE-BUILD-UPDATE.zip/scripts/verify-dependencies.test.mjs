import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, mkdirSync, writeFileSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { inspectDependencies } from './verify-dependencies.mjs';

function fixture() {
  const root = mkdtempSync(join(tmpdir(), 'imperial-deps-'));
  mkdirSync(join(root, 'node_modules', 'jose'), { recursive: true });
  mkdirSync(join(root, 'node_modules', '@tanstack', 'react-start'), { recursive: true });
  writeFileSync(join(root, 'package.json'), JSON.stringify({ dependencies: { jose: '6.2.9', '@tanstack/react-start': '1.168.60' } }));
  writeFileSync(join(root, 'package-lock.json'), JSON.stringify({ packages: {
    'node_modules/jose': { version: '6.2.9' },
    'node_modules/@tanstack/react-start': { version: '1.168.60' },
  } }));
  writeFileSync(join(root, 'node_modules', 'jose', 'package.json'), JSON.stringify({ name: 'jose', version: '6.2.9', main: 'index.js' }));
  writeFileSync(join(root, 'node_modules', 'jose', 'index.js'), 'module.exports = {};');
  writeFileSync(join(root, 'node_modules', '@tanstack', 'react-start', 'package.json'), JSON.stringify({ name: '@tanstack/react-start', version: '1.168.60', main: 'index.js' }));
  writeFileSync(join(root, 'node_modules', '@tanstack', 'react-start', 'index.js'), 'module.exports = {};');
  return root;
}

test('dependency verifier accepts installed packages matching lockfile versions', () => {
  const root = fixture();
  try { assert.deepEqual(inspectDependencies(root, ['jose', '@tanstack/react-start']), { ok: true, errors: [] }); }
  finally { rmSync(root, { recursive: true, force: true }); }
});

test('dependency verifier clearly reports a missing installed package', () => {
  const root = fixture();
  try {
    rmSync(join(root, 'node_modules', 'jose'), { recursive: true, force: true });
    const result = inspectDependencies(root, ['jose']);
    assert.equal(result.ok, false);
    assert.match(result.errors.join('\n'), /jose: not installed.*6\.2\.9/);
  } finally { rmSync(root, { recursive: true, force: true }); }
});

test('dependency verifier detects an installed version that disagrees with lockfile', () => {
  const root = fixture();
  try {
    writeFileSync(join(root, 'node_modules', 'jose', 'package.json'), JSON.stringify({ name: 'jose', version: '6.2.8', main: 'index.js' }));
    const result = inspectDependencies(root, ['jose']);
    assert.equal(result.ok, false);
    assert.match(result.errors.join('\n'), /installed 6\.2\.8, lockfile requires 6\.2\.9/);
  } finally { rmSync(root, { recursive: true, force: true }); }
});
