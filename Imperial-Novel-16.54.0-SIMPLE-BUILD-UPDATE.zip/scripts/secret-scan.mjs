#!/usr/bin/env node
/**
 * High-confidence secret scan for text files plus available Git history.
 * This is a safety net, not a replacement for provider-side secret scanning.
 */
import { execFileSync } from 'node:child_process';
import { existsSync, readdirSync, readFileSync, statSync } from 'node:fs';
import { join, relative } from 'node:path';
import { isMainModule, projectRoot } from './with-app-env.mjs';

const MAX_FILE_BYTES = 2 * 1024 * 1024;
const SKIP_DIRS = new Set(['.git', 'node_modules', '.output', '.wrangler', 'dist', 'build', 'coverage', 'attachments', 'screenshots']);
const TEXT_EXTENSIONS = new Set(['.ts', '.tsx', '.js', '.mjs', '.cjs', '.json', '.jsonc', '.yml', '.yaml', '.toml', '.env', '.md', '.txt', '.html', '.css', '.sql', '.sh']);
const PATTERNS = [
  ['private-key', /-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----/],
  ['github-token', /\b(?:gh[pousr]_[A-Za-z0-9_]{30,}|github_pat_[A-Za-z0-9_]{50,})\b/],
  ['slack-token', /\bxox[baprs]-[A-Za-z0-9-]{20,}\b/],
  ['aws-access-key-id', /\bAKIA[0-9A-Z]{16}\b/],
  ['google-api-key', /\bAIza[0-9A-Za-z_-]{35}\b/],
  ['stripe-live-secret', /\b(?:sk|rk)_live_[0-9A-Za-z]{16,}\b/],
  ['stripe-webhook-secret', /\bwhsec_[0-9A-Za-z]{24,}\b/],
];

export function findSecretPatterns(text) {
  const hits = [];
  for (const [name, pattern] of PATTERNS) {
    if (pattern.test(text)) hits.push(name);
  }
  return hits;
}

function scanTree(root) {
  const findings = [];
  function walk(dir) {
    let entries;
    try { entries = readdirSync(dir); } catch { return; }
    for (const name of entries) {
      if (dir === root && ['.git', ...SKIP_DIRS].includes(name)) continue;
      const path = join(dir, name);
      let stat;
      try { stat = statSync(path); } catch { continue; }
      if (stat.isDirectory()) { walk(path); continue; }
      const ext = name.startsWith('.env') ? '.env' : name.slice(name.lastIndexOf('.'));
      if (!TEXT_EXTENSIONS.has(ext) || stat.size > MAX_FILE_BYTES) continue;
      let content;
      try { content = readFileSync(path, 'utf8'); } catch { continue; }
      for (const kind of findSecretPatterns(content)) findings.push(`${relative(root, path)}: high-confidence ${kind} pattern`);
    }
  }
  walk(root);
  return findings;
}

function scanHistory(root) {
  try {
    execFileSync('git', ['rev-parse', '--git-dir'], { cwd: root, stdio: 'ignore' });
  } catch {
    return { available: false, findings: [] };
  }
  let history = '';
  try {
    history = execFileSync('git', ['log', '--all', '-p', '--no-ext-diff', '--format=', '--', '.' ], {
      cwd: root, encoding: 'utf8', maxBuffer: 128 * 1024 * 1024, stdio: ['ignore', 'pipe', 'ignore'],
    });
  } catch (error) {
    return { available: true, findings: [`Git history scan failed: ${error.message}`] };
  }
  return { available: true, findings: findSecretPatterns(history).map((kind) => `Git history: high-confidence ${kind} pattern`) };
}

export function runSecretScan(root = projectRoot()) {
  const workingTree = scanTree(root);
  const history = scanHistory(root);
  return { workingTree, history };
}

async function main() {
  const result = runSecretScan();
  const findings = [...result.workingTree, ...result.history.findings];
  console.log(`Secret scan: ${result.workingTree.length} working-tree findings; Git history ${result.history.available ? 'scanned' : 'not available in this workspace'}.`);
  if (findings.length) {
    for (const finding of findings) console.error(`FAIL: ${finding}`);
    process.exitCode = 1;
    return;
  }
  if (!result.history.available && process.env.CI === 'true') {
    console.error('FAIL: CI must provide Git history for the repository-history secret scan.');
    process.exitCode = 1;
    return;
  }
  if (!result.history.available) console.warn('WARNING: history was not available; CI must run this check in a Git checkout.');
  console.log('PASS: no high-confidence secret patterns detected. Review provider-side scanning and rotate any suspected exposed credentials.');
}

if (isMainModule(import.meta.url)) await main();
