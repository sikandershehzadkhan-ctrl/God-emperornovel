import test from "node:test";
import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import { mkdtempSync, readFileSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { fileURLToPath } from "node:url";

const script = fileURLToPath(new URL("./prepare-cloudflare-staging-config.mjs", import.meta.url));
const valid = {
  CLOUDFLARE_ACCOUNT_ID: "a".repeat(32),
  STAGING_D1_DATABASE_ID: "12345678-1234-1234-1234-123456789abc",
  STAGING_BETTER_AUTH_URL: "https://imperial-novel-staging.example.workers.dev",
  STAGING_BOOTSTRAP_ADMIN_EMAIL: "owner@example.com",
};

function run(env, cwd) {
  return spawnSync(process.execPath, [script], { cwd, env: { ...process.env, ...env }, encoding: "utf8" });
}

test("generates a staging-only config with D1 binding and migrations", () => {
  const cwd = mkdtempSync(join(tmpdir(), "imperial-staging-config-"));
  try {
    const result = run(valid, cwd);
    assert.equal(result.status, 0, result.stderr);
    const config = JSON.parse(readFileSync(join(cwd, ".wrangler-staging.generated.json"), "utf8"));
    assert.equal(config.name, "imperial-novel-staging");
    assert.equal(config.d1_databases[0].database_id, valid.STAGING_D1_DATABASE_ID);
    assert.equal(config.d1_databases[0].migrations_dir, "migrations/d1");
    assert.equal(config.vars.IMPERIAL_RUNTIME, "cloudflare");
    assert.equal(config.vars.BETTER_AUTH_URL, valid.STAGING_BETTER_AUTH_URL);
    assert.equal(config.vars.IMPERIAL_BOOTSTRAP_ADMIN_EMAIL, "owner@example.com");
    assert.equal(config.main, ".output/server/index.mjs");
  } finally {
    rmSync(cwd, { recursive: true, force: true });
  }
});

test("refuses production hostname", () => {
  const cwd = mkdtempSync(join(tmpdir(), "imperial-staging-config-"));
  try {
    const result = run({ ...valid, STAGING_BETTER_AUTH_URL: "https://god-emperornovel.workers.dev" }, cwd);
    assert.notEqual(result.status, 0);
    assert.match(result.stderr, /production Worker hostname/);
  } finally {
    rmSync(cwd, { recursive: true, force: true });
  }
});

test("requires a real D1 UUID rather than the source placeholder", () => {
  const cwd = mkdtempSync(join(tmpdir(), "imperial-staging-config-"));
  try {
    const result = run({ ...valid, STAGING_D1_DATABASE_ID: "REPLACE_WITH_STAGING_D1_ID" }, cwd);
    assert.notEqual(result.status, 0);
    assert.match(result.stderr, /must be a UUID/);
  } finally {
    rmSync(cwd, { recursive: true, force: true });
  }
});

test("rejects malformed bootstrap admin email", () => {
  const cwd = mkdtempSync(join(tmpdir(), "imperial-staging-config-"));
  try {
    const result = run({ ...valid, STAGING_BOOTSTRAP_ADMIN_EMAIL: "not-an-email" }, cwd);
    assert.notEqual(result.status, 0);
    assert.match(result.stderr, /STAGING_BOOTSTRAP_ADMIN_EMAIL must be a valid email/);
  } finally {
    rmSync(cwd, { recursive: true, force: true });
  }
});
