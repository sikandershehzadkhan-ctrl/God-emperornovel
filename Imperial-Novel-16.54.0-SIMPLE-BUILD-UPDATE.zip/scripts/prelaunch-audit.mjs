import { existsSync, readFileSync, readdirSync, statSync } from 'node:fs';
import { join, relative } from 'node:path';

const root = process.cwd();
const required = [
  'src/routes/privacy.tsx', 'src/routes/terms.tsx', 'src/routes/faq.tsx',
  'src/components/privacy/cookie-consent.tsx', 'src/routes/$.tsx',
  'public/robots.txt', 'public/sitemap.xml', 'public/favicon.svg', 'public/og.jpg',
  'server/middleware/imperial-security.ts', '.gitignore',
  'PRE-LAUNCH-CHECKLIST-16.41.0.md', 'PRE-LAUNCH-CHECKLIST-16.42.0.md', 'PRE-LAUNCH-CHECKLIST-16.43.0.md', 'PRE-LAUNCH-CHECKLIST-16.44.0.md', 'PRE-LAUNCH-CHECKLIST-16.45.0.md', 'PRE-LAUNCH-CHECKLIST-16.46.0.md', 'PRE-LAUNCH-CHECKLIST-16.47.0.md', 'PRE-LAUNCH-SAFETY-NET-PROMPT.md',
  'scripts/secret-scan.mjs', 'scripts/secret-scan.test.mjs',
  'scripts/verify-lockfile-integrity-refresh.mjs', 'scripts/verify-lockfile-integrity-refresh.test.mjs',
  'RELEASE-REPORT-16.43.0.md', 'RELEASE-REPORT-16.44.0.md', 'RELEASE-REPORT-16.45.0.md', 'RELEASE-REPORT-16.46.0.md', 'RELEASE-REPORT-16.47.0.md',
  'scripts/verify-dependencies.mjs', 'scripts/verify-dependencies.test.mjs',
];
const failures = [];
const notes = [];
for (const file of required) {
  if (!existsSync(join(root, file))) failures.push(`Missing required source asset: ${file}`);
}
const routesRoot = join(root, 'src/routes');
function walk(dir) {
  for (const name of readdirSync(dir)) {
    const file = join(dir, name);
    if (statSync(file).isDirectory()) walk(file);
    else if (name.endsWith('.tsx') && name !== '__root.tsx') {
      const source = readFileSync(file, 'utf8');
      if (/createFileRoute\(/.test(source) && !/head:\s*\(/.test(source)) {
        notes.push(`Route needs metadata review: ${relative(root, file)}`);
      } else if (/createFileRoute\(/.test(source) && !/name:\s*["']description["']/.test(source)) {
        failures.push(`Route lacks a page description: ${relative(root, file)}`);
      }
    }
  }
}
walk(routesRoot);
const faq = readFileSync(join(root, 'src/routes/faq.tsx'), 'utf8');
if (!faq.includes('Frequently Asked Questions')) failures.push('FAQ page title missing');
if (!faq.includes('rights evidence')) failures.push('FAQ should explain publishing rights');
const rootRoute = readFileSync(join(root, 'src/routes/__root.tsx'), 'utf8');
for (const token of ['og:title', 'og:description', 'og:image', 'twitter:card']) {
  if (!rootRoute.includes(token)) failures.push(`Default social metadata missing: ${token}`);
}
const robots = readFileSync(join(root, 'public/robots.txt'), 'utf8');
if (!/Sitemap:\s+https:\/\//i.test(robots)) failures.push('robots.txt has no absolute sitemap URL');
if (!robots.includes('Disallow: /api/')) failures.push('robots.txt should exclude API endpoints');
const sitemap = readFileSync(join(root, 'public/sitemap.xml'), 'utf8');
if (!sitemap.includes('<urlset') || !sitemap.includes('</urlset>') || !sitemap.includes('/faq')) failures.push('sitemap.xml is malformed or FAQ missing');
const ignore = readFileSync(join(root, '.gitignore'), 'utf8');
for (const token of ['.env', '.dev.vars', 'node_modules/']) if (!ignore.includes(token)) failures.push(`.gitignore missing ${token}`);
const security = readFileSync(join(root, 'server/middleware/imperial-security.ts'), 'utf8');
for (const token of ['X-Content-Type-Options', 'X-Frame-Options', 'Referrer-Policy', 'Strict-Transport-Security', 'Permissions-Policy']) {
  if (!security.includes(token)) failures.push(`Security header source missing ${token}`);
}
const packageJson = JSON.parse(readFileSync(join(root, 'package.json'), 'utf8'));
const workflow = readFileSync(join(root, '.github/workflows/imperial-novel-cloudflare.yml'), 'utf8');
if (!packageJson.scripts?.['scan:secrets']) failures.push('Secret scanning script is not exposed through npm scripts');
if (!workflow.includes('npm run scan:secrets')) failures.push('CI does not run the secret scan');
if (!workflow.includes('npm run check:dependencies')) failures.push('CI does not verify critical installed dependencies');
if (!workflow.includes('npm run lint')) failures.push('CI does not run lint');
if (!workflow.includes('npm audit --audit-level=high')) failures.push('CI does not block high-severity dependency advisories');
if (!workflow.includes('verify-lockfile-integrity-refresh.mjs')) failures.push('CI does not verify lockfile integrity-only refresh');
if (!/uses: actions\/checkout@v4\s+with:\s+fetch-depth: 0/.test(workflow)) failures.push('CI must fetch full Git history for the secret scan');
if (!existsSync(join(root, 'scripts/verify-lockfile-integrity-refresh.mjs'))) failures.push('Lockfile integrity refresh verifier is missing');
if (!workflow.includes('Refresh and verify lockfile integrity metadata only')) failures.push('CI lockfile integrity-only step is missing');
if (!workflow.includes('Configure resilient npm registry retries') || !workflow.includes('npm ci --no-audit --no-fund')) failures.push('CI dependency installation retry gate is missing');
if (!packageJson.scripts?.test || !packageJson.scripts?.typecheck || !packageJson.scripts?.['build:cloudflare']) {
  failures.push('Expected test, typecheck, and Cloudflare build scripts must exist');
}
console.log(`Pre-launch source audit: ${required.length} required assets checked; ${notes.length} route metadata notes.`);
for (const note of notes) console.log(`NOTE: ${note}`);
if (failures.length) {
  for (const failure of failures) console.error(`FAIL: ${failure}`);
  process.exitCode = 1;
} else {
  console.log('PASS: source-level pre-launch invariants are present. This is not a production-readiness certification.');
}
