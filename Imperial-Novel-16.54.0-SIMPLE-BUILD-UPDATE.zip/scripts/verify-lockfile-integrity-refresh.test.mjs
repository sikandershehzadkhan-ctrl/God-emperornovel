import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { spawnSync } from 'node:child_process';

const script = new URL('./verify-lockfile-integrity-refresh.mjs', import.meta.url);
const integrity = 'sha512-AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==';
function run(before, after) {
  const dir = mkdtempSync(join(tmpdir(), 'imperial-lock-integrity-'));
  try {
    const beforePath = join(dir, 'before.json');
    const afterPath = join(dir, 'after.json');
    writeFileSync(beforePath, JSON.stringify(before));
    writeFileSync(afterPath, JSON.stringify(after));
    return spawnSync(process.execPath, [script.pathname, beforePath, afterPath], { encoding: 'utf8' });
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
}

const base = { lockfileVersion: 3, packages: { '': { name: 'app' }, 'node_modules/demo': { version: '1.0.0', resolved: 'https://registry.npmjs.org/demo/-/demo-1.0.0.tgz' } } };

test('accepts registry integrity metadata added without dependency graph changes', () => {
  const after = structuredClone(base);
  after.packages['node_modules/demo'].integrity = integrity;
  const result = run(base, after);
  assert.equal(result.status, 0, result.stderr);
  assert.match(result.stdout, /dependency graph unchanged; 1 missing integrity record/);
});

test('rejects version or dependency graph drift', () => {
  const after = structuredClone(base);
  after.packages['node_modules/demo'].version = '1.0.1';
  after.packages['node_modules/demo'].integrity = integrity;
  const result = run(base, after);
  assert.notEqual(result.status, 0);
  assert.match(result.stderr, /dependency graph or non-integrity metadata/);
});

test('rejects changes to previously committed integrity', () => {
  const before = structuredClone(base);
  before.packages['node_modules/demo'].integrity = integrity;
  const after = structuredClone(before);
  after.packages['node_modules/demo'].integrity = 'sha512-BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB==';
  const result = run(before, after);
  assert.notEqual(result.status, 0);
  assert.match(result.stderr, /existing integrity metadata changed/);
});

test('rejects a registry package still missing integrity metadata', () => {
  const result = run(base, base);
  assert.notEqual(result.status, 0);
  assert.match(result.stderr, /still lack valid integrity metadata/);
});
