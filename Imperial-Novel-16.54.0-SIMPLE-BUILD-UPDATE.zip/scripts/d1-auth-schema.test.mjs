import test from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { DatabaseSync } from "node:sqlite";
import path from "node:path";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const migrationPath = path.join(root, "migrations/d1/0001_auth.sql");
const migration = await readFile(migrationPath, "utf8");
const canonicalMigration = await readFile(path.join(root, "migrations/auth/0001_auth.sql"), "utf8");

function tableColumns(db, table) {
  return db.prepare(`pragma table_info("${table}")`).all().map((row) => row.name);
}

test("D1 auth migration executes on SQLite and defines Better Auth core columns", () => {
  const db = new DatabaseSync(":memory:");
  try {
    db.exec("pragma foreign_keys = on");
    assert.doesNotThrow(() => db.exec(migration));
    const expected = {
      user: ["id", "name", "email", "emailVerified", "image", "createdAt", "updatedAt"],
      session: ["id", "expiresAt", "token", "createdAt", "updatedAt", "ipAddress", "userAgent", "userId"],
      account: ["id", "accountId", "providerId", "userId", "accessToken", "refreshToken", "idToken", "accessTokenExpiresAt", "refreshTokenExpiresAt", "scope", "password", "createdAt", "updatedAt"],
      verification: ["id", "identifier", "value", "expiresAt", "createdAt", "updatedAt"],
    };
    for (const [table, columns] of Object.entries(expected)) {
      const actual = tableColumns(db, table);
      for (const column of columns) assert.ok(actual.includes(column), `${table}.${column} is missing`);
    }
  } finally {
    db.close();
  }
});

test("D1 auth schema enforces unique email/token and cascades user deletion", () => {
  const db = new DatabaseSync(":memory:");
  try {
    db.exec("pragma foreign_keys = on");
    db.exec(migration);
    db.prepare('insert into "user" (id,name,email,"emailVerified") values (?,?,?,?)')
      .run("u1", "Reader", "reader@example.test", 0);
    db.prepare('insert into "session" (id,"expiresAt",token,"createdAt","updatedAt","userId") values (?,?,?,?,?,?)')
      .run("s1", "2030-01-01T00:00:00.000Z", "token-1", "2026-01-01T00:00:00.000Z", "2026-01-01T00:00:00.000Z", "u1");
    assert.throws(() => db.prepare('insert into "user" (id,name,email,"emailVerified") values (?,?,?,?)')
      .run("u2", "Duplicate", "reader@example.test", 0));
    assert.throws(() => db.prepare('insert into "session" (id,"expiresAt",token,"createdAt","updatedAt","userId") values (?,?,?,?,?,?)')
      .run("s2", "2030-01-01T00:00:00.000Z", "token-1", "2026-01-01T00:00:00.000Z", "2026-01-01T00:00:00.000Z", "u1"));
    db.prepare('delete from "user" where id = ?').run("u1");
    assert.equal(db.prepare('select count(*) as count from "session"').get().count, 0);
  } finally {
    db.close();
  }
});

test("D1 auth migration can be applied twice without schema errors", () => {
  const db = new DatabaseSync(":memory:");
  try {
    assert.doesNotThrow(() => db.exec(migration));
    assert.doesNotThrow(() => db.exec(migration));
  } finally {
    db.close();
  }
});

test("D1 auth schema creates lookup indexes used by sessions, accounts, and verifications", () => {
  const db = new DatabaseSync(":memory:");
  try {
    db.exec(migration);
    const indexes = new Set(
      db.prepare("select name from sqlite_master where type = 'index'").all().map((row) => row.name),
    );
    for (const name of ["session_userId_idx", "account_userId_idx", "verification_identifier_idx"]) {
      assert.ok(indexes.has(name), `missing lookup index ${name}`);
    }
  } finally {
    db.close();
  }
});

test("D1 auth schema keeps account and session foreign keys valid", () => {
  const db = new DatabaseSync(":memory:");
  try {
    db.exec("pragma foreign_keys = on");
    db.exec(migration);
    db.prepare('insert into "user" (id,name,email,"emailVerified") values (?,?,?,?)')
      .run("u1", "Reader", "reader@example.test", 0);
    db.prepare('insert into "account" (id,"accountId","providerId","userId","createdAt","updatedAt") values (?,?,?,?,?,?)')
      .run("a1", "remote-1", "grok", "u1", "2026-01-01T00:00:00.000Z", "2026-01-01T00:00:00.000Z");
    assert.throws(() => db.prepare('insert into "account" (id,"accountId","providerId","userId","createdAt","updatedAt") values (?,?,?,?,?,?)')
      .run("a2", "remote-2", "grok", "missing-user", "2026-01-01T00:00:00.000Z", "2026-01-01T00:00:00.000Z"));
    assert.deepEqual(db.prepare("pragma foreign_key_check").all(), []);
  } finally {
    db.close();
  }
});


test("D1 auth schema keeps column names in parity with the canonical Better Auth schema", () => {
  const d1 = new DatabaseSync(":memory:");
  const canonical = new DatabaseSync(":memory:");
  try {
    d1.exec(migration);
    canonical.exec(canonicalMigration);
    for (const table of ["user", "session", "account", "verification"]) {
      const d1Columns = tableColumns(d1, table).sort();
      const canonicalColumns = tableColumns(canonical, table).sort();
      assert.deepEqual(
        d1Columns,
        canonicalColumns,
        `D1 migration column drift detected for ${table}`,
      );
    }
  } finally {
    d1.close();
    canonical.close();
  }
});
