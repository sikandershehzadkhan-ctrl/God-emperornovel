#!/usr/bin/env node
/**
 * Build a temporary Cloudflare config for the isolated staging Worker.
 * Never writes to wrangler.jsonc and refuses to target the production Worker.
 */
import { writeFileSync } from "node:fs";
import { resolve } from "node:path";

const required = (name) => {
  const value = process.env[name]?.trim();
  if (!value) throw new Error(`Missing required environment variable: ${name}`);
  return value;
};

const accountId = required("CLOUDFLARE_ACCOUNT_ID");
const databaseId = required("STAGING_D1_DATABASE_ID");
const authUrl = required("STAGING_BETTER_AUTH_URL");
if (!/^[a-f0-9]{32}$/i.test(accountId)) throw new Error("CLOUDFLARE_ACCOUNT_ID must be a 32-character hex ID.");
if (!/^[a-f0-9-]{36}$/i.test(databaseId) || !/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i.test(databaseId)) {
  throw new Error("STAGING_D1_DATABASE_ID must be a UUID from the separate staging D1 database.");
}
const parsedUrl = new URL(authUrl);
if (parsedUrl.protocol !== "https:" || parsedUrl.pathname !== "/" || parsedUrl.search || parsedUrl.hash || parsedUrl.username || parsedUrl.password) {
  throw new Error("STAGING_BETTER_AUTH_URL must be an HTTPS origin only, such as https://imperial-novel-staging.example.workers.dev.");
}
if (/god-emperornovel/i.test(parsedUrl.hostname)) {
  throw new Error("Refusing to use the production Worker hostname for staging.");
}

const bootstrapAdminEmail = process.env.STAGING_BOOTSTRAP_ADMIN_EMAIL?.trim().toLowerCase();
if (bootstrapAdminEmail && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(bootstrapAdminEmail)) {
  throw new Error("STAGING_BOOTSTRAP_ADMIN_EMAIL must be a valid email address.");
}

const config = {
  "$schema": "node_modules/wrangler/config-schema.json",
  name: "imperial-novel-staging",
  main: ".output/server/index.mjs",
  account_id: accountId,
  compatibility_date: "2026-10-01",
  compatibility_flags: ["nodejs_compat"],
  vars: {
    IMPERIAL_DB: "d1",
    IMPERIAL_RUNTIME: "cloudflare",
    VITE_AUTH_ENABLED: "true",
    BETTER_AUTH_URL: parsedUrl.origin,
    ...(bootstrapAdminEmail ? { IMPERIAL_BOOTSTRAP_ADMIN_EMAIL: bootstrapAdminEmail } : {}),
  },
  assets: {
    directory: ".output/public",
    binding: "ASSETS",
    run_worker_first: true,
  },
  d1_databases: [
    {
      binding: "DB",
      database_name: "imperial-novel-staging",
      database_id: databaseId,
      migrations_dir: "migrations/d1",
    },
  ],
};

const output = resolve(process.cwd(), ".wrangler-staging.generated.json");
writeFileSync(output, `${JSON.stringify(config, null, 2)}\n`, { flag: "w", mode: 0o600 });
console.log(`Prepared isolated staging config at ${output}`);
console.log("Target: imperial-novel-staging (not production)");
