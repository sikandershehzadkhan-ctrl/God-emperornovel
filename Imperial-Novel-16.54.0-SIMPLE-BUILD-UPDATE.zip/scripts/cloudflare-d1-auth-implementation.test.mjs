import test from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const read = (name) => readFile(path.join(root, name), "utf8");

test("Cloudflare auth uses the supported Better Auth Drizzle adapter and D1 driver", async () => {
  const source = await read("src/lib/auth/cloudflare.server.ts");
  assert.match(source, /better-auth\/adapters\/drizzle/);
  assert.match(source, /drizzle-orm\/d1/);
  assert.match(source, /drizzleAdapter\(db,\s*\{\s*provider:\s*"sqlite",\s*schema:\s*d1AuthSchema\s*\}\)/);
  assert.doesNotMatch(source, /from ["']pg["']|from ["']@electric-sql\/pglite["']|from ["']node:crypto["']/);
});

test("Cloudflare auth refuses missing D1, weak secret, missing OAuth credentials, and unsafe origins", async () => {
  const source = await read("src/lib/auth/cloudflare.server.ts");
  assert.match(source, /if \(!env\.DB \|\| typeof env\.DB\.prepare !== "function"\)/);
  assert.match(source, /secret\.length < 32/);
  assert.match(source, /required\(env\.GROK_AUTH_CLIENT_ID/);
  assert.match(source, /required\(env\.GROK_AUTH_CLIENT_SECRET/);
  assert.match(source, /BETTER_AUTH_URL must use HTTPS outside local development/);
  assert.match(source, /GROK_AUTH_ISSUER must be an HTTPS origin/);
});

test("Cloudflare route has separate lazy loaders for Node and D1 auth", async () => {
  const route = await read("src/routes/api/auth/$.ts");
  const handler = await read("src/lib/auth/route-handler.ts");
  assert.match(route, /import\("@\/lib\/auth\/server"\)/);
  assert.match(route, /import\("@\/lib\/auth\/cloudflare\.server"\)/);
  assert.match(handler, /loadCloudflareAuth\(env\)/);
  assert.match(handler, /loadNodeAuth\(\)/);
});

test("D1 schema and migration have matching core tables and millisecond timestamp storage", async () => {
  const schema = await read("src/lib/auth/d1-schema.ts");
  const migration = await read("migrations/d1/0001_auth.sql");
  for (const table of ["user", "session", "account", "verification"]) {
    assert.match(schema, new RegExp(`sqliteTable\\(\\s*\\n?\\s*["']${table}["']`));
    assert.match(migration, new RegExp(`create table if not exists ["']?${table}["']?`, "i"));
  }
  assert.match(schema, /mode: "timestamp_ms"/);
  assert.match(migration, /"createdAt" integer not null/i);
  assert.match(migration, /"expiresAt" integer not null/i);
});

test("Drizzle dependency is declared and the lock resolves the same exact version", async () => {
  const pkg = JSON.parse(await read("package.json"));
  const lock = JSON.parse(await read("package-lock.json"));
  assert.equal(pkg.dependencies["drizzle-orm"], "0.45.2");
  assert.equal(lock.packages[""].dependencies["drizzle-orm"], "0.45.2");
  assert.equal(lock.packages["node_modules/drizzle-orm"].version, "0.45.2");
});


test("Cloudflare build aliases out the Node/PGLite auth server", async () => {
  const vite = await read("vite.config.ts");
  const stub = await read("src/lib/auth/cloudflare-node-auth-disabled.server.ts");
  assert.match(vite, /process\.env\.IMPERIAL_RUNTIME === "cloudflare"/);
  assert.match(vite, /find: "@\/lib\/auth\/server"/);
  assert.match(vite, /cloudflare-node-auth-disabled\.server\.ts/);
  assert.match(stub, /authUnavailableResponse\(\)/);
  assert.doesNotMatch(stub, /from ["']pg["']|from ["']@electric-sql\/pglite["']/);
});

test("Cloudflare auth uses Secure cookies on HTTPS staging and production origins", async () => {
  const source = await read("src/lib/auth/cloudflare.server.ts");
  assert.match(source, /const secureCookies = new URL\(baseURL\)\.protocol === "https:"/);
  assert.match(source, /useSecureCookies: secureCookies/);
  assert.match(source, /defaultCookieAttributes: \{ secure: secureCookies, sameSite: "lax", path: "\/" \}/);
});
