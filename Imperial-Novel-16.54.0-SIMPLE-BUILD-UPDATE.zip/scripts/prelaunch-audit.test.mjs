import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, existsSync } from 'node:fs';
import { spawnSync } from 'node:child_process';

test('pre-launch source audit passes and makes no production-readiness claim', () => {
  const result = spawnSync(process.execPath, ['scripts/prelaunch-audit.mjs'], { encoding: 'utf8' });
  assert.equal(result.status, 0, `${result.stdout}\n${result.stderr}`);
  assert.match(result.stdout, /PASS: source-level pre-launch invariants are present/);
  assert.match(result.stdout, /not a production-readiness certification/i);
});

test('visitor FAQ is included in the generated route tree and footer', () => {
  assert.ok(existsSync('src/routes/faq.tsx'));
  assert.match(readFileSync('src/routeTree.gen.ts', 'utf8'), /FaqRouteImport/);
  assert.match(readFileSync('src/components/layout/shell.tsx', 'utf8'), /to="\/faq"/);
});

test('sitemap includes public FAQ and excludes account-only routes', () => {
  const sitemap = readFileSync('public/sitemap.xml', 'utf8');
  assert.match(sitemap, /\/faq/);
  assert.doesNotMatch(sitemap, /\/(admin|profile|settings|tickets|trend-factory|read)\b/);
});


test('CI includes secret scanning, dependency advisory and lockfile drift gates', () => {
  const workflow = readFileSync('.github/workflows/imperial-novel-cloudflare.yml', 'utf8');
  assert.match(workflow, /npm run scan:secrets/);
  assert.match(workflow, /npm audit --audit-level=high/);
  assert.match(workflow, /Refresh and verify lockfile integrity metadata only/);
  assert.match(readFileSync('PRE-LAUNCH-CHECKLIST-16.42.0.md', 'utf8'), /Git-history scan/);
});


test("16.43.0 checklist documents full-history scanning and integrity-only lock refresh", () => {
  const checklist = readFileSync("PRE-LAUNCH-CHECKLIST-16.43.0.md", "utf8");
  assert.match(checklist, /fetch-depth: 0|full Git history/i);
  assert.match(checklist, /integrity metadata/i);
});


test("16.44.0 release documents HTTPS cookie hardening and external verification blockers", () => {
  const report = readFileSync("RELEASE-REPORT-16.44.0.md", "utf8");
  const checklist = readFileSync("PRE-LAUNCH-CHECKLIST-16.44.0.md", "utf8");
  assert.match(report, /Secure cookies|Secure session cookies/i);
  assert.match(report, /NOT PRODUCTION READY/);
  assert.match(checklist, /rate.?limit/i);
  assert.match(checklist, /staging/i);
});


test("16.45.0 release documents dependency recovery diagnostics and CI gates", () => {
  const report = readFileSync("RELEASE-REPORT-16.45.0.md", "utf8");
  const workflow = readFileSync(".github/workflows/imperial-novel-cloudflare.yml", "utf8");
  assert.match(report, /EAI_AGAIN registry\.npmjs\.org/);
  assert.match(workflow, /npm run check:dependencies/);
  assert.match(workflow, /npm run lint/);
});


test("16.46.0 release documents resilient npm recovery without claiming a successful install", () => {
  const report = readFileSync("RELEASE-REPORT-16.46.0.md", "utf8");
  const workflow = readFileSync(".github/workflows/imperial-novel-cloudflare.yml", "utf8");
  assert.match(report, /NOT PRODUCTION READY/);
  assert.match(workflow, /Configure resilient npm registry retries/);
  assert.match(workflow, /npm ci failed after 3 attempts/);
});


test("16.47.0 release records request-scoped D1/auth fixes without claiming production readiness", () => {
  const report = readFileSync("RELEASE-REPORT-16.47.0.md", "utf8");
  const checklist = readFileSync("PRE-LAUNCH-CHECKLIST-16.47.0.md", "utf8");
  assert.match(report, /261 passed, 0 failed/);
  assert.match(report, /request-scoped Cloudflare database and auth context/i);
  assert.match(report, /NOT PRODUCTION READY/);
  assert.match(checklist, /request identity matching/i);
});
