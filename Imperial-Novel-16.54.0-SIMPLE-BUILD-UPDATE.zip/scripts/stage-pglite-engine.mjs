#!/usr/bin/env node
/**
 * PGLite's bundled module resolves engine sidecars with
 * `new URL("./pglite.data", import.meta.url)`. Nitro renames the JS to
 * `_libs/electric-sql__pglite.mjs` and does not emit those sidecars.
 *
 * These files are the empty Postgres WASM engine (pglite.wasm, initdb.wasm,
 * pglite.data). They are not application data and are not a database dump.
 * Production with DATABASE_URL never opens them. Preview without DATABASE_URL
 * cannot boot unless they sit beside the bundled module.
 */
import { copyFileSync, existsSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const srcDir = join(root, "node_modules/@electric-sql/pglite/dist");
const destDir = join(root, ".vercel/output/functions/__server.func/_libs");
const files = ["pglite.data", "pglite.wasm", "initdb.wasm"];

export function stagePgliteEngine() {
  if (!existsSync(destDir)) {
    console.log("[pglite] server bundle not present; skip engine sidecars");
    return false;
  }
  for (const name of files) {
    const from = join(srcDir, name);
    if (!existsSync(from)) throw new Error(`Missing PGLite engine file: ${from}`);
    copyFileSync(from, join(destDir, name));
  }
  console.log("[pglite] staged WASM engine sidecars next to the server bundle");
  return true;
}

if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1]) {
  stagePgliteEngine();
}
