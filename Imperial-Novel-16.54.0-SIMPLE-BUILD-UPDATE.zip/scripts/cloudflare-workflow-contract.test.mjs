import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";

const workflow = readFileSync(
  fileURLToPath(new URL("../.github/workflows/imperial-novel-cloudflare.yml", import.meta.url)),
  "utf8",
);

test("staging deploy is restricted to main push or explicit main dispatch", () => {
  assert.match(workflow, /github\.event_name == 'push' && github\.ref == 'refs\/heads\/main'/);
  assert.match(workflow, /github\.event_name == 'workflow_dispatch' && github\.ref == 'refs\/heads\/main'/);
  assert.match(workflow, /name: Deploy to isolated staging only/);
});

test("missing staging credentials fail the release job instead of producing a false green", () => {
  assert.match(workflow, /Staging release blocked: configure all required staging GitHub secrets\/variables/);
  assert.match(workflow, /exit 1/);
  assert.doesNotMatch(workflow, /staging deployment was skipped[\s\S]{0,300}exit 0/);
});

test("staging release runs HTTP smoke checks after setting secrets", () => {
  const deploy = workflow.indexOf("npx --yes wrangler@4 deploy --config .wrangler-staging.generated.json");
  const secret = workflow.indexOf("secret put BETTER_AUTH_SECRET");
  const homepage = workflow.indexOf('"$STAGING_BETTER_AUTH_URL/"');
  const session = workflow.indexOf("/api/auth/get-session");
  assert.ok(deploy >= 0 && secret > deploy && homepage > secret && session > homepage);
  assert.match(workflow, /AUTH_STATUS.*!= "200"/);
});

test("staging workflow never names the production Worker or database as its target", () => {
  assert.doesNotMatch(workflow, /wrangler[^\n]*(god-emperornovel|god-emperornovel-db)/i);
  assert.match(workflow, /Production Worker and database were not targeted/);
});


test("secret-history scan receives full Git history in CI", () => {
  assert.match(workflow, /uses: actions\/checkout@v4\s+with:\s+fetch-depth: 0/);
  assert.match(workflow, /Scan source and repository history for high-confidence leaked secrets/);
});

test("lockfile CI refresh permits integrity additions only and rejects dependency drift", () => {
  assert.match(workflow, /Refresh and verify lockfile integrity metadata only/);
  assert.match(workflow, /verify-lockfile-integrity-refresh\.mjs/);
  assert.doesNotMatch(workflow, /if ! cmp -s.*package-lock/i);
});


test("npm registry refresh and locked install retry transient failures without dependency drift", () => {
  assert.match(workflow, /Configure resilient npm registry retries/);
  assert.match(workflow, /fetch-retries 4/);
  assert.match(workflow, /for attempt in 1 2 3/);
  assert.match(workflow, /npm ci --no-audit --no-fund/);
  assert.match(workflow, /refusing to run build\/tests on an incomplete environment/);
});
