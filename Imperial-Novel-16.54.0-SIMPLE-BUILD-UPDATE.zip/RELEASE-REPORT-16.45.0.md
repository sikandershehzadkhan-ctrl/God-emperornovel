# Imperial Novel 16.45.0 — Dependency Recovery Diagnostics

## Changes made
- Added `scripts/verify-dependencies.mjs` and regression tests to check that critical direct dependencies are installed at the versions in `package-lock.json`.
- Added `npm run check:dependencies`.
- GitHub Actions now runs the dependency check after `npm ci` and includes ESLint in CI.
- Updated application and seed version markers to 16.45.0.

## Verified in this workspace
- `jose@6.2.9` and `@tanstack/react-start@1.168.60` are declared in `package.json` and locked in `package-lock.json`.
- The packages are not installed in the current workspace.
- `npm view jose@6.2.9` fails with `EAI_AGAIN registry.npmjs.org`; the registry cannot be resolved from this environment. Therefore `npm ci` cannot complete here.
- `node --test 'scripts/**/*.test.mjs'`: **257 passed, 0 failed** (includes the new dependency-check tests).
- `node --experimental-sqlite --test scripts/d1-auth-schema.test.mjs`: **6 passed, 0 failed**.
- `npm run audit:prelaunch`: **26 required assets checked, 0 route metadata notes; pass**.
- `node scripts/verify-dependencies.mjs` correctly fails closed and lists all six missing packages.
- `npm test`: script tests **257 passed, 0 failed**; D1 schema tests **6 passed, 0 failed**; runtime/database phase **41 passed, 2 test modules failed to load** because `@tanstack/react-start` and `jose` are not installed.
- `npm run typecheck` fails because `@types/node` and `vite/client` are not installed; `npm run lint` fails because `eslint` is not installed; `npm run build:cloudflare` fails because `vite` is not installed.
- `npm audit --audit-level=high` cannot reach the npm audit endpoint and fails with `EAI_AGAIN registry.npmjs.org`.
- A fresh `npm ci --no-audit --no-fund --fetch-retries=0 --fetch-timeout=12000` attempt fails with `EAI_AGAIN registry.npmjs.org`. This confirms the remaining blocker is registry DNS/network access, not absent package declarations.

## Not verified / blocked
- A successful full dependency installation, full `npm test`, typecheck, lint, dependency audit, and Cloudflare build remain blocked until npm registry access works.
- Cloudflare staging/account prerequisites remain separate requirements.

## Safety
No GitHub push, production deployment, production D1 migration, or remote credential change was performed. The live Worker and production database remain untouched.

**Decision: NOT PRODUCTION READY.** This release adds a reliable diagnosis and CI gate; it does not falsely label the missing dependency installation as fixed.
