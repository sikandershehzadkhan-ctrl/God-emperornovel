# Imperial Novel 16.32.2 — Contrast and accessibility update

## Contrast work completed
- Primary CTA gradient `#5b21b6 → #4f46e5 → #1d4ed8`: white-label contrast at the stops is 8.59:1, 6.01:1, and 6.41:1.
- Explore CTA gradient `#047857 → #065f46`: white-label contrast at the stops is 5.24:1 and 7.34:1.
- Cookie consent primary gradient `#6d28d9 → #1d4ed8`: white-label contrast at the stops is 6.79:1 and 6.41:1.
- Secondary text `#aab6cc` on canvas `#050814` is 9.77:1.
- Muted text `#b7c0d4` on surface `#101628` is 9.85:1.
- Cyan focus ring `#22d3ee` on canvas `#050814` is 11.05:1.
- High-contrast mode strengthens text and boundary tokens.
- Automated test command: `node --test scripts/a11y-color-contrast.test.mjs`. Result: 10 passed.

These ratios are computed for listed authored colors. This is not a complete WCAG certification or rendered-page audit. Translucent layers, images, overlays, disabled states, and all individual routes still require browser-based inspection.

## Release status unchanged
This contrast update does not resolve Better Auth + D1 compatibility. Full typecheck/build and generated Worker smoke test remain unverified. No staging deployment or production changes were performed.
