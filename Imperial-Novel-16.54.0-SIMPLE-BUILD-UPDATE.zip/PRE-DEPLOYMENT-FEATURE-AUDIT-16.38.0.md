# Imperial Novel — Pre-deployment feature audit (16.38.0 audit pass)

**Date:** 2026-10-12  
**Baseline inspected:** source snapshot packaged as 16.37.2  
**Status:** Audit pass only. This is not a deployment approval or a claim that all selected features are complete.

## Executive finding

The source has substantial existing routes and server functions, but several critical workflows are incomplete or not safe to certify. The first implementation work should address database/authentication readiness and financial atomicity before adding more user-facing functionality.

## Findings from source inspection

### P0 — release blockers

1. **Cloudflare authentication is not certified.** The prior 16.37.1/16.37.2 reports explicitly state that the full dependency-backed typecheck/build and hosted Better Auth + D1 lifecycle have not been run. A staging database ID is still an external prerequisite. Keep production untouched.
2. **First-account administrator bootstrap is race-prone.** `src/lib/imperial/db.ts` checks whether any admin exists, then separately inserts a profile assigning admin to the first user. Two concurrent first sign-ins can both observe no admin. Replace with an explicit, one-time bootstrap mechanism and database-safe claim before production.
3. **Ticket-credit workflows span multiple independent SQL statements.** `src/lib/imperial/admin.ts` changes a donation from pending to approved, then separately credits the profile, writes a ledger entry and sends a notification. If a later operation fails, the status can be approved without the corresponding credit/ledger record. The `Sql` interface in `src/lib/db.ts` exposes single statements but no transaction/batch API. This must be resolved with a backend-compatible atomic design and failure-injection tests.
4. **Chapter unlock charging is not atomic.** `src/lib/imperial/reader.ts` checks for an existing unlock, debits tickets, inserts the unlock and writes the ledger separately. `batchUnlock` similarly inserts multiple unlock rows and debits in separate statements. Concurrent requests or mid-flow errors can create inconsistent balances/ledger state. Do not certify paid chapter unlocks until this is atomic/idempotent on both Postgres and Cloudflare D1.

### P1 — selected features not implemented or not demonstrated

5. **Trend Factory workflow is absent as a dedicated route/module.** The current route inventory includes `/trending` but no `/trend-factory` route. Search and connector request/import-queue primitives are not the full editorial workflow. Build the requested sequence: Trend → Analyze → Discover Author → Invite/Create → Rights Review → Review → Publish.
6. **OmniPortal currently reports local search only.** `src/lib/imperial/omni.ts` returns `searched_connectors: 0` and only `Imperial Novel` as provider in `omniSearch`. Connector request and import-job functions exist, but a functioning external provider pipeline is not demonstrated. Keep connectors disabled until authorization and rights gates are real.
7. **AI writing capability is not established by source evidence.** No production-ready AI provider/key/backend path was verified in this pass. The Author Studio must show a clear unavailable/configuration-required state unless a real provider is configured server-side.
8. **Payment-to-ticket conversion needs a documented rule.** `adminReviewDonation` currently computes `max(1, round(PKR amount / 20))`, while the ticket UI exposes packs `[10,25,50,100]`. Confirm and document the exact conversion before enabling payment crediting; do not silently change existing financial semantics during an audit-only pass.
9. **Rights publication validation is too coarse to certify.** `adminSetPublication` checks `rights_status` against allowed labels but does not itself verify meaningful evidence, review history, or a separate approval record. Add evidence and audit gates appropriate to original, public-domain, licensed and authorized works.

### P2 — complete during feature hardening

10. Reader, bookmarks, history, library and Author Studio routes exist, but end-to-end persistence, theme preference persistence, save recovery, chapter navigation and cross-account isolation need browser/staging tests.
11. Community code contains ratings, comments/likes and notifications; test duplicate voting/liking, moderation, abuse controls, ownership and real-data ranking behavior.
12. Mobile checks in prior reports are not a complete rendered-route/performance audit. Test on 390×844 and a narrow Android viewport, slow network, reduced-motion mode, no horizontal overflow, no console errors, and no private-data cache leakage.
13. Monetag, patronage, ticket accounting and author earnings must remain separate systems. Monetag is the only permitted third-party ad network under the current product requirements.

## Implementation order

1. **Foundation:** install dependencies from a network-enabled CI environment, verify lockfile integrity, pass typecheck/full test suite/Cloudflare build; resolve Better Auth + D1 and request isolation.
2. **Financial correctness:** add backend-compatible transaction/batch semantics; make donation approval, ticket debit, unlock, ledger and notification operations atomic/idempotent; define ticket conversion; test failures and concurrent duplicate requests.
3. **Administrator bootstrap and permissions:** replace first-user race with explicit bootstrap configuration; audit server-side role checks, account recovery, sessions, CSRF/origin policy, rate limits and audit trails.
4. **Core reader and author flows:** complete end-to-end persistence and ownership tests before UI expansion.
5. **Community + Trend Factory:** complete moderation and implement the rights-first editorial state machine.
6. **AI + OmniPortal:** add only real, server-side configured provider functionality; connectors off until approved.
7. **Mobile/performance and release:** route-by-route responsive checks, accessibility, staging migration/rollback drill and written go/no-go review.

## Required staging tests

- Concurrent first-account bootstrap attempts result in exactly one explicitly authorized admin.
- Two simultaneous reviews of the same donation credit tickets exactly once.
- Injected failures at every point in donation approval leave status, profile balance, ledger and notification consistent.
- Two simultaneous chapter unlock requests debit exactly once; repeated batch unlock is idempotent.
- Negative, zero, fractional, excessively large and malformed payment submissions are rejected according to a documented payment policy.
- User cannot view or mutate another user's library, progress, author drafts, transactions or notification records.
- Unapproved rights status/evidence cannot publish; no external chapter-body ingestion occurs.
- Connector and AI calls fail closed when not configured or authorized.
- Auth registration, login, session persistence, expiry/revocation, sign-out and request-scoped D1 isolation work in a generated staging Worker.
- Typecheck, complete tests, Cloudflare build, migration idempotency, mobile smoke and rollback rehearsal all pass.

## Safety boundary

This pass did not modify runtime application code, production resources, production data, GitHub, Cloudflare secrets, or deployment settings. It adds an audit/roadmap document only. Do not deploy based on this audit package.
