# Imperial Novel 16.37.2 — GitHub and Cloudflare staging automation

## Delivered

- `.github/workflows/imperial-novel-cloudflare.yml`: CI on pull requests/pushes to `main`, Cloudflare build, and staging-only deploy step after successful checks.
- `scripts/prepare-cloudflare-staging-config.mjs`: creates a temporary config for `imperial-novel-staging`, validates the account and D1 IDs, requires an HTTPS staging origin, and rejects the known production hostname.
- `scripts/prepare-cloudflare-staging-config.test.mjs`: covers generated config, production hostname rejection, and placeholder D1 ID rejection.
- `GITHUB-CLOUDFLARE-AUTOMATION.md`: setup guide and required Actions secrets/variables.

## Checks run in this environment

- Combined staging-config, Cloudflare readiness, auth-route, and source regression tests: 21 passed, 0 failed (including 3 staging-config safety tests).
- Workflow file and script source added; archive integrity is checked at packaging time.

## Not claimed

- No GitHub push was made because no GitHub repository write connector is available.
- No Cloudflare resource was created, no secret was configured, and no Worker was deployed.
- The full npm install, TypeScript check, Cloudflare build, and hosted staging authentication lifecycle have not been run here. The workflow is designed to run those checks in GitHub Actions; it will stop before deploy if CI/build fails or npm metadata refresh cannot complete.
- Production is deliberately excluded from automated deployment.

## Activation requirements

Push the package contents to the existing GitHub repository and configure the secrets/variables listed in `GITHUB-CLOUDFLARE-AUTOMATION.md`. Pushes to `main` then trigger verification and, if the required staging settings exist, deployment to the isolated staging Worker only.
