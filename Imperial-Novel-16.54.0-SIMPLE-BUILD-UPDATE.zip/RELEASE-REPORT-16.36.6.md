# Imperial Novel 16.36.6 — D1 Authentication Schema Drift Guard

## Scope

This release adds a local regression guard comparing the D1 authentication migration against the canonical Better Auth migration. It is deliberately a schema-verification release, not an authentication-adapter release.

## Changes

- Added an executable test that applies `migrations/auth/0001_auth.sql` and `migrations/d1/0001_auth.sql` independently in in-memory SQLite databases and compares exact column names for `user`, `session`, `account`, and `verification`.
- Added `npm run check:d1-auth-schema-parity` for a focused preflight.
- Documented the parity check and its limitations in `CLOUDFLARE.md`.
- Kept Cloudflare authentication fail-closed. No adapter was falsely declared ready.

## Verification performed

- Script test suite: **224 passed, 0 failed**.
- SQLite D1 auth schema suite: **6 passed, 0 failed**.
- Focused auth-route, runtime, D1 adapter-contract, request-context, and middleware tests: **19 passed, 0 failed**.
- Focused schema parity command: **1 passed, 0 failed**.
- Package JSON syntax: passed.
- ZIP integrity: checked after packaging.

The 224 script tests, six SQLite schema tests, and 19 focused runtime tests were run in separate commands. The parity test is included in the six schema tests and is also run separately as a focused check, so do not add that repeated test to the unique-test total. Unique test count across those suites: **249 passed, 0 failed**.

## Cloudflare readiness status

The read-only readiness check remains **4/6 source checks passed**, with two blockers:

1. `wrangler.jsonc` still uses `REPLACE_WITH_STAGING_D1_ID`; a separate staging D1 database must be created and its real ID supplied.
2. Better Auth still uses the Postgres/PGLite setup. The experimental Kysely bridge is not a Better Auth adapter, and interactive transactions are intentionally unsupported. The Cloudflare auth route must remain closed until a supported persistent adapter and complete auth lifecycle are verified.

## Not verified / not performed

- Full application typecheck and Cloudflare build were not run because project dependencies are not installed in this environment.
- No Cloudflare staging deployment was performed.
- No GitHub push was performed.
- The live Worker `god-emperornovel` and production D1 database `god-emperornovel-db` were not modified.
