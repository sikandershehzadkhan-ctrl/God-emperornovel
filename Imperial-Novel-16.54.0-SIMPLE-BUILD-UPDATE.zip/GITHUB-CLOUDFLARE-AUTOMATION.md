# Imperial Novel 16.37.2 — GitHub to Cloudflare staging automation

This package adds GitHub Actions automation for **CI plus the isolated staging Worker only**. It does not deploy to the production Worker `god-emperornovel` and does not use the production D1 database `god-emperornovel-db`.

## What the workflow does

- Runs on pull requests to `main`, pushes to `main`, and manual workflow dispatch.
- Refreshes npm lock metadata from the registry before `npm ci`; if registry access is unavailable, the workflow fails before deployment.
- Runs the project tests, staging-config safety tests, TypeScript typecheck, and Cloudflare build.
- On a push to `main`, deploys only to `imperial-novel-staging`, and only if the required GitHub secrets and variable are configured. If those settings are absent, CI/build can still finish and the staging deployment step reports that it was skipped.
- Generates a temporary staging Wrangler config and refuses the known production Worker hostname. The generated config is ignored by Git and never overwrites `wrangler.jsonc`.
- Applies only the staging D1 migrations under `migrations/d1`.

## Configure GitHub once

In the existing repository `sikandershehzadkhan-ctrl/God-emperornovel`, open **Settings → Secrets and variables → Actions**.

Add these repository secrets:

- `CLOUDFLARE_API_TOKEN`: a Cloudflare API token scoped to the correct account with Workers Scripts edit, D1 edit, and required account read permissions.
- `CLOUDFLARE_ACCOUNT_ID`: the Cloudflare account ID (32 hexadecimal characters).
- `STAGING_D1_DATABASE_ID`: the ID of a newly created D1 database named `imperial-novel-staging`. Do not use the production database ID.
- `STAGING_BETTER_AUTH_SECRET`: a unique random secret of at least 32 characters for staging only.
- `STAGING_GROK_AUTH_CLIENT_ID`: OAuth client ID authorized for the staging callback URL.
- `STAGING_GROK_AUTH_CLIENT_SECRET`: matching OAuth client secret.

Add these Actions variables:

- `STAGING_BETTER_AUTH_URL`: the HTTPS origin of the staging Worker, without a path or trailing route, for example `https://imperial-novel-staging.<your-account-subdomain>.workers.dev`.
- `STAGING_GROK_AUTH_ISSUER` (optional): the HTTPS issuer origin, if different from the source default.

The staging OAuth provider must allow the correct callback URL for the staging origin. Never copy production secrets into staging without reviewing their allowed origins/callbacks.

## How to activate it from mobile

1. Download the 16.37.2 ZIP and extract it.
2. Add the ZIP's **contents** to the existing repository, preserving existing source files. Do not upload only the ZIP as a single file and expect GitHub to deploy its contents.
3. Commit/push the updated contents to `main` only after reviewing the diff. GitHub Actions will then run CI and, when all checks pass and the staging settings exist, deploy the staging Worker.
4. Open the repository's **Actions** tab to inspect the workflow result and deployment logs.
5. Test the staging URL, registration/sign-in, OAuth callback, session persistence, sign-out, and key existing routes before considering production.

## Production is intentionally not automated

There is no production deployment job in this workflow. Once staging has passed end-to-end tests, production deployment should be configured as a separate, explicit release workflow with approval and a reviewed production configuration. This prevents a routine push from replacing the live website before D1 authentication is verified.

## Honest limitations

This environment cannot push to the GitHub repository, create Cloudflare resources, or configure repository secrets. The workflow is included in source, but it becomes active only after its contents are pushed to GitHub and the account owner configures the required secrets/variables. The first hosted workflow run is the authoritative test of the real npm install, full build, and staging deploy.
