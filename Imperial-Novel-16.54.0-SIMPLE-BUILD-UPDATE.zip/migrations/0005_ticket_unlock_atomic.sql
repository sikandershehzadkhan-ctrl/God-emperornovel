-- Ticket debits are coupled to unlock inserts so a failed or concurrent unlock
-- cannot debit without granting access, or grant access without a debit.
CREATE OR REPLACE FUNCTION imperial_apply_unlock_ticket_debit()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  IF NEW.cost < 0 OR NEW.cost <> trunc(NEW.cost) THEN
    RAISE EXCEPTION 'Ticket cost must be a non-negative whole number';
  END IF;
  UPDATE profiles
     SET tickets = tickets - NEW.cost
   WHERE user_id = NEW.user_id
     AND tickets >= NEW.cost;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Not enough tickets or profile missing';
  END IF;
  INSERT INTO ticket_ledger (user_id, delta, reason, reference)
  VALUES (NEW.user_id, -NEW.cost, 'unlock', 'chapter:' || NEW.chapter_id::text);
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS imperial_unlock_ticket_debit ON unlocks;
CREATE TRIGGER imperial_unlock_ticket_debit
AFTER INSERT ON unlocks
FOR EACH ROW EXECUTE FUNCTION imperial_apply_unlock_ticket_debit();
