-- Additive library shelves. Existing rows default to reading.
alter table user_library add column if not exists shelf text not null default 'reading';
alter table user_library add column if not exists favorite boolean not null default false;

do $$
begin
  if not exists (
    select 1 from pg_constraint where conname = 'user_library_shelf_check'
  ) then
    alter table user_library
      add constraint user_library_shelf_check
      check (shelf in ('reading', 'completed', 'dropped'));
  end if;
end $$;
