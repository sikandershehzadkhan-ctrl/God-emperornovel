-- Imperial Novel schema (Postgres / PGLite). Additive, idempotent.

create table if not exists profiles (
  user_id text primary key,
  username text not null unique,
  role text not null default 'user' check (role in ('user','author','moderator','admin')),
  tickets numeric not null default 0,
  verified boolean not null default false,
  banned boolean not null default false,
  bio text not null default '',
  created_at timestamptz not null default now()
);

create table if not exists novels (
  id serial primary key,
  title text not null,
  slug text not null unique,
  alt_titles text not null default '',
  author text not null,
  description text not null default '',
  status text not null default 'ongoing',
  kind text not null default 'original',
  language text not null default 'English',
  cover_url text not null default '',
  source_url text not null default '',
  rights_status text not null default 'original',
  views integer not null default 0,
  rating numeric not null default 0,
  owner_user_id text,
  publication_status text not null default 'draft',
  rights_evidence text not null default '',
  rights_notes text not null default '',
  review_feedback text not null default '',
  featured boolean not null default false,
  category text not null default 'original-fiction',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists chapters (
  id serial primary key,
  novel_id integer not null references novels(id) on delete cascade,
  chapter_number integer not null,
  title text not null,
  content text not null,
  is_locked boolean not null default false,
  ticket_cost numeric not null default 0,
  publication_status text not null default 'draft',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (novel_id, chapter_number)
);

create table if not exists genres (
  id serial primary key,
  name text not null unique,
  slug text not null unique,
  category text not null default 'literary'
);

create table if not exists tags (
  id serial primary key,
  name text not null unique,
  slug text not null unique
);

create table if not exists novel_genres (
  novel_id integer not null references novels(id) on delete cascade,
  genre_id integer not null references genres(id) on delete cascade,
  primary key (novel_id, genre_id)
);

create table if not exists novel_tags (
  novel_id integer not null references novels(id) on delete cascade,
  tag_id integer not null references tags(id) on delete cascade,
  primary key (novel_id, tag_id)
);

create table if not exists user_library (
  user_id text not null,
  novel_id integer not null references novels(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, novel_id)
);

create table if not exists bookmarks (
  user_id text not null,
  novel_id integer not null references novels(id) on delete cascade,
  chapter_number integer not null default 1,
  updated_at timestamptz not null default now(),
  primary key (user_id, novel_id)
);

create table if not exists history (
  user_id text not null,
  novel_id integer not null references novels(id) on delete cascade,
  chapter_number integer not null,
  updated_at timestamptz not null default now(),
  primary key (user_id, novel_id)
);

create table if not exists follows (
  user_id text not null,
  novel_id integer not null references novels(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, novel_id)
);

create table if not exists ratings (
  user_id text not null,
  novel_id integer not null references novels(id) on delete cascade,
  rating integer not null check (rating between 1 and 5),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  primary key (user_id, novel_id)
);

create table if not exists comments (
  id serial primary key,
  user_id text not null,
  novel_id integer not null references novels(id) on delete cascade,
  parent_id integer,
  body text not null,
  status text not null default 'visible',
  created_at timestamptz not null default now()
);

create table if not exists comment_likes (
  user_id text not null,
  comment_id integer not null references comments(id) on delete cascade,
  primary key (user_id, comment_id)
);

create table if not exists unlocks (
  user_id text not null,
  chapter_id integer not null references chapters(id) on delete cascade,
  cost numeric not null,
  unlocked_at timestamptz not null default now(),
  primary key (user_id, chapter_id)
);

create table if not exists ticket_ledger (
  id serial primary key,
  user_id text not null,
  delta numeric not null,
  reason text not null,
  reference text not null default '',
  created_at timestamptz not null default now()
);

create table if not exists donations (
  id serial primary key,
  user_id text not null,
  amount numeric not null,
  reference_id text not null unique,
  status text not null default 'pending',
  created_at timestamptz not null default now()
);

create table if not exists notifications (
  id serial primary key,
  user_id text not null,
  title text not null,
  body text not null,
  read_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists novel_requests (
  id serial primary key,
  user_id text not null,
  title text not null default '',
  url text not null,
  source_host text not null,
  week_key integer not null,
  cost numeric not null default 0,
  status text not null default 'pending',
  created_at timestamptz not null default now()
);

create table if not exists request_votes (
  request_id integer not null references novel_requests(id) on delete cascade,
  user_id text not null,
  created_at timestamptz not null default now(),
  primary key (request_id, user_id)
);

create table if not exists reports (
  id serial primary key,
  user_id text,
  novel_id integer,
  chapter_id integer,
  comment_id integer,
  reason text not null,
  details text not null default '',
  status text not null default 'open',
  created_at timestamptz not null default now()
);

create table if not exists connectors (
  id serial primary key,
  name text not null,
  base_url text not null unique,
  type text not null default 'registry',
  enabled boolean not null default false,
  rights_status text not null default 'pending',
  last_status text not null default 'registry',
  last_checked_at timestamptz,
  rights_evidence_url text not null default '',
  terms_url text not null default '',
  rights_notes text not null default '',
  created_at timestamptz not null default now()
);

create table if not exists import_jobs (
  id serial primary key,
  user_id text,
  connector_id integer references connectors(id) on delete set null,
  source_url text not null,
  status text not null default 'queued',
  message text not null default 'Queued for authorized metadata import. No source chapters will be copied.',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists connector_auth_requests (
  id serial primary key,
  connector_id integer not null references connectors(id) on delete cascade,
  user_id text not null,
  evidence_url text not null default '',
  terms_url text not null default '',
  notes text not null default '',
  status text not null default 'pending',
  created_at timestamptz not null default now()
);

create table if not exists ai_projects (
  id serial primary key,
  owner_user_id text not null,
  novel_id integer references novels(id) on delete set null,
  name text not null,
  mode text not null default 'manual',
  status text not null default 'draft',
  genre text not null default '',
  premise text not null default '',
  protagonist text not null default '',
  bible_json text not null default '{}',
  chapters_target integer not null default 10,
  chapters_generated integer not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists ai_jobs (
  id serial primary key,
  project_id integer not null references ai_projects(id) on delete cascade,
  owner_user_id text not null,
  tool text not null,
  status text not null default 'ok',
  prompt text not null default '',
  result text not null default '',
  provider text not null default 'xai',
  created_at timestamptz not null default now()
);

create table if not exists audit_logs (
  id serial primary key,
  user_id text,
  action text not null,
  details text not null default '',
  created_at timestamptz not null default now()
);

create table if not exists app_settings (
  key text primary key,
  value text not null
);

create index if not exists idx_novels_pub on novels (publication_status, updated_at desc);
create index if not exists idx_novels_views on novels (views desc);
create index if not exists idx_chapters_novel on chapters (novel_id, publication_status, chapter_number);
create index if not exists idx_history_user on history (user_id, updated_at desc);
create index if not exists idx_notifications_user on notifications (user_id, created_at desc);
create index if not exists idx_comments_novel on comments (novel_id, created_at);
create index if not exists idx_donations_status on donations (status);
create index if not exists idx_ledger_user on ticket_ledger (user_id, created_at desc);
