-- Imperial Novel schema for a NEW staging D1 database.
-- Includes library shelves and the view log. Do not apply to production D1.
-- Postgres migrations in ../ stay the source for PGLite and Neon.

create table if not exists profiles (
  user_id text primary key,
  username text not null unique,
  role text not null default 'user' check (role in ('user','author','moderator','admin')),
  tickets real not null default 0,
  verified integer not null default 0,
  banned integer not null default 0,
  bio text not null default '',
  created_at text not null default (datetime('now'))
);

create table if not exists novels (
  id integer primary key,
  title text not null,
  slug text not null unique,
  alt_titles text not null default '',
  author text not null,
  description text not null default '',
  status text not null default 'ongoing',
  kind text not null default 'original',
  language text not null default 'English',
  cover_url text not null default '',
  source_url text not null default '',
  rights_status text not null default 'original',
  views integer not null default 0,
  rating real not null default 0,
  owner_user_id text,
  publication_status text not null default 'draft',
  rights_evidence text not null default '',
  rights_notes text not null default '',
  review_feedback text not null default '',
  featured integer not null default 0,
  category text not null default 'original-fiction',
  created_at text not null default (datetime('now')),
  updated_at text not null default (datetime('now'))
);

create table if not exists chapters (
  id integer primary key,
  novel_id integer not null references novels(id) on delete cascade,
  chapter_number integer not null,
  title text not null,
  content text not null,
  is_locked integer not null default 0,
  ticket_cost real not null default 0,
  publication_status text not null default 'draft',
  created_at text not null default (datetime('now')),
  updated_at text not null default (datetime('now')),
  unique (novel_id, chapter_number)
);

create table if not exists genres (
  id integer primary key,
  name text not null unique,
  slug text not null unique,
  category text not null default 'literary'
);

create table if not exists tags (
  id integer primary key,
  name text not null unique,
  slug text not null unique
);

create table if not exists novel_genres (
  novel_id integer not null references novels(id) on delete cascade,
  genre_id integer not null references genres(id) on delete cascade,
  primary key (novel_id, genre_id)
);

create table if not exists novel_tags (
  novel_id integer not null references novels(id) on delete cascade,
  tag_id integer not null references tags(id) on delete cascade,
  primary key (novel_id, tag_id)
);

create table if not exists user_library (
  user_id text not null,
  novel_id integer not null references novels(id) on delete cascade,
  shelf text not null default 'reading' check (shelf in ('reading', 'completed', 'dropped')),
  favorite integer not null default 0,
  created_at text not null default (datetime('now')),
  primary key (user_id, novel_id)
);

create table if not exists bookmarks (
  user_id text not null,
  novel_id integer not null references novels(id) on delete cascade,
  chapter_number integer not null default 1,
  updated_at text not null default (datetime('now')),
  primary key (user_id, novel_id)
);

create table if not exists history (
  user_id text not null,
  novel_id integer not null references novels(id) on delete cascade,
  chapter_number integer not null,
  updated_at text not null default (datetime('now')),
  primary key (user_id, novel_id)
);

create table if not exists follows (
  user_id text not null,
  novel_id integer not null references novels(id) on delete cascade,
  created_at text not null default (datetime('now')),
  primary key (user_id, novel_id)
);

create table if not exists ratings (
  user_id text not null,
  novel_id integer not null references novels(id) on delete cascade,
  rating integer not null check (rating between 1 and 5),
  created_at text not null default (datetime('now')),
  updated_at text not null default (datetime('now')),
  primary key (user_id, novel_id)
);

create table if not exists comments (
  id integer primary key,
  user_id text not null,
  novel_id integer not null references novels(id) on delete cascade,
  parent_id integer,
  body text not null,
  status text not null default 'visible',
  created_at text not null default (datetime('now'))
);

create table if not exists comment_likes (
  user_id text not null,
  comment_id integer not null references comments(id) on delete cascade,
  primary key (user_id, comment_id)
);

create table if not exists unlocks (
  user_id text not null,
  chapter_id integer not null references chapters(id) on delete cascade,
  cost real not null,
  unlocked_at text not null default (datetime('now')),
  primary key (user_id, chapter_id)
);

create table if not exists ticket_ledger (
  id integer primary key,
  user_id text not null,
  delta real not null,
  reason text not null,
  reference text not null default '',
  created_at text not null default (datetime('now'))
);

create table if not exists donations (
  id integer primary key,
  user_id text not null,
  amount real not null,
  reference_id text not null unique,
  status text not null default 'pending',
  created_at text not null default (datetime('now'))
);

create table if not exists notifications (
  id integer primary key,
  user_id text not null,
  title text not null,
  body text not null,
  read_at text,
  created_at text not null default (datetime('now'))
);

create table if not exists novel_requests (
  id integer primary key,
  user_id text not null,
  title text not null default '',
  url text not null,
  source_host text not null,
  week_key integer not null,
  cost real not null default 0,
  status text not null default 'pending',
  created_at text not null default (datetime('now'))
);

create table if not exists request_votes (
  request_id integer not null references novel_requests(id) on delete cascade,
  user_id text not null,
  created_at text not null default (datetime('now')),
  primary key (request_id, user_id)
);

create table if not exists reports (
  id integer primary key,
  user_id text,
  novel_id integer,
  chapter_id integer,
  comment_id integer,
  reason text not null,
  details text not null default '',
  status text not null default 'open',
  created_at text not null default (datetime('now'))
);

create table if not exists connectors (
  id integer primary key,
  name text not null,
  base_url text not null unique,
  type text not null default 'registry',
  enabled integer not null default 0,
  rights_status text not null default 'pending',
  last_status text not null default 'registry',
  last_checked_at text,
  rights_evidence_url text not null default '',
  terms_url text not null default '',
  rights_notes text not null default '',
  created_at text not null default (datetime('now'))
);

create table if not exists import_jobs (
  id integer primary key,
  user_id text,
  connector_id integer references connectors(id) on delete set null,
  source_url text not null,
  status text not null default 'queued',
  message text not null default 'Queued for authorized metadata import. No source chapters will be copied.',
  created_at text not null default (datetime('now')),
  updated_at text not null default (datetime('now'))
);

create table if not exists connector_auth_requests (
  id integer primary key,
  connector_id integer not null references connectors(id) on delete cascade,
  user_id text not null,
  evidence_url text not null default '',
  terms_url text not null default '',
  notes text not null default '',
  status text not null default 'pending',
  created_at text not null default (datetime('now'))
);

create table if not exists ai_projects (
  id integer primary key,
  owner_user_id text not null,
  novel_id integer references novels(id) on delete set null,
  name text not null,
  mode text not null default 'manual',
  status text not null default 'draft',
  genre text not null default '',
  premise text not null default '',
  protagonist text not null default '',
  bible_json text not null default '{}',
  chapters_target integer not null default 10,
  chapters_generated integer not null default 0,
  created_at text not null default (datetime('now')),
  updated_at text not null default (datetime('now'))
);

create table if not exists ai_jobs (
  id integer primary key,
  project_id integer not null references ai_projects(id) on delete cascade,
  owner_user_id text not null,
  tool text not null,
  status text not null default 'ok',
  prompt text not null default '',
  result text not null default '',
  provider text not null default 'xai',
  created_at text not null default (datetime('now'))
);

create table if not exists audit_logs (
  id integer primary key,
  user_id text,
  action text not null,
  details text not null default '',
  created_at text not null default (datetime('now'))
);

create table if not exists app_settings (
  key text primary key,
  value text not null
);

create table if not exists view_events (
  id integer primary key,
  novel_id integer not null references novels(id) on delete cascade,
  created_at text not null default (datetime('now'))
);

create index if not exists idx_novels_pub on novels (publication_status, updated_at desc);
create index if not exists idx_novels_views on novels (views desc);
create index if not exists idx_chapters_novel on chapters (novel_id, publication_status, chapter_number);
create index if not exists idx_history_user on history (user_id, updated_at desc);
create index if not exists idx_notifications_user on notifications (user_id, created_at desc);
create index if not exists idx_comments_novel on comments (novel_id, created_at);
create index if not exists idx_donations_status on donations (status);
create index if not exists idx_ledger_user on ticket_ledger (user_id, created_at desc);
create index if not exists view_events_created_idx on view_events (created_at);
create index if not exists view_events_novel_created_idx on view_events (novel_id, created_at);
