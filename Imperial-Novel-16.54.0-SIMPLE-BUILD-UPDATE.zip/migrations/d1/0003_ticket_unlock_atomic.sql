-- D1/SQLite equivalent of migrations/0005_ticket_unlock_atomic.sql.
-- The trigger is part of the same statement transaction as the unlock insert.
CREATE TRIGGER IF NOT EXISTS imperial_unlock_ticket_debit
AFTER INSERT ON unlocks
BEGIN
  SELECT CASE WHEN NEW.cost < 0 OR NEW.cost != CAST(NEW.cost AS INTEGER)
    THEN RAISE(ABORT, 'Ticket cost must be a non-negative whole number') END;
  UPDATE profiles
     SET tickets = tickets - NEW.cost
   WHERE user_id = NEW.user_id
     AND tickets >= NEW.cost;
  SELECT CASE WHEN changes() = 0
    THEN RAISE(ABORT, 'Not enough tickets or profile missing') END;
  INSERT INTO ticket_ledger (user_id, delta, reason, reference)
  VALUES (NEW.user_id, -NEW.cost, 'unlock', 'chapter:' || NEW.chapter_id);
END;
