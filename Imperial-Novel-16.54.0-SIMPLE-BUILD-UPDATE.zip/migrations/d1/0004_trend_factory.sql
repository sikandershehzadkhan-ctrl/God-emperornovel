-- Rights-first Trend Factory. Metadata only; source chapter bodies are never ingested.
CREATE TABLE IF NOT EXISTS trend_candidates (
  id integer PRIMARY KEY,
  trend_title text NOT NULL,
  trend_url text NOT NULL UNIQUE,
  source_host text NOT NULL,
  trend_signal text NOT NULL DEFAULT '',
  stage text NOT NULL DEFAULT 'trend' CHECK (stage IN ('trend','analyzed','author_discovered','invite_ready','rights_review','review','linked_to_novel','published','rejected')),
  author_name text NOT NULL DEFAULT '',
  author_profile_url text NOT NULL DEFAULT '',
  rights_status text NOT NULL DEFAULT 'unknown' CHECK (rights_status IN ('unknown','original','public_domain','licensed','authorized')),
  rights_evidence text NOT NULL DEFAULT '',
  notes text NOT NULL DEFAULT '',
  novel_id integer REFERENCES novels(id) ON DELETE SET NULL,
  created_by text NOT NULL,
  created_at text NOT NULL DEFAULT (datetime('now')),
  updated_at text NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_trend_candidates_stage_updated ON trend_candidates(stage, updated_at DESC);
