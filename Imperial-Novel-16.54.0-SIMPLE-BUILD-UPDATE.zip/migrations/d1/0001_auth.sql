-- Better Auth tables for a NEW staging D1 database.
-- SQLite types. Do not apply this file to god-emperornovel-db.
-- Cloudflare staging auth uses Drizzle + D1; timestamps are integer milliseconds.

create table if not exists "user" (
  "id" text not null primary key,
  "name" text not null,
  "email" text not null,
  "emailVerified" integer not null default 0,
  "image" text,
  "createdAt" integer not null default (unixepoch() * 1000),
  "updatedAt" integer not null default (unixepoch() * 1000)
);

create table if not exists "session" (
  "id" text not null primary key,
  "expiresAt" integer not null,
  "token" text not null,
  "createdAt" integer not null default (unixepoch() * 1000),
  "updatedAt" integer not null default (unixepoch() * 1000),
  "ipAddress" text,
  "userAgent" text,
  "userId" text not null references "user" ("id") on delete cascade
);

create table if not exists "account" (
  "id" text not null primary key,
  "accountId" text not null,
  "providerId" text not null,
  "userId" text not null references "user" ("id") on delete cascade,
  "accessToken" text,
  "refreshToken" text,
  "idToken" text,
  "accessTokenExpiresAt" integer,
  "refreshTokenExpiresAt" integer,
  "scope" text,
  "password" text,
  "createdAt" integer not null default (unixepoch() * 1000),
  "updatedAt" integer not null default (unixepoch() * 1000)
);

create table if not exists "verification" (
  "id" text not null primary key,
  "identifier" text not null,
  "value" text not null,
  "expiresAt" integer not null,
  "createdAt" integer not null default (unixepoch() * 1000),
  "updatedAt" integer not null default (unixepoch() * 1000)
);

create unique index if not exists "user_email_unique" on "user" ("email");
create unique index if not exists "session_token_unique" on "session" ("token");
create index if not exists "session_userId_idx" on "session" ("userId");
create index if not exists "account_userId_idx" on "account" ("userId");
create index if not exists "verification_identifier_idx" on "verification" ("identifier");
