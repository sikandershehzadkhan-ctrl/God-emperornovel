-- Additive view log. Weekly and monthly rankings use only rows written after
-- this migration. Lifetime novel.views is not backfilled into this table.

create table if not exists view_events (
  id serial primary key,
  novel_id integer not null references novels(id) on delete cascade,
  created_at timestamptz not null default now()
);

create index if not exists view_events_created_idx on view_events (created_at);
create index if not exists view_events_novel_created_idx on view_events (novel_id, created_at);
