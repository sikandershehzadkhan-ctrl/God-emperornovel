# Imperial Novel 16.43.0 — CI Reproducibility and Secret-History Gate

This checklist records source-level changes and external release blockers. It is not production certification. The live Worker `god-emperornovel` and production D1 `god-emperornovel-db` remain protected.

## Implemented in 16.43.0
- [x] GitHub Actions checks out full Git history (`fetch-depth: 0`) so repository-history secret scanning can run.
- [x] CI refreshes missing npm integrity metadata in its temporary checkout only.
- [x] A verifier permits only newly added integrity metadata and rejects dependency graph, version, resolution, and existing-integrity changes.
- [x] Regression tests cover successful integrity-only refresh, version drift, integrity tampering, and still-missing integrity.
- [x] Workflow contract tests ensure full-history checkout and the lockfile verification step remain configured (10 focused workflow/lockfile tests passed).
- [x] Application version and seed version updated to 16.43.0.

## Verified locally in this exported workspace
- [x] Lockfile refresh verifier tests: 4 passed, 0 failed.
- [x] Cloudflare workflow contract tests: 6 passed, 0 failed.
- [x] Source-only Cloudflare readiness checks: 15/15 passed.
- [x] Pre-launch source audit: 20 required assets, 0 route metadata notes.
- [x] Script test suite: 251 passed, 0 failed.
- [x] Selected TypeScript/runtime tests: 41 passed, 0 failed (excluding two modules that cannot load without installed dependencies).
- [ ] Full `npm test`: blocked because `@tanstack/react-start` and `jose` are not installed.
- [ ] Git-history secret scan: unavailable in this exported source directory because it has no `.git`; CI now fetches full history.
- [ ] Typecheck/build/lint: not verified because `node_modules` is absent and `registry.npmjs.org` DNS resolution fails here.

## External release blockers
- [ ] CI successfully installs dependencies and completes `npm audit --audit-level=high`.
- [ ] Full `npm test`, `npm run typecheck`, `npm run lint`, and `npm run build:cloudflare` pass in GitHub Actions.
- [ ] Cloudflare owner creates a separate staging D1 and configures real staging-only secrets/variables.
- [ ] Staging deployment passes sign-in, session, logout, admin role, ticket purchase, donation approval, chapter unlock, rights-review and route smoke tests.
- [ ] Security checks verify HTTPS, cookie flags, CSP/security headers, CORS/CSRF, rate limits, spam protections and no secret exposure.
- [ ] Backup/restore and rollback rehearsal passes; concurrent ticket/payment operations and failure injection pass.
- [ ] Mobile/desktop accessibility, load, cache and performance tests pass.
- [ ] Canonical domain is confirmed and sitemap is submitted to Search Console by its verified owner.
- [ ] Privacy/terms receive appropriate legal review and the production support/retention/deletion details are accurate.

## Release rule
Do not deploy this source package to production based only on source tests. Production approval requires green dependency-backed CI, successful isolated staging, operational recovery evidence and explicit approval. No production deploy or production database operation was performed for this milestone.
