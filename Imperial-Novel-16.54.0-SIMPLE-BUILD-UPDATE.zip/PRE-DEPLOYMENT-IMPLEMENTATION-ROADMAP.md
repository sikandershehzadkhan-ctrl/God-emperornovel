# Imperial Novel — implementation roadmap after 16.39.0

The release sequence is gated. Do not skip ahead to production.

## Gate 1 — Runtime reproducibility
**Status: source checks pass; release blocked.**
- [x] Source readiness gate: 15/15 checks pass.
- [x] 234 script tests, 6 D1 auth schema tests, and selected source/runtime tests pass in the available environment.
- [x] Syntax-transpile 22 changed TS/TSX files with zero syntax errors.
- [ ] Install from the committed lockfile with npm registry access and regenerate missing package integrity metadata without inventing hashes.
- [ ] Pass `npm test`, `npm run typecheck`, and `npm run build:cloudflare`; inspect the generated Worker graph.

## Gate 2 — Authentication and account safety
- [ ] Provision a separate staging D1 and staging OAuth credentials.
- [ ] Exercise sign-up/sign-in, provider callback, session persistence across isolate restarts, sign-out, expiration, revocation, and unauthorized server functions.
- [x] Add explicit exact-user-ID and verified-email bootstrap paths; never grant admin based on signup order.
- [ ] Verify the bootstrap on staging; remove the bootstrap variable after the intended profile exists.
- Verify existing roles and account recovery paths are not altered.

## Gate 3 — Financial integrity
- [x] Provide backend-specific atomic operations for Neon/Postgres, PGLite, and request-bound D1.
- [x] Add local tests for idempotent donation approval, atomic rollback, unlock debit/ledger triggers, insufficient balance, and invalid costs.
- [ ] Run simultaneous/replayed reviews and concurrent single/batch unlocks against real staging D1 and Postgres-compatible staging.
- [ ] Keep PKR amounts, ticket packs, and conversion rules distinct until the owner approves the exact policy.
- Keep PKR amounts, ticket packs, and conversion rules distinct until the owner approves the exact policy.

## Gate 4 — Rights and creator workflows
- [x] Require eligible rights status and meaningful rights evidence at the publication update.
- [x] Add a dedicated persisted Trend Factory pipeline and transition policy tests; metadata only, no source chapter ingestion.
- [x] Make OmniPortal disclose that external provider searches/fetching are not active in this source build.
- [ ] Implement and verify real authorized provider adapters only after source-specific rights approval; do not ingest chapter bodies.
- [x] AI Author Studio remains unavailable without a configured server-side model key; no fake generation path is advertised.

## Gate 5 — Product and release quality
- Exercise all major routes and mobile/desktop layouts against the generated staging Worker.
- Verify accessibility, performance, error states, empty states, and no horizontal overflow.
- Verify backups, migration compatibility, rollback instructions, and observability.
- Only after staging sign-off may a separately approved production plan be prepared. Production Worker and D1 are not staging targets.
