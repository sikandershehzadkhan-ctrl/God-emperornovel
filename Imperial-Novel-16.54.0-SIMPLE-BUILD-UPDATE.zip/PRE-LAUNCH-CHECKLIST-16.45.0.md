# Imperial Novel 16.45.0 — Production Pre-Launch Checklist

This checklist distinguishes source implementation from checks requiring account access or a deployed environment. A checked source item is not proof of deployed behavior. The production Worker `god-emperornovel` and production D1 database `god-emperornovel-db` are out of scope for staging.

## Source implementation present
- [x] Privacy policy, terms, visitor FAQ, and cookie preference UI exist.
- [x] No fabricated testimonials are included.
- [x] Secret scanner covers high-confidence token formats and scans Git history when a Git checkout is available; CI fetches full history.
- [x] Local environment files and generated staging configuration are ignored by Git.
- [x] Cloudflare D1 mode fails closed when the request binding is absent; Node/PGLite auth is isolated from Cloudflare auth routing.
- [x] Administrator bootstrap requires an explicit, verified configuration; the first signup is not promoted automatically.
- [x] HTTPS origins configure Secure authentication cookies; localhost HTTP preview remains possible.
- [x] Baseline security headers include content-type sniffing protection, frame protection, referrer policy, permissions policy, HSTS, and opener policy.
- [x] Auth origin is constrained to the configured Better Auth base URL; unsafe non-HTTPS deployed origins are rejected.
- [x] Form/server services use schema/input validation in the audited payment, chapter-cost, publication-rights and Trend Factory paths.
- [x] Donation approval and chapter unlock accounting use backend-native atomic operations with idempotency/insufficient-balance protections.
- [x] Trend Factory stores metadata only and enforces rights-first stages.
- [x] Unique page metadata defaults, social preview metadata, favicon, `robots.txt`, sitemap and custom 404 exist.
- [x] Database migrations include indexes for the inspected auth and application lookups; further production query-plan review remains necessary.
- [x] Release workflow runs tests, secret scan, high-severity npm audit, lockfile integrity checks, typecheck and Cloudflare build before staging deploy.
- [x] Staging deployment workflow is isolated from production and fails closed when required credentials are missing.

## Local checks that passed in this workspace
- [x] Script suite: see `RELEASE-REPORT-16.45.0.md` for the exact run result.
- [x] D1 authentication schema tests run on disposable local SQLite.
- [x] Selected runtime/database tests that do not require unavailable application dependencies.
- [x] Source Cloudflare readiness checks: 16/16.
- [x] Pre-launch source audit: 22 required assets; 0 route metadata notes.
- [x] ZIP archive integrity and working-tree secret-pattern scan.

## Must be verified in network-enabled CI and isolated staging
- [ ] `npm ci` succeeds using the committed lockfile; fill the missing npm registry integrity metadata in CI and review the verified delta.
- [ ] `npm audit --audit-level=high` passes; resolve or explicitly review every high/critical advisory.
- [ ] Full `npm test`, `npm run typecheck`, `npm run lint`, and `npm run build:cloudflare` all pass.
- [ ] Generated Worker bundle is inspected for accidental Node/PGLite imports, exposed secrets, and correct asset routing.
- [ ] Cloudflare account owner provisions a separate staging D1 and configures staging-only GitHub secrets/variables.
- [ ] Real staging OAuth sign-in, callback, verified identity, session persistence, cookie flags, logout, authorization and admin restrictions pass.
- [ ] Cloudflare WAF/rate-limiting rules are configured for auth, public forms, APIs and expensive routes; validate limits under load. Do not substitute per-isolate in-memory throttling for edge controls.
- [ ] CORS/CSRF behavior is tested against expected and hostile origins; security headers are inspected on actual responses.
- [ ] Form spam/bot defenses, sanitization and XSS checks pass with adversarial inputs.
- [ ] Donation approval, duplicate requests, concurrent unlocks, insufficient balances, failed statements and retry behavior pass against staging D1.
- [ ] Database backup/export, restore into a disposable database, and rollback/redeploy rehearsal pass.
- [ ] Broken links, image alt text, image payload sizes, contrast, keyboard/screen-reader behavior and mobile/desktop layouts are manually/browser tested.
- [ ] Page load, caching behavior, database indexes/query plans and realistic load tests meet a written performance budget.
- [ ] Canonical hostname is confirmed; robots/sitemap are checked on the deployed host and sitemap is submitted by a verified owner in Search Console.
- [ ] Privacy/terms are reviewed against actual data collection, retention, deletion, support and payment practices.
- [ ] Real analytics are configured only after privacy/cookie implications are decided. Do not add Google Analytics automatically if consent/legal setup is not ready.
- [ ] Only real, permissioned testimonials may be published; do not use placeholder praise or fake metrics.
- [ ] Monetag, AI model access, and external connectors remain disabled until real credentials, rights approvals, consent rules and end-to-end tests are in place.

## Release decision

**NOT PRODUCTION READY until every required CI and staging item above is evidenced.** This source package does not have access to the Cloudflare account, GitHub secrets, a real staging D1 ID, or network-enabled npm registry access. No production deploy, production migration, or production database operation has been performed.


## Dependency recovery gate
- [ ] `npm ci --no-audit --no-fund` succeeds in a network-enabled environment.
- [ ] `npm run check:dependencies` confirms `jose`, `@tanstack/react-start`, Vite, TypeScript, ESLint, and Node type declarations match the lockfile.
- [ ] Full tests, typecheck, lint, npm audit, and Cloudflare build pass after installation.
- [ ] Do not interpret source-only dependency declarations as proof that packages were installed or the app built.
