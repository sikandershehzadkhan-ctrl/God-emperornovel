# Imperial Novel 16.41.0 — Pre-launch checklist integration

## Delivered in this source package

- Added `/faq` visitor page with reader, author, rights, tickets, EasyPaisa, privacy and mobile-use answers. No fabricated testimonials were added.
- Added footer links to FAQ and cookie preferences.
- Added default Open Graph and Twitter card metadata and route-level descriptions across routes, including redirect aliases.
- Added `public/robots.txt` and `public/sitemap.xml` for intended public pages only. The sitemap uses the currently known workers.dev URL; replace it only when a verified canonical custom domain is configured.
- Added a comprehensive status-labelled pre-launch checklist covering the supplied legal, privacy, security, SEO, accessibility, performance, operational and project-specific items.
- Added `PRE-LAUNCH-SAFETY-NET-PROMPT.md` for future AI-assisted maintenance and truthful release reporting.
- Added `npm run audit:prelaunch` and source tests. Audit output explicitly does not certify production readiness.
- Updated visible application version to 16.41.0 and updated the generated TanStack route tree for FAQ.

## Verification

| Check | Result | Evidence |
|---|---|---|
| Pre-launch source audit | PASS | `node scripts/prelaunch-audit.mjs`; 12 required assets checked, zero route metadata notes |
| New pre-launch audit tests | PASS | 3/3 passed |
| Script test suite after this change | PASS | `node --test 'scripts/**/*.test.mjs'`: 241 passed, 0 failed |
| New pre-launch audit tests | PASS | 3/3 passed (also included in the script suite count) |
| Full `npm test` | BLOCKED | The later TypeScript test phase cannot resolve missing dependency `jose`; project dependencies are not installed |
| Typecheck / lint / Cloudflare build | UNVERIFIED | `npm run typecheck` fails because `@types/node` and `vite/client` are absent; `node_modules` is missing |
| Real Cloudflare staging / mobile / load / headers / session tests | NOT PERFORMED | Requires network-enabled CI and separate staging resources |
| Repository-history secret scan | NOT PERFORMED | Requires a Git clone/history and secret-scanning environment; `.gitignore` is not proof that history is clean |
| Search Console submission | NOT PERFORMED | Requires domain ownership and account access |

## Remaining production blockers

- Provision a separate staging D1 database and configure the GitHub Actions staging secrets/variables.
- Install dependencies in a network-enabled environment; verify lockfile, full tests, typecheck, lint, and Cloudflare build.
- Complete Better Auth D1 login/session/logout and role verification against a generated staging Worker.
- Perform secret-history scan, dependency audit, CORS/CSRF/rate-limit/abuse checks, and deployed security-header inspection.
- Verify ticket/donation/unlock operations under concurrency and injected failures, plus database backup/restore and rollback.
- Validate page speed, image optimization, accessibility, broken links, 404 status, cookie behavior and social preview on the deployed host.
- Review policy language for the actual data flows and obtain legal review; confirm support/contact and retention/account-deletion processes.
- Submit sitemap only after canonical domain and Google Search Console ownership are confirmed.
- Explicitly approve production release only after staging evidence passes.

No production Worker deployment, production D1 migration, or remote credential change was performed. This package is a source update, not production certification.
