# Imperial Novel 16.48.0 — GitHub / Cloudflare Workers / D1 deployment bundle

## Scope

This release assembles the hardened 16.47.0 source into a repository-root bundle for the existing GitHub repository and GitHub Actions → Wrangler → Cloudflare Workers → D1 deployment route. It adds explicit deployment instructions and aligns the npm package identity with Imperial Novel 16.48.0. It does not deploy anything, modify the production Worker, alter the production D1 database, or push to GitHub.

## Verified locally

- `node --test scripts/**/*.test.mjs`: 261 passed, 0 failed.
- `node --experimental-sqlite --test scripts/d1-auth-schema.test.mjs`: 6 passed, 0 failed.
- `npm run audit:prelaunch`: 30 required assets checked, 0 route metadata notes, source audit passed.
- `node scripts/cloudflare-readiness.mjs`: 17/17 source checks passed; command exits non-zero because external release prerequisites are still missing.
- ZIP integrity and required deployment/source files: passed when packaging this release.

## Blockers to full compatibility certification

- `npm ci` could not be completed because the npm registry request timed out in this environment.
- Dependency-backed tests could not all load: 2 test modules fail at import because `@tanstack/react-start` and `jose` are not installed; the remaining focused tests passed. This is not a green full test suite.
- TypeScript, ESLint, dependency audit, and the generated Cloudflare Worker build have not been certified in this environment.
- The staging D1 database ID and Cloudflare credentials are account-side prerequisites; the config intentionally retains a staging placeholder.
- No real staging Worker was deployed or tested.

## Deployment safety

The included GitHub workflow targets `imperial-novel-staging`, not production. It requires staging-only GitHub secrets/variables, runs checks/build, applies only `migrations/d1/` to the staging database, deploys with Wrangler, and performs basic HTTP smoke checks. It must not be repointed to `god-emperornovel` or `god-emperornovel-db` before schema compatibility, backup/rollback, and staging acceptance tests are complete.

## Required release gates

Run in a network-enabled CI runner:

```sh
npm ci --no-audit --no-fund
npm run check:dependencies
npm run scan:secrets
npm audit --audit-level=high
npm test
npm run typecheck
npm run lint
npm run build:cloudflare
npm run check:cloudflare-readiness
npm run audit:prelaunch
```

Then create a separate staging D1 database, configure the required GitHub Actions secrets/variables, and test authentication, session lifecycle, user isolation, catalog/reader, ticket unlock atomicity, EasyPaisa approval, rights review, and security headers. This report intentionally does not claim complete deployment certification until those steps pass.
