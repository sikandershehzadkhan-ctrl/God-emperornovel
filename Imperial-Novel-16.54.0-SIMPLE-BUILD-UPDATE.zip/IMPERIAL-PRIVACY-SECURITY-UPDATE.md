# Imperial Novel privacy, security and palette update

This is an update to the existing application source, not a replacement app.

## Cookie preferences
- First-visit panel with Accept all, Reject optional, and Customize.
- Essential storage is always on; analytics and marketing default to off.
- Saved choices persist in localStorage and can be reopened from the Privacy page.
- Consent changes dispatch `imperial:consent-changed` for future optional integrations to honor. This UI does not add or activate analytics or marketing providers by itself.

## Browser security
- MIME sniffing, framing, referrer, permissions, opener, DNS-prefetch, and download hardening headers.
- HSTS omits `includeSubDomains` to avoid imposing policy on unrelated subdomains of shared hosting domains. Verify the canonical host and HTTPS behavior before release.
- A strict CSP is not forced until sign-in, external images/fonts, and payment flows are inventoried; an untested policy could break them.

## Colour and usability
- Midnight/obsidian surfaces dominate.
- Violet is the brand accent; turquoise is reserved for focus and interactive cues; blue adds depth; emerald signals success; amber/gold remains restrained.
- Cookie controls use 44px minimum touch targets; focus visibility and reduced-motion rules remain intact.

## Deployment safety
- No production credentials are added.
- The Cloudflare configuration remains staging-only.
- Better Auth + D1 compatibility is documented as a deployment blocker. Do not deploy this bundle to the production Worker until the adapter and session storage are implemented and tested.
- Follow `SECURITY-AND-RELEASE-CHECKLIST.md` before release.
