# Imperial Novel 16.43.0 — CI Reproducibility and Secret-History Gate

## Summary
This update fixes two actionable CI defects found while continuing the production-readiness work: the secret-history scanner was being run from the default shallow Git checkout, and the lockfile gate would block the release whenever npm could add missing registry integrity metadata. The new workflow fetches full history and permits only integrity metadata additions in its ephemeral CI copy while rejecting dependency graph drift.

## Implemented
- GitHub Actions checkout now uses `fetch-depth: 0` so `git log --all` can scan repository history.
- Added `scripts/verify-lockfile-integrity-refresh.mjs`; it compares lockfiles after removing integrity fields, refuses any other graph or metadata change, verifies existing integrity values remain unchanged, and requires valid integrity for npm registry tarballs.
- CI refreshes integrity metadata from npm registry in the ephemeral runner, validates the delta, and then installs the resulting lockfile.
- Added 4 focused lockfile tests and 2 workflow-contract tests.
- Added 16.43.0 checklist and updated the app version label and seed version.

## Verification in this workspace
| Check | Result |
|---|---|
| Lockfile verifier + workflow contract tests | PASS: 10 tests, 0 failures |
| D1 auth schema tests | PASS: 6 tests, 0 failures |
| Selected TypeScript/runtime tests excluding two dependency-blocked modules | PASS: 41 tests, 0 failures |
| Focused workflow + lockfile tests | PASS: 10 tests, 0 failures |
| Cloudflare source readiness | PASS: 15/15 source checks |
| Pre-launch audit | PASS: 20 required assets, 0 route metadata notes |
| Script tests (`node --test scripts/**/*.test.mjs`) | PASS: 251 tests, 0 failures |
| Secret scan | 0 working-tree findings; history unavailable because this exported workspace has no `.git` |
| Full `npm test` | BLOCKED: two modules cannot load because `@tanstack/react-start` and `jose` are not installed; remaining selected TS/runtime tests pass |
| Typecheck/build/lint | BLOCKED: registry DNS resolution fails and `node_modules` is absent |
| Cloudflare staging | NOT PERFORMED: no separate staging D1 ID or account credentials in this environment |

## Release blockers
- A network-enabled CI run must complete `npm ci`, `npm audit`, the full test suite, typecheck, lint and Cloudflare build.
- Cloudflare owner must create and configure a dedicated staging D1 and staging-only secrets/variables.
- Staging must pass real auth/session/logout/role, tickets, donations, chapter unlock, rights review, security headers, rate-limit, CORS/CSRF, backup/restore and rollback checks.
- Mobile/desktop performance, accessibility, load tests, canonical domain verification and Search Console submission remain outstanding.

## Safety
No remote GitHub changes, Cloudflare deploy, production migration, or production database operation was performed. The live Worker `god-emperornovel` and D1 database `god-emperornovel-db` remain untouched.

## Decision
**NOT PRODUCTION READY.** This is a CI hardening source milestone. Do not deploy to production until dependency-backed CI and isolated staging are green.
