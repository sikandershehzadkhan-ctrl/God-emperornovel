# Imperial Novel 16.38.1 — Admin bootstrap security hardening

## Outcome

This is an intermediate source update, not a deployment-ready release. It closes one identified privilege-escalation risk in profile creation: the first account no longer automatically becomes an administrator.

## Changes

- Added `resolveNewProfileRole`, a pure helper that grants the bootstrap role only when the authenticated user ID exactly matches `IMPERIAL_BOOTSTRAP_ADMIN_USER_ID`.
- Updated `ensureProfile` to stop querying whether an admin exists and stop granting admin to the first signup.
- Passed the explicit bootstrap ID through the Cloudflare auth environment allowlist. D1 bindings are not copied into `process.env`.
- Added five focused tests covering absent/mismatched/exact configuration, whitespace handling, source integration, and Cloudflare env allowlisting.
- Added `ADMIN-BOOTSTRAP-SECURITY.md` with a staging-only provisioning procedure.

## Verification

| Check | Result | Notes |
|---|---|---|
| Script tests | PASS | 233 passed, 0 failed |
| D1 auth schema tests | PASS | 6 passed, 0 failed |
| Focused runtime/D1/identity tests | PARTIAL | 30 passed, 2 test files failed to load because required project dependencies are not installed (`ERR_MODULE_NOT_FOUND`) |
| Admin bootstrap tests | PASS | 5 passed, 0 failed using Node's experimental TypeScript stripping |
| Cloudflare readiness source gate | PASS WITH RELEASE BLOCKERS | 8/8 source checks pass; external prerequisites remain |
| TypeScript typecheck | NOT VERIFIED | Project dependencies are unavailable in this environment |
| Cloudflare build | NOT VERIFIED | Project dependencies are unavailable in this environment |
| Better Auth + D1 live lifecycle | NOT VERIFIED | Requires an isolated staging Worker/D1 and configured OAuth/auth settings |
| Ticket/payment atomicity | BLOCKED | Donation approval and chapter unlock writes still lack verified atomic transaction handling across supported backends |
| Production Worker/database | UNCHANGED | No remote operations were performed |

## Required before calling this ready

1. Install dependencies with a network-enabled registry and verify `package-lock.json` integrity metadata.
2. Run `npm ci`, `npm test`, `npm run typecheck`, `npm run build:cloudflare`, and inspect the generated Worker bundle.
3. Provision a distinct staging D1 database, set actual staging-only auth/OAuth settings, and complete sign-up/sign-in/session/sign-out/revocation tests against the generated Worker.
4. Implement and test atomic donation review, ticket crediting, single unlock, and batch unlock behavior on D1 as well as Postgres/PGLite. Do not guess or change the PKR-to-ticket conversion policy.
5. Complete authorization/rights-evidence review and validate the real feature inventory, including a dedicated Trend Factory workflow and connector execution status.
6. Run staging regression and rollback checks before separately considering production deployment.

The production Worker `god-emperornovel` and production D1 database `god-emperornovel-db` remain protected. No GitHub push or deployment was performed.
