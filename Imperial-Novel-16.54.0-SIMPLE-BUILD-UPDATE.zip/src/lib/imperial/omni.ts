import { createServerFn } from "@tanstack/react-start";
import { authMiddleware } from "@/lib/auth/middleware";
import { attachTaxonomy, ensureProfile, imperialSql, novelSelect } from "./db";
import type { NovelCard } from "./types";

type OmniHit = {
  provider: string;
  title: string;
  author: string;
  description: string;
  url: string;
  cover_url: string;
};

export const omniStatus = createServerFn({ method: "GET" }).handler(async () => {
  const sql = await imperialSql();
  const sources = await sql<{
    id: number;
    name: string;
    base_url: string;
    type: string;
    enabled: boolean;
    rights_status: string;
    last_status: string;
    last_checked_at: string | null;
  }>`
    select id, name, base_url, type, enabled, rights_status, last_status, last_checked_at::text as last_checked_at
    from connectors order by name
  `;
  return {
    engine: "OmniPortal",
    version: "1.0",
    mode: "rights-first",
    sources,
    capabilities: [
      "local-catalog-search",
      "metadata-only-import-request-queue",
      "connector-authorization-request-records",
    ],
  };
});

export const omniSearch = createServerFn({ method: "GET" })
  .validator((q: string) => q)
  .handler(async ({ data: q }): Promise<{ query: string; results: OmniHit[]; providers: string[]; searched_connectors: number }> => {
    const query = q.trim();
    if (query.length < 2) return { query, results: [], providers: [], searched_connectors: 0 };
    const sql = await imperialSql();
    const local = await sql.query<NovelCard>(
      `select ${novelSelect} from novels n
       where n.publication_status='published'
         and (n.title ilike '%'||$1||'%' or n.author ilike '%'||$1||'%')
       limit 24`,
      [query],
    );
    const results = (await attachTaxonomy(sql, local)).map((n) => ({
      provider: "Imperial Novel",
      title: n.title,
      author: n.author,
      description: n.description,
      url: `/novel/${n.id}`,
      cover_url: n.cover_url,
    }));
    return { query, results, providers: ["Imperial Novel"], searched_connectors: 0 };
  });

export const requestConnectorAuth = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { connector_id: number; evidence_url?: string; terms_url?: string; notes?: string }) => input)
  .handler(async ({ context, data }) => {
    const sql = await imperialSql();
    await ensureProfile(sql, context.userId);
    if (!data.evidence_url && !data.terms_url && !data.notes) {
      throw new Error("Provide rights evidence, a terms/license URL, or rights notes.");
    }
    const existing = await sql`
      select id from connector_auth_requests
      where connector_id = ${data.connector_id} and user_id = ${context.userId} and status = 'pending'
    `;
    if (existing[0]) return { ok: true, request_id: (existing[0] as { id: number }).id, status: "pending" };
    const rows = await sql<{ id: number }>`
      insert into connector_auth_requests (connector_id, user_id, evidence_url, terms_url, notes)
      values (${data.connector_id}, ${context.userId}, ${data.evidence_url || ""}, ${data.terms_url || ""}, ${data.notes || ""})
      returning id
    `;
    return { ok: true, request_id: rows[0]!.id, status: "pending" };
  });

export const queueImport = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((url: string) => url)
  .handler(async ({ context, data: url }) => {
    const candidateUrl = String(url || "").trim();
    if (candidateUrl.length > 2000) throw new Error("Source URL is too long");
    let parsed: URL;
    try { parsed = new URL(candidateUrl); } catch { throw new Error("Source URL must be a valid HTTP or HTTPS URL"); }
    if (!["http:", "https:"].includes(parsed.protocol) || parsed.username || parsed.password) {
      throw new Error("Source URL must use HTTP or HTTPS and cannot contain credentials");
    }
    const normalizedUrl = parsed.toString();
    const sql = await imperialSql();
    await ensureProfile(sql, context.userId);
    const rows = await sql<{ id: number }>`
      insert into import_jobs (user_id, source_url, status, message)
      values (${context.userId}, ${normalizedUrl}, 'queued', 'Metadata-only request recorded. External fetching is not active in this build; no source chapters were copied.')
      returning id
    `;
    return { ok: true, job_id: rows[0]!.id };
  });

export const myImportJobs = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await imperialSql();
    return sql<{ id: number; source_url: string; status: string; message: string; created_at: string }>`
      select id, source_url, status, message, created_at::text as created_at
      from import_jobs where user_id = ${context.userId} order by created_at desc limit 50
    `;
  });
