export const TREND_FACTORY_STAGES = [
  "trend",
  "analyzed",
  "author_discovered",
  "invite_ready",
  "rights_review",
  "review",
  "linked_to_novel",
  "published",
  "rejected",
] as const;
export type TrendFactoryStage = (typeof TREND_FACTORY_STAGES)[number];
export type TrendRightsStatus = "unknown" | "original" | "public_domain" | "licensed" | "authorized";

export const ELIGIBLE_TREND_RIGHTS: TrendRightsStatus[] = [
  "original", "public_domain", "licensed", "authorized",
];

const NEXT_STAGE: Partial<Record<TrendFactoryStage, TrendFactoryStage>> = {
  trend: "analyzed",
  analyzed: "author_discovered",
  author_discovered: "invite_ready",
  invite_ready: "rights_review",
  rights_review: "review",
  review: "linked_to_novel",
  linked_to_novel: "published",
};

export function canAdvanceTrendStage(current: TrendFactoryStage, next: TrendFactoryStage): boolean {
  if (current === "published" || current === "rejected") return false;
  if (next === "rejected") return true;
  return NEXT_STAGE[current] === next;
}

export function hasMeaningfulRightsEvidence(value: string | undefined | null): boolean {
  return String(value ?? "").trim().length >= 8;
}
