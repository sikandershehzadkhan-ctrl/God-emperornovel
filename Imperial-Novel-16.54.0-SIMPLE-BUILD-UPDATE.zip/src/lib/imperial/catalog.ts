import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { attachTaxonomy, imperialSql, novelSelect, num } from "./db";
import type { NovelCard } from "./types";

const listInput = z.object({
  q: z.string().optional(),
  sort: z.string().optional(),
  status: z.string().optional(),
  genre: z.string().optional(),
  tag: z.string().optional(),
  kind: z.string().optional(),
  language: z.string().optional(),
  category: z.string().optional(),
  author: z.string().optional(),
  min_rating: z.number().optional(),
  page: z.number().optional(),
  limit: z.number().optional(),
});

export const listNovels = createServerFn({ method: "GET" })
  .validator((input: z.infer<typeof listInput>) => listInput.parse(input ?? {}))
  .handler(async ({ data }) => {
    const sql = await imperialSql();
    const page = Math.max(1, data.page || 1);
    const limit = Math.min(48, Math.max(1, data.limit || 24));
    const offset = (page - 1) * limit;
    const sort = data.sort || "updated";
    const order =
      sort === "trending" || sort === "views"
        ? "n.views desc, n.rating desc"
        : sort === "rating"
          ? "n.rating desc, n.views desc"
          : sort === "newest"
            ? "n.created_at desc"
            : sort === "chapters"
              ? "chapter_count desc"
              : "n.updated_at desc";
    const q = (data.q || "").trim();
    const rows = await sql.query<NovelCard>(
      `select ${novelSelect}
       from novels n
       where n.publication_status = 'published'
         and ($1 = '' or n.title ilike '%'||$1||'%' or n.author ilike '%'||$1||'%' or n.alt_titles ilike '%'||$1||'%')
         and ($2 = '' or n.status = $2)
         and ($3 = '' or n.kind = $3)
         and ($4 = '' or n.language ilike $4)
         and ($5 = '' or n.category = $5)
         and ($6 = '' or n.author ilike '%'||$6||'%')
         and n.rating >= $7
         and ($8 = '' or exists (select 1 from novel_genres ng join genres g on g.id = ng.genre_id where ng.novel_id = n.id and (g.slug = $8 or lower(g.name) = lower($8))))
         and ($9 = '' or exists (select 1 from novel_tags nt join tags t on t.id = nt.tag_id where nt.novel_id = n.id and (t.slug = $9 or lower(t.name) = lower($9))))
       order by ${order}
       limit $10 offset $11`,
      [
        q,
        data.status || "",
        data.kind || "",
        data.language || "",
        data.category || "",
        data.author || "",
        data.min_rating || 0,
        data.genre || "",
        data.tag || "",
        limit,
        offset,
      ],
    );
    const withTax = await attachTaxonomy(sql, rows);
    return { page, limit, results: withTax };
  });

export const getHomeData = createServerFn({ method: "GET" }).handler(async () => {
  const sql = await imperialSql();
  const featured = await sql.query<NovelCard>(
    `select ${novelSelect} from novels n where n.publication_status='published' and n.featured = true order by n.views desc limit 6`,
  );
  const trending = await sql.query<NovelCard>(
    `select ${novelSelect} from novels n where n.publication_status='published' order by n.views desc, n.rating desc limit 10`,
  );
  const updated = await sql.query<NovelCard>(
    `select ${novelSelect} from novels n where n.publication_status='published' order by n.updated_at desc limit 10`,
  );
  const newest = await sql.query<NovelCard>(
    `select ${novelSelect} from novels n where n.publication_status='published' order by n.created_at desc limit 8`,
  );
  const picks = await sql.query<NovelCard>(
    `select ${novelSelect} from novels n where n.publication_status='published' order by n.rating desc, n.views desc limit 8`,
  );
  const [f, t, u, nw, p] = await Promise.all([
    attachTaxonomy(sql, featured),
    attachTaxonomy(sql, trending),
    attachTaxonomy(sql, updated),
    attachTaxonomy(sql, newest),
    attachTaxonomy(sql, picks),
  ]);
  const genres = await sql<{ name: string; slug: string; n: number }>`
    select g.name, g.slug, count(ng.novel_id)::int as n
    from genres g left join novel_genres ng on ng.genre_id = g.id
    group by g.id order by n desc, g.name asc
  `;
  const tags = await sql<{ name: string; slug: string; n: number }>`
    select t.name, t.slug, count(nt.novel_id)::int as n
    from tags t left join novel_tags nt on nt.tag_id = t.id
    group by t.id order by n desc, t.name asc
  `;
  const statsRows = await sql<{ novels: number; chapters: number; authors: number; genres: number }>`
    select
      (select count(*)::int from novels where publication_status = 'published') as novels,
      (select count(*)::int from chapters where publication_status = 'published') as chapters,
      (select count(distinct author)::int from novels where publication_status = 'published') as authors,
      (select count(*)::int from genres) as genres
  `;
  return {
    featured: f,
    trending: t,
    updated: u,
    newest: nw,
    picks: p,
    genres,
    tags,
    stats: statsRows[0] || { novels: 0, chapters: 0, authors: 0, genres: 0 },
  };
});

export const getNovel = createServerFn({ method: "GET" })
  .validator((id: number) => id)
  .handler(async ({ data: id }) => {
    const sql = await imperialSql();
    const rows = await sql.query<NovelCard>(
      `select ${novelSelect} from novels n where n.id = $1 and n.publication_status = 'published'`,
      [id],
    );
    if (!rows[0]) throw new Error("Novel not found");
    const [novel] = await attachTaxonomy(sql, rows);
    const chapters = await sql<
      { id: number; chapter_number: number; title: string; is_locked: boolean; ticket_cost: number; publication_status: string }
    >`
      select id, chapter_number, title, is_locked, ticket_cost::float as ticket_cost, publication_status
      from chapters
      where novel_id = ${id} and publication_status = 'published'
      order by chapter_number
    `;
    let userState = { in_library: false, following: false, bookmark: 0, user_rating: 0 };
    try {
      const { getSessionUser } = await import("@/lib/auth/verify.server");
      const user = await getSessionUser();
      if (user) {
        const lib = await sql`select 1 from user_library where user_id = ${user.id} and novel_id = ${id}`;
        const fol = await sql`select 1 from follows where user_id = ${user.id} and novel_id = ${id}`;
        const bm = await sql<{ chapter_number: number }>`select chapter_number from bookmarks where user_id = ${user.id} and novel_id = ${id}`;
        const rt = await sql<{ rating: number }>`select rating from ratings where user_id = ${user.id} and novel_id = ${id}`;
        userState = {
          in_library: lib.length > 0,
          following: fol.length > 0,
          bookmark: num(bm[0]?.chapter_number),
          user_rating: num(rt[0]?.rating),
        };
      }
    } catch {
      /* public */
    }
    const related = await sql.query<NovelCard>(
      `select ${novelSelect} from novels n
       where n.publication_status='published' and n.id <> $1
         and (n.category = $2 or exists (
           select 1 from novel_genres ng where ng.novel_id = n.id and ng.genre_id in (
             select genre_id from novel_genres where novel_id = $1
           )
         ))
       order by n.rating desc limit 6`,
      [id, novel.category],
    );
    await sql`update novels set views = views + 1 where id = ${id}`;
    await sql`insert into view_events (novel_id) values (${id})`;
    return {
      ...novel,
      chapters,
      related: await attachTaxonomy(sql, related),
      ...userState,
    };
  });

export const listGenres = createServerFn({ method: "GET" }).handler(async () => {
  const sql = await imperialSql();
  return sql<{ name: string; slug: string; n: number }>`
    select g.name, g.slug, count(ng.novel_id)::int as n
    from genres g left join novel_genres ng on ng.genre_id = g.id
    group by g.id order by g.name
  `;
});

export const listTags = createServerFn({ method: "GET" }).handler(async () => {
  const sql = await imperialSql();
  return sql<{ name: string; slug: string; n: number }>`
    select t.name, t.slug, count(nt.novel_id)::int as n
    from tags t left join novel_tags nt on nt.tag_id = t.id
    group by t.id order by t.name
  `;
});

export const getRandomNovel = createServerFn({ method: "GET" }).handler(async () => {
  const sql = await imperialSql();
  const rows = await sql.query<NovelCard>(
    `select ${novelSelect} from novels n where n.publication_status='published' order by random() limit 1`,
  );
  const [novel] = await attachTaxonomy(sql, rows);
  return novel ?? null;
});
