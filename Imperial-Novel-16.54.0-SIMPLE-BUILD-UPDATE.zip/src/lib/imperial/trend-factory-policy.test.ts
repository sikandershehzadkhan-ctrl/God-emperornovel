import assert from "node:assert/strict";
import test from "node:test";
import {
  canAdvanceTrendStage,
  hasMeaningfulRightsEvidence,
  TREND_FACTORY_STAGES,
} from "./trend-factory-policy.ts";

test("Trend Factory follows the required ordered discovery workflow", () => {
  const ordered = ["trend", "analyzed", "author_discovered", "invite_ready", "rights_review", "review", "linked_to_novel", "published"] as const;
  assert.deepEqual(TREND_FACTORY_STAGES.slice(0, -1), ordered);
  for (let index = 0; index < ordered.length - 1; index += 1) {
    assert.equal(canAdvanceTrendStage(ordered[index]!, ordered[index + 1]!), true);
    if (index + 2 < ordered.length) assert.equal(canAdvanceTrendStage(ordered[index]!, ordered[index + 2]!), false);
  }
});

test("Trend Factory can reject an active candidate but terminal records cannot move", () => {
  assert.equal(canAdvanceTrendStage("trend", "rejected"), true);
  assert.equal(canAdvanceTrendStage("published", "rejected"), false);
  assert.equal(canAdvanceTrendStage("rejected", "trend"), false);
});

test("rights evidence must contain meaningful non-whitespace text", () => {
  assert.equal(hasMeaningfulRightsEvidence("License URL"), true);
  assert.equal(hasMeaningfulRightsEvidence("  "), false);
  assert.equal(hasMeaningfulRightsEvidence("short"), false);
  assert.equal(hasMeaningfulRightsEvidence(undefined), false);
});
