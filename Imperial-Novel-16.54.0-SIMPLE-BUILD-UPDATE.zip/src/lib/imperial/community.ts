import { createServerFn } from "@tanstack/react-start";
import { authMiddleware } from "@/lib/auth/middleware";
import { attachTaxonomy, ensureProfile, imperialSql, novelSelect, num } from "./db";
import type { NovelCard } from "./types";

export const getLeaderboard = createServerFn({ method: "GET" })
  .validator((period: string) => (period === "monthly" || period === "all" ? period : "weekly"))
  .handler(async ({ data: period }) => {
    const sql = await imperialSql();
    if (period === "all") {
      const all = await sql.query<NovelCard>(
        `select ${novelSelect} from novels n where n.publication_status='published' order by n.views desc, n.rating desc limit 12`,
      );
      const authors = await sql<{ author: string; novels: number; views: number; rating: number }>`
        select author, count(*)::int as novels, coalesce(sum(views),0)::int as views, coalesce(avg(rating),0)::float as rating
        from novels where publication_status='published'
        group by author order by views desc limit 12
      `;
      return {
        novels: await attachTaxonomy(sql, all),
        authors,
        period,
        basis: "lifetime" as const,
        note: "All-time totals are lifetime published views stored on each novel.",
      };
    }
    const windowSql = period === "monthly" ? "30 days" : "7 days";
    const novels = await sql.query<NovelCard & { window_views: number }>(
      `select ${novelSelect}, w.views as window_views
       from novels n
       join (
         select novel_id, count(*)::int as views
         from view_events
         where created_at >= now() - interval '${windowSql}'
         group by novel_id
       ) w on w.novel_id = n.id
       where n.publication_status='published'
       order by w.views desc, n.rating desc
       limit 12`,
    );
    const authors = await sql<{ author: string; novels: number; views: number; rating: number }>`
      select n.author,
             count(distinct n.id)::int as novels,
             count(e.id)::int as views,
             coalesce(avg(n.rating),0)::float as rating
      from novels n
      join view_events e on e.novel_id = n.id
      where n.publication_status='published'
        and e.created_at >= now() - ${windowSql}::interval
      group by n.author
      order by views desc
      limit 12
    `;
    return {
      novels: await attachTaxonomy(sql, novels),
      authors,
      period,
      basis: "recorded-views" as const,
      note:
        period === "monthly"
          ? "Monthly counts only novel opens recorded in the last 30 days. Lifetime views from before this log are not included."
          : "Weekly counts only novel opens recorded in the last 7 days. Lifetime views from before this log are not included.",
    };
  });

export const getTierList = createServerFn({ method: "GET" }).handler(async () => {
  const sql = await imperialSql();
  const rows = await sql.query<NovelCard>(
    `select ${novelSelect} from novels n where n.publication_status='published' order by n.rating desc, n.views desc`,
  );
  const withTax = await attachTaxonomy(sql, rows);
  const tiers: Record<string, typeof withTax> = { S: [], A: [], B: [], C: [] };
  for (const n of withTax) {
    const r = num(n.rating);
    if (r >= 4.7) tiers.S.push(n);
    else if (r >= 4.3) tiers.A.push(n);
    else if (r >= 3.8) tiers.B.push(n);
    else tiers.C.push(n);
  }
  return { tiers };
});

export const getComments = createServerFn({ method: "GET" })
  .validator((novelId: number) => novelId)
  .handler(async ({ data: novelId }) => {
    const sql = await imperialSql();
    return sql<{
      id: number;
      body: string;
      parent_id: number | null;
      created_at: string;
      username: string;
      likes: number;
    }>`
      select c.id, c.body, c.parent_id, c.created_at::text as created_at,
             coalesce(p.username, 'Reader') as username,
             coalesce((select count(*) from comment_likes cl where cl.comment_id = c.id),0)::int as likes
      from comments c
      left join profiles p on p.user_id = c.user_id
      where c.novel_id = ${novelId} and c.status = 'visible'
      order by c.created_at asc
      limit 300
    `;
  });

export const postComment = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { novelId: number; body: string; parentId?: number }) => input)
  .handler(async ({ context, data }) => {
    const text = data.body.trim();
    if (!text || text.length > 1000) throw new Error("Comment must be 1-1000 characters");
    const sql = await imperialSql();
    await ensureProfile(sql, context.userId);
    await sql`
      insert into comments (user_id, novel_id, body, parent_id)
      values (${context.userId}, ${data.novelId}, ${text}, ${data.parentId || null})
    `;
    return { ok: true };
  });

export const likeComment = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((commentId: number) => commentId)
  .handler(async ({ context, data: commentId }) => {
    const sql = await imperialSql();
    await ensureProfile(sql, context.userId);
    const x = await sql`select 1 from comment_likes where user_id = ${context.userId} and comment_id = ${commentId}`;
    if (x.length) await sql`delete from comment_likes where user_id = ${context.userId} and comment_id = ${commentId}`;
    else await sql`insert into comment_likes (user_id, comment_id) values (${context.userId}, ${commentId})`;
    const count = await sql<{ n: number }>`select count(*)::int as n from comment_likes where comment_id = ${commentId}`;
    return { likes: num(count[0]?.n), liked: !x.length };
  });

export const rateNovel = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { novelId: number; rating: number }) => input)
  .handler(async ({ context, data }) => {
    const rating = Math.round(data.rating);
    if (rating < 1 || rating > 5) throw new Error("Rating must be 1-5");
    const sql = await imperialSql();
    await ensureProfile(sql, context.userId);
    await sql`
      insert into ratings (user_id, novel_id, rating)
      values (${context.userId}, ${data.novelId}, ${rating})
      on conflict (user_id, novel_id)
      do update set rating = excluded.rating, updated_at = now()
    `;
    await sql`
      update novels set rating = coalesce((select avg(rating) from ratings where novel_id = ${data.novelId}), 0)
      where id = ${data.novelId}
    `;
    const stats = await sql<{ count: number; avg: number }>`
      select count(*)::int as count, coalesce(avg(rating),0)::float as avg from ratings where novel_id = ${data.novelId}
    `;
    return { ok: true, average: num(stats[0]?.avg), count: num(stats[0]?.count) };
  });

export const getRating = createServerFn({ method: "GET" })
  .validator((novelId: number) => novelId)
  .handler(async ({ data: novelId }) => {
    const sql = await imperialSql();
    const stats = await sql<{ count: number; avg: number }>`
      select count(*)::int as count, coalesce(avg(rating),0)::float as avg from ratings where novel_id = ${novelId}
    `;
    let user_rating = 0;
    try {
      const { getSessionUser } = await import("@/lib/auth/verify.server");
      const user = await getSessionUser();
      if (user) {
        const mine = await sql<{ rating: number }>`select rating from ratings where user_id = ${user.id} and novel_id = ${novelId}`;
        user_rating = num(mine[0]?.rating);
      }
    } catch {
      /* public */
    }
    return { count: num(stats[0]?.count), average: num(stats[0]?.avg), user_rating };
  });

export const listNotifications = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await imperialSql();
    await ensureProfile(sql, context.userId);
    return sql<{ id: number; title: string; body: string; read_at: string | null; created_at: string }>`
      select id, title, body, read_at::text as read_at, created_at::text as created_at
      from notifications where user_id = ${context.userId}
      order by created_at desc limit 50
    `;
  });

export const markNotificationsRead = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await imperialSql();
    await sql`update notifications set read_at = now() where user_id = ${context.userId} and read_at is null`;
    return { ok: true };
  });

export const submitRequest = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { url: string; title?: string }) => input)
  .handler(async ({ context, data }) => {
    let parsed: URL;
    try {
      parsed = new URL(data.url.trim());
    } catch {
      throw new Error("Enter a complete valid URL");
    }
    const sql = await imperialSql();
    const profile = await ensureProfile(sql, context.userId);
    const week = Math.floor(Date.now() / 1000 / 604800);
    const count = await sql<{ n: number }>`
      select count(*)::int as n from novel_requests where user_id = ${context.userId} and week_key = ${week}
    `;
    const used = num(count[0]?.n);
    const free = used < 3;
    const price = free ? 0 : (used - 3 + 1) * 5;
    if (!free && num(profile.tickets) < price) throw new Error(`Weekly free limit reached. This request costs ${price} tickets.`);
    await sql`
      insert into novel_requests (user_id, title, url, source_host, week_key, cost, status)
      values (${context.userId}, ${data.title || ""}, ${parsed.toString()}, ${parsed.hostname}, ${week}, ${price}, 'pending')
    `;
    if (price) {
      await sql`update profiles set tickets = tickets - ${price} where user_id = ${context.userId}`;
      await sql`
        insert into ticket_ledger (user_id, delta, reason, reference)
        values (${context.userId}, ${-price}, 'request', ${parsed.hostname})
      `;
    }
    return { ok: true, cost: price, message: "Request submitted for review." };
  });

export const getMyRequests = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await imperialSql();
    await ensureProfile(sql, context.userId);
    const week = Math.floor(Date.now() / 1000 / 604800);
    const count = await sql<{ n: number }>`
      select count(*)::int as n from novel_requests where user_id = ${context.userId} and week_key = ${week}
    `;
    const rows = await sql<{ id: number; url: string; source_host: string; cost: number; status: string; created_at: string }>`
      select id, url, source_host, cost::float as cost, status, created_at::text as created_at
      from novel_requests where user_id = ${context.userId} order by created_at desc limit 50
    `;
    return { used: num(count[0]?.n), limit: 3, rows };
  });

export const listOpenRequests = createServerFn({ method: "GET" }).handler(async () => {
  const sql = await imperialSql();
  return sql<{ id: number; url: string; source_host: string; votes: number; status: string }>`
    select r.id, r.url, r.source_host, r.status,
           coalesce((select count(*) from request_votes v where v.request_id = r.id),0)::int as votes
    from novel_requests r where r.status = 'pending' order by votes desc, r.created_at desc limit 50
  `;
});

export const voteRequest = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((requestId: number) => requestId)
  .handler(async ({ context, data: requestId }) => {
    const sql = await imperialSql();
    await ensureProfile(sql, context.userId);
    const x = await sql`select 1 from request_votes where request_id = ${requestId} and user_id = ${context.userId}`;
    if (x.length) {
      await sql`delete from request_votes where request_id = ${requestId} and user_id = ${context.userId}`;
      return { voted: false };
    }
    await sql`insert into request_votes (request_id, user_id) values (${requestId}, ${context.userId}) on conflict do nothing`;
    return { voted: true };
  });

export const reportContent = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { reason: string; details?: string; novelId?: number; chapterId?: number; commentId?: number }) => input)
  .handler(async ({ context, data }) => {
    const reason = data.reason.trim();
    if (!reason) throw new Error("Reason is required");
    const sql = await imperialSql();
    await ensureProfile(sql, context.userId);
    await sql`
      insert into reports (user_id, novel_id, chapter_id, comment_id, reason, details)
      values (${context.userId}, ${data.novelId || null}, ${data.chapterId || null}, ${data.commentId || null}, ${reason.slice(0, 300)}, ${(data.details || "").slice(0, 2000)})
    `;
    return { ok: true };
  });
