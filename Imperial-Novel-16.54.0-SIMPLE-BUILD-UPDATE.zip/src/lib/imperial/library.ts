import { createServerFn } from "@tanstack/react-start";
import { authMiddleware } from "@/lib/auth/middleware";
import { attachTaxonomy, ensureProfile, imperialSql, novelSelect } from "./db";
import type { NovelCard } from "./types";

export const toggleLibrary = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((novelId: number) => novelId)
  .handler(async ({ context, data: novelId }) => {
    const sql = await imperialSql();
    await ensureProfile(sql, context.userId);
    const exists = await sql`select 1 from user_library where user_id = ${context.userId} and novel_id = ${novelId}`;
    if (exists.length) {
      await sql`delete from user_library where user_id = ${context.userId} and novel_id = ${novelId}`;
      return { in_library: false };
    }
    await sql`insert into user_library (user_id, novel_id, shelf) values (${context.userId}, ${novelId}, 'reading') on conflict do nothing`;
    return { in_library: true };
  });

export const toggleFollow = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((novelId: number) => novelId)
  .handler(async ({ context, data: novelId }) => {
    const sql = await imperialSql();
    await ensureProfile(sql, context.userId);
    const exists = await sql`select 1 from follows where user_id = ${context.userId} and novel_id = ${novelId}`;
    if (exists.length) {
      await sql`delete from follows where user_id = ${context.userId} and novel_id = ${novelId}`;
      return { following: false };
    }
    await sql`insert into follows (user_id, novel_id) values (${context.userId}, ${novelId}) on conflict do nothing`;
    return { following: true };
  });

export const setBookmark = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { novelId: number; chapterNumber: number }) => input)
  .handler(async ({ context, data }) => {
    const sql = await imperialSql();
    await ensureProfile(sql, context.userId);
    await sql`
      insert into bookmarks (user_id, novel_id, chapter_number)
      values (${context.userId}, ${data.novelId}, ${data.chapterNumber})
      on conflict (user_id, novel_id)
      do update set chapter_number = excluded.chapter_number, updated_at = now()
    `;
    return { ok: true };
  });

export const getLibrary = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await imperialSql();
    await ensureProfile(sql, context.userId);
    const saved = await sql.query<NovelCard & { last_chapter: number; bookmark_chapter: number; shelf: string; favorite: boolean }>(
      `select ${novelSelect},
         coalesce((select chapter_number from history h where h.user_id=$1 and h.novel_id=n.id),0)::int as last_chapter,
         coalesce((select chapter_number from bookmarks b where b.user_id=$1 and b.novel_id=n.id),0)::int as bookmark_chapter,
         coalesce(l.shelf, 'reading') as shelf,
         coalesce(l.favorite, false) as favorite
       from user_library l join novels n on n.id = l.novel_id
       where l.user_id=$1 and n.publication_status='published'
       order by l.created_at desc`,
      [context.userId],
    );
    const history = await sql.query<NovelCard & { chapter_number: number }>(
      `select ${novelSelect}, h.chapter_number
       from history h join novels n on n.id = h.novel_id
       where h.user_id=$1 and n.publication_status='published'
       order by h.updated_at desc limit 50`,
      [context.userId],
    );
    const bookmarks = await sql.query<NovelCard & { chapter_number: number }>(
      `select ${novelSelect}, b.chapter_number
       from bookmarks b join novels n on n.id = b.novel_id
       where b.user_id=$1 and n.publication_status='published'
       order by b.updated_at desc limit 50`,
      [context.userId],
    );
    const following = await sql.query<NovelCard>(
      `select ${novelSelect}
       from follows f join novels n on n.id = f.novel_id
       where f.user_id=$1 and n.publication_status='published'
       order by f.created_at desc`,
      [context.userId],
    );
    return {
      saved: await attachTaxonomy(sql, saved),
      history: await attachTaxonomy(sql, history),
      bookmarks: await attachTaxonomy(sql, bookmarks),
      following: await attachTaxonomy(sql, following),
    };
  });

export const getMadeForYou = createServerFn({ method: "GET" }).handler(async () => {
  const sql = await imperialSql();
  try {
    const { getSessionUser } = await import("@/lib/auth/verify.server");
    const user = await getSessionUser();
    if (user) {
      const rows = await sql.query<NovelCard & { genre_overlap: number }>(
        `select ${novelSelect},
           (
             select count(*)::int from novel_genres ng
             where ng.novel_id = n.id
               and ng.genre_id in (
                 select ng2.genre_id from history h
                 join novel_genres ng2 on ng2.novel_id = h.novel_id
                 where h.user_id = $1
               )
           ) as genre_overlap
         from novels n
         where n.publication_status='published'
           and n.id not in (select novel_id from history where user_id=$1)
         order by genre_overlap desc, n.rating desc, n.views desc
         limit 12`,
        [user.id],
      );
      const overlap = rows.some((row) => Number(row.genre_overlap) > 0);
      return {
        personalized: overlap,
        basis: overlap ? ("shared-genres" as const) : ("catalog-rating" as const),
        results: await attachTaxonomy(sql, rows),
      };
    }
  } catch {
    /* public */
  }
  const rows = await sql.query<NovelCard>(
    `select ${novelSelect} from novels n where n.publication_status='published' order by n.views desc limit 12`,
  );
  return {
    personalized: false,
    basis: "popular" as const,
    results: await attachTaxonomy(sql, rows),
  };
});

export const setLibraryShelf = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { novelId: number; shelf: "reading" | "completed" | "dropped" }) => input)
  .handler(async ({ context, data }) => {
    const sql = await imperialSql();
    await ensureProfile(sql, context.userId);
    await sql`
      insert into user_library (user_id, novel_id, shelf)
      values (${context.userId}, ${data.novelId}, ${data.shelf})
      on conflict (user_id, novel_id) do update set shelf = excluded.shelf
    `;
    return { ok: true, shelf: data.shelf };
  });

export const toggleFavorite = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((novelId: number) => novelId)
  .handler(async ({ context, data: novelId }) => {
    const sql = await imperialSql();
    await ensureProfile(sql, context.userId);
    const row = await sql<{ favorite: boolean }>`
      select favorite from user_library where user_id = ${context.userId} and novel_id = ${novelId}
    `;
    if (!row[0]) {
      await sql`
        insert into user_library (user_id, novel_id, shelf, favorite)
        values (${context.userId}, ${novelId}, 'reading', true)
      `;
      return { favorite: true };
    }
    const next = !row[0].favorite;
    await sql`update user_library set favorite = ${next} where user_id = ${context.userId} and novel_id = ${novelId}`;
    return { favorite: next };
  });

