import { createServerFn } from "@tanstack/react-start";
import { authMiddleware } from "@/lib/auth/middleware";
import { ensureProfile, imperialSql, num } from "./db";

const TOOLS: Record<string, string> = {
  ideas: "Propose three original story ideas. Stay original. No copyrighted characters.",
  world: "Develop a concise original world bible: places, factions, rules of power.",
  character: "Create a character dossier: want, wound, method, contradiction.",
  plot: "Outline a three-act plot with turning points. Original only.",
  outline: "Write a chapter-by-chapter outline for the next 8 chapters.",
  write: "Write a 700-1000 word original chapter draft in literary prose.",
  rewrite: "Rewrite the passage for clarity and voice without changing plot.",
  grammar: "Correct grammar and rhythm. Return the cleaned passage only.",
  continuity: "Check continuity issues and list contradictions.",
  lore: "Extract a lore entry from the text: names, places, rules.",
  summary: "Summarize the chapter in 8 sentences for a recap page.",
  expand: "Expand the outline into a fuller scene, still original.",
};

export const listAiProjects = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await imperialSql();
    await ensureProfile(sql, context.userId);
    return sql<{
      id: number;
      name: string;
      mode: string;
      status: string;
      genre: string;
      premise: string;
      protagonist: string;
      novel_id: number | null;
      chapters_target: number;
      chapters_generated: number;
    }>`
      select id, name, mode, status, genre, premise, protagonist, novel_id, chapters_target, chapters_generated
      from ai_projects where owner_user_id = ${context.userId} order by updated_at desc
    `;
  });

export const createAiProject = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { name: string; mode?: string; genre?: string; premise?: string; protagonist?: string; novel_id?: number; chapters_target?: number }) => input)
  .handler(async ({ context, data }) => {
    const sql = await imperialSql();
    await ensureProfile(sql, context.userId);
    const rows = await sql<{ id: number }>`
      insert into ai_projects (owner_user_id, novel_id, name, mode, genre, premise, protagonist, chapters_target)
      values (
        ${context.userId}, ${data.novel_id || null}, ${data.name.trim()}, ${data.mode || "manual"},
        ${data.genre || "Fantasy"}, ${data.premise || ""}, ${data.protagonist || ""}, ${data.chapters_target || 10}
      ) returning id
    `;
    return { id: rows[0]!.id };
  });

export const runAiTool = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { project_id?: number; tool: string; prompt: string }) => input)
  .handler(async ({ context, data }) => {
    const sql = await imperialSql();
    await ensureProfile(sql, context.userId);
    const tool = TOOLS[data.tool] || TOOLS.ideas;
    const apiKey = process.env.XAI_API_KEY;
    if (!apiKey) {
      return {
        ok: false as const,
        error: "AI Author Studio is unavailable in this environment. No server-side model key is configured.",
      };
    }
    const prompt = data.prompt.trim();
    if (prompt.length < 8) throw new Error("Give the model a little more to work with.");
    const res = await fetch("https://api.x.ai/v1/chat/completions", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${apiKey}` },
      body: JSON.stringify({
        model: "grok-4.5",
        max_tokens: 1200,
        messages: [
          {
            role: "system",
            content:
              "You are an editor in Imperial Novel's Author Studio. Produce original literary assistance only. Never imitate copyrighted novels, never include secrets, never claim a scrape source. If asked for fanfiction of protected IP, refuse and offer an original analogue.",
          },
          { role: "user", content: `${tool}\n\nAuthor brief:\n${prompt.slice(0, 6000)}` },
        ],
      }),
    });
    if (!res.ok) return { ok: false as const, error: `The writing engine returned ${res.status}. Try again in a moment.` };
    const body = (await res.json()) as { choices?: { message?: { content?: string } }[] };
    const text = body.choices?.[0]?.message?.content ?? "";
    if (data.project_id) {
      await sql`
        insert into ai_jobs (project_id, owner_user_id, tool, status, prompt, result, provider)
        values (${data.project_id}, ${context.userId}, ${data.tool}, 'ok', ${prompt.slice(0, 2000)}, ${text}, 'xai')
      `;
      if (data.tool === "write") {
        await sql`update ai_projects set chapters_generated = chapters_generated + 1, updated_at = now() where id = ${data.project_id} and owner_user_id = ${context.userId}`;
      }
    }
    return { ok: true as const, text, provider: "xai" };
  });

export const listAiJobs = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .validator((projectId: number) => projectId)
  .handler(async ({ context, data: projectId }) => {
    const sql = await imperialSql();
    return sql<{ id: number; tool: string; result: string; created_at: string }>`
      select id, tool, result, created_at::text as created_at
      from ai_jobs where project_id = ${projectId} and owner_user_id = ${context.userId}
      order by created_at desc limit 30
    `;
  });

export const aiAvailable = createServerFn({ method: "GET" }).handler(async () => {
  return { available: Boolean(process.env.XAI_API_KEY) };
});
