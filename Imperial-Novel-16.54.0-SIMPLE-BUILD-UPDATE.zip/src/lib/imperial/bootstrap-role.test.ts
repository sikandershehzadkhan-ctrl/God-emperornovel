import assert from "node:assert/strict";
import test from "node:test";
import { matchesVerifiedBootstrapAdminEmail, resolveNewProfileRole } from "./bootstrap-role.ts";

test("new accounts are never admins when bootstrap ID is absent", () => {
  assert.equal(resolveNewProfileRole("user-1", undefined), "user");
  assert.equal(resolveNewProfileRole("user-1", ""), "user");
  assert.equal(resolveNewProfileRole("user-1", "   "), "user");
});

test("only the exact configured user ID receives the bootstrap admin role", () => {
  assert.equal(resolveNewProfileRole("user-1", "user-1"), "admin");
  assert.equal(resolveNewProfileRole("user-2", "user-1"), "user");
  assert.equal(resolveNewProfileRole("user-1-extra", "user-1"), "user");
});

test("bootstrap matching trims operator configuration and candidate ID", () => {
  assert.equal(resolveNewProfileRole(" user-1 ", " user-1 "), "admin");
});

import { readFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";

const here = dirname(fileURLToPath(import.meta.url));

test("profile creation uses explicit bootstrap configuration, not first-account count", async () => {
  const source = await readFile(resolve(here, "db.ts"), "utf8");
  assert.match(source, /resolveNewProfileRole\(/);
  assert.match(source, /IMPERIAL_BOOTSTRAP_ADMIN_USER_ID/);
  assert.match(source, /IMPERIAL_BOOTSTRAP_ADMIN_EMAIL/);
  assert.match(source, /matchesVerifiedBootstrapAdminEmail/);
  assert.doesNotMatch(source, /count\(\*\).*role\s*=\s*'admin'/is);
});

test("Cloudflare auth allowlists the bootstrap ID as a string setting", async () => {
  const source = await readFile(resolve(here, "../auth/cloudflare.server.ts"), "utf8");
  assert.match(source, /IMPERIAL_BOOTSTRAP_ADMIN_USER_ID\?: string/);
  assert.match(source, /"IMPERIAL_BOOTSTRAP_ADMIN_USER_ID"/);
  assert.match(source, /IMPERIAL_BOOTSTRAP_ADMIN_EMAIL\?: string/);
  assert.match(source, /"IMPERIAL_BOOTSTRAP_ADMIN_EMAIL"/);
});

test("email bootstrap requires an exact matching verified email", () => {
  assert.equal(matchesVerifiedBootstrapAdminEmail("owner@example.com", true, "owner@example.com"), true);
  assert.equal(matchesVerifiedBootstrapAdminEmail("OWNER@EXAMPLE.COM", true, " owner@example.com "), true);
  assert.equal(matchesVerifiedBootstrapAdminEmail("owner@example.com", false, "owner@example.com"), false);
  assert.equal(matchesVerifiedBootstrapAdminEmail("other@example.com", true, "owner@example.com"), false);
  assert.equal(matchesVerifiedBootstrapAdminEmail(undefined, true, "owner@example.com"), false);
});
