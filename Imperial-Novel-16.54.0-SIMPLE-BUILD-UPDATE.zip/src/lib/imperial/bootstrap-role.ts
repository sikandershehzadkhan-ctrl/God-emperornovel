/**
 * Resolve the role for a newly created Imperial Novel profile.
 *
 * Security invariant: account order must never grant administrator privileges.
 * An administrator bootstrap is allowed only when an operator explicitly sets
 * IMPERIAL_BOOTSTRAP_ADMIN_USER_ID to the exact authenticated user ID.
 */
export function resolveNewProfileRole(
  userId: string,
  bootstrapAdminUserId: string | undefined,
): "admin" | "user" {
  const configuredId = bootstrapAdminUserId?.trim();
  const candidateId = userId.trim();
  return configuredId && candidateId && candidateId === configuredId ? "admin" : "user";
}

/** Only a verified email can use the optional email-based bootstrap path. */
export function matchesVerifiedBootstrapAdminEmail(
  accountEmail: string | undefined,
  emailVerified: boolean,
  configuredEmail: string | undefined,
): boolean {
  const account = accountEmail?.trim().toLowerCase();
  const configured = configuredEmail?.trim().toLowerCase();
  return Boolean(account && configured && emailVerified && account === configured);
}
