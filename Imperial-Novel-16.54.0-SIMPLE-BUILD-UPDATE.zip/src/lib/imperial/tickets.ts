import { createServerFn } from "@tanstack/react-start";
import { authMiddleware } from "@/lib/auth/middleware";
import { ensureProfile, imperialSql, num } from "./db";
import { EASYPAISA_NUMBER } from "./types";

export const getTickets = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await imperialSql();
    const profile = await ensureProfile(sql, context.userId);
    const ledger = await sql<{ id: number; delta: number; reason: string; reference: string; created_at: string }>`
      select id, delta::float as delta, reason, reference, created_at::text as created_at
      from ticket_ledger where user_id = ${context.userId}
      order by created_at desc limit 100
    `;
    const donations = await sql<{ id: number; amount: number; reference_id: string; status: string; created_at: string }>`
      select id, amount::float as amount, reference_id, status, created_at::text as created_at
      from donations where user_id = ${context.userId} order by created_at desc limit 50
    `;
    return {
      tickets: num(profile.tickets),
      ledger,
      donations,
      easypaisa: EASYPAISA_NUMBER,
      packs: [10, 25, 50, 100],
    };
  });

export const submitDonation = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { amount: number; reference_id: string }) => input)
  .handler(async ({ context, data }) => {
    const amount = Number(data.amount);
    const ref = String(data.reference_id || "").trim();
    if (!Number.isSafeInteger(amount) || amount < 1 || amount > 1_000_000) {
      throw new Error("Enter a whole PKR amount between 1 and 1,000,000");
    }
    if (ref.length < 4 || ref.length > 120) throw new Error("Transaction / reference number must be 4 to 120 characters");
    const sql = await imperialSql();
    await ensureProfile(sql, context.userId);
    const dup = await sql`select id, status from donations where reference_id = ${ref}`;
    if (dup.length) throw new Error("This transaction reference has already been submitted");
    await sql`
      insert into donations (user_id, amount, reference_id, status)
      values (${context.userId}, ${amount}, ${ref}, 'pending')
    `;
    await sql`
      insert into notifications (user_id, title, body)
      values (${context.userId}, 'Donation received for review', ${"Reference " + ref + " is pending administrator verification. Tickets are credited only after approval."})
    `;
    return { ok: true, message: "Payment submitted for verification. Tickets are not credited until an administrator confirms the transfer." };
  });
