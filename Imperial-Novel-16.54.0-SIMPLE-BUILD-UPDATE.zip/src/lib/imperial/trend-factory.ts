import { createServerFn } from "@tanstack/react-start";
import { authMiddleware } from "@/lib/auth/middleware";
import { z } from "zod";
import { audit, imperialSql, requireProfileRole } from "./db";
import { canAdvanceTrendStage, ELIGIBLE_TREND_RIGHTS, hasMeaningfulRightsEvidence, TREND_FACTORY_STAGES, type TrendFactoryStage, type TrendRightsStatus } from "./trend-factory-policy";

function safeHttpUrl(value: string, label: string): URL {
  let parsed: URL;
  try {
    parsed = new URL(value.trim());
  } catch {
    throw new Error(`${label} must be a valid URL.`);
  }
  if (parsed.protocol !== "https:" && parsed.protocol !== "http:") {
    throw new Error(`${label} must use HTTP or HTTPS.`);
  }
  if (parsed.username || parsed.password) throw new Error(`${label} cannot contain credentials.`);
  return parsed;
}

export const listTrendCandidates = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await imperialSql();
    await requireProfileRole(sql, context.userId, ["admin"]);
    return sql<{
      id: number; trend_title: string; trend_url: string; source_host: string; trend_signal: string;
      stage: TrendFactoryStage; author_name: string; author_profile_url: string; rights_status: TrendRightsStatus;
      rights_evidence: string; notes: string; novel_id: number | null; created_by: string;
      created_at: string; updated_at: string;
    }>`select id, trend_title, trend_url, source_host, trend_signal, stage, author_name, author_profile_url,
       rights_status, rights_evidence, notes, novel_id, created_by,
       created_at::text as created_at, updated_at::text as updated_at
       from trend_candidates order by updated_at desc limit 300`;
  });

export const createTrendCandidate = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { trend_title: string; trend_url: string; trend_signal?: string; author_name?: string; author_profile_url?: string; notes?: string }) => z.object({
    trend_title: z.string().trim().min(2).max(180),
    trend_url: z.string().trim().min(8).max(2000),
    trend_signal: z.string().max(1000).optional(),
    author_name: z.string().max(180).optional(),
    author_profile_url: z.string().max(2000).optional(),
    notes: z.string().max(2000).optional(),
  }).parse(input))
  .handler(async ({ context, data }) => {
    const sql = await imperialSql();
    await requireProfileRole(sql, context.userId, ["admin"]);
    const title = data.trend_title.trim();
    if (title.length < 2 || title.length > 180) throw new Error("Trend title must be between 2 and 180 characters.");
    const source = safeHttpUrl(data.trend_url, "Trend source URL");
    const authorProfile = data.author_profile_url?.trim() ? safeHttpUrl(data.author_profile_url, "Author profile URL").toString() : "";
    const signal = (data.trend_signal || "").trim().slice(0, 1000);
    const notes = (data.notes || "").trim().slice(0, 2000);
    const authorName = (data.author_name || "").trim().slice(0, 180);
    const rows = await sql<{ id: number }>`
      insert into trend_candidates (trend_title, trend_url, source_host, trend_signal, author_name, author_profile_url, notes, created_by)
      values (${title}, ${source.toString()}, ${source.hostname.toLowerCase()}, ${signal}, ${authorName}, ${authorProfile}, ${notes}, ${context.userId})
      returning id
    `;
    await audit(sql, context.userId, "trend_candidate_created", `${rows[0]!.id}:${source.hostname.toLowerCase()}`);
    return { ok: true, id: rows[0]!.id };
  });

export const advanceTrendCandidate = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: {
    id: number; stage: TrendFactoryStage; rights_status?: TrendRightsStatus; rights_evidence?: string;
    author_name?: string; author_profile_url?: string; notes?: string; novel_id?: number | null;
  }) => z.object({
    id: z.number().int().positive(),
    stage: z.enum(TREND_FACTORY_STAGES),
    rights_status: z.enum(["unknown", "original", "public_domain", "licensed", "authorized"]).optional(),
    rights_evidence: z.string().max(4000).optional(),
    author_name: z.string().max(180).optional(),
    author_profile_url: z.string().max(2000).optional(),
    notes: z.string().max(2000).optional(),
    novel_id: z.number().int().positive().nullable().optional(),
  }).parse(input))
  .handler(async ({ context, data }) => {
    const sql = await imperialSql();
    await requireProfileRole(sql, context.userId, ["admin"]);
    if (!TREND_FACTORY_STAGES.includes(data.stage)) throw new Error("Invalid Trend Factory stage.");
    const rows = await sql<{
      id: number; stage: TrendFactoryStage; rights_status: TrendRightsStatus; rights_evidence: string; novel_id: number | null;
    }>`select id, stage, rights_status, rights_evidence, novel_id from trend_candidates where id = ${data.id}`;
    const current = rows[0];
    if (!current) throw new Error("Trend candidate not found.");
    if (!canAdvanceTrendStage(current.stage, data.stage)) {
      throw new Error(`Invalid transition: ${current.stage} → ${data.stage}. Follow the rights-first workflow in order.`);
    }
    const rightsStatus = data.rights_status ?? current.rights_status;
    const rightsEvidence = (data.rights_evidence ?? current.rights_evidence).trim().slice(0, 4000);
    if (data.stage === "review" || data.stage === "linked_to_novel" || data.stage === "published") {
      if (!ELIGIBLE_TREND_RIGHTS.includes(rightsStatus) || !hasMeaningfulRightsEvidence(rightsEvidence)) {
        throw new Error("Rights review requires an eligible rights status and meaningful evidence before review can proceed.");
      }
    }
    let novelId = data.novel_id === undefined ? current.novel_id : data.novel_id;
    if (data.stage === "linked_to_novel" || data.stage === "published") {
      if (!novelId || !Number.isSafeInteger(novelId)) throw new Error("Link a real Imperial Novel record before this stage.");
      const novel = await sql<{ publication_status: string; rights_status: string; rights_evidence: string }>`
        select publication_status, rights_status, rights_evidence from novels where id = ${novelId}
      `;
      if (!novel[0]) throw new Error("Linked novel was not found.");
      if (!ELIGIBLE_TREND_RIGHTS.includes(novel[0].rights_status as TrendRightsStatus) || !hasMeaningfulRightsEvidence(novel[0].rights_evidence)) {
        throw new Error("The linked novel must have eligible rights status and evidence recorded in its own rights review.");
      }
      if (data.stage === "published" && novel[0].publication_status !== "published") {
        throw new Error("The linked novel must already be published through the normal publication review.");
      }
    }
    const authorProfile = data.author_profile_url?.trim()
      ? safeHttpUrl(data.author_profile_url, "Author profile URL").toString()
      : undefined;
    const result = await sql<{ id: number }>`
      update trend_candidates set stage = ${data.stage}, rights_status = ${rightsStatus}, rights_evidence = ${rightsEvidence},
        author_name = coalesce(${data.author_name?.trim().slice(0, 180) || null}, author_name),
        author_profile_url = coalesce(${authorProfile ?? null}, author_profile_url),
        notes = coalesce(${data.notes?.trim().slice(0, 2000) || null}, notes),
        novel_id = ${novelId ?? null}, updated_at = now()
      where id = ${data.id} and stage = ${current.stage}
      returning id
    `;
    if (!result.length) throw new Error("Candidate changed during review. Refresh and try again.");
    await audit(sql, context.userId, "trend_candidate_stage", `${data.id}:${current.stage}->${data.stage}`);
    return { ok: true, stage: data.stage };
  });
