import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { authMiddleware } from "@/lib/auth/middleware";
import { ensureProfile, imperialSql, num } from "./db";

export const getChapter = createServerFn({ method: "GET" })
  .validator((input: { novelId: number; chapterNumber: number }) => input)
  .handler(async ({ data }) => {
    const sql = await imperialSql();
    const novel = await sql<{ id: number; title: string; author: string; cover_url: string; slug: string }>`
      select id, title, author, cover_url, slug from novels
      where id = ${data.novelId} and publication_status = 'published'
    `;
    if (!novel[0]) throw new Error("Novel not found");
    const chapters = await sql<{
      id: number;
      chapter_number: number;
      title: string;
      is_locked: boolean;
      ticket_cost: number;
    }>`
      select id, chapter_number, title, is_locked, ticket_cost::float as ticket_cost
      from chapters
      where novel_id = ${data.novelId} and publication_status = 'published'
      order by chapter_number
    `;
    const current = chapters.find((c) => c.chapter_number === data.chapterNumber);
    if (!current) throw new Error("Chapter not found");
    const full = await sql<{ content: string; is_locked: boolean; ticket_cost: number }>`
      select content, is_locked, ticket_cost::float as ticket_cost from chapters where id = ${current.id}
    `;
    let unlocked = !full[0]?.is_locked;
    let userId: string | null = null;
    try {
      const { getSessionUser } = await import("@/lib/auth/verify.server");
      const user = await getSessionUser();
      userId = user?.id ?? null;
      if (user && full[0]?.is_locked) {
        const row = await sql`select 1 from unlocks where user_id = ${user.id} and chapter_id = ${current.id}`;
        unlocked = row.length > 0;
      }
    } catch {
      /* public */
    }
    const idx = chapters.findIndex((c) => c.chapter_number === data.chapterNumber);
    return {
      novel: novel[0],
      chapters,
      chapter: {
        ...current,
        content: unlocked ? full[0]?.content || "This chapter has no content yet." : "",
        unlocked,
        ticket_cost: num(full[0]?.ticket_cost),
      },
      previous: idx > 0 ? chapters[idx - 1] : null,
      next: idx < chapters.length - 1 ? chapters[idx + 1] : null,
      signedIn: Boolean(userId),
    };
  });

export const unlockChapter = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((chapterId: number) => chapterId)
  .handler(async ({ context, data: chapterId }) => {
    const sql = await imperialSql();
    const profile = await ensureProfile(sql, context.userId);
    const ch = await sql<{
      id: number;
      novel_id: number;
      chapter_number: number;
      is_locked: boolean;
      ticket_cost: number;
      publication_status: string;
    }>`
      select id, novel_id, chapter_number, is_locked, ticket_cost::float as ticket_cost, publication_status
      from chapters where id = ${chapterId}
    `;
    if (!ch[0] || ch[0].publication_status !== "published") throw new Error("Chapter not found");
    if (!ch[0].is_locked) return { ok: true, tickets: profile.tickets, already: true };
    const existing = await sql`select 1 from unlocks where user_id = ${context.userId} and chapter_id = ${chapterId}`;
    if (existing.length) return { ok: true, tickets: profile.tickets, already: true };
    const cost = num(ch[0].ticket_cost);
    if (num(profile.tickets) < cost) throw new Error("Not enough tickets");
    // The database trigger debits tickets and writes the ledger inside the
    // unlock INSERT transaction. Never split those writes across requests.
    await sql.batch([{
      text: "insert into unlocks (user_id, chapter_id, cost) values ($1, $2, $3) on conflict (user_id, chapter_id) do nothing",
      params: [context.userId, chapterId, cost],
    }]);
    const next = await sql<{ tickets: number }>`select tickets::float as tickets from profiles where user_id = ${context.userId}`;
    const confirmed = await sql`select 1 from unlocks where user_id = ${context.userId} and chapter_id = ${chapterId}`;
    if (!confirmed.length) throw new Error("Chapter unlock could not be completed");
    return { ok: true, tickets: num(next[0]?.tickets), already: false };
  });

export const batchUnlock = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { novelId: number; count: number; start: number }) =>
    z.object({ novelId: z.number(), count: z.number(), start: z.number() }).parse(input),
  )
  .handler(async ({ context, data }) => {
    if (![10, 25, 50, 100].includes(data.count)) throw new Error("Batch size must be 10, 25, 50 or 100");
    const sql = await imperialSql();
    const profile = await ensureProfile(sql, context.userId);
    const locked = await sql<{ id: number; ticket_cost: number }>`
      select c.id, c.ticket_cost::float as ticket_cost
      from chapters c
      where c.novel_id = ${data.novelId}
        and c.publication_status = 'published'
        and c.is_locked = true
        and c.chapter_number >= ${data.start}
        and c.id not in (select chapter_id from unlocks where user_id = ${context.userId})
      order by c.chapter_number
      limit ${data.count}
    `;
    const cost = locked.reduce((a, x) => a + num(x.ticket_cost), 0);
    if (num(profile.tickets) < cost) throw new Error(`Not enough tickets. Need ${cost}.`);
    if (locked.length) {
      // One native transaction for the whole batch. Each unlock row invokes the
      // trigger that checks/debits balance and inserts its ledger entry; if any
      // chapter cannot be paid for, every insert and debit rolls back together.
      await sql.batch(locked.map((row) => ({
        text: "insert into unlocks (user_id, chapter_id, cost) values ($1, $2, $3) on conflict (user_id, chapter_id) do nothing",
        params: [context.userId, row.id, num(row.ticket_cost)],
      })));
    }
    const next = await sql<{ tickets: number }>`select tickets::float as tickets from profiles where user_id = ${context.userId}`;
    return { unlocked: locked.length, cost, tickets: num(next[0]?.tickets) };
  });

export const saveProgress = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { novelId: number; chapterNumber: number }) => input)
  .handler(async ({ context, data }) => {
    const sql = await imperialSql();
    await ensureProfile(sql, context.userId);
    await sql`
      insert into history (user_id, novel_id, chapter_number)
      values (${context.userId}, ${data.novelId}, ${data.chapterNumber})
      on conflict (user_id, novel_id)
      do update set chapter_number = excluded.chapter_number, updated_at = now()
    `;
    await sql`
      insert into bookmarks (user_id, novel_id, chapter_number)
      values (${context.userId}, ${data.novelId}, ${data.chapterNumber})
      on conflict (user_id, novel_id)
      do update set chapter_number = excluded.chapter_number, updated_at = now()
    `;
    return { ok: true };
  });
