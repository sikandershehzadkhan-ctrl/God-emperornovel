export type Role = "user" | "author" | "moderator" | "admin";

export type NovelCard = {
  id: number;
  title: string;
  slug: string;
  author: string;
  description: string;
  status: string;
  kind: string;
  language: string;
  cover_url: string;
  rights_status: string;
  views: number;
  rating: number;
  publication_status: string;
  featured: boolean;
  category: string;
  chapter_count: number;
  latest_chapter: number;
  updated_at: string;
  genres: { name: string; slug: string }[];
  tags: { name: string; slug: string }[];
};

export type ChapterSummary = {
  id: number;
  chapter_number: number;
  title: string;
  is_locked: boolean;
  ticket_cost: number;
  publication_status: string;
};

export type Profile = {
  user_id: string;
  username: string;
  role: Role;
  tickets: number;
  verified: boolean;
  banned: boolean;
  bio: string;
  email?: string | null;
};

export const CATEGORIES = [
  { slug: "anime-manga", name: "Anime & Manga" },
  { slug: "games", name: "Games" },
  { slug: "drama-tv", name: "Drama & TV" },
  { slug: "fantasy-worlds", name: "Fantasy Worlds" },
  { slug: "original-fiction", name: "Original Fiction" },
  { slug: "fanfiction", name: "Fanfiction" },
] as const;

export const CORE_GENRES = [
  "Fantasy",
  "Action",
  "Adventure",
  "Romance",
  "Cultivation",
  "Xianxia",
  "Wuxia",
  "Sci-Fi",
  "Progression Fantasy",
  "System",
  "Reincarnation",
  "Isekai",
  "Kingdom Building",
  "Empire Building",
  "Comedy",
  "Mystery",
  "Horror",
  "LitRPG",
  "Cyberpunk",
  "Drama",
] as const;

export const CORE_TAGS = [
  "system",
  "weak-to-strong",
  "empire",
  "court-intrigue",
  "male-lead",
  "female-lead",
  "original-world",
  "magic",
  "strategy",
  "slow-burn",
  "found-family",
  "antihero",
  "isekai",
] as const;

export const CONNECTOR_REGISTRY = [
  { name: "WTR-Lab", host: "wtr-lab.com" },
  { name: "FictionZone", host: "fictionzone.net" },
  { name: "Tomato MTL", host: "tomatomtl.com" },
  { name: "TWKan", host: "twkan.com" },
  { name: "Fanqie Novel", host: "fanqienovel.com" },
  { name: "QQ Reading", host: "book.qq.com" },
] as const;

export const APP_VERSION = "16.54.0";
export const APP_NAME = "Imperial Novel";
export const BRAND_LINE = "Read • Create • Conquer";
export const EASYPAISA_NUMBER = "03154329984";
export const BATCH_UNLOCK = [10, 25, 50, 100] as const;

export const PATRON_TIERS = [
  { id: "bronze", name: "Bronze", pkr: 500, perks: "Suggested support to keep the archive running." },
  { id: "silver", name: "Silver", pkr: 1500, perks: "Helps fund original chapters and catalog work." },
  { id: "gold", name: "Gold", pkr: 3000, perks: "Sustains author tools and reading infrastructure." },
  { id: "royal", name: "Royal", pkr: 7500, perks: "Highest suggested patronage. Still verified by an administrator." },
] as const;
