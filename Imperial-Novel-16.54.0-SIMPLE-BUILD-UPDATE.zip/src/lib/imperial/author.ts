import { createServerFn } from "@tanstack/react-start";
import { authMiddleware } from "@/lib/auth/middleware";
import { ensureProfile, imperialSql, num } from "./db";
import { slugify } from "@/lib/utils";

async function ownNovel(sql: Awaited<ReturnType<typeof imperialSql>>, userId: string, novelId: number, role: string) {
  const n = await sql<{ id: number; owner_user_id: string | null; publication_status: string }>`
    select id, owner_user_id, publication_status from novels where id = ${novelId}
  `;
  if (!n[0]) throw new Error("Novel not found");
  if (role === "admin" || role === "moderator") return n[0];
  if (n[0].owner_user_id !== userId) throw new Error("Forbidden");
  return n[0];
}

export const listAuthorNovels = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await imperialSql();
    const profile = await ensureProfile(sql, context.userId);
    const rows = await sql<{
      id: number;
      title: string;
      author: string;
      publication_status: string;
      rights_status: string;
      review_feedback: string;
      views: number;
      rating: number;
      chapter_count: number;
      published_chapters: number;
      description: string;
      status: string;
      kind: string;
      cover_url: string;
    }>`
      select n.id, n.title, n.author, n.publication_status, n.rights_status, n.review_feedback,
             n.views, n.rating::float as rating, n.description, n.status, n.kind, n.cover_url,
             (select count(*) from chapters c where c.novel_id = n.id)::int as chapter_count,
             (select count(*) from chapters c where c.novel_id = n.id and c.publication_status='published')::int as published_chapters
      from novels n
      where n.owner_user_id = ${context.userId}
         or ${profile.role} = 'admin'
      order by n.updated_at desc
      limit 100
    `;
    return { profile, novels: rows };
  });

export const getStudioNovel = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .validator((id: number) => id)
  .handler(async ({ context, data: id }) => {
    const sql = await imperialSql();
    const profile = await ensureProfile(sql, context.userId);
    await ownNovel(sql, context.userId, id, profile.role);
    const novel = await sql<{
      id: number;
      title: string;
      slug: string;
      author: string;
      description: string;
      status: string;
      kind: string;
      language: string;
      cover_url: string;
      alt_titles: string;
      rights_status: string;
      rights_evidence: string;
      rights_notes: string;
      publication_status: string;
      review_feedback: string;
      category: string;
    }>`
      select id, title, slug, author, description, status, kind, language, cover_url, alt_titles,
             rights_status, rights_evidence, rights_notes, publication_status, review_feedback, category
      from novels where id = ${id}
    `;
    if (!novel[0]) throw new Error("Novel not found");
    const chapters = await sql<{
      id: number;
      novel_id: number;
      chapter_number: number;
      title: string;
      content: string;
      is_locked: boolean;
      ticket_cost: number;
      publication_status: string;
    }>`
      select id, novel_id, chapter_number, title, content, is_locked, ticket_cost::float as ticket_cost, publication_status
      from chapters where novel_id = ${id} order by chapter_number
    `;
    return { profile, novel: novel[0], chapters };
  });

export const createNovel = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: {
    title: string;
    author: string;
    description?: string;
    kind?: string;
    status?: string;
    language?: string;
    rights_status?: string;
    rights_evidence?: string;
    cover_url?: string;
    alt_titles?: string;
    category?: string;
  }) => input)
  .handler(async ({ context, data }) => {
    const title = data.title.trim();
    if (title.length < 2) throw new Error("Title is required");
    const sql = await imperialSql();
    const profile = await ensureProfile(sql, context.userId);
    const base = slugify(title) || "untitled";
    let slug = base;
    for (let i = 0; i < 6; i++) {
      const clash = await sql`select 1 from novels where slug = ${slug}`;
      if (!clash.length) break;
      slug = `${base}-${i + 2}`;
    }
    const rows = await sql<{ id: number }>`
      insert into novels (
        title, slug, author, description, status, kind, language, cover_url, alt_titles,
        rights_status, rights_evidence, publication_status, owner_user_id, category
      ) values (
        ${title}, ${slug}, ${data.author.trim() || profile.username}, ${data.description || ""},
        ${data.status || "ongoing"}, ${data.kind || "original"}, ${data.language || "English"},
        ${data.cover_url || ""}, ${data.alt_titles || ""}, ${data.rights_status || "original"},
        ${data.rights_evidence || ""}, 'draft', ${context.userId}, ${data.category || "original-fiction"}
      ) returning id
    `;
    return { id: rows[0]!.id, message: "Draft created. Submit it for review when the rights evidence is complete." };
  });

export const updateNovel = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: Record<string, unknown> & { id: number }) => input)
  .handler(async ({ context, data }) => {
    const sql = await imperialSql();
    const profile = await ensureProfile(sql, context.userId);
    await ownNovel(sql, context.userId, data.id, profile.role);
    const n = await sql`select publication_status from novels where id = ${data.id}`;
    if (String((n[0] as { publication_status: string })?.publication_status) === "published" && profile.role !== "admin") {
      throw new Error("Published novels must be edited through review");
    }
    await sql`
      update novels set
        title = coalesce(${(data.title as string) || null}, title),
        author = coalesce(${(data.author as string) || null}, author),
        description = coalesce(${data.description as string | null}, description),
        status = coalesce(${(data.status as string) || null}, status),
        kind = coalesce(${(data.kind as string) || null}, kind),
        language = coalesce(${(data.language as string) || null}, language),
        cover_url = coalesce(${(data.cover_url as string) || null}, cover_url),
        category = coalesce(${(data.category as string) || null}, category),
        rights_status = coalesce(${(data.rights_status as string) || null}, rights_status),
        rights_evidence = coalesce(${(data.rights_evidence as string) || null}, rights_evidence),
        rights_notes = coalesce(${(data.rights_notes as string) || null}, rights_notes),
        updated_at = now()
      where id = ${data.id}
    `;
    return { ok: true, message: "Novel saved." };
  });

export const submitNovel = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((id: number) => id)
  .handler(async ({ context, data: id }) => {
    const sql = await imperialSql();
    const profile = await ensureProfile(sql, context.userId);
    const n = await ownNovel(sql, context.userId, id, profile.role);
    if (n.publication_status === "published") return { message: "Already published." };
    await sql`update novels set publication_status = 'review', updated_at = now() where id = ${id}`;
    return { message: "Submitted for publication review." };
  });

export const listAuthorChapters = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .validator((novelId: number) => novelId)
  .handler(async ({ context, data: novelId }) => {
    const sql = await imperialSql();
    const profile = await ensureProfile(sql, context.userId);
    await ownNovel(sql, context.userId, novelId, profile.role);
    return sql<{
      id: number;
      novel_id: number;
      chapter_number: number;
      title: string;
      content: string;
      is_locked: boolean;
      ticket_cost: number;
      publication_status: string;
    }>`
      select id, novel_id, chapter_number, title, content, is_locked, ticket_cost::float as ticket_cost, publication_status
      from chapters where novel_id = ${novelId} order by chapter_number
    `;
  });

export const saveChapter = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: {
    id?: number;
    novel_id: number;
    chapter_number: number;
    title: string;
    content: string;
    is_locked?: boolean;
    ticket_cost?: number;
  }) => input)
  .handler(async ({ context, data }) => {
    if (!data.content.trim()) throw new Error("Chapter content is required");
    if (!Number.isSafeInteger(data.chapter_number) || data.chapter_number < 1) {
      throw new Error("Chapter number must be a positive whole number");
    }
    const ticketCost = num(data.ticket_cost);
    if (!Number.isSafeInteger(ticketCost) || ticketCost < 0 || ticketCost > 100000) {
      throw new Error("Ticket cost must be a whole number between 0 and 100000");
    }
    const sql = await imperialSql();
    const profile = await ensureProfile(sql, context.userId);
    await ownNovel(sql, context.userId, data.novel_id, profile.role);
    if (data.id) {
      await sql`
        update chapters set
          chapter_number = ${data.chapter_number},
          title = ${data.title.trim()},
          content = ${data.content},
          is_locked = ${Boolean(data.is_locked)},
          ticket_cost = ${ticketCost},
          updated_at = now()
        where id = ${data.id} and novel_id = ${data.novel_id}
      `;
      return { id: data.id, message: "Chapter saved as draft." };
    }
    const rows = await sql<{ id: number }>`
      insert into chapters (novel_id, chapter_number, title, content, is_locked, ticket_cost, publication_status)
      values (${data.novel_id}, ${data.chapter_number}, ${data.title.trim()}, ${data.content}, ${Boolean(data.is_locked)}, ${ticketCost}, 'draft')
      returning id
    `;
    await sql`update novels set updated_at = now() where id = ${data.novel_id}`;
    return { id: rows[0]!.id, message: "Chapter saved as draft." };
  });

export const publishChapter = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { id: number; publication_status: "draft" | "published" }) => input)
  .handler(async ({ context, data }) => {
    const sql = await imperialSql();
    const profile = await ensureProfile(sql, context.userId);
    const ch = await sql<{ novel_id: number }>`select novel_id from chapters where id = ${data.id}`;
    if (!ch[0]) throw new Error("Chapter not found");
    const novel = await ownNovel(sql, context.userId, ch[0].novel_id, profile.role);
    if (data.publication_status === "published" && novel.publication_status !== "published" && profile.role !== "admin") {
      throw new Error("The novel must be published before chapters can go live.");
    }
    await sql`update chapters set publication_status = ${data.publication_status}, updated_at = now() where id = ${data.id}`;
    return { message: data.publication_status === "published" ? "Chapter published." : "Chapter moved to draft." };
  });
