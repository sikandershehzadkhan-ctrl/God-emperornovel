import type { Sql } from "@/lib/db";
import { CORE_GENRES, CORE_TAGS, CONNECTOR_REGISTRY } from "./types";
import { slugify } from "@/lib/utils";

let seededRev = 0;
const SEED_REV = 31;

const ch = (title: string, body: string) => ({ title, body: body.trim() });

const NOVELS = [
  {
    title: "The Imperial Ascendant",
    author: "SSKB1908",
    cover: "/covers/ascendant.jpg",
    status: "ongoing",
    kind: "original",
    category: "original-fiction",
    featured: true,
    views: 78,
    rating: 5,
    genres: ["Fantasy", "Empire Building", "Progression Fantasy"],
    tags: ["empire", "male-lead", "weak-to-strong", "original-world"],
    rights: "Original work created for Imperial Novel. No third-party copyrighted text, characters, or translations used.",
    description:
      "When the last prince of a ruined house awakens a dormant imperial seal, he must rebuild a nation from ash, law, and will. An original fantasy of power, duty, and the cost of founding an empire.",
    chapters: [
      ch(
        "The Seal Beneath the Ruin",
        `The wind over the Broken Court smelled of wet lime and old banners. Kael Veyra stood where the throne had been and counted the remaining stones. Seventeen. That was all the masons had left of a hall that once seated three hundred.

He was nineteen, and already the last of his name who would answer to it in public.

“You should not be here after dusk,” said Captain Sera, her spear grounded in the rubble. “The scavengers come when the lamps die.”

“Then they will find me first,” Kael said. “Better that than the seal.”

The seal was a rumor until his palm found it: a disk of black glass set in the dais, warm as a living throat. Gold veins crawled across its face and arranged themselves into a sunburst. The court, empty a breath ago, seemed to inhale.

Kael did not kneel. Kneeling was what the old empire had required of everyone except the man who had broken it.

Light climbed his wrist. It did not burn. It named him.

A voice without a mouth spoke in the language of ledgers and law.

FOUNDATION PROTOCOL. HEIR RECOGNIZED. BEGIN THE WORK.

Sera’s spear dipped. “Kael.”

“I heard it.” He closed his fist. The light folded inward until it was only a thin ring under the skin. “We start with grain, not glory. Tomorrow you will list every household that still has a roof. I want names. Not titles.”

“And if the southern prefects refuse?”

“Then they will learn that a ruined house can still write decrees.” He looked at the seventeen stones. “An empire is not a crown. It is a promise kept long enough that people stop packing their bags.”

Rain began, fine as ash. Kael did not move until Sera had written the first three names in a damp ledger. The seal pulsed once, like a heart deciding to continue.`,
      ),
      ch(
        "Laws Before Banners",
        `The first week of the new court was a table in a baker’s loft. Kael sat with flour on his sleeves and argued about wells.

“Water is not a gift,” said Magistrate Oren, who had served three emperors and trusted none. “It is a weapon if you let the wrong house own the cisterns.”

“Then no house owns them,” Kael said. “The cisterns belong to the street. We will post the hours. We will flog theft of water the same as theft of bread.”

Sera leaned in the doorway, armor unpolished on purpose. “The southern prefect sent a rider. He offers grain if you take his daughter into the inner court.”

Kael did not look up from the map. “Offer him a road instead. Grain that arrives as a bride-price arrives with a knife.”

The seal under his skin warmed when he wrote. Not magic in the storybook sense — more like a clerk who never slept. It tallied stores. It marked the lie in a petition before the ink dried. It did not tell him who to love, only who was stealing.

That night he walked the market with a hood up. A child sold roasted chestnuts from a cracked pan. Kael paid twice the price and asked for the child’s name.

“Lin,” she said. “Are you the prince who talks to stones?”

“I am the man who intends to keep your pan full through winter. If I fail, you may throw the pan at me.”

Lin considered this and nodded, which was the first honest coronation he had received.

On the seventh dawn, banners went up anyway — not gold, not violet, but plain linen with a single mark: a ring. No house crest. People gathered because the wells opened on time.

Oren watched from the loft. “You will make enemies of every family that lived by exception.”

“Good,” Kael said. “Empires that survive are built from rules the founder cannot break.”

The seal recorded the sentence. Somewhere in the glass, a foundation stone set itself true.`,
      ),
      ch(
        "The Test of the Southern Road",
        `Locked chapter in the live Imperial catalog. In this restored original, the southern prefect finally answers — not with grain, but with a blockade on the only road that still carries salt.

Kael rides out with forty soldiers who have not been paid in coin, only in bread and the promise that their names will be written first if the court endures. Sera hates the promise. Promises are how the old empire dressed hunger.

At the ford they find wagons turned on their sides, salt spilled like snow. The prefect’s captain waits on the far bank with twice their number.

“The heir may pass,” the captain calls, “if he signs the old exemptions.”

Kael dismounts. He does not raise the seal like a miracle. He raises a list.

“Here are the households that will starve if salt does not move. Here are the names of your own cousins among them. I will not sign a lie. I will open this road. You may stand on it or under it.”

The river is loud. The captain’s horse stamps. For a moment the world is only the choice between spectacle and administration.

Sera whispers, “If you use the seal as a weapon, they will never believe the laws.”

Kael knows. That is the test.

He wades into the ford with a measuring pole and begins, absurdly, to mark the depth for the wagons. Soldiers laugh on both banks, then stop laughing, then — one by one — step in to help because work is harder to hate than a speech.

By dusk the road is a road again. The prefect’s captain signs nothing. He simply moves.

The seal is quiet. It has learned what its heir prefers: a nation that can be maintained.`,
      ),
    ],
  },
  {
    title: "Crown of Ember Peak",
    author: "Liora Vale",
    cover: "/covers/ember.jpg",
    status: "ongoing",
    kind: "original",
    category: "fantasy-worlds",
    featured: false,
    views: 41,
    rating: 4.6,
    genres: ["Cultivation", "Xianxia", "Action"],
    tags: ["weak-to-strong", "magic", "original-world"],
    rights: "Original work.",
    description:
      "On a mountain that burns without wood, a disgraced inner disciple learns a cultivation path that feeds on restraint rather than rage.",
    chapters: [
      ch(
        "Ash in the Inner Court",
        `They sent Wen down the mountain with a cracked sword and a joke for a title: Ember-Watcher. It meant she would sit beside a vent that never went out and count how often it coughed sparks.

The inner court liked that kind of exile. It looked like duty.

Wen sat. She counted. On the ninth night the vent spoke, not in words but in heat that arranged itself into a rhythm. Inhale. Hold. Do not grasp.

Every manual she had stolen as a child said the opposite. Seize. Devour. Rise.

She tried the vent’s way. The fire entered her meridians and, finding no greed, did not tear them. It nested.

At dawn an elder arrived to confirm she had failed. He found her hair singed and her pulse even.

“You are still here,” he said, disappointed.

“The mountain is still here,” Wen answered. “We are practicing together.”`,
      ),
      ch(
        "The Ring of Quiet Flame",
        `The first real test came when outer disciples tried to harvest the vent for a tournament. They brought formation flags and a bronze siphon.

Wen stood in their way with her cracked sword. “This fire is not a storehouse.”

They laughed until the vent dimmed — not dying, listening. The siphon cracked. Flags wilted. Wen did not strike anyone. She only refused to want their victory.

That, she learned, was a technique. The mountain approved.`,
      ),
    ],
  },
  {
    title: "A System Named Mercy",
    author: "Kael Orin",
    cover: "/covers/mercy.jpg",
    status: "ongoing",
    kind: "original",
    category: "games",
    featured: false,
    views: 63,
    rating: 4.8,
    genres: ["System", "LitRPG", "Progression Fantasy"],
    tags: ["system", "male-lead", "antihero"],
    rights: "Original work.",
    description:
      "A fallen knight is offered a system that heals instead of scoring kills — and discovers that mercy has a harsher math than war.",
    chapters: [
      ch(
        "Interface Over the Mud",
        `Daren woke in the ditch with a spear still in his side and a pane of light hanging over the rain.

MERCY PROTOCOL ONLINE
PRIMARY QUEST: KEEP ONE PERSON ALIVE WHO WOULD NOT KEEP YOU

“No,” he told the air. “I am done with quests.”

The pane waited. It did not threaten. That was new. Every system story he had heard in taverns came with a whip.

He pulled the spear out because dying on a schedule offended him. The wound closed in a way that felt like being forgiven against his will.

A girl from the losing side was hiding under a cart. Daren swore, then crawled to her, then used the last of the light to stop her bleeding.

QUEST COMPLETE. MERCY IS NOT A LOOPHOLE.

He laughed until it hurt in a different place.`,
      ),
      ch(
        "Scoreless",
        `The system refused to show a leaderboard. Daren kept looking for one the way a drunk looks for a familiar door.

Instead it showed him lists of people he had failed to notice. A baker. A sentry who had lowered a gate too late. Himself, aged thirty-one, still hoping violence would become a personality.

He began to train anyway — not to be feared, but to arrive in time.`,
      ),
    ],
  },
  {
    title: "Glass Throne",
    author: "Seraphine Holt",
    cover: "/covers/glass.jpg",
    status: "ongoing",
    kind: "original",
    category: "original-fiction",
    featured: true,
    views: 52,
    rating: 4.7,
    genres: ["Kingdom Building", "Drama", "Fantasy"],
    tags: ["court-intrigue", "female-lead", "strategy"],
    rights: "Original work.",
    description:
      "A glassblower’s daughter is crowned because the court believes she is ornamental. She turns a transparent throne into a ledger of every lie spoken before it.",
    chapters: [
      ch(
        "An Ornament Is Still a Seat",
        `They crowned Ilya because the glass throne would look well with her dark hair. That was the minute in the council record. She read it twice.

The throne was a single pouring of river silica, cold even in summer. When a minister lied, a hairline frost appeared near the arm.

Ilya learned to hold audiences with her palm on that frost. She asked for numbers. She asked who ate. She asked why the eastern granary reported the same harvest in drought and flood.

By the third week, ministers brought true papers because frost is embarrassing.

“You were meant to be quiet,” the chancellor whispered.

“Glass is quiet,” Ilya said. “It is not blind.”`,
      ),
      ch(
        "The Inventory of Vows",
        `She commissioned no army. She commissioned clerks. Each vow spoken in the hall was copied onto vellum and hung where petitioners could see it.

A kingdom, she decided, was an inventory that people were afraid to falsify.`,
      ),
    ],
  },
  {
    title: "The Last Cartographer",
    author: "E. N. Solace",
    cover: "/covers/cartographer.jpg",
    status: "ongoing",
    kind: "original",
    category: "fantasy-worlds",
    featured: false,
    views: 29,
    rating: 4.4,
    genres: ["Adventure", "Mystery", "Fantasy"],
    tags: ["original-world", "slow-burn"],
    rights: "Original work.",
    description:
      "Maps have begun to lie. A cartographer whose ink still tells the truth is hired to chart a coastline that moves when it is observed.",
    chapters: [
      ch(
        "The Coast That Will Not Sit",
        `Ness unrolled the vellum on the tavern table and watched the shoreline crawl half an inch inland, as if ashamed.

“That,” said the harbormaster, “is why we stopped paying surveyors.”

“You should have paid them more,” Ness said. “Lying maps are how fleets die politely.”

She mixed ink with iron filings and a drop of her own blood, which was not witchcraft so much as a refusal to let the paper forget her. The coast hesitated, then held.

Outside, bells marked a tide that did not match the moon. Ness packed her compass and went to see whether the sea was lonely or hunting.`,
      ),
      ch(
        "A Legend in the Margin",
        `In the old guild hall she found a note in her master’s hand: If the land moves, ask who benefits from being unfindable.

The list of beneficiaries was long. Ness started with the shortest name.`,
      ),
    ],
  },
  {
    title: "After Rain of Swords",
    author: "Wei Lan",
    cover: "/covers/swords.jpg",
    status: "ongoing",
    kind: "original",
    category: "fantasy-worlds",
    featured: false,
    views: 37,
    rating: 4.5,
    genres: ["Wuxia", "Action", "Romance"],
    tags: ["slow-burn", "found-family"],
    rights: "Original work.",
    description:
      "When a night rain of blades ends a clan war, the only survivor of the courtyard school must decide whether to avenge the dead or teach the living how to put swords down.",
    chapters: [
      ch(
        "The Courtyard After",
        `Shen walked between the blades as if they were reeds. Rain still beaded on steel. His teachers were gone. The school’s signboard hung from one nail.

A girl from the rival house sat on the step with a cut across her palm, too tired to pretend enmity.

“If you kill me,” she said, “the rain will have been efficient.”

Shen picked up a broom instead of a sword. “Help me clear a path. The dead should not be stepped on.”

They worked until the east paled. That was how a new school began: with housekeeping.`,
      ),
      ch(
        "Names on the Rafters",
        `He wrote every fallen name on the rafters, including enemies. The girl — Yue — objected once, then added two names he had not known.

“If we remember only our own,” she said, “we will invent the war again.”`,
      ),
    ],
  },
  {
    title: "Neon Archive",
    author: "Mira Chen",
    cover: "/covers/neon.jpg",
    status: "ongoing",
    kind: "original",
    category: "original-fiction",
    featured: false,
    views: 44,
    rating: 4.3,
    genres: ["Sci-Fi", "Cyberpunk", "Mystery"],
    tags: ["female-lead", "mystery"],
    rights: "Original work.",
    description:
      "In a city that stores memory as licensed light, an archivist discovers a shelf of unlicensed lives — including her own.",
    chapters: [
      ch(
        "Unlicensed Light",
        `The archive hummed like a refrigerator full of ghosts. Jun wore gloves because fingerprints could be billed.

Shelf 19-C was not on the inventory. It glowed a shade of violet the city had not licensed for public grief.

She pulled a spool. Her own childhood unspooled: a kitchen, a window, a mother counting coins. None of it was in her paid memory plan.

“Hello,” said a voice from the dark end of the aisle. “You are not supposed to remember that you forgot.”`,
      ),
      ch(
        "The Fee for Truth",
        `The voice belonged to a former indexer who had cut his own license. He wanted Jun to smuggle the shelf into public rain — the only medium the city could not invoice.

Jun named her price: the rest of her life, unredacted.`,
      ),
    ],
  },
  {
    title: "The Silent Isekai",
    author: "Rowan Ash",
    cover: "/covers/isekai.jpg",
    status: "ongoing",
    kind: "original",
    category: "original-fiction",
    featured: false,
    views: 33,
    rating: 4.2,
    genres: ["Isekai", "Reincarnation", "Comedy"],
    tags: ["isekai", "comedy", "male-lead"],
    rights: "Original work.",
    description:
      "A quiet librarian dies at his desk and wakes in a world that expected a loud hero. He files the prophecy, alphabetizes the quest board, and accidentally saves a village with logistics.",
    chapters: [
      ch(
        "Reincarnated, Please Lower Your Voice",
        `Theo’s first words in the new world were “Could we not shout?”

The goddess who had summoned him looked personally injured. “You are the chosen—”

“I was the night librarian. I can stamp forms. I cannot make a speech.”

She left him in a meadow with a sword he immediately wrapped in cloth so no one would trip. A farmer hired him to reorganize seed stores. The bandits who arrived that evening found a locked granary, a posted schedule, and Theo asking if they had an appointment.

They did not. They left.

The goddess watched from a cloud, confused, and slightly proud.`,
      ),
      ch(
        "The Quest Board, Indexed",
        `Theo built a quest board with categories: wolves, wells, weddings, actual doom. Heroes complained. Villagers stopped dying of duplicated errands.

He still refused the title of savior. He accepted “temporary clerk.”`,
      ),
    ],
  },
];

export async function ensureSeeded(sql: Sql) {
  if (seededRev >= SEED_REV) return;

  for (const name of CORE_GENRES) {
    const slug = slugify(name);
    await sql`insert into genres (name, slug) values (${name}, ${slug}) on conflict (slug) do nothing`;
  }
  for (const name of CORE_TAGS) {
    await sql`insert into tags (name, slug) values (${name}, ${name}) on conflict (slug) do nothing`;
  }
  for (const c of CONNECTOR_REGISTRY) {
    await sql`
      insert into connectors (name, base_url, type, enabled, rights_status, last_status)
      values (${c.name}, ${"https://" + c.host}, 'registry', false, 'pending', 'registry')
      on conflict (base_url) do nothing
    `;
  }

  for (const novel of NOVELS) {
    const slug = slugify(novel.title);
    const existing = await sql<{ id: number; cover_url: string }>`
      select id, cover_url from novels where slug = ${slug}
    `;
    let id = existing[0]?.id;
    if (!id) {
      const inserted = await sql<{ id: number }>`
        insert into novels (
          title, slug, author, description, status, kind, language, cover_url,
          rights_status, views, rating, publication_status, rights_evidence, featured, category
        ) values (
          ${novel.title}, ${slug}, ${novel.author}, ${novel.description}, ${novel.status},
          ${novel.kind}, 'English', ${novel.cover}, 'original', ${novel.views}, ${novel.rating},
          'published', ${novel.rights}, ${novel.featured}, ${novel.category}
        ) returning id
      `;
      id = inserted[0]!.id;
      for (const [i, chapter] of novel.chapters.entries()) {
        const locked = i > 0;
        await sql`
          insert into chapters (novel_id, chapter_number, title, content, is_locked, ticket_cost, publication_status)
          values (${id}, ${i + 1}, ${chapter.title}, ${chapter.body}, ${locked}, ${locked ? 1 : 0}, 'published')
          on conflict (novel_id, chapter_number) do nothing
        `;
      }
    } else {
      const current = existing[0]?.cover_url || "";
      if (!current || current.endsWith(".svg")) {
        await sql`update novels set cover_url = ${novel.cover} where id = ${id}`;
      }
    }
    for (const g of novel.genres) {
      const row = await sql<{ id: number }>`select id from genres where slug = ${slugify(g)}`;
      if (row[0]) {
        await sql`insert into novel_genres (novel_id, genre_id) values (${id}, ${row[0].id}) on conflict do nothing`;
      }
    }
    for (const t of novel.tags) {
      const row = await sql<{ id: number }>`select id from tags where slug = ${t}`;
      if (row[0]) {
        await sql`insert into novel_tags (novel_id, tag_id) values (${id}, ${row[0].id}) on conflict do nothing`;
      }
    }
  }

  await sql`insert into app_settings (key, value) values ('version', '16.47.0') on conflict (key) do update set value = excluded.value`;
  seededRev = SEED_REV;
}
