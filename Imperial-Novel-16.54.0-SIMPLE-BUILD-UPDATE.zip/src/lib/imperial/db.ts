import { getSql, type Sql } from "@/lib/db";
import type { Profile, Role } from "./types";
import { slugify } from "@/lib/utils";
import { ensureSeeded } from "./seed.server";
import { matchesVerifiedBootstrapAdminEmail, resolveNewProfileRole } from "./bootstrap-role";

export async function imperialSql() {
  const sql = await getSql();
  await ensureSeeded(sql);
  return sql;
}

export function num(v: unknown) {
  return Number(v || 0);
}

export async function ensureProfile(
  sql: Sql,
  userId: string,
  opts?: { email?: string | null; name?: string | null },
): Promise<Profile> {
  const existing = await sql<Profile>`
    select user_id, username, role, tickets::float as tickets, verified, banned, bio
    from profiles where user_id = ${userId}
  `;
  if (existing[0]) return existing[0];

  // Never grant admin to whichever account happens to sign up first.
  // Provision the bootstrap admin explicitly by authenticated user ID in the
  // deployment environment, then remove the variable after the profile exists.
  const bootstrapUserId = typeof process !== "undefined" ? process.env.IMPERIAL_BOOTSTRAP_ADMIN_USER_ID : undefined;
  const bootstrapEmail = typeof process !== "undefined" ? process.env.IMPERIAL_BOOTSTRAP_ADMIN_EMAIL : undefined;
  let role: Role = resolveNewProfileRole(userId, bootstrapUserId);
  if (role !== "admin" && bootstrapEmail?.trim()) {
    // Fail closed: email bootstrap is allowed only for the exact verified auth
    // identity, and only before its Imperial profile has been created.
    try {
      const identity = await sql<{ email: string; email_verified: boolean | number }>`
        select email, "emailVerified" as email_verified from "user" where id = ${userId}
      `;
      const verified = identity[0]?.email_verified === true || identity[0]?.email_verified === 1;
      if (matchesVerifiedBootstrapAdminEmail(identity[0]?.email, verified, bootstrapEmail)) role = "admin";
      else if (identity[0]?.email?.trim().toLowerCase() === bootstrapEmail.trim().toLowerCase() && !verified) {
        throw new Error("The configured bootstrap administrator email must be verified before profile creation.");
      }
    } catch (error) {
      if (error instanceof Error && error.message.includes("must be verified")) throw error;
      // Missing auth schema or lookup failure must never grant an administrator role.
    }
  }
  const base =
    slugify(opts?.name || opts?.email?.split("@")[0] || "reader").replace(/-/g, "_") ||
    "reader";
  let username = base.slice(0, 20);
  for (let i = 0; i < 8; i++) {
    const clash = await sql`select 1 from profiles where username = ${username} limit 1`;
    if (!clash.length) break;
    username = `${base.slice(0, 16)}${Math.floor(Math.random() * 90 + 10)}`;
  }
  const welcome = 25;
  await sql`
    insert into profiles (user_id, username, role, tickets)
    values (${userId}, ${username}, ${role}, ${welcome})
  `;
  await sql`
    insert into ticket_ledger (user_id, delta, reason, reference)
    values (${userId}, ${welcome}, 'welcome', 'signup')
  `;
  await sql`
    insert into notifications (user_id, title, body)
    values (
      ${userId},
      'Welcome to Imperial Novel',
      'Your library, tickets and reading history are ready. 25 welcome tickets have been granted.'
    )
  `;
  if (role === "admin") {
    await sql`
      insert into audit_logs (user_id, action, details)
      values (${userId}, 'admin_bootstrap', 'Explicitly configured bootstrap administrator')
    `;
  }
  const created = await sql<Profile>`
    select user_id, username, role, tickets::float as tickets, verified, banned, bio
    from profiles where user_id = ${userId}
  `;
  return created[0]!;
}

export async function getProfile(sql: Sql, userId: string) {
  const rows = await sql<Profile>`
    select user_id, username, role, tickets::float as tickets, verified, banned, bio
    from profiles where user_id = ${userId}
  `;
  return rows[0] ?? null;
}

export async function requireProfileRole(sql: Sql, userId: string, roles: Role[]) {
  const profile = await getProfile(sql, userId);
  if (!profile || profile.banned) {
    throw Object.assign(new Error("Forbidden"), { status: 403 });
  }
  if (!roles.includes(profile.role)) {
    throw Object.assign(new Error("Forbidden"), { status: 403 });
  }
  return profile;
}

export async function audit(sql: Sql, userId: string | null, action: string, details: string) {
  await sql`
    insert into audit_logs (user_id, action, details)
    values (${userId}, ${action}, ${details})
  `;
}

export const novelSelect = `
  n.id, n.title, n.slug, n.author, n.description, n.status, n.kind, n.language,
  n.cover_url, n.rights_status, n.views, n.rating::float as rating,
  n.publication_status, n.featured, n.category, n.updated_at::text as updated_at,
  coalesce((select count(*) from chapters c where c.novel_id = n.id and c.publication_status = 'published'), 0)::int as chapter_count,
  coalesce((select max(chapter_number) from chapters c where c.novel_id = n.id and c.publication_status = 'published'), 0)::int as latest_chapter
`;

export async function attachTaxonomy<T extends { id: number }>(sql: Sql, novels: T[]) {
  if (!novels.length) return novels.map((n) => ({ ...n, genres: [], tags: [] }));
  const ids = novels.map((n) => n.id);
  const genres = await sql.query<{ novel_id: number; name: string; slug: string }>(
    `select ng.novel_id, g.name, g.slug
     from novel_genres ng join genres g on g.id = ng.genre_id
     where ng.novel_id = any($1::int[])`,
    [ids],
  );
  const tags = await sql.query<{ novel_id: number; name: string; slug: string }>(
    `select nt.novel_id, t.name, t.slug
     from novel_tags nt join tags t on t.id = nt.tag_id
     where nt.novel_id = any($1::int[])`,
    [ids],
  );
  return novels.map((n) => ({
    ...n,
    genres: genres.filter((g) => g.novel_id === n.id).map((g) => ({ name: g.name, slug: g.slug })),
    tags: tags.filter((t) => t.novel_id === n.id).map((t) => ({ name: t.name, slug: t.slug })),
  }));
}
