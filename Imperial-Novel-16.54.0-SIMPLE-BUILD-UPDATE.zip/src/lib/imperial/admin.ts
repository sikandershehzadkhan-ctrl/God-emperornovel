import { createServerFn } from "@tanstack/react-start";
import { authMiddleware } from "@/lib/auth/middleware";
import { audit, ensureProfile, imperialSql, num, requireProfileRole } from "./db";

export const adminStats = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await imperialSql();
    await requireProfileRole(sql, context.userId, ["admin"]);
    const [users, novels, chapters, donations, requests, reports] = await Promise.all([
      sql<{ n: number }>`select count(*)::int as n from profiles`,
      sql<{ n: number }>`select count(*)::int as n from novels`,
      sql<{ n: number }>`select count(*)::int as n from chapters`,
      sql<{ n: number }>`select count(*)::int as n from donations where status='pending'`,
      sql<{ n: number }>`select count(*)::int as n from novel_requests where status='pending'`,
      sql<{ n: number }>`select count(*)::int as n from reports where status='open'`,
    ]);
    return {
      users: num(users[0]?.n),
      novels: num(novels[0]?.n),
      chapters: num(chapters[0]?.n),
      pendingDonations: num(donations[0]?.n),
      pendingRequests: num(requests[0]?.n),
      openReports: num(reports[0]?.n),
    };
  });

export const adminUsers = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await imperialSql();
    await requireProfileRole(sql, context.userId, ["admin"]);
    return sql<{
      user_id: string;
      username: string;
      role: string;
      tickets: number;
      verified: boolean;
      banned: boolean;
      created_at: string;
    }>`
      select user_id, username, role, tickets::float as tickets, verified, banned, created_at::text as created_at
      from profiles order by created_at desc limit 500
    `;
  });

export const adminSetRole = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { user_id: string; role: "user" | "author" | "moderator" | "admin"; banned?: boolean }) => input)
  .handler(async ({ context, data }) => {
    const sql = await imperialSql();
    await requireProfileRole(sql, context.userId, ["admin"]);
    if (data.user_id === context.userId && data.role !== "admin") throw new Error("You cannot remove your own admin role");
    await sql`update profiles set role = ${data.role}, banned = ${Boolean(data.banned)} where user_id = ${data.user_id}`;
    await audit(sql, context.userId, "set_role", `${data.user_id}:${data.role}`);
    return { ok: true };
  });

export const adminPublishing = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await imperialSql();
    await requireProfileRole(sql, context.userId, ["admin", "moderator"]);
    return sql<{
      id: number;
      title: string;
      author: string;
      rights_status: string;
      publication_status: string;
      rights_evidence: string;
      chapter_count: number;
      owner_user_id: string | null;
    }>`
      select n.id, n.title, n.author, n.rights_status, n.publication_status, n.rights_evidence,
             (select count(*) from chapters c where c.novel_id = n.id)::int as chapter_count,
             n.owner_user_id
      from novels n
      order by case n.publication_status when 'review' then 0 when 'draft' then 1 when 'published' then 2 else 3 end, n.updated_at desc
      limit 300
    `;
  });

export const adminSetPublication = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { id: number; publication_status: string; review_feedback?: string }) => input)
  .handler(async ({ context, data }) => {
    const sql = await imperialSql();
    await requireProfileRole(sql, context.userId, ["admin"]);
    const allowed = ["draft", "review", "published", "archived"];
    if (!allowed.includes(data.publication_status)) throw new Error("Invalid status");
    const feedback = data.review_feedback || null;
    const updated = data.publication_status === "published"
      ? await sql<{ id: number }>`
          update novels set publication_status = 'published',
            review_feedback = coalesce(${feedback}, review_feedback), updated_at = now()
          where id = ${data.id}
            and rights_status in ('original', 'public_domain', 'licensed', 'authorized')
            and length(trim(coalesce(rights_evidence, ''))) >= 8
          returning id
        `
      : await sql<{ id: number }>`
          update novels set publication_status = ${data.publication_status},
            review_feedback = coalesce(${feedback}, review_feedback), updated_at = now()
          where id = ${data.id}
          returning id
        `;
    if (!updated.length) {
      if (data.publication_status === "published") {
        throw new Error("Publication requires an eligible rights status and meaningful rights evidence");
      }
      throw new Error("Novel not found");
    }
    await audit(sql, context.userId, "publication", `${data.id}:${data.publication_status}`);
    return { ok: true };
  });

export const adminDonations = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await imperialSql();
    await requireProfileRole(sql, context.userId, ["admin"]);
    return sql<{
      id: number;
      user_id: string;
      amount: number;
      reference_id: string;
      status: string;
      created_at: string;
      username: string;
    }>`
      select d.id, d.user_id, d.amount::float as amount, d.reference_id, d.status, d.created_at::text as created_at,
             coalesce(p.username, 'unknown') as username
      from donations d left join profiles p on p.user_id = d.user_id
      order by d.created_at desc limit 100
    `;
  });

export const adminReviewDonation = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { id: number; status: "approved" | "rejected" }) => input)
  .handler(async ({ context, data }) => {
    const sql = await imperialSql();
    await requireProfileRole(sql, context.userId, ["admin"]);
    const row = await sql<{ id: number; user_id: string; amount: number; status: string; reference_id: string }>`
      select id, user_id, amount::float as amount, status, reference_id from donations where id = ${data.id}
    `;
    if (!row[0]) throw new Error("Donation not found");
    if (row[0].status !== "pending") throw new Error("Only pending donations can be reviewed");
    const donorProfile = await sql`select 1 from profiles where user_id = ${row[0].user_id}`;
    if (!donorProfile.length) throw new Error("Donation owner profile is missing; no review or credit was applied");

    // All writes are one backend-native transaction. The intermediate state is
    // only visible inside that transaction; a failed write rolls everything back.
    const tickets = Math.max(1, Math.round(num(row[0].amount) / 20));
    const statements = data.status === "approved"
      ? [
          { text: "update donations set status = 'processing' where id = $1 and status = 'pending'", params: [data.id] },
          { text: "insert into ticket_ledger (user_id, delta, reason, reference) select user_id, $1, 'donation', reference_id from donations where id = $2 and status = 'processing'", params: [tickets, data.id] },
          { text: "update profiles set tickets = tickets + $1 where user_id = $2 and exists (select 1 from donations where id = $3 and status = 'processing')", params: [tickets, row[0].user_id, data.id] },
          { text: "insert into notifications (user_id, title, body) select user_id, 'Donation approved', $1 from donations where id = $2 and status = 'processing'", params: [tickets + " tickets credited after EasyPaisa verification.", data.id] },
          { text: "insert into audit_logs (user_id, action, details) select $1, 'donation', $2 where exists (select 1 from donations where id = $3 and status = 'processing')", params: [context.userId, `${data.id}:approved`, data.id] },
          { text: "update donations set status = 'approved' where id = $1 and status = 'processing'", params: [data.id] },
        ]
      : [
          { text: "update donations set status = 'processing' where id = $1 and status = 'pending'", params: [data.id] },
          { text: "insert into notifications (user_id, title, body) select user_id, 'Donation rejected', 'The submitted EasyPaisa reference could not be verified. No tickets were credited.' from donations where id = $1 and status = 'processing'", params: [data.id] },
          { text: "insert into audit_logs (user_id, action, details) select $1, 'donation', $2 where exists (select 1 from donations where id = $3 and status = 'processing')", params: [context.userId, `${data.id}:rejected`, data.id] },
          { text: "update donations set status = 'rejected' where id = $1 and status = 'processing'", params: [data.id] },
        ];
    await sql.batch(statements);
    const confirmed = await sql<{ status: string }>`select status from donations where id = ${data.id}`;
    if (confirmed[0]?.status !== data.status) throw new Error("Donation review lost a concurrent update; no credit was applied");
    return { ok: true };
  });

export const adminRequests = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await imperialSql();
    await requireProfileRole(sql, context.userId, ["admin", "moderator"]);
    return sql<{
      id: number;
      url: string;
      source_host: string;
      cost: number;
      status: string;
      username: string;
      created_at: string;
    }>`
      select r.id, r.url, r.source_host, r.cost::float as cost, r.status, r.created_at::text as created_at,
             coalesce(p.username,'unknown') as username
      from novel_requests r left join profiles p on p.user_id = r.user_id
      order by r.created_at desc limit 100
    `;
  });

export const adminReports = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await imperialSql();
    await requireProfileRole(sql, context.userId, ["admin", "moderator"]);
    return sql<{
      id: number;
      reason: string;
      details: string;
      status: string;
      created_at: string;
    }>`
      select id, reason, details, status, created_at::text as created_at
      from reports order by created_at desc limit 200
    `;
  });

export const adminCreditTickets = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { user_id: string; amount: number }) => input)
  .handler(async ({ context, data }) => {
    const sql = await imperialSql();
    await requireProfileRole(sql, context.userId, ["admin"]);
    if (!data.amount) throw new Error("Ticket amount required");
    if (!Number.isSafeInteger(data.amount) || data.amount < 1 || data.amount > 100000) {
      throw new Error("Ticket credit must be a whole number between 1 and 100000");
    }
    const target = await sql`select 1 from profiles where user_id = ${data.user_id}`;
    if (!target.length) throw new Error("Target profile not found");
    await sql.batch([
      { text: "update profiles set tickets = tickets + $1 where user_id = $2", params: [data.amount, data.user_id] },
      { text: "insert into ticket_ledger (user_id, delta, reason, reference) values ($1, $2, 'admin_credit', $3)", params: [data.user_id, data.amount, context.userId] },
      { text: "insert into audit_logs (user_id, action, details) values ($1, 'admin_ticket_credit', $2)", params: [context.userId, `${data.user_id}:${data.amount}`] },
    ]);
    return { ok: true };
  });

export const adminConnectors = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await imperialSql();
    await requireProfileRole(sql, context.userId, ["admin"]);
    return sql<{
      id: number;
      name: string;
      base_url: string;
      enabled: boolean;
      rights_status: string;
      last_status: string;
    }>`
      select id, name, base_url, enabled, rights_status, last_status from connectors order by name
    `;
  });
