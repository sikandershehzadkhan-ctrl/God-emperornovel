import { createServerFn } from "@tanstack/react-start";
import { authMiddleware } from "@/lib/auth/middleware";
import { ensureProfile, getProfile, imperialSql, num } from "./db";

export const getMyProfile = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await imperialSql();
    const profile = await ensureProfile(sql, context.userId);
    const [history, following, unlocks, library, unread] = await Promise.all([
      sql<{ n: number }>`select count(*)::int as n from history where user_id = ${context.userId}`,
      sql<{ n: number }>`select count(*)::int as n from follows where user_id = ${context.userId}`,
      sql<{ n: number }>`select count(*)::int as n from unlocks where user_id = ${context.userId}`,
      sql<{ n: number }>`select count(*)::int as n from user_library where user_id = ${context.userId}`,
      sql<{ n: number }>`select count(*)::int as n from notifications where user_id = ${context.userId} and read_at is null`,
    ]);
    return {
      profile,
      stats: {
        history: num(history[0]?.n),
        following: num(following[0]?.n),
        unlocks: num(unlocks[0]?.n),
        library: num(library[0]?.n),
        unread: num(unread[0]?.n),
      },
    };
  });

export const getOptionalProfile = createServerFn({ method: "GET" }).handler(async () => {
  try {
    const { getSessionUser } = await import("@/lib/auth/verify.server");
    const user = await getSessionUser();
    if (!user) return null;
    const sql = await imperialSql();
    const profile = await ensureProfile(sql, user.id, { email: user.email });
    const unread = await sql<{ n: number }>`
      select count(*)::int as n from notifications where user_id = ${user.id} and read_at is null
    `;
    return { ...profile, email: user.email, unread: num(unread[0]?.n) };
  } catch {
    return null;
  }
});

export const updateProfile = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { bio?: string; username?: string }) => input)
  .handler(async ({ context, data }) => {
    const sql = await imperialSql();
    await ensureProfile(sql, context.userId);
    if (data.username) {
      const u = data.username.trim();
      if (!/^[a-zA-Z0-9_]{3,24}$/.test(u)) throw new Error("Username must be 3-24 letters, numbers or underscores");
      await sql`update profiles set username = ${u} where user_id = ${context.userId}`;
    }
    if (data.bio !== undefined) {
      await sql`update profiles set bio = ${data.bio.slice(0, 500)} where user_id = ${context.userId}`;
    }
    return getProfile(sql, context.userId);
  });
