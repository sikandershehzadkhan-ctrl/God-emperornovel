/**
 * Experimental Kysely dialect bridge for Cloudflare D1.
 *
 * IMPORTANT: this dialect is not wired into Better Auth yet. D1 has batch
 * transactions rather than an interactive BEGIN/COMMIT connection, while the
 * generic Kysely adapter may request interactive transactions. We deliberately
 * reject those calls rather than pretending they are atomic. Keep the auth route
 * fail-closed until transaction semantics and Better Auth's full CRUD/session
 * lifecycle are integration-tested against a real staging D1 database.
 */
import {
  SqliteAdapter,
  SqliteIntrospector,
  SqliteQueryCompiler,
  type CompiledQuery,
  type DatabaseConnection,
  type DatabaseIntrospector,
  type Dialect,
  type Driver,
  type Kysely,
  type QueryCompiler,
  type QueryResult,
  type TransactionSettings,
} from "kysely";

export interface D1KyselyResult<T = Record<string, unknown>> {
  results?: T[];
  success?: boolean;
  meta?: { changes?: number; last_row_id?: number };
}

export interface D1KyselyStatement<T = Record<string, unknown>> {
  bind(...values: unknown[]): D1KyselyStatement<T>;
  all(): Promise<D1KyselyResult<T>>;
}

export interface D1KyselyBinding {
  prepare(sql: string): D1KyselyStatement;
}

export function d1KyselyDialect(binding: D1KyselyBinding): Dialect {
  return {
    createAdapter: () => new SqliteAdapter(),
    createDriver: () => new D1KyselyDriver(binding),
    createQueryCompiler: (): QueryCompiler => new SqliteQueryCompiler(),
    createIntrospector: (db: Kysely<unknown>): DatabaseIntrospector =>
      new SqliteIntrospector(db),
  };
}

class D1KyselyDriver implements Driver {
  constructor(private readonly binding: D1KyselyBinding) {}

  async init(): Promise<void> {}

  async acquireConnection(): Promise<DatabaseConnection> {
    return new D1KyselyConnection(this.binding);
  }

  async releaseConnection(_connection: DatabaseConnection): Promise<void> {}

  async beginTransaction(
    _connection: DatabaseConnection,
    _settings: TransactionSettings,
  ): Promise<void> {
    throw new Error(
      "Interactive transactions are not supported by the D1 Kysely bridge. Use a tested D1 batch adapter before enabling authentication.",
    );
  }

  async commitTransaction(): Promise<void> {
    throw new Error("D1 interactive transactions are unsupported by this bridge.");
  }

  async rollbackTransaction(): Promise<void> {
    throw new Error("D1 interactive transactions are unsupported by this bridge.");
  }

  async destroy(): Promise<void> {}
}

class D1KyselyConnection implements DatabaseConnection {
  constructor(private readonly binding: D1KyselyBinding) {}

  async executeQuery<O>(compiledQuery: CompiledQuery): Promise<QueryResult<O>> {
    const statement = this.binding
      .prepare(compiledQuery.sql)
      .bind(...compiledQuery.parameters);
    const result = await statement.all() as D1KyselyResult<O>;
    const rows = result.results ?? [];
    const changes = result.meta?.changes ?? 0;
    return {
      rows,
      ...(changes > 0 ? { numAffectedRows: BigInt(changes) } : {}),
      ...(result.meta?.last_row_id !== undefined
        ? { insertId: BigInt(result.meta.last_row_id) }
        : {}),
    };
  }

  async *streamQuery<O>(
    compiledQuery: CompiledQuery,
    chunkSize: number,
  ): AsyncIterableIterator<QueryResult<O>> {
    if (!Number.isInteger(chunkSize) || chunkSize < 1) {
      throw new Error("chunkSize must be a positive integer");
    }
    const result = await this.executeQuery<O>(compiledQuery);
    for (let offset = 0; offset < result.rows.length; offset += chunkSize) {
      yield { rows: result.rows.slice(offset, offset + chunkSize) };
    }
  }
}
