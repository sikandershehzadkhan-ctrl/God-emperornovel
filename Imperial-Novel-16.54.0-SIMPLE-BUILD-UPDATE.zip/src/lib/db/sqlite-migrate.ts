export interface SqliteExec {
  exec(sql: string): void;
  query<T = Record<string, unknown>>(text: string, params?: unknown[]): T[];
}

export interface MigrationFile {
  name: string;
  sql: string;
}

/**
 * Apply ordered SQL files once. A failed file is rolled back and not recorded.
 * This talks to a caller-supplied SQLite connection. It does not open D1.
 */
export function applySqliteMigrations(db: SqliteExec, files: MigrationFile[]): string[] {
  db.exec(
    "create table if not exists _migrations (name text primary key, applied_at text not null default (datetime('now')))",
  );
  const applied = new Set(
    db.query<{ name: string }>("select name from _migrations").map((row) => row.name),
  );
  const pending = [...files]
    .filter((file) => file.name.endsWith(".sql") && !applied.has(file.name))
    .sort((a, b) => a.name.localeCompare(b.name));
  const done: string[] = [];
  for (const file of pending) {
    db.exec("begin");
    try {
      db.exec(file.sql);
      db.query("insert into _migrations (name) values (?)", [file.name]);
      db.exec("commit");
    } catch (error) {
      try {
        db.exec("rollback");
      } catch {
        /* keep the original error */
      }
      throw new Error(
        `Migration ${file.name} failed and was not recorded. ${error instanceof Error ? error.message : String(error)}`,
      );
    }
    done.push(file.name);
  }
  return done;
}
