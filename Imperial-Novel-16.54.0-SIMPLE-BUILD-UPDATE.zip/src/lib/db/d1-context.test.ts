import assert from "node:assert/strict";
import test from "node:test";
import { batchD1, imperialD1, queryD1, withImperialD1 } from "./d1-context.ts";
import type { D1Like } from "./d1-sql.ts";

function fakeD1(label: string): D1Like {
  return {
    prepare(sql: string) {
      return {
        bind(...values: unknown[]) {
          return {
            async all<T>() {
              return { results: [{ label, sql, values }] as T[] };
            },
            async run() {
              return { success: true };
            },
          };
        },
      };
    },
  };
}

test("D1 context fails closed outside a request scope", () => {
  assert.throws(() => imperialD1(), /not available for this request/);
});

test("D1 context is available only within its async request scope", async () => {
  const result = await withImperialD1(fakeD1("request-a"), async () => {
    await Promise.resolve();
    return queryD1<{ label: string }>("select 1");
  });
  assert.equal(result[0]?.label, "request-a");
  assert.throws(() => imperialD1(), /not available for this request/);
});

test("atomic D1 batches use the native database batch API", async () => {
  let batchCalls = 0;
  let directRuns = 0;
  const db: D1Like = {
    prepare(sql: string) {
      return {
        bind(...values: unknown[]) {
          return {
            async all<T>() { return { results: [{ sql, values }] as T[] }; },
            async run() { directRuns += 1; return { success: true }; },
          };
        },
      };
    },
    async batch(statements) {
      batchCalls += 1;
      assert.equal(statements.length, 2);
      return [];
    },
  };
  await withImperialD1(db, () => batchD1([
    { text: "update profiles set tickets = tickets + $1 where user_id = $2", params: [5, "reader"] },
    { text: "insert into ticket_ledger (user_id, delta, reason, reference) values ($1, $2, 'admin_credit', $3)", params: ["reader", 5, "admin"] },
  ]));
  assert.equal(batchCalls, 1);
  assert.equal(directRuns, 0);
});


test("parallel requests keep their D1 bindings isolated", async () => {
  const [a, b] = await Promise.all([
    withImperialD1(fakeD1("request-a"), async () => {
      await new Promise((resolve) => setTimeout(resolve, 8));
      return (await queryD1<{ label: string }>("select 1"))[0]?.label;
    }),
    withImperialD1(fakeD1("request-b"), async () => {
      await new Promise((resolve) => setTimeout(resolve, 1));
      return (await queryD1<{ label: string }>("select 1"))[0]?.label;
    }),
  ]);
  assert.equal(a, "request-a");
  assert.equal(b, "request-b");
});
