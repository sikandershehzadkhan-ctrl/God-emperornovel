/**
 * Rewrite the app's Postgres-shaped SQL into SQLite/D1 SQL.
 * Placeholders become positional `?` bindings. `$1` used twice repeats the value.
 * This does not talk to a database.
 */

export interface TranslatedSql {
  text: string;
  params: unknown[];
}

export function translatePostgresSql(text: string, params: readonly unknown[] = []): TranslatedSql {
  let sql = text;
  const next = [...params];

  sql = sql.replace(/now\(\)\s*-\s*interval\s+'(\d+)\s+days'/gi, (_m, days: string) => {
    return `datetime('now', '-${days} days')`;
  });

  sql = sql.replace(/now\(\)\s*-\s*\$(\d+)::interval/gi, (_m, index: string) => {
    const at = Number(index) - 1;
    const raw = String(next[at] ?? "");
    next[at] = raw.startsWith("-") ? raw : `-${raw}`;
    return `datetime('now', $${index}__interval)`;
  });

  sql = sql.replace(/\bilike\b/gi, "like");

  sql = sql.replace(/=\s*any\(\s*\$(\d+)(?:::[a-z0-9_[\]]+)?\s*\)/gi, (_m, index: string) => {
    const at = Number(index) - 1;
    const value = next[at];
    if (!Array.isArray(value)) {
      throw new Error("any() expects an array parameter");
    }
    if (value.length === 0) return "in (select null where 0)";
    const copy = [...value];
    next[at] = copy;
    return `in (${copy.map(() => `$${index}__any`).join(", ")})`;
  });

  sql = sql.replace(/::(int|integer|float|float8|text|numeric|boolean|bigint)\b/gi, "");
  sql = sql.replace(/\bnow\(\)/gi, "datetime('now')");

  const bound: unknown[] = [];
  sql = sql.replace(/\$(\d+)(?:__any|__interval)?/g, (match, index: string) => {
    const value = next[Number(index) - 1];
    if (Array.isArray(value) && match.endsWith("__any")) {
      bound.push(value[0]);
      value.shift();
      return "?";
    }
    if (Array.isArray(value)) {
      throw new Error("Array parameters must use any($n) so they can be expanded for SQLite");
    }
    bound.push(value);
    return "?";
  });

  if (/::|interval\b|\bany\s*\(|\bilike\b/i.test(sql)) {
    throw new Error("SQLite translation left unsupported Postgres syntax");
  }
  return { text: sql, params: bound.map(coerceSqliteValue) };
}

function coerceSqliteValue(value: unknown): unknown {
  if (typeof value === "boolean") return value ? 1 : 0;
  if (typeof value === "bigint") return Number(value);
  return value;
}
