import { translatePostgresSql } from "./sqlite-sql.ts";

/** The slice of D1 this app uses. No Cloudflare types package required. */
export interface D1PreparedStatementLike {
  all<T = Record<string, unknown>>(): Promise<{ results: T[] }>;
  run(): Promise<unknown>;
}

export interface D1Like {
  batch?(statements: D1PreparedStatementLike[]): Promise<unknown[]>;
  prepare(sql: string): {
    bind(...values: unknown[]): D1PreparedStatementLike;
  };
}

export interface StatementDatabase {
  batch?(statements: { run(): Promise<void>; all<T = Record<string, unknown>>(): Promise<T[]> }[]): Promise<void>;
  prepare(sql: string): {
    bind(...values: unknown[]): {
      all<T = Record<string, unknown>>(): Promise<T[]>;
      run(): Promise<void>;
    };
  };
}

const BOOLEAN_COLUMNS = new Set([
  "verified",
  "banned",
  "featured",
  "is_locked",
  "enabled",
  "favorite",
  "emailVerified",
]);

export function wrapD1(db: D1Like): StatementDatabase {
  return {
    ...(db.batch ? {
      batch: async (statements) => {
        if (!db.batch) throw new Error("D1 batch API is unavailable; refusing non-atomic writes.");
        await db.batch(statements.map((statement) => {
          const prepared = statement as { __d1Statement?: unknown };
          if (!prepared.__d1Statement) throw new Error("D1 batch statement was not created by this adapter.");
          return prepared.__d1Statement as D1PreparedStatementLike;
        }));
      },
    } : {}),
    prepare(sql: string) {
      return {
        bind(...values: unknown[]) {
          const statement = db.prepare(sql).bind(...values);
          return {
            __d1Statement: statement,
            all: async <T>() => (await statement.all<T>()).results ?? [],
            run: async () => {
              await statement.run();
            },
          };
        },
      };
    },
  };
}

const writes = /^(insert|update|delete)\b/i;

function coerceRow<T>(row: T): T {
  if (!row || typeof row !== "object") return row;
  const copy: Record<string, unknown> = { ...(row as Record<string, unknown>) };
  for (const key of Object.keys(copy)) {
    const value = copy[key];
    if (BOOLEAN_COLUMNS.has(key) && (value === 0 || value === 1)) copy[key] = value === 1;
  }
  return copy as T;
}

export async function batchStatementDb(
  db: StatementDatabase,
  statements: { text: string; params?: unknown[] }[],
): Promise<void> {
  if (!db.batch) throw new Error("Atomic batch is not supported by this database adapter.");
  const prepared = statements.map(({ text, params = [] }) => {
    const translated = translatePostgresSql(text, params);
    return db.prepare(translated.text).bind(...translated.params);
  });
  await db.batch(prepared);
}

export async function queryStatementDb<T = Record<string, unknown>>(
  db: StatementDatabase,
  text: string,
  params: unknown[] = [],
): Promise<T[]> {
  const translated = translatePostgresSql(text, params);
  const statement = db.prepare(translated.text).bind(...translated.params);
  if (writes.test(translated.text.trim()) && !/\breturning\b/i.test(translated.text)) {
    await statement.run();
    return [];
  }
  const rows = await statement.all<T>();
  return rows.map(coerceRow);
}
