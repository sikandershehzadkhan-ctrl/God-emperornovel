/** Request-aware D1 query entry point for TanStack Start server functions. */
import { getRequest } from "@tanstack/react-start/server";
import { batchD1ForRequest, queryD1ForRequest } from "./d1-context.ts";

export function queryCurrentD1<T = Record<string, unknown>>(
  text: string,
  params: unknown[] = [],
): Promise<T[]> {
  const request = getRequest();
  if (!request) {
    throw new Error("No active server request is available for D1 access.");
  }
  return queryD1ForRequest<T>(request, text, params);
}

export function batchCurrentD1(
  statements: { text: string; params?: unknown[] }[],
): Promise<void> {
  const request = getRequest();
  if (!request) {
    throw new Error("No active server request is available for D1 access.");
  }
  return batchD1ForRequest(request, statements);
}
