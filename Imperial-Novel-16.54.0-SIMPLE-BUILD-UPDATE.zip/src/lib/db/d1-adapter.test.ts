import assert from "node:assert/strict";
import { readFileSync, readdirSync } from "node:fs";
import { join } from "node:path";
import { DatabaseSync } from "node:sqlite";
import test from "node:test";
import { assertSafeD1Target, resolveDbBackend } from "./backend.ts";
import { batchStatementDb, queryStatementDb, type StatementDatabase } from "./d1-sql.ts";
import { applySqliteMigrations } from "./sqlite-migrate.ts";
import { translatePostgresSql } from "./sqlite-sql.ts";

function sqliteDb(): StatementDatabase & {
  exec(sql: string): void;
  query<T>(text: string, params?: unknown[]): T[];
} {
  const db = new DatabaseSync(":memory:");
  db.exec("pragma foreign_keys = on");
  return {
    exec(sql: string) {
      db.exec(sql);
    },
    query<T>(text: string, params: unknown[] = []) {
      return db.prepare(text).all(...(params as never[])) as T[];
    },
    async batch(statements) {
      db.exec("begin immediate");
      try {
        for (const statement of statements) await statement.run();
        db.exec("commit");
      } catch (error) {
        db.exec("rollback");
        throw error;
      }
    },
    prepare(sql: string) {
      return {
        bind(...values: unknown[]) {
          const statement = db.prepare(sql);
          return {
            all: async <T>() => statement.all(...(values as never[])) as T[],
            run: async () => {
              statement.run(...(values as never[]));
            },
          };
        },
      };
    },
  };
}

test("backend refuses Cloudflare without an explicit D1 selection", () => {
  assert.throws(
    () => resolveDbBackend({ imperialRuntime: "cloudflare" }),
    /IMPERIAL_DB=d1/,
  );
  assert.equal(resolveDbBackend({ imperialRuntime: "cloudflare", imperialDb: "d1" }), "d1");
  assert.throws(() => resolveDbBackend({ imperialDb: "postgres" }), /DATABASE_URL/);
  assert.equal(resolveDbBackend({}), "pglite");
  assert.equal(resolveDbBackend({ databaseUrl: "postgres://local/app" }), "neon");
});

test("staging guard refuses the live Worker and live D1 database", () => {
  assert.throws(
    () => assertSafeD1Target({ workerName: "god-emperornovel", databaseId: "REPLACE_WITH_STAGING_D1_ID" }),
    /god-emperornovel/,
  );
  assert.throws(
    () => assertSafeD1Target({ databaseName: "god-emperornovel-db" }),
    /god-emperornovel-db/,
  );
  assert.throws(
    () => assertSafeD1Target({ databaseId: "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee" }),
    /not authorized/,
  );
  assert.doesNotThrow(() =>
    assertSafeD1Target({
      workerName: "imperial-novel-staging",
      databaseName: "imperial-novel-staging",
      databaseId: "REPLACE_WITH_STAGING_D1_ID",
    }),
  );
});

test("translates the SQL shapes the catalog and rankings use", () => {
  const cast = translatePostgresSql("select tickets::float as tickets, count(*)::int as n");
  assert.equal(cast.text, "select tickets as tickets, count(*) as n");

  const search = translatePostgresSql("select id where title ilike '%'||$1||'%'", ["Ash"]);
  assert.equal(search.text, "select id where title like '%'||?||'%'");
  assert.deepEqual(search.params, ["Ash"]);

  const ids = translatePostgresSql("select * where novel_id = any($1::int[])", [[2, 5]]);
  assert.equal(ids.text, "select * where novel_id in (?, ?)");
  assert.deepEqual(ids.params, [2, 5]);

  const week = translatePostgresSql("where created_at >= now() - interval '7 days'");
  assert.equal(week.text, "where created_at >= datetime('now', '-7 days')");

  const bound = translatePostgresSql("where created_at >= now() - $1::interval", ["30 days"]);
  assert.equal(bound.text, "where created_at >= datetime('now', ?)");
  assert.deepEqual(bound.params, ["-30 days"]);

  assert.throws(() => translatePostgresSql("select value::jsonb"), /unsupported Postgres syntax/);
});

test("D1 migrations apply once on SQLite and keep a failed file unrecorded", () => {
  const dir = join(process.cwd(), "migrations/d1");
  const files = readdirSync(dir)
    .filter((name) => name.endsWith(".sql"))
    .map((name) => ({ name, sql: readFileSync(join(dir, name), "utf8") }));
  const db = sqliteDb();
  const first = applySqliteMigrations(db, files);
  assert.deepEqual(first, ["0001_auth.sql", "0002_imperial.sql", "0003_ticket_unlock_atomic.sql", "0004_trend_factory.sql"]);
  assert.deepEqual(applySqliteMigrations(db, files), []);
  const tables = db.query<{ name: string }>("select name from sqlite_master where type = 'table' and name = 'donations'");
  assert.equal(tables.length, 1);

  const broken = sqliteDb();
  assert.throws(() => applySqliteMigrations(broken, [{ name: "0099_bad.sql", sql: "create table (" }]), /0099_bad.sql/);
  assert.deepEqual(broken.query("select name from _migrations"), []);
});

test("Trend Factory migration stores metadata-only pipeline and rejects invalid stages", async () => {
  const db = sqliteDb();
  const files = readdirSync(join(process.cwd(), "migrations/d1"))
    .filter((name) => name.endsWith(".sql"))
    .map((name) => ({ name, sql: readFileSync(join(process.cwd(), "migrations/d1", name), "utf8") }));
  applySqliteMigrations(db, files);
  await queryStatementDb(db, "insert into profiles (user_id, username) values ($1, $2)", ["admin-1", "admin_1"]);
  await queryStatementDb(db, "insert into trend_candidates (trend_title, trend_url, source_host, created_by) values ($1, $2, $3, $4)", ["Public metadata test", "https://example.org/story", "example.org", "admin-1"]);
  const rows = await queryStatementDb<{ stage: string; rights_status: string; trend_url: string }>(db, "select stage, rights_status, trend_url from trend_candidates");
  assert.equal(rows[0]?.stage, "trend");
  assert.equal(rows[0]?.rights_status, "unknown");
  assert.equal(rows[0]?.trend_url, "https://example.org/story");
  await assert.rejects(queryStatementDb(db, "insert into trend_candidates (trend_title, trend_url, source_host, stage, created_by) values ($1, $2, $3, $4, $5)", ["Bad stage", "https://example.org/other", "example.org", "auto_import_chapters", "admin-1"]));
  await assert.rejects(queryStatementDb(db, "insert into trend_candidates (trend_title, trend_url, source_host, created_by) values ($1, $2, $3, $4)", ["Duplicate", "https://example.org/story", "example.org", "admin-1"]));
});

test("unlock trigger atomically debits tickets and records one ledger entry", async () => {
  const db = sqliteDb();
  const files = readdirSync(join(process.cwd(), "migrations/d1"))
    .filter((name) => name.endsWith(".sql"))
    .map((name) => ({ name, sql: readFileSync(join(process.cwd(), "migrations/d1", name), "utf8") }));
  applySqliteMigrations(db, files);
  await queryStatementDb(db, "insert into profiles (user_id, username, tickets) values ($1, $2, $3)", ["reader-unlock", "reader_unlock", 10]);
  await queryStatementDb(db, "insert into novels (id, title, slug, author, publication_status) values (1, 'Test', 'test-novel', 'Author', 'published')");
  await queryStatementDb(db, "insert into chapters (id, novel_id, chapter_number, title, content, is_locked, ticket_cost, publication_status) values (1, 1, 1, 'One', 'Body', 1, 4, 'published')");
  await queryStatementDb(db, "insert into unlocks (user_id, chapter_id, cost) values ($1, $2, $3)", ["reader-unlock", 1, 4]);
  const balance = await queryStatementDb<{ tickets: number }>(db, "select tickets from profiles where user_id = $1", ["reader-unlock"]);
  const ledger = await queryStatementDb<{ delta: number; reference: string }>(db, "select delta, reference from ticket_ledger where user_id = $1 and reason = 'unlock'", ["reader-unlock"]);
  assert.equal(balance[0]?.tickets, 6);
  assert.equal(ledger.length, 1);
  assert.equal(ledger[0]?.delta, -4);
  assert.equal(ledger[0]?.reference, "chapter:1");
});

test("unlock trigger rejects insufficient balance without granting access or debiting", async () => {
  const db = sqliteDb();
  const files = readdirSync(join(process.cwd(), "migrations/d1"))
    .filter((name) => name.endsWith(".sql"))
    .map((name) => ({ name, sql: readFileSync(join(process.cwd(), "migrations/d1", name), "utf8") }));
  applySqliteMigrations(db, files);
  await queryStatementDb(db, "insert into profiles (user_id, username, tickets) values ($1, $2, $3)", ["poor-reader", "poor_reader", 2]);
  await queryStatementDb(db, "insert into novels (id, title, slug, author, publication_status) values (1, 'Test', 'test-novel', 'Author', 'published')");
  await queryStatementDb(db, "insert into chapters (id, novel_id, chapter_number, title, content, is_locked, ticket_cost, publication_status) values (1, 1, 1, 'One', 'Body', 1, 4, 'published')");
  await assert.rejects(queryStatementDb(db, "insert into unlocks (user_id, chapter_id, cost) values ($1, $2, $3)", ["poor-reader", 1, 4]), /Not enough tickets/);
  await assert.rejects(queryStatementDb(db, "insert into unlocks (user_id, chapter_id, cost) values ($1, $2, $3)", ["poor-reader", 1, -1]), /non-negative whole number/);
  await assert.rejects(queryStatementDb(db, "insert into unlocks (user_id, chapter_id, cost) values ($1, $2, $3)", ["poor-reader", 1, 2.5]), /non-negative whole number/);
  const balance = await queryStatementDb<{ tickets: number }>(db, "select tickets from profiles where user_id = $1", ["poor-reader"]);
  const unlocks = await queryStatementDb(db, "select 1 from unlocks where user_id = $1", ["poor-reader"]);
  assert.equal(balance[0]?.tickets, 2);
  assert.equal(unlocks.length, 0);
});

test("pending donation approval is atomic and idempotent on SQLite", async () => {
  const db = sqliteDb();
  applySqliteMigrations(
    db,
    [{ name: "0002_imperial.sql", sql: readFileSync(join(process.cwd(), "migrations/d1/0002_imperial.sql"), "utf8") }],
  );
  await queryStatementDb(
    db,
    "insert into profiles (user_id, username, tickets) values ($1, $2, $3)",
    ["user-1", "reader", 0],
  );
  await queryStatementDb(
    db,
    "insert into donations (user_id, amount, reference_id, status) values ($1, $2, $3, 'pending')",
    ["user-1", 100, "ref-1"],
  );
  const approval = [
    { text: "update donations set status = 'processing' where id = $1 and status = 'pending'", params: [1] },
    { text: "insert into ticket_ledger (user_id, delta, reason, reference) select user_id, $1, 'donation', reference_id from donations where id = $2 and status = 'processing'", params: [5, 1] },
    { text: "update profiles set tickets = tickets + $1 where user_id = $2 and exists (select 1 from donations where id = $3 and status = 'processing')", params: [5, "user-1", 1] },
    { text: "insert into notifications (user_id, title, body) select user_id, 'Donation approved', '5 tickets credited' from donations where id = $1 and status = 'processing'", params: [1] },
    { text: "insert into audit_logs (user_id, action, details) select $1, 'donation', '1:approved' where exists (select 1 from donations where id = $2 and status = 'processing')", params: ["admin-1", 1] },
    { text: "update donations set status = 'approved' where id = $1 and status = 'processing'", params: [1] },
  ];
  await batchStatementDb(db, approval);
  await batchStatementDb(db, approval);
  const balance = await queryStatementDb<{ tickets: number; banned: boolean }>(
    db,
    "select tickets::float as tickets, banned from profiles where user_id = $1",
    ["user-1"],
  );
  const donation = await queryStatementDb<{ status: string }>(db, "select status from donations where id = 1");
  const ledger = await queryStatementDb(db, "select id from ticket_ledger where user_id = $1 and reason = 'donation'", ["user-1"]);
  const notices = await queryStatementDb(db, "select id from notifications where user_id = $1 and title = 'Donation approved'", ["user-1"]);
  assert.equal(balance[0]?.tickets, 5);
  assert.equal(balance[0]?.banned, false);
  assert.equal(donation[0]?.status, "approved");
  assert.equal(ledger.length, 1);
  assert.equal(notices.length, 1);
});

test("atomic statement batches roll back all earlier writes when a later write fails", async () => {
  const db = sqliteDb();
  applySqliteMigrations(
    db,
    [{ name: "0002_imperial.sql", sql: readFileSync(join(process.cwd(), "migrations/d1/0002_imperial.sql"), "utf8") }],
  );
  await queryStatementDb(db, "insert into profiles (user_id, username, tickets) values ($1, $2, $3)", ["atomic-user", "atomic_reader", 10]);
  await queryStatementDb(db, "insert into donations (user_id, amount, reference_id, status) values ($1, $2, $3, 'pending')", ["atomic-user", 100, "atomic-ref"]);
  await assert.rejects(batchStatementDb(db, [
    { text: "update donations set status = 'processing' where reference_id = $1 and status = 'pending'", params: ["atomic-ref"] },
    { text: "update profiles set tickets = tickets + $1 where user_id = $2", params: [5, "atomic-user"] },
    { text: "insert into table_that_does_not_exist (x) values ($1)", params: [1] },
  ]));
  const donation = await queryStatementDb<{ status: string }>(db, "select status from donations where reference_id = $1", ["atomic-ref"]);
  const profile = await queryStatementDb<{ tickets: number }>(db, "select tickets from profiles where user_id = $1", ["atomic-user"]);
  assert.equal(donation[0]?.status, "pending");
  assert.equal(profile[0]?.tickets, 10);
});

test("weekly ranking counts recorded opens, not lifetime views", async () => {
  const db = sqliteDb();
  db.exec(
    "create table novels (id integer primary key, title text, publication_status text, views integer, rating real)",
  );
  db.exec("create table view_events (id integer primary key, novel_id integer, created_at text)");
  db.exec("insert into novels (id, title, publication_status, views, rating) values (1, 'Old', 'published', 900, 4)");
  db.exec("insert into novels (id, title, publication_status, views, rating) values (2, 'New', 'published', 3, 5)");
  db.exec("insert into view_events (novel_id, created_at) values (2, datetime('now'))");
  const rows = await queryStatementDb<{ title: string; window_views: number }>(
    db,
    `select n.title, w.views as window_views
     from novels n
     join (
       select novel_id, count(*)::int as views from view_events
       where created_at >= now() - interval '7 days'
       group by novel_id
     ) w on w.novel_id = n.id
     where n.publication_status = 'published'
     order by w.views desc`,
  );
  assert.deepEqual(
    rows.map((row) => row.title),
    ["New"],
  );
  assert.equal(rows[0]?.window_views, 1);
});
