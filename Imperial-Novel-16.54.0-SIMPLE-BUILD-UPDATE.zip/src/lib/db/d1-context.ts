import { AsyncLocalStorage } from "node:async_hooks";
import { batchStatementDb, queryStatementDb, wrapD1, type D1Like, type StatementDatabase } from "./d1-sql.ts";

export type D1BindingLike = D1Like;

// AsyncLocalStorage remains useful for isolated adapter tests and non-Nitro
// callers. Nitro middleware itself does not receive a `next` callback, so the
// deployed path also binds the DB to the exact Fetch Request object.
const storage = new AsyncLocalStorage<StatementDatabase>();
const requestDatabases = new WeakMap<object, StatementDatabase>();

export function withImperialD1<T>(db: D1Like, run: () => T): T {
  return storage.run(wrapD1(db), run);
}

export function registerImperialD1Request(request: object, db: D1Like): void {
  requestDatabases.set(request, wrapD1(db));
}

export function imperialD1(request?: object): StatementDatabase {
  const db = storage.getStore() ?? (request ? requestDatabases.get(request) : undefined);
  if (!db) {
    throw new Error(
      "D1 binding DB is not available for this request. Refusing to open PGLite.",
    );
  }
  return db;
}

/** Resolve the D1 binding registered for the current TanStack Start request.
 * The import is lazy so isolated adapter tests and non-request callers do not
 * need to load TanStack's server runtime. If no request context exists, the
 * final imperialD1() call throws instead of falling back to PGLite.
 */
async function currentRequestDatabase(): Promise<StatementDatabase> {
  const scoped = storage.getStore();
  if (scoped) return scoped;

  let request: object | undefined;
  try {
    const { getRequest } = await import("@tanstack/react-start/server");
    const current = getRequest();
    if (current && typeof current === "object") request = current;
  } catch {
    // getRequest throws outside a TanStack Start request. The canonical
    // fail-closed diagnostic below handles that case.
  }
  if (request) return imperialD1(request);
  return imperialD1();
}

export async function queryD1<T = Record<string, unknown>>(
  text: string,
  params: unknown[] = [],
): Promise<T[]> {
  return queryStatementDb<T>(await currentRequestDatabase(), text, params);
}

export function queryD1ForRequest<T = Record<string, unknown>>(
  request: object,
  text: string,
  params: unknown[] = [],
): Promise<T[]> {
  return queryStatementDb<T>(imperialD1(request), text, params);
}

export async function batchD1(statements: { text: string; params?: unknown[] }[]): Promise<void> {
  return batchStatementDb(await currentRequestDatabase(), statements);
}

export function batchD1ForRequest(
  request: object,
  statements: { text: string; params?: unknown[] }[],
): Promise<void> {
  return batchStatementDb(imperialD1(request), statements);
}
