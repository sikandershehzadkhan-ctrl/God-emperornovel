export type DbBackend = "neon" | "pglite" | "d1";

const PRODUCTION_DATABASE_NAMES = new Set(["god-emperornovel-db"]);
const PRODUCTION_WORKER_NAMES = new Set(["god-emperornovel"]);

export function resolveDbBackend(input: {
  databaseUrl?: string;
  imperialDb?: string;
  imperialRuntime?: string;
}): DbBackend {
  const forced = input.imperialDb?.trim().toLowerCase();
  const runtime = input.imperialRuntime?.trim().toLowerCase();
  const hasUrl = Boolean(input.databaseUrl?.trim());

  if (runtime === "cloudflare" && forced !== "d1") {
    throw new Error(
      "Cloudflare runtime requires IMPERIAL_DB=d1. Refusing to open PGLite or guess a database.",
    );
  }
  if (forced === "d1") return "d1";
  if (forced === "postgres" || forced === "neon") {
    if (!hasUrl) {
      throw new Error("IMPERIAL_DB=postgres requires DATABASE_URL. Refusing the PGLite fallback.");
    }
    return "neon";
  }
  if (forced === "pglite") return "pglite";
  if (forced) {
    throw new Error(`Unknown IMPERIAL_DB value "${forced}". Expected d1, postgres, or pglite.`);
  }
  return hasUrl ? "neon" : "pglite";
}

/** Reject the live Worker and the live D1 database. A placeholder id is not a remote target. */
export function assertSafeD1Target(input: {
  workerName?: string;
  databaseName?: string;
  databaseId?: string;
  allowRemote?: boolean;
}): void {
  const worker = input.workerName?.trim() ?? "";
  const database = input.databaseName?.trim() ?? "";
  if (PRODUCTION_WORKER_NAMES.has(worker) || PRODUCTION_DATABASE_NAMES.has(database)) {
    throw new Error(
      "Refusing the production Worker god-emperornovel and the production D1 database god-emperornovel-db.",
    );
  }
  const id = input.databaseId?.trim() ?? "";
  const placeholder = !id || id === "REPLACE_WITH_STAGING_D1_ID";
  if (!placeholder && !input.allowRemote) {
    throw new Error(
      "A real D1 database id was set, but remote access is not authorized. Use a local SQLite file for tests.",
    );
  }
}
