import type { ErrorComponentProps } from "@tanstack/react-router";
import { Link } from "@tanstack/react-router";
import { TriangleAlert } from "lucide-react";

const FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";

function errorMessage(error: unknown): string {
  if (error instanceof Error && error.message) return error.message;
  if (typeof error === "string" && error) return error;
  return FALLBACK_MESSAGE;
}

export function AppErrorComponent({ error }: ErrorComponentProps) {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center gap-4 bg-bg px-6 text-center text-fg">
      <span className="text-gold" aria-hidden="true">
        <TriangleAlert className="size-10" strokeWidth={1.5} />
      </span>
      <p className="text-[11px] font-semibold tracking-[0.22em] text-gold-2 uppercase">Imperial Gateway</p>
      <h1 className="font-display text-3xl font-semibold text-fg">Something went wrong</h1>
      <p className="max-w-md text-sm break-words text-muted">{errorMessage(error)}</p>
      <div className="mt-2 flex flex-wrap justify-center gap-2">
        <Link
          to="/"
          className="inline-flex min-h-11 items-center rounded-md border border-gold/35 bg-violet px-4 text-sm font-semibold text-primary-fg"
        >
          Return Home
        </Link>
        <Link
          to="/catalog"
          className="inline-flex min-h-11 items-center rounded-md border border-line bg-surface-2 px-4 text-sm font-semibold text-fg"
        >
          Explore Catalog
        </Link>
      </div>
    </main>
  );
}
