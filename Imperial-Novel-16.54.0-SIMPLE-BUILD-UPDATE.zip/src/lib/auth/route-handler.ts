import { authUnavailableResponse, isCloudflareAuthRuntime, type RuntimeContextLike } from "./runtime-mode.ts";

export interface AuthHandlerModule {
  auth: { handler(request: Request): Promise<Response> };
}

export type AuthModuleLoader = () => Promise<AuthHandlerModule>;
export type CloudflareAuthEnvLike = Record<string, unknown> & {
  DB?: { prepare?: unknown };
  BETTER_AUTH_URL?: string;
  BETTER_AUTH_SECRET?: string;
  GROK_AUTH_CLIENT_ID?: string;
  GROK_AUTH_CLIENT_SECRET?: string;
};
export type CloudflareAuthModuleLoader = (env: CloudflareAuthEnvLike) => Promise<AuthHandlerModule>;

/**
 * Route auth to the runtime-specific persistent backend. Cloudflare must never
 * import the Node/PGLite module; its module is loaded only after D1 and all
 * required auth settings are present. Any initialization error fails closed.
 */
export async function handleAuthRequest(
  request: Request,
  context: RuntimeContextLike | null | undefined,
  runtimeValue: string,
  loadNodeAuth: AuthModuleLoader,
  loadCloudflareAuth?: CloudflareAuthModuleLoader,
): Promise<Response> {
  if (isCloudflareAuthRuntime(context, runtimeValue)) {
    const env = context?.cloudflare?.env as CloudflareAuthEnvLike | undefined;
    if (
      !env?.DB ||
      typeof env.DB.prepare !== "function" ||
      !env.BETTER_AUTH_URL?.trim() ||
      !env.BETTER_AUTH_SECRET?.trim() ||
      !env.GROK_AUTH_CLIENT_ID?.trim() ||
      !env.GROK_AUTH_CLIENT_SECRET?.trim() ||
      !loadCloudflareAuth
    ) {
      return authUnavailableResponse();
    }

    try {
      const { auth } = await loadCloudflareAuth(env);
      return await auth.handler(request);
    } catch (error) {
      // Keep operational detail in server logs, never in a client response.
      console.error("[imperial-auth] Cloudflare D1 auth initialization/request failed", error);
      return authUnavailableResponse();
    }
  }

  try {
    const { auth } = await loadNodeAuth();
    return await auth.handler(request);
  } catch (error) {
    // A misdetected/partially configured edge runtime must never downgrade to
    // a dev identity or leak internal auth configuration through the response.
    if (runtimeValue.trim().toLowerCase() === "cloudflare") {
      console.error("[imperial-auth] Cloudflare auth fallback was blocked", error);
      return authUnavailableResponse();
    }
    throw error;
  }
}
