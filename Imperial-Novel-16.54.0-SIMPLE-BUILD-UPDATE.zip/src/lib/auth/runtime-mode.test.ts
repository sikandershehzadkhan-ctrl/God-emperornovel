import assert from "node:assert/strict";
import test from "node:test";
import { authUnavailableResponse, isCloudflareAuthRuntime } from "./runtime-mode.ts";

test("Cloudflare runtime flag is detected case-insensitively", () => {
  assert.equal(isCloudflareAuthRuntime(undefined, " Cloudflare "), true);
});

test("Cloudflare request environment is a fail-closed runtime signal", () => {
  assert.equal(isCloudflareAuthRuntime({ cloudflare: { env: { DB: {} } } }, ""), true);
});

test("local runtime without a Cloudflare environment remains eligible for existing auth", () => {
  assert.equal(isCloudflareAuthRuntime({}, "node"), false);
  assert.equal(isCloudflareAuthRuntime(undefined, ""), false);
});

test("unconfigured Cloudflare auth returns a non-cacheable 503 without identity data", async () => {
  const response = authUnavailableResponse();
  assert.equal(response.status, 503);
  assert.equal(response.headers.get("cache-control"), "no-store, max-age=0");
  const body = await response.json() as { error: string; message: string };
  assert.equal(body.error, "cloudflare_auth_unavailable");
  assert.match(body.message, /No fallback session/);
});
