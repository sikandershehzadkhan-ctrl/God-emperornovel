/** Request-scoped Cloudflare bindings shared by auth and data access. */
export type CloudflareRequestEnv = Record<string, unknown> & {
  DB?: { prepare?: unknown };
  BETTER_AUTH_URL?: string;
  BETTER_AUTH_SECRET?: string;
  GROK_AUTH_ISSUER?: string;
  GROK_AUTH_CLIENT_ID?: string;
  GROK_AUTH_CLIENT_SECRET?: string;
  GROK_PROJECT_ID?: string;
  GROK_GATE_ORIGIN?: string;
  VITE_AUTH_ENABLED?: string;
  IMPERIAL_DB?: string;
  IMPERIAL_RUNTIME?: string;
  IMPERIAL_BOOTSTRAP_ADMIN_USER_ID?: string;
  IMPERIAL_BOOTSTRAP_ADMIN_EMAIL?: string;
};

const requestEnvironments = new WeakMap<object, CloudflareRequestEnv>();

export function registerCloudflareEnvRequest(
  request: object,
  env: CloudflareRequestEnv,
): void {
  requestEnvironments.set(request, env);
}

export function cloudflareEnvForRequest(
  request: object | null | undefined,
): CloudflareRequestEnv | undefined {
  if (!request || typeof request !== "object") return undefined;
  return requestEnvironments.get(request);
}
