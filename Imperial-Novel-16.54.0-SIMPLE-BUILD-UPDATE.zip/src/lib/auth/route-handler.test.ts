import assert from "node:assert/strict";
import test from "node:test";
import { handleAuthRequest } from "./route-handler.ts";

test("Cloudflare requests return a non-cacheable 503 without loading Node auth", async () => {
  let loaded = false;
  const response = await handleAuthRequest(
    new Request("https://imperial-novel-staging.example/api/auth/get-session"),
    { cloudflare: { env: { DB: {} } } },
    "",
    async () => {
      loaded = true;
      throw new Error("the Node auth module must not load on Cloudflare");
    },
  );

  assert.equal(loaded, false);
  assert.equal(response.status, 503);
  assert.equal(response.headers.get("cache-control"), "no-store, max-age=0");
  assert.equal((await response.json()).error, "cloudflare_auth_unavailable");
});

test("non-Cloudflare requests invoke the injected auth handler", async () => {
  const expected = new Response("auth ok", { status: 200 });
  let loaded = false;
  const response = await handleAuthRequest(
    new Request("http://localhost:8080/api/auth/get-session"),
    {},
    "node",
    async () => {
      loaded = true;
      return { auth: { handler: async () => expected } };
    },
  );

  assert.equal(loaded, true);
  assert.equal(response, expected);
});

test("a Cloudflare runtime flag fails closed even if module loading fails", async () => {
  const response = await handleAuthRequest(
    new Request("https://imperial-novel-staging.example/api/auth/get-session"),
    {},
    " Cloudflare ",
    async () => { throw new Error("should not be loaded"); },
  );
  assert.equal(response.status, 503);
});


test("Cloudflare requests use the D1 auth loader when required settings exist", async () => {
  const expected = new Response("D1 auth ok", { status: 200 });
  const env = {
    DB: { prepare() {} },
    BETTER_AUTH_URL: "https://imperial-novel-staging.example",
    BETTER_AUTH_SECRET: "x".repeat(48),
    GROK_AUTH_CLIENT_ID: "staging-client",
    GROK_AUTH_CLIENT_SECRET: "staging-secret",
  };
  let nodeLoaded = false;
  let cloudflareEnv;
  const response = await handleAuthRequest(
    new Request("https://imperial-novel-staging.example/api/auth/get-session"),
    { cloudflare: { env } },
    "",
    async () => {
      nodeLoaded = true;
      throw new Error("Node auth must never load on Cloudflare");
    },
    async (receivedEnv) => {
      cloudflareEnv = receivedEnv;
      return { auth: { handler: async () => expected } };
    },
  );
  assert.equal(nodeLoaded, false);
  assert.equal(cloudflareEnv, env);
  assert.equal(response, expected);
});

test("Cloudflare requests fail closed when a required auth secret is absent", async () => {
  let cloudflareLoaded = false;
  const response = await handleAuthRequest(
    new Request("https://imperial-novel-staging.example/api/auth/get-session"),
    { cloudflare: { env: { DB: { prepare() {} }, BETTER_AUTH_URL: "https://imperial-novel-staging.example" } } },
    "cloudflare",
    async () => { throw new Error("Node auth must not load"); },
    async () => {
      cloudflareLoaded = true;
      throw new Error("Cloudflare auth must not load without secrets");
    },
  );
  assert.equal(cloudflareLoaded, false);
  assert.equal(response.status, 503);
  assert.equal(response.headers.get("cache-control"), "no-store, max-age=0");
});
