/**
 * Cloudflare-only Better Auth configuration.
 *
 * This module deliberately has no imports from pg, PGLite, node:crypto, or the
 * local Postgres/PGLite auth server. It is loaded only after the request has a
 * real D1 binding and the required deployment secrets have been validated.
 */
import { betterAuth } from "better-auth";
import { drizzleAdapter } from "better-auth/adapters/drizzle";
import { bearer, genericOAuth } from "better-auth/plugins";
import { tanstackStartCookies } from "better-auth/tanstack-start";
import { drizzle } from "drizzle-orm/d1";
import type { D1Like } from "../db/d1-context.ts";
import { emailAndPasswordEnabled } from "./email-password.ts";
import { GATE_PROVIDER_ID, gateIdentitySessions } from "./gate-session.server.ts";
import { GROK_PROVIDERS } from "./providers.ts";
import { d1AuthSchema } from "./d1-schema.ts";

export interface CloudflareAuthEnv {
  DB?: D1Like;
  BETTER_AUTH_URL?: string;
  BETTER_AUTH_SECRET?: string;
  GROK_AUTH_ISSUER?: string;
  GROK_AUTH_CLIENT_ID?: string;
  GROK_AUTH_CLIENT_SECRET?: string;
  GROK_PROJECT_ID?: string;
  GROK_GATE_ORIGIN?: string;
  VITE_AUTH_ENABLED?: string;
  IMPERIAL_DB?: string;
  IMPERIAL_RUNTIME?: string;
  IMPERIAL_BOOTSTRAP_ADMIN_USER_ID?: string;
  IMPERIAL_BOOTSTRAP_ADMIN_EMAIL?: string;
}

const required = (value: string | undefined, name: string): string => {
  const normalized = value?.trim();
  if (!normalized) throw new Error(`Missing required Cloudflare auth setting: ${name}`);
  return normalized;
};

function validatedBaseUrl(value: string): string {
  const url = new URL(value);
  if (url.protocol !== "https:" && !(url.protocol === "http:" && ["localhost", "127.0.0.1"].includes(url.hostname))) {
    throw new Error("BETTER_AUTH_URL must use HTTPS outside local development.");
  }
  if (url.username || url.password || url.search || url.hash || url.pathname !== "/") {
    throw new Error("BETTER_AUTH_URL must be an origin without credentials, path, query, or fragment.");
  }
  return url.origin;
}

function populateProcessEnv(env: CloudflareAuthEnv): void {
  // Existing gate-identity hooks and Better Auth integrations read these
  // string settings through src/lib/env.server.ts. Worker bindings are fixed
  // for the isolate, so copying only allowlisted strings is safe; DB is never
  // copied into process.env.
  const names = [
    "BETTER_AUTH_URL", "BETTER_AUTH_SECRET", "GROK_AUTH_ISSUER",
    "GROK_AUTH_CLIENT_ID", "GROK_AUTH_CLIENT_SECRET", "GROK_PROJECT_ID",
    "GROK_GATE_ORIGIN", "VITE_AUTH_ENABLED", "IMPERIAL_DB", "IMPERIAL_RUNTIME",
    "IMPERIAL_BOOTSTRAP_ADMIN_USER_ID", "IMPERIAL_BOOTSTRAP_ADMIN_EMAIL",
  ] as const;
  for (const name of names) {
    const value = env[name];
    if (typeof value === "string" && value.trim()) process.env[name] = value.trim();
  }
}

export function createCloudflareAuth(env: CloudflareAuthEnv) {
  if (!env.DB || typeof env.DB.prepare !== "function") {
    throw new Error("Cloudflare D1 binding DB is unavailable.");
  }
  if (env.VITE_AUTH_ENABLED?.trim().toLowerCase() === "false") {
    throw new Error("Authentication is disabled by VITE_AUTH_ENABLED=false.");
  }
  const secret = required(env.BETTER_AUTH_SECRET, "BETTER_AUTH_SECRET");
  if (secret.length < 32) throw new Error("BETTER_AUTH_SECRET must contain at least 32 characters.");
  const baseURL = validatedBaseUrl(required(env.BETTER_AUTH_URL, "BETTER_AUTH_URL"));
  // Production/staging origins are HTTPS. Keep local HTTP preview usable without
  // weakening cookie security for deployed origins.
  const secureCookies = new URL(baseURL).protocol === "https:";
  const clientId = required(env.GROK_AUTH_CLIENT_ID, "GROK_AUTH_CLIENT_ID");
  const clientSecret = required(env.GROK_AUTH_CLIENT_SECRET, "GROK_AUTH_CLIENT_SECRET");
  const issuer = (env.GROK_AUTH_ISSUER?.trim() || "https://auth.grok.me").replace(/\/+$/, "");
  const issuerBase = new URL(issuer);
  if (issuerBase.protocol !== "https:" || issuerBase.pathname !== "/" || issuerBase.search || issuerBase.hash) {
    throw new Error("GROK_AUTH_ISSUER must be an HTTPS origin without a path, query, or fragment.");
  }
  const issuerOrigin = issuerBase.origin;

  populateProcessEnv({ ...env, IMPERIAL_DB: "d1", IMPERIAL_RUNTIME: "cloudflare", BETTER_AUTH_URL: baseURL });

  const db = drizzle(env.DB as never, { schema: d1AuthSchema });
  const database = drizzleAdapter(db, { provider: "sqlite", schema: d1AuthSchema });
  const grokOAuthPlugin = genericOAuth({
    config: GROK_PROVIDERS.map(({ providerId, idp }) => ({
      providerId,
      clientId,
      clientSecret,
      authorizationUrl: `${issuerOrigin}/api/auth/oauth2/authorize`,
      tokenUrl: `${issuerOrigin}/api/auth/oauth2/token`,
      userInfoUrl: `${issuerOrigin}/api/auth/oauth2/userinfo`,
      scopes: ["openid", "profile", "email"],
      authorizationUrlParams: { idp, prompt: "login" },
    })),
  });

  return betterAuth({
    baseURL,
    secret,
    database,
    trustedOrigins: [baseURL],
    account: {
      encryptOAuthTokens: true,
      accountLinking: {
        enabled: true,
        trustedProviders: [...GROK_PROVIDERS.map((provider) => provider.providerId), GATE_PROVIDER_ID],
        requireLocalEmailVerified: false,
      },
    },
    session: { cookieCache: { enabled: true, maxAge: 300 } },
    ...(emailAndPasswordEnabled ? { emailAndPassword: { enabled: true } } : {}),
    advanced: {
      useSecureCookies: secureCookies,
      defaultCookieAttributes: { secure: secureCookies, sameSite: "lax", path: "/" },
      cookies: {
        session_token: { name: "__Host-grok-auth.session_token" },
        session_data: { name: "__Host-grok-auth.session_data" },
        account_data: { name: "__Host-grok-auth.account_data" },
        dont_remember: { name: "__Host-grok-auth.dont_remember" },
      },
    },
    plugins: [gateIdentitySessions(), grokOAuthPlugin, bearer(), tanstackStartCookies()],
  });
}
