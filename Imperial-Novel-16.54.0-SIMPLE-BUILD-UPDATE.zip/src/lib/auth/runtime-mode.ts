/** Runtime guards shared by route handlers and dependency-free tests. */
export interface RuntimeContextLike {
  cloudflare?: { env?: Record<string, unknown> };
}

/**
 * Detect a Cloudflare request without importing the Node/PGLite auth module.
 * The deployment variable is the primary signal; the request environment is a
 * second fail-closed signal when the runtime provides it on the route context.
 */
export function isCloudflareAuthRuntime(
  context?: RuntimeContextLike | null,
  runtimeValue?: string,
): boolean {
  const runtime = (runtimeValue ?? "").trim().toLowerCase();
  return runtime === "cloudflare" || Boolean(context?.cloudflare?.env);
}

export function authUnavailableResponse(): Response {
  return Response.json(
    {
      error: "cloudflare_auth_unavailable",
      message:
        "Authentication is temporarily unavailable because the persistent Cloudflare authentication service is not configured or could not initialize safely. No fallback session or in-memory identity was created.",
    },
    {
      status: 503,
      headers: {
        "cache-control": "no-store, max-age=0",
        "content-type": "application/json; charset=utf-8",
      },
    },
  );
}
