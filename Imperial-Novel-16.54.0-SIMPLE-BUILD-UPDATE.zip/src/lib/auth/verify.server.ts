import { getRequest } from "@tanstack/react-start/server";
import { gateIdentityEnabled } from "./gate-identity.server";
import { cloudflareEnvForRequest } from "./cloudflare-context.server";

/**
 * Server-side session resolution (server-only).
 *
 * Because this app runs its OWN Better Auth at same-origin `/api/auth/*`, the
 * session cookie is sent with every request to this app — server functions AND
 * SSR loaders included. So we resolve the user straight from the request cookies
 * via `auth.api.getSession` (no client-minted JWT needed). Never trust a
 * client-supplied user id — only the result of this verification.
 */

/** True when a real database is configured server-side. */
const databaseConfigured = Boolean(
  process.env.DATABASE_URL?.trim() ||
    process.env.IMPERIAL_DB?.trim().toLowerCase() === "d1" ||
    process.env.IMPERIAL_RUNTIME?.trim().toLowerCase() === "cloudflare",
);

/** Dev fallback user id, used only when auth is disabled (VITE_AUTH_ENABLED=false). */
export const DEV_USER_ID = "dev-user";

/**
 * Thrown by `requireUserId` when the caller has no valid session. Carries
 * `status: 401`; the message is a stable contract — match
 * `err.message === "Unauthorized"` client-side to send the visitor to sign-in.
 */
export class UnauthorizedError extends Error {
  readonly status = 401;
  constructor() {
    super("Unauthorized");
    this.name = "UnauthorizedError";
  }
}

export type VerifiedUser = { id: string; email: string | null };

/**
 * Resolve the signed-in user from the current request, or `null` when auth isn't
 * configured / nobody is signed in. Safe to call from server functions and SSR
 * loaders.
 *
 * `bearerToken` is for the LIVE PREVIEW: the app runs in a partitioned iframe
 * whose cookies don't reach the server, so `authMiddleware` forwards the session
 * as a bearer token, which we present as `Authorization: Bearer …` (the `bearer`
 * plugin resolves it). When deployed no token is passed and the cookie is used.
 */
export async function getSessionUser(
  bearerToken?: string,
): Promise<VerifiedUser | null> {
  const request = getRequest();
  if (!request) return null;

  const cloudflareEnv = cloudflareEnvForRequest(request);
  let authInstance: { api: { getSession(input: { headers: Headers }): Promise<{ user?: { id: string; email?: string | null } } | null> } };

  if (cloudflareEnv) {
    // The Node/PGLite auth module is deliberately not imported in a Worker.
    // Resolve Better Auth from the same request's D1 binding and secrets.
    const { createCloudflareAuth } = await import("./cloudflare.server");
    authInstance = createCloudflareAuth(
      cloudflareEnv as Parameters<typeof createCloudflareAuth>[0],
    );
  } else {
    // Use the aliasable absolute path: Cloudflare builds replace this module
    // with a fail-closed stub and must never bundle pg/PGLite into the Worker.
    const { auth, authConfigured } = await import("@/lib/auth/server");
    if (!authConfigured && !gateIdentityEnabled()) return null;
    authInstance = auth;
  }

  let headers = request.headers;
  if (bearerToken) {
    headers = new Headers(request.headers);
    headers.set("Authorization", `Bearer ${bearerToken}`);
  }
  const session = await authInstance.api.getSession({ headers });
  if (!session?.user) return null;
  return { id: session.user.id, email: session.user.email ?? null };
}

/**
 * Resolve the current user id for a server function, or throw when unauthorized.
 * Prefer `authMiddleware` (`./middleware`), which calls this for you.
 * - Auth enabled -> the verified session user id; throws
 *   `UnauthorizedError` when signed out. Works in the sandbox preview too (real
 *   sign-in via the baked preview client).
 * - Auth disabled (`VITE_AUTH_ENABLED=false`) + `DATABASE_URL` set -> throw (fail
 *   closed): one shared dev user on a real database would let every visitor
 *   read/write everyone's rows.
 * - Auth disabled + no database -> the shared dev user id.
 */
export async function requireUserId(bearerToken?: string): Promise<string> {
  const request = getRequest();
  const cloudflareEnv = cloudflareEnvForRequest(request);

  if (!cloudflareEnv) {
    const { authConfigured } = await import("@/lib/auth/server");
    if (!authConfigured && !gateIdentityEnabled()) {
      if (databaseConfigured) {
        throw new Error(
          "Auth is disabled or its persistent backend is unavailable — refusing to fall back to the shared dev user against a configured database.",
        );
      }
      return DEV_USER_ID;
    }
  }

  const user = await getSessionUser(bearerToken);
  if (!user) throw new UnauthorizedError();
  return user.id;
}
