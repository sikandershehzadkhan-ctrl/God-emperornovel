/** Drizzle schema for the staging Cloudflare D1 Better Auth database. */
import { sql } from "drizzle-orm";
import { index, integer, sqliteTable, text, uniqueIndex } from "drizzle-orm/sqlite-core";

const timestamp = (name: string) => integer(name, { mode: "timestamp_ms" });

export const d1User = sqliteTable(
  "user",
  {
    id: text("id").primaryKey(),
    name: text("name").notNull(),
    email: text("email").notNull(),
    emailVerified: integer("emailVerified", { mode: "boolean" }).notNull().default(false),
    image: text("image"),
    createdAt: timestamp("createdAt").notNull().default(sql`(unixepoch() * 1000)`),
    updatedAt: timestamp("updatedAt").notNull().default(sql`(unixepoch() * 1000)`),
  },
  (table) => [uniqueIndex("user_email_unique").on(table.email)],
);

export const d1Session = sqliteTable(
  "session",
  {
    id: text("id").primaryKey(),
    expiresAt: timestamp("expiresAt").notNull(),
    token: text("token").notNull(),
    createdAt: timestamp("createdAt").notNull().default(sql`(unixepoch() * 1000)`),
    updatedAt: timestamp("updatedAt").notNull().default(sql`(unixepoch() * 1000)`),
    ipAddress: text("ipAddress"),
    userAgent: text("userAgent"),
    userId: text("userId").notNull().references(() => d1User.id, { onDelete: "cascade" }),
  },
  (table) => [
    uniqueIndex("session_token_unique").on(table.token),
    index("session_userId_idx").on(table.userId),
  ],
);

export const d1Account = sqliteTable(
  "account",
  {
    id: text("id").primaryKey(),
    accountId: text("accountId").notNull(),
    providerId: text("providerId").notNull(),
    userId: text("userId").notNull().references(() => d1User.id, { onDelete: "cascade" }),
    accessToken: text("accessToken"),
    refreshToken: text("refreshToken"),
    idToken: text("idToken"),
    accessTokenExpiresAt: timestamp("accessTokenExpiresAt"),
    refreshTokenExpiresAt: timestamp("refreshTokenExpiresAt"),
    scope: text("scope"),
    password: text("password"),
    createdAt: timestamp("createdAt").notNull().default(sql`(unixepoch() * 1000)`),
    updatedAt: timestamp("updatedAt").notNull().default(sql`(unixepoch() * 1000)`),
  },
  (table) => [index("account_userId_idx").on(table.userId)],
);

export const d1Verification = sqliteTable(
  "verification",
  {
    id: text("id").primaryKey(),
    identifier: text("identifier").notNull(),
    value: text("value").notNull(),
    expiresAt: timestamp("expiresAt").notNull(),
    createdAt: timestamp("createdAt").notNull().default(sql`(unixepoch() * 1000)`),
    updatedAt: timestamp("updatedAt").notNull().default(sql`(unixepoch() * 1000)`),
  },
  (table) => [index("verification_identifier_idx").on(table.identifier)],
);

export const d1AuthSchema = {
  user: d1User,
  session: d1Session,
  account: d1Account,
  verification: d1Verification,
};
