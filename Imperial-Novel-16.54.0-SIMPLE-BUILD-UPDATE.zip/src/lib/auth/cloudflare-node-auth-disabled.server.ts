/**
 * Cloudflare-build alias target for the Node/PGLite auth server import.
 *
 * The Cloudflare route always chooses cloudflare.server.ts. This stub exists so
 * Vite/Nitro do not bundle pg/PGLite/Node crypto into the Worker artifact just
 * because the route retains a defensive Node loader for non-Cloudflare builds.
 */
import { authUnavailableResponse } from "./runtime-mode.ts";

export const authConfigured = false;

export const auth = {
  async handler(): Promise<Response> {
    return authUnavailableResponse();
  },
  api: {
    async getSession(): Promise<null> {
      return null;
    },
  },
};
