import { createFileRoute, redirect } from "@tanstack/react-router";

export const Route = createFileRoute("/home")({
  head: () => ({ meta: [{ title: "Home Redirect | Imperial Novel" }, { name: "description", content: "Discover original, licensed and authorized novels in the Imperial Novel reading realm." }, { name: "robots", content: "noindex,follow" }] }),
  beforeLoad: () => {
    throw redirect({ to: "/" });
  },
});
