import { createFileRoute, redirect } from "@tanstack/react-router";

export const Route = createFileRoute("/account")({
  head: () => ({ meta: [{ title: "Account Redirect | Imperial Novel" }, { name: "description", content: "Redirect to your Imperial Novel account page." }, { name: "robots", content: "noindex,follow" }] }),
  beforeLoad: () => {
    throw redirect({ to: "/profile" });
  },
});
