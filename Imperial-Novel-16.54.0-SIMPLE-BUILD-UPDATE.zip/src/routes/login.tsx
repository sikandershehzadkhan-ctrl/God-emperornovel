import { createFileRoute, Link, useRouter } from "@tanstack/react-router";
import { useState } from "react";
import { GROK_PROVIDERS, authClient, authEnabled, signIn } from "@/lib/auth/client";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { Button } from "@/components/ui/button";
import { Field, Input } from "@/components/ui/input";
import { Panel } from "@/components/ui/panel";
import { errMessage } from "@/lib/utils";

export const Route = createFileRoute("/login")({
  head: () => ({ meta: [{ title: "Sign in | Imperial Novel" }, { name: "description", content: "Sign in to your Imperial Novel account to access your library and reader features." }] }),
  component: Login,
});

function Login() {
  const { user, isPending } = useCurrentUserState();
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  if (!isPending && user) {
    void router.navigate({ to: "/profile" });
  }

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setBusy(true);
    try {
      const { error: err } = await authClient.signIn.email({ email, password });
      if (err) throw new Error(err.message || "Sign-in failed");
      await router.invalidate();
      await router.navigate({ to: "/profile" });
    } catch (err) {
      setError(errMessage(err, "Unable to sign in."));
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="mx-auto w-full max-w-md px-4 py-12">
      <Panel className="p-6">
        <p className="text-[11px] font-semibold tracking-[0.2em] text-cyan uppercase">Imperial Account</p>
        <h1 className="font-display mt-2 text-3xl text-fg">Sign in</h1>
        <p className="mt-1 text-sm text-muted">Continue your reading journey.</p>
        {authEnabled ? (
          <div className="mt-5 grid gap-2">
            {GROK_PROVIDERS.map((p) => (
              <Button
                key={p.providerId}
                type="button"
                variant="secondary"
                onClick={() => signIn(p.providerId, { callbackURL: "/profile" })}
              >
                Continue with {p.label}
              </Button>
            ))}
          </div>
        ) : (
          <p className="mt-4 text-sm text-muted">Sign-in is disabled.</p>
        )}
        <div className="my-5 flex items-center gap-3 text-xs text-subtle">
          <span className="h-px flex-1 bg-line" />
          or email
          <span className="h-px flex-1 bg-line" />
        </div>
        <form className="grid gap-3" onSubmit={onSubmit}>
          <Field label="Email">
            <Input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="email" />
          </Field>
          <Field label="Password">
            <Input
              type="password"
              required
              minLength={8}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              autoComplete="current-password"
            />
          </Field>
          {error ? <p className="text-sm text-danger">{error}</p> : null}
          <Button type="submit" disabled={busy}>
            {busy ? "Signing in…" : "Sign In"}
          </Button>
        </form>
        <p className="mt-4 text-sm text-muted">
          New here?{" "}
          <Link to="/signup" className="text-gold-2">
            Create an account
          </Link>
        </p>
      </Panel>
    </div>
  );
}
