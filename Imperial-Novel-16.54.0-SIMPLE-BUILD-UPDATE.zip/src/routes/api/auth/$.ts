import { createFileRoute } from "@tanstack/react-router";
import { handleAuthRequest } from "@/lib/auth/route-handler";

/**
 * Runtime-specific auth modules are loaded lazily. Cloudflare uses only the
 * D1/Drizzle module; Node/PGLite remains isolated to non-Cloudflare runtimes.
 */
function handleAuth(request: Request, context: unknown): Promise<Response> {
  const runtimeValue =
    typeof process !== "undefined" ? process.env.IMPERIAL_RUNTIME ?? "" : "";

  return handleAuthRequest(
    request,
    context as { cloudflare?: { env?: Record<string, unknown> } },
    runtimeValue,
    () => import("@/lib/auth/server"),
    async (env) => {
      const { createCloudflareAuth } = await import("@/lib/auth/cloudflare.server");
      return { auth: createCloudflareAuth(env as Parameters<typeof createCloudflareAuth>[0]) };
    },
  );
}

export const Route = createFileRoute("/api/auth/$")({
  server: {
    handlers: {
      GET: ({ request, context }) => handleAuth(request, context),
      POST: ({ request, context }) => handleAuth(request, context),
    },
  },
});
