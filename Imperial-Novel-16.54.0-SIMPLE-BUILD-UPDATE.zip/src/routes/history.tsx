import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { PageWrap, RequireAuth } from "@/components/layout/shell";
import { EmptyState, PageHeader } from "@/components/ui/panel";
import { StoryGrid } from "@/components/novel/story-card";
import { getLibrary } from "@/lib/imperial/library";
import type { NovelCard } from "@/lib/imperial/types";

export const Route = createFileRoute("/history")({
  head: () => ({ meta: [{ title: "Reading History | Imperial Novel" }, { name: "description", content: "Continue reading with your personal Imperial Novel reading history." }] }),
  component: () => (
    <RequireAuth>
      <HistoryPage />
    </RequireAuth>
  ),
});

function HistoryPage() {
  const [rows, setRows] = useState<NovelCard[]>([]);
  useEffect(() => {
    getLibrary()
      .then((d) => setRows(d.history))
      .catch(() => setRows([]));
  }, []);
  return (
    <PageWrap>
      <PageHeader title="Reading History" sub="Your recently read novels and the latest chapters you reached." />
      <StoryGrid
        novels={rows}
        empty={
          <EmptyState title="No reading history yet." body="Open a chapter to begin your journey.">
            <Link to="/catalog" className="text-gold-2">
              Browse catalog
            </Link>
          </EmptyState>
        }
      />
    </PageWrap>
  );
}
