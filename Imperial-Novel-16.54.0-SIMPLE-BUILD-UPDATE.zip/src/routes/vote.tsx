import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { PageWrap } from "@/components/layout/shell";
import { Button } from "@/components/ui/button";
import { EmptyState, PageHeader } from "@/components/ui/panel";
import { listOpenRequests, voteRequest } from "@/lib/imperial/community";
import { errMessage } from "@/lib/utils";

export const Route = createFileRoute("/vote")({
  head: () => ({ meta: [{ title: "Vote Novels | Imperial Novel" }, { name: "description", content: "Browse community novel requests and voting on Imperial Novel." }] }),
  component: VotePage,
});

function VotePage() {
  const [rows, setRows] = useState<Awaited<ReturnType<typeof listOpenRequests>>>([]);
  async function load() {
    setRows(await listOpenRequests());
  }
  useEffect(() => {
    load().catch(() => setRows([]));
  }, []);
  return (
    <PageWrap>
      <PageHeader title="Vote Novels" sub="Vote on open requests to help the community surface what readers want reviewed." />
      {rows.length ? (
        <div className="grid gap-2">
          {rows.map((r) => (
            <div key={r.id} className="grid grid-cols-[72px_1fr_auto] items-center gap-3 rounded-md border border-line bg-surface px-3 py-3">
              <span className="text-center font-semibold text-gold-2">
                {r.votes}
                <small className="block text-[10px] font-normal text-muted">votes</small>
              </span>
              <span>
                <b className="text-fg">Request #{r.id}</b>
                <p className="truncate text-xs text-muted">
                  {r.source_host} · {r.url}
                </p>
              </span>
              <Button
                variant="ghost"
                onClick={async () => {
                  try {
                    await voteRequest({ data: r.id });
                    await load();
                  } catch (e) {
                    toast.error(errMessage(e));
                  }
                }}
              >
                Vote
              </Button>
            </div>
          ))}
        </div>
      ) : (
        <EmptyState title="No open novel requests yet.">
          <Button asChild>
            <Link to="/requests">Submit a request</Link>
          </Button>
        </EmptyState>
      )}
    </PageWrap>
  );
}
