import { createFileRoute, Link } from "@tanstack/react-router";
import { toast } from "sonner";
import { PageWrap, RequireAuth } from "@/components/layout/shell";
import { Button } from "@/components/ui/button";
import { EmptyState, PageHeader } from "@/components/ui/panel";
import { CoverImage } from "@/components/novel/story-card";
import { getLibrary, setLibraryShelf, toggleFavorite, toggleLibrary } from "@/lib/imperial/library";
import { cn, errMessage, formatRating, safeText } from "@/lib/utils";
import { useEffect, useState } from "react";

export const Route = createFileRoute("/library")({
  head: () => ({ meta: [{ title: "Library | Imperial Novel" }, { name: "description", content: "Manage your Imperial Novel reading library and saved stories." }] }),
  component: () => (
    <RequireAuth>
      <LibraryPage />
    </RequireAuth>
  ),
});

type Shelf = "all" | "reading" | "completed" | "dropped" | "favorites";

function LibraryPage() {
  const [data, setData] = useState<Awaited<ReturnType<typeof getLibrary>> | null>(null);
  const [shelf, setShelf] = useState<Shelf>("all");

  async function load() {
    const d = await getLibrary();
    setData(d);
  }

  useEffect(() => {
    load().catch(() => setData({ saved: [], history: [], bookmarks: [], following: [] }));
  }, []);

  if (!data) {
    return (
      <PageWrap>
        <div className="h-10 w-48 animate-pulse rounded-md bg-surface-3" />
        <div className="mt-6 grid grid-cols-2 gap-4 md:grid-cols-4">
          <div className="aspect-3/4 animate-pulse rounded-lg bg-surface-3" />
          <div className="aspect-3/4 animate-pulse rounded-lg bg-surface-3" />
        </div>
      </PageWrap>
    );
  }

  const saved = data.saved as Array<(typeof data.saved)[number] & { shelf?: string; favorite?: boolean; last_chapter?: number }>;
  const filtered = saved.filter((x) => {
    if (shelf === "all") return true;
    if (shelf === "favorites") return Boolean(x.favorite);
    return (x.shelf || "reading") === shelf;
  });

  return (
    <PageWrap>
      <PageHeader
        eyebrow="Private collection"
        title="My Library"
        sub="Saved stories, shelves and reading progress synced to your account."
      />
      {data.history[0] ? (
        <Link
          to="/read/$novelId/$chapterId"
          params={{
            novelId: String(data.history[0].id),
            chapterId: String(data.history[0].chapter_number || 1),
          }}
          className="mb-5 flex min-h-16 items-center justify-between gap-3 rounded-xl border border-cyan/25 bg-surface/80 px-4 py-3"
        >
          <span>
            <span className="text-[11px] font-semibold tracking-[0.16em] text-cyan uppercase">Continue reading</span>
            <b className="mt-1 block text-fg">{safeText(data.history[0].title)}</b>
          </span>
          <span className="text-sm font-semibold text-gold-2">Chapter {data.history[0].chapter_number || 1}</span>
        </Link>
      ) : null}
      <div className="mb-6 flex gap-2 overflow-auto">
        {(
          [
            ["all", "All"],
            ["reading", "Reading"],
            ["completed", "Completed"],
            ["dropped", "Dropped"],
            ["favorites", "Favorites"],
          ] as const
        ).map(([id, label]) => (
          <button
            key={id}
            type="button"
            className={cn("filter-chip", shelf === id && "is-active")}
            onClick={() => setShelf(id)}
          >
            {label}
          </button>
        ))}
        <Link to="/history" className="filter-chip">
          History
        </Link>
        <Link to="/bookmarks" className="filter-chip">
          Bookmarks
        </Link>
      </div>

      {filtered.length ? (
        <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
          {filtered.map((x) => (
            <article key={x.id} className="story-card">
              <Link to="/novel/$id" params={{ id: String(x.id) }}>
                <div className="aspect-3/4">
                  <CoverImage src={x.cover_url} alt={safeText(x.title)} />
                </div>
                <div className="p-3">
                  <h3 className="truncate font-semibold text-fg">{safeText(x.title)}</h3>
                  <p className="text-xs text-muted">{safeText(x.author)}</p>
                  <p className="mt-1 text-[11px] text-subtle">
                    ★ {formatRating(x.rating)}
                    {x.last_chapter ? ` · Ch. ${x.last_chapter}` : ""}
                  </p>
                </div>
              </Link>
              <div className="flex flex-wrap gap-1 px-3 pb-3">
                <select
                  className="min-h-11 flex-1 rounded-md border border-line bg-bg2 px-2 text-xs text-fg"
                  value={x.shelf || "reading"}
                  aria-label={`Shelf for ${safeText(x.title)}`}
                  onChange={async (e) => {
                    try {
                      await setLibraryShelf({
                        data: { novelId: x.id, shelf: e.target.value as "reading" | "completed" | "dropped" },
                      });
                      await load();
                    } catch (err) {
                      toast.error(errMessage(err));
                    }
                  }}
                >
                  <option value="reading">Reading</option>
                  <option value="completed">Completed</option>
                  <option value="dropped">Dropped</option>
                </select>
                <Button
                  size="sm"
                  variant={x.favorite ? "gold" : "ghost"}
                  onClick={async () => {
                    try {
                      await toggleFavorite({ data: x.id });
                      await load();
                    } catch (err) {
                      toast.error(errMessage(err));
                    }
                  }}
                >
                  {x.favorite ? "Favorited" : "Favorite"}
                </Button>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={async () => {
                    try {
                      await toggleLibrary({ data: x.id });
                      await load();
                    } catch (err) {
                      toast.error(errMessage(err));
                    }
                  }}
                >
                  Remove
                </Button>
              </div>
            </article>
          ))}
        </div>
      ) : (
        <EmptyState
          title={shelf === "all" ? "Your library is empty." : "Nothing on this shelf yet."}
          body="Open a novel and add it to your library. Shelves stay private to your account."
        >
          <Button asChild>
            <Link to="/catalog">Explore Catalog</Link>
          </Button>
        </EmptyState>
      )}
    </PageWrap>
  );
}
