import { createFileRoute, Link } from "@tanstack/react-router";
import { PageWrap } from "@/components/layout/shell";
import { PageHeader, Panel } from "@/components/ui/panel";

const FAQS = [
  { q: "What is Imperial Novel?", a: "Imperial Novel is a reading and creator platform for original, licensed, public-domain and otherwise authorized stories." },
  { q: "Can I publish a novel here?", a: "Author tools are intended for creators who own or have permission to publish their work. Publication may require rights evidence and review. Do not upload material you are not authorized to distribute." },
  { q: "How do tickets work?", a: "Tickets may be used for eligible chapter unlocks. Ticket balances and unlocks depend on a successful server-side operation. Never share your password or authentication codes with anyone." },
  { q: "How are EasyPaisa payments verified?", a: "Payment references are reviewed manually. A submission is pending until an administrator approves or rejects it. Tickets must not be treated as credited before approval." },
  { q: "Does Imperial Novel import chapters from other websites?", a: "External sources must be authorized first. Discovery can use permitted public metadata, but the platform must not bypass access controls or copy protected chapter text without permission." },
  { q: "Does the website use optional analytics or marketing cookies?", a: "Optional categories are off until you choose them. Selecting a preference does not activate a provider by itself; the provider must also be configured. You can change preferences through the cookie settings link on the Privacy page." },
  { q: "How do I report a rights or safety concern?", a: "Use the available report or copyright tools where present, and include enough information for the team to identify the content. Do not include passwords, payment card data or other secrets in a report." },
  { q: "Can I use Imperial Novel on a phone?", a: "The interface is designed to adapt to mobile and desktop screens. Availability and performance can still vary by device, browser and network." },
];

export const Route = createFileRoute("/faq")({
  head: () => ({ meta: [
    { title: "FAQ | Imperial Novel" },
    { name: "description", content: "Answers about reading, publishing rights, tickets, EasyPaisa verification, privacy and using Imperial Novel." },
    { property: "og:title", content: "FAQ | Imperial Novel" },
    { property: "og:description", content: "Answers about reading, publishing rights, tickets, payments and privacy on Imperial Novel." },
  ] }),
  component: FAQPage,
});

function FAQPage() {
  return (
    <PageWrap>
      <PageHeader title="Frequently Asked Questions" sub="Clear answers for readers, authors and visitors." />
      <div className="mx-auto grid max-w-3xl gap-3">
        {FAQS.map((item) => (
          <Panel key={item.q} className="space-y-2">
            <h2 className="text-base font-semibold text-fg">{item.q}</h2>
            <p className="text-sm leading-relaxed text-muted">{item.a}</p>
          </Panel>
        ))}
        <p className="text-sm text-muted">Please also read our <Link to="/terms" className="text-cyan underline">Terms</Link> and <Link to="/privacy" className="text-cyan underline">Privacy Policy</Link>.</p>
      </div>
    </PageWrap>
  );
}
