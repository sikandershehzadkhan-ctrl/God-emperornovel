import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { PageWrap, PatronageStrip, RequireAuth } from "@/components/layout/shell";
import { Button } from "@/components/ui/button";
import { Field, Input, Textarea } from "@/components/ui/input";
import { Badge, PageHeader, Panel } from "@/components/ui/panel";
import { getMyProfile, updateProfile } from "@/lib/imperial/profile";
import { signOut } from "@/lib/auth/client";
import { errMessage, formatNumber, safeText } from "@/lib/utils";

export const Route = createFileRoute("/profile")({
  head: () => ({ meta: [{ title: "Account | Imperial Novel" }, { name: "description", content: "Manage your Imperial Novel profile and account preferences." }] }),
  component: () => (
    <RequireAuth>
      <ProfilePage />
    </RequireAuth>
  ),
});

function ProfilePage() {
  const [data, setData] = useState<Awaited<ReturnType<typeof getMyProfile>> | null>(null);
  const [username, setUsername] = useState("");
  const [bio, setBio] = useState("");

  useEffect(() => {
    getMyProfile()
      .then((d) => {
        setData(d);
        setUsername(d.profile.username);
        setBio(d.profile.bio);
      })
      .catch(() => setData(null));
  }, []);

  if (!data) {
    return (
      <PageWrap>
        <p className="text-sm text-muted">Loading account…</p>
      </PageWrap>
    );
  }

  return (
    <PageWrap>
      <PageHeader title="Account" sub="Your personal Imperial command room." />
      <div className="grid gap-5 lg:grid-cols-[230px_1fr]">
        <aside className="flex gap-2 overflow-auto lg:flex-col">
          {[
            ["/profile", "Profile"],
            ["/library", "Library"],
            ["/history", "History"],
            ["/following", "Following"],
            ["/tickets", "Tickets"],
            ["/requests", "Requests"],
            ["/settings", "Settings"],
            ["/notifications", "Notifications"],
          ].map(([to, label]) => (
            <Link
              key={to}
              to={to}
              className="whitespace-nowrap rounded-md px-3 py-2 text-sm text-muted hover:bg-violet/15 hover:text-fg"
            >
              {label}
            </Link>
          ))}
        </aside>
        <div>
          <Panel>
            <div className="flex items-center gap-4">
              <img src="/imperial-character.png" alt="" className="size-16 rounded-full border border-line object-cover" />
              <div>
                <h2 className="font-display text-2xl text-fg">{safeText(data.profile.username)}</h2>
                <p className="text-sm text-muted capitalize">{data.profile.role}</p>
              </div>
            </div>
            <div className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-4">
              {[
                [formatNumber(data.profile.tickets), "Tickets"],
                [String(data.stats.library), "Library"],
                [String(data.stats.following), "Following"],
                [String(data.stats.unlocks), "Unlocks"],
              ].map(([v, l]) => (
                <div key={l} className="rounded-md border border-line bg-bg2 p-3">
                  <b className="text-lg text-fg">{v}</b>
                  <div className="text-xs text-muted">{l}</div>
                </div>
              ))}
            </div>
            <div className="mt-4 flex flex-wrap gap-2">
              <Badge tone="cyan">{data.profile.role}</Badge>
              {data.profile.verified ? <Badge tone="good">Verified</Badge> : null}
              {data.profile.banned ? <Badge tone="danger">Restricted</Badge> : null}
            </div>
          </Panel>
          <div className="mt-4">
            <PatronageStrip />
          </div>
          <Panel className="mt-4">
            <h2 className="font-display text-xl text-fg">Profile details</h2>
            <form
              className="mt-3 grid gap-3"
              onSubmit={async (e) => {
                e.preventDefault();
                try {
                  await updateProfile({ data: { username, bio } });
                  toast.success("Profile saved");
                } catch (err) {
                  toast.error(errMessage(err));
                }
              }}
            >
              <Field label="Username">
                <Input value={username} onChange={(e) => setUsername(e.target.value)} />
              </Field>
              <Field label="Bio">
                <Textarea value={bio} onChange={(e) => setBio(e.target.value)} maxLength={500} />
              </Field>
              <Button type="submit">Save profile</Button>
            </form>
          </Panel>
          <Button
            variant="ghost"
            className="mt-4"
            onClick={() => {
              void signOut().catch(() => {});
            }}
          >
            Sign out
          </Button>
        </div>
      </div>
    </PageWrap>
  );
}
