import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { PageWrap, RequireAuth } from "@/components/layout/shell";
import { EmptyState, PageHeader } from "@/components/ui/panel";
import { StoryGrid } from "@/components/novel/story-card";
import { getLibrary } from "@/lib/imperial/library";
import type { NovelCard } from "@/lib/imperial/types";

export const Route = createFileRoute("/following")({
  head: () => ({ meta: [{ title: "Following | Imperial Novel" }, { name: "description", content: "Browse updates from authors and stories you follow on Imperial Novel." }] }),
  component: () => (
    <RequireAuth>
      <FollowingPage />
    </RequireAuth>
  ),
});

function FollowingPage() {
  const [rows, setRows] = useState<NovelCard[]>([]);
  useEffect(() => {
    getLibrary()
      .then((d) => setRows(d.following))
      .catch(() => setRows([]));
  }, []);
  return (
    <PageWrap>
      <PageHeader title="Following" sub="Stories you follow for future chapter updates." />
      <StoryGrid novels={rows} empty={<EmptyState title="You are not following any stories yet." />} />
    </PageWrap>
  );
}
