import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { PageWrap } from "@/components/layout/shell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge, EmptyState, PageHeader, Panel } from "@/components/ui/panel";
import { myImportJobs, omniSearch, omniStatus, queueImport, requestConnectorAuth } from "@/lib/imperial/omni";
import { errMessage, safeText } from "@/lib/utils";

export const Route = createFileRoute("/omniportal")({
  head: () => ({ meta: [{ title: "OmniPortal | Imperial Novel" }, { name: "description", content: "Review rights-aware discovery and connector status in Imperial Novel OmniPortal." }] }),
  loader: () => omniStatus(),
  component: OmniPage,
});

function OmniPage() {
  const status = Route.useLoaderData();
  const [q, setQ] = useState("");
  const [results, setResults] = useState<
    Array<{ provider: string; title: string; author: string; description: string; url: string; cover_url: string }>
  >([]);
  const [jobs, setJobs] = useState<Awaited<ReturnType<typeof myImportJobs>>>([]);

  useEffect(() => {
    myImportJobs()
      .then(setJobs)
      .catch(() => setJobs([]));
  }, []);

  return (
    <PageWrap>
      <PageHeader
        title="OmniPortal"
        sub="Rights-first discovery across Imperial Novel and authorized provider connectors."
      />
      <Panel>
        <p className="text-sm text-muted">
          Current search queries Imperial Novel's local catalog only. External provider searches remain disabled until a real
          provider adapter, credentials and source-specific rights authorization are reviewed. Import requests currently record
          metadata URLs only; this build does not fetch external catalogs or copy source chapters. Imperial Novel never bypasses
          paywalls, DRM, logins or access controls.
        </p>
        <form
          className="mt-4 flex flex-col gap-2 sm:flex-row"
          onSubmit={async (e) => {
            e.preventDefault();
            if (q.trim().length < 2) return;
            try {
              const d = await omniSearch({ data: q });
              setResults(d.results);
            } catch (err) {
              toast.error(errMessage(err));
            }
          }}
        >
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search titles, authors and worlds..." />
          <Button type="submit">Search</Button>
        </form>
      </Panel>

      <h2 className="font-display mt-8 text-2xl text-fg">Connector registry</h2>
      <div className="mt-3 grid gap-3 md:grid-cols-2">
        {status.sources.map((s) => (
          <Panel key={s.id}>
            <div className="flex items-start justify-between gap-2">
              <div>
                <h3 className="font-medium text-fg">{s.name}</h3>
                <p className="text-xs text-muted">{s.base_url}</p>
              </div>
              <Badge tone={s.enabled ? "good" : "gold"}>{s.rights_status}</Badge>
            </div>
            <p className="mt-2 text-xs text-subtle">Health: {s.last_status}</p>
            <Button
              size="sm"
              variant="ghost"
              className="mt-3"
              onClick={async () => {
                const notes = window.prompt("Rights notes, license URL, or authorization evidence");
                if (!notes) return;
                try {
                  await requestConnectorAuth({ data: { connector_id: s.id, notes } });
                  toast.success("Authorization request queued for review.");
                } catch (e) {
                  toast.error(errMessage(e));
                }
              }}
            >
              Request authorization
            </Button>
          </Panel>
        ))}
      </div>

      <h2 className="font-display mt-8 text-2xl text-fg">Search results</h2>
      <div className="mt-3 grid gap-3 md:grid-cols-2">
        {results.length ? (
          results.map((x, i) => (
            <Panel key={i}>
              <Badge tone="violet">{safeText(x.provider, "Imperial Novel")}</Badge>
              <h3 className="mt-2 font-display text-xl text-fg">{safeText(x.title)}</h3>
              <p className="text-sm text-muted">{safeText(x.author)}</p>
              <p className="mt-1 text-sm text-subtle">{safeText(x.description)}</p>
              <div className="mt-3 flex gap-2">
                {String(x.url || "").startsWith("http") ? (
                  <>
                    <Button variant="ghost" asChild>
                      <a href={x.url} target="_blank" rel="noopener noreferrer">
                        Open Source
                      </a>
                    </Button>
                    <Button
                      variant="secondary"
                      onClick={async () => {
                        try {
                          const d = await queueImport({ data: x.url });
                          toast.success(`Metadata-only request #${d.job_id} recorded. External fetching is not active.`);
                        } catch (e) {
                          toast.error(errMessage(e));
                        }
                      }}
                    >
                      Request Metadata Review
                    </Button>
                  </>
                ) : (
                  <Button asChild>
                    <Link to={x.url || "/catalog"}>Read on Imperial Novel</Link>
                  </Button>
                )}
              </div>
            </Panel>
          ))
        ) : (
          <EmptyState title="Search the authorized Imperial catalog." />
        )}
      </div>

      {jobs.length ? (
        <section className="mt-8">
          <h2 className="font-display text-2xl text-fg">Import history</h2>
          <div className="mt-3 grid gap-2">
            {jobs.map((j) => (
              <Panel key={j.id}>
                <Badge>{j.status}</Badge>
                <p className="mt-1 truncate text-sm text-fg">{j.source_url}</p>
                <p className="text-xs text-muted">{j.message}</p>
              </Panel>
            ))}
          </div>
        </section>
      ) : null}
    </PageWrap>
  );
}
