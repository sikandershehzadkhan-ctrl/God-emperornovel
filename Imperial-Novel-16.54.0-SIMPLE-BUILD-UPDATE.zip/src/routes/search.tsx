import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { PageWrap } from "@/components/layout/shell";
import { Button } from "@/components/ui/button";
import { EmptyState, PageHeader } from "@/components/ui/panel";
import { Input } from "@/components/ui/input";
import { StoryGrid } from "@/components/novel/story-card";
import { listNovels } from "@/lib/imperial/catalog";
import type { NovelCard } from "@/lib/imperial/types";

export const Route = createFileRoute("/search")({
  validateSearch: (s: Record<string, unknown>): { q?: string } => ({
    q: typeof s.q === "string" ? s.q : undefined,
  }),
  head: () => ({ meta: [{ title: "Search | Imperial Novel" }, { name: "description", content: "Search Imperial Novel stories, authors, genres and tags." }] }),
  component: SearchPage,
});

function SearchPage() {
  const { q = "" } = Route.useSearch();
  const navigate = useNavigate({ from: "/search" });
  const [term, setTerm] = useState(q);
  const [rows, setRows] = useState<NovelCard[] | null>(q ? null : []);

  useEffect(() => {
    setTerm(q);
    if (!q) {
      setRows([]);
      return;
    }
    let alive = true;
    setRows(null);
    listNovels({ data: { q, limit: 50 } })
      .then((d) => alive && setRows(d.results))
      .catch(() => alive && setRows([]));
    return () => {
      alive = false;
    };
  }, [q]);

  return (
    <PageWrap>
      <PageHeader title="Search" sub="Find novels, authors and alternate titles, then refine with catalog filters." />
      <form
        className="flex flex-col gap-2 sm:flex-row"
        onSubmit={(e) => {
          e.preventDefault();
          void navigate({ search: { q: term.trim() || undefined } });
        }}
      >
        <Input value={term} onChange={(e) => setTerm(e.target.value)} placeholder="Search novels, authors, alternate titles..." />
        <Button type="submit">Search</Button>
      </form>
      <div className="mt-3 flex flex-wrap gap-2">
        <Button variant="ghost" asChild>
          <Link to="/catalog" search={{ sort: "trending" }}>
            Trending
          </Link>
        </Button>
        <Button variant="ghost" asChild>
          <Link to="/catalog" search={{ sort: "rating" }}>
            Top Rated
          </Link>
        </Button>
        <Button variant="ghost" asChild>
          <Link to="/catalog" search={{ status: "completed" }}>
            Completed
          </Link>
        </Button>
      </div>
      <div className="mt-6">
        {!q ? (
          <EmptyState title="Search the Imperial catalog" body="Enter a title, author or alternate title to begin.">
            <Button asChild>
              <Link to="/catalog" search={{ sort: "trending" }}>
                Explore Trending Stories
              </Link>
            </Button>
          </EmptyState>
        ) : rows === null ? (
          <p className="text-sm text-muted">Searching…</p>
        ) : (
          <StoryGrid
            novels={rows}
            empty={<EmptyState title={`No results for “${q}”.`} body="Try a shorter title or browse the catalog." />}
          />
        )}
      </div>
    </PageWrap>
  );
}
