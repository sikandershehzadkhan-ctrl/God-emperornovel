import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { PageWrap } from "@/components/layout/shell";
import { Button } from "@/components/ui/button";
import { Select } from "@/components/ui/input";
import { PageHeader, Panel } from "@/components/ui/panel";

export const Route = createFileRoute("/settings")({
  head: () => ({ meta: [{ title: "Settings | Imperial Novel" }, { name: "description", content: "Customize your Imperial Novel reading and accessibility preferences." }] }),
  component: SettingsPage,
});

function SettingsPage() {
  const [font, setFont] = useState("18");
  const [line, setLine] = useState("1.85");
  const [width, setWidth] = useState("760");
  const [theme, setTheme] = useState("obsidian");
  const [reduced, setReduced] = useState(false);
  const [contrast, setContrast] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    setFont(localStorage.getItem("imperial_font_size") || "18");
    setLine(localStorage.getItem("imperial_line_height") || "1.85");
    setWidth(localStorage.getItem("imperial_reader_width") || "760");
    setTheme(localStorage.getItem("imperial_reader_theme") || "obsidian");
    setReduced(localStorage.getItem("imperial_reduced_motion") === "true");
    setContrast(localStorage.getItem("imperial_high_contrast") === "true");
  }, []);

  function persist(next?: Partial<{ font: string; line: string; width: string; theme: string; reduced: boolean; contrast: boolean }>) {
    const fontNext = next?.font ?? font;
    const lineNext = next?.line ?? line;
    const widthNext = next?.width ?? width;
    const themeNext = next?.theme ?? theme;
    const reducedNext = next?.reduced ?? reduced;
    const contrastNext = next?.contrast ?? contrast;
    localStorage.setItem("imperial_font_size", fontNext);
    localStorage.setItem("imperial_line_height", lineNext);
    localStorage.setItem("imperial_reader_width", widthNext);
    localStorage.setItem("imperial_reader_theme", themeNext);
    localStorage.setItem("imperial_reduced_motion", String(reducedNext));
    localStorage.setItem("imperial_high_contrast", String(contrastNext));
    document.documentElement.dataset.reducedMotion = reducedNext ? "true" : "false";
    document.documentElement.dataset.highContrast = contrastNext ? "true" : "false";
    setSaved(true);
    window.setTimeout(() => setSaved(false), 1600);
  }

  return (
    <PageWrap>
      <PageHeader title="Settings" sub="Control your Imperial Novel reading and interface experience." />
      <div className="grid gap-4 lg:grid-cols-3">
        <Panel>
          <p className="text-[11px] font-semibold tracking-[0.2em] text-gold-2 uppercase">Reader</p>
          <h2 className="font-display mt-1 text-xl text-fg">Reading Experience</h2>
          <label className="mt-4 grid gap-1 text-sm text-muted">
            Font size ({font}px)
            <input
              type="range"
              min={14}
              max={26}
              value={font}
              onChange={(e) => {
                setFont(e.target.value);
                persist({ font: e.target.value });
              }}
            />
          </label>
          <label className="mt-3 grid gap-1 text-sm text-muted">
            Line spacing
            <Select
              value={line}
              onChange={(e) => {
                setLine(e.target.value);
                persist({ line: e.target.value });
              }}
            >
              <option value="1.6">Compact</option>
              <option value="1.85">Comfort</option>
              <option value="2">Relaxed</option>
            </Select>
          </label>
          <label className="mt-3 grid gap-1 text-sm text-muted">
            Reading width
            <Select
              value={width}
              onChange={(e) => {
                setWidth(e.target.value);
                persist({ width: e.target.value });
              }}
            >
              <option value="680">Focused</option>
              <option value="760">Standard</option>
              <option value="860">Wide</option>
            </Select>
          </label>
          <label className="mt-3 grid gap-1 text-sm text-muted">
            Reading theme
            <Select
              value={theme}
              onChange={(e) => {
                setTheme(e.target.value);
                persist({ theme: e.target.value });
              }}
            >
              <option value="obsidian">Imperial</option>
              <option value="dark">Dark</option>
              <option value="midnight">Midnight</option>
              <option value="cosmic">Cosmic</option>
              <option value="sepia">Sepia</option>
              <option value="light">Light</option>
            </Select>
          </label>
        </Panel>
        <Panel>
          <p className="text-[11px] font-semibold tracking-[0.2em] text-gold-2 uppercase">Motion</p>
          <h2 className="font-display mt-1 text-xl text-fg">Motion & Accessibility</h2>
          <label className="mt-4 flex min-h-11 items-start gap-3 text-sm">
            <input
              type="checkbox"
              checked={reduced}
              onChange={(e) => {
                setReduced(e.target.checked);
                persist({ reduced: e.target.checked });
              }}
              className="mt-1 size-4"
            />
            <span>
              <b className="block text-fg">Reduce motion</b>
              <small className="text-muted">Minimize ambient and interface animations.</small>
            </span>
          </label>
          <label className="mt-3 flex min-h-11 items-start gap-3 text-sm">
            <input
              type="checkbox"
              checked={contrast}
              onChange={(e) => {
                setContrast(e.target.checked);
                persist({ contrast: e.target.checked });
              }}
              className="mt-1 size-4"
            />
            <span>
              <b className="block text-fg">High contrast</b>
              <small className="text-muted">Increase visual separation for controls and text.</small>
            </span>
          </label>
        </Panel>
        <Panel>
          <p className="text-[11px] font-semibold tracking-[0.2em] text-gold-2 uppercase">Account</p>
          <h2 className="font-display mt-1 text-xl text-fg">Account & Privacy</h2>
          <p className="mt-2 text-sm text-muted">Manage your account, sessions and privacy from your account center.</p>
          <div className="mt-4 flex flex-wrap gap-2">
            <Button asChild>
              <Link to="/profile">Open Account</Link>
            </Button>
            <Button variant="secondary" asChild>
              <Link to="/notifications">Notifications</Link>
            </Button>
          </div>
        </Panel>
      </div>
      {saved ? <p className="mt-4 text-sm text-good">Settings saved.</p> : null}
    </PageWrap>
  );
}
