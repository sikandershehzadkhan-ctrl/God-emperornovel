import { createFileRoute } from "@tanstack/react-router";
import { PageWrap } from "@/components/layout/shell";
import { PageHeader, Panel } from "@/components/ui/panel";
import { CookieSettingsLink } from "@/components/privacy/cookie-consent";

export const Route = createFileRoute("/privacy")({
  head: () => ({ meta: [{ title: "Privacy | Imperial Novel" }, { name: "description", content: "Read the Imperial Novel privacy policy and manage optional cookie preferences." }] }),
  component: () => (
    <PageWrap>
      <PageHeader title="Privacy" sub="How Imperial Novel handles account and reading data." />
      <Panel className="prose-imperial max-w-3xl space-y-3 text-sm leading-relaxed text-muted">
        <p>
          Imperial Novel stores the account data required to operate the library: email, username, reading history,
          bookmarks, tickets, comments and publishing drafts. Session cookies authenticate you to this app only.
        </p>
        <p>
          Reading progress and library items are scoped to your signed-in account. Public catalog metadata (titles,
          synopses, covers, ratings) is visible to all visitors.
        </p>
        <p>Donation references submitted for EasyPaisa verification are reviewed by administrators and are not shown publicly.</p>
        <p>Essential browser storage supports sign-in, security and core preferences. Optional analytics and marketing preferences are off until you choose otherwise. Choosing a category does not itself activate a third-party provider; any provider must be separately configured and reviewed.</p>
        <p>You can review or change your cookie choices at any time: <CookieSettingsLink /></p>
        <p>Do not submit passwords, payment card details, or other secrets in support messages. We use reasonable safeguards, but no online service can promise absolute security.</p>
      </Panel>
    </PageWrap>
  ),
});
