import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { PageWrap } from "@/components/layout/shell";
import { Button } from "@/components/ui/button";
import { EmptyState, PageHeader, Panel } from "@/components/ui/panel";
import { CoverImage } from "@/components/novel/story-card";
import { getRandomNovel } from "@/lib/imperial/catalog";
import type { NovelCard } from "@/lib/imperial/types";
import { formatNumber, formatRating, safeText } from "@/lib/utils";

export const Route = createFileRoute("/random")({
  head: () => ({ meta: [{ title: "Random Novel | Imperial Novel" }, { name: "description", content: "Discover a random story from the Imperial Novel catalog." }] }),
  component: RandomPage,
});

function RandomPage() {
  const [novel, setNovel] = useState<NovelCard | null>(null);
  const [busy, setBusy] = useState(false);
  async function spin() {
    setBusy(true);
    try {
      setNovel(await getRandomNovel());
    } finally {
      setBusy(false);
    }
  }
  return (
    <PageWrap>
      <PageHeader title="Random Novel" sub="One button. One story. Zero browsing indecision." />
      <Panel className="text-center">
        {novel ? (
          <article className="mx-auto grid max-w-xl gap-4 text-left sm:grid-cols-[140px_1fr]">
            <div className="aspect-3/4 overflow-hidden rounded-md">
              <CoverImage src={novel.cover_url} alt={safeText(novel.title)} />
            </div>
            <div>
              <p className="text-[11px] font-semibold tracking-[0.2em] text-gold-2 uppercase">Your random discovery</p>
              <h2 className="font-display text-3xl text-fg">{safeText(novel.title)}</h2>
              <p className="text-sm text-muted">{safeText(novel.author)}</p>
              <p className="mt-2 text-sm text-subtle">
                ★ {formatRating(novel.rating)} · {novel.chapter_count} chapters · {formatNumber(novel.views)} views
              </p>
              <Button className="mt-4" asChild>
                <Link to="/novel/$id" params={{ id: String(novel.id) }}>
                  Open Novel
                </Link>
              </Button>
            </div>
          </article>
        ) : (
          <EmptyState title="Ready to discover something unexpected." />
        )}
        <Button className="mt-6" onClick={spin} disabled={busy}>
          {busy ? "Searching the archive…" : "Discover a Random Novel"}
        </Button>
      </Panel>
    </PageWrap>
  );
}
