import { createFileRoute, Link } from "@tanstack/react-router";
import { toast } from "sonner";
import { PageWrap } from "@/components/layout/shell";
import { Button } from "@/components/ui/button";
import { PageHeader } from "@/components/ui/panel";
import { getNovel } from "@/lib/imperial/catalog";
import { batchUnlock } from "@/lib/imperial/reader";
import { BATCH_UNLOCK } from "@/lib/imperial/types";
import { errMessage, safeText } from "@/lib/utils";

export const Route = createFileRoute("/novel/$id/chapters")({
  loader: ({ params }) => getNovel({ data: Number(params.id) }),
  head: ({ loaderData }) => ({
    meta: [{ title: `${safeText(loaderData?.title, "Chapters")} | Imperial Novel` }, { name: "description", content: `Browse available chapters for ${safeText(loaderData?.title, "this story")} on Imperial Novel.` }],
  }),
  component: ChaptersPage,
});

function ChaptersPage() {
  const novel = Route.useLoaderData();
  return (
    <PageWrap>
      <PageHeader
        title={safeText(novel.title, "Untitled")}
        sub="Complete chapter archive"
        actions={
          <>
            <Button asChild>
              <Link to="/read/$novelId/$chapterId" params={{ novelId: String(novel.id), chapterId: "1" }}>
                Start at Chapter 1
              </Link>
            </Button>
            <Button
              variant="secondary"
              onClick={async () => {
                const raw = window.prompt("Batch size: 10, 25, 50 or 100", "10");
                const count = Number(raw);
                if (!BATCH_UNLOCK.includes(count as (typeof BATCH_UNLOCK)[number])) return;
                try {
                  const d = await batchUnlock({ data: { novelId: novel.id, count, start: 1 } });
                  toast.success(`Unlocked ${d.unlocked} chapters for ${d.cost} tickets. Balance: ${d.tickets}`);
                } catch (e) {
                  toast.error(errMessage(e));
                }
              }}
            >
              Batch Unlock
            </Button>
          </>
        }
      />
      <div className="grid gap-2">
        {novel.chapters.map((ch) => (
          <Link
            key={ch.id}
            to="/read/$novelId/$chapterId"
            params={{ novelId: String(novel.id), chapterId: String(ch.chapter_number) }}
            className="grid grid-cols-[56px_1fr_auto] items-center gap-3 rounded-md border border-line bg-surface px-3 py-3 hover:border-violet/40"
          >
            <span className="font-semibold text-gold-2">{ch.chapter_number}</span>
            <span>
              <b className="block text-fg">{safeText(ch.title, "Chapter")}</b>
              <span className="text-xs text-muted">
                {ch.is_locked ? `Locked · ${ch.ticket_cost} tickets` : "Free to read"}
              </span>
            </span>
            <span className="text-muted">{ch.is_locked ? "Locked" : "Read"}</span>
          </Link>
        ))}
      </div>
    </PageWrap>
  );
}
