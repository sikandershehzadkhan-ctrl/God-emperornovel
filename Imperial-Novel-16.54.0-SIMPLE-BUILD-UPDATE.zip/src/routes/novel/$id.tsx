import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { PageWrap } from "@/components/layout/shell";
import { Button } from "@/components/ui/button";
import { Badge, EmptyState, Panel } from "@/components/ui/panel";
import { CoverImage, StoryGrid } from "@/components/novel/story-card";
import { Textarea } from "@/components/ui/input";
import { getNovel } from "@/lib/imperial/catalog";
import { toggleFollow, toggleLibrary } from "@/lib/imperial/library";
import { getComments, getRating, likeComment, postComment, rateNovel, reportContent } from "@/lib/imperial/community";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { errMessage, formatNumber, formatRating, safeText } from "@/lib/utils";

export const Route = createFileRoute("/novel/$id")({
  loader: ({ params }) => getNovel({ data: Number(params.id) }),
  head: ({ loaderData }) => ({
    meta: [{ title: `${safeText(loaderData?.title, "Novel")} | Imperial Novel` }, { name: "description", content: `${safeText(loaderData?.title, "Discover this story")} on Imperial Novel. Explore the synopsis, details and available chapters.` }],
  }),
  component: NovelPage,
});

function NovelPage() {
  const novel = Route.useLoaderData();
  const { user } = useCurrentUserState();
  const navigate = useNavigate();
  const [inLib, setInLib] = useState(novel.in_library);
  const [following, setFollowing] = useState(novel.following);
  const [rating, setRating] = useState({ average: novel.rating, count: 0, user_rating: novel.user_rating });
  const [comments, setComments] = useState<Awaited<ReturnType<typeof getComments>>>([]);
  const [body, setBody] = useState("");
  const [replyTo, setReplyTo] = useState<number | undefined>();
  const [tab, setTab] = useState<"overview" | "chapters" | "comments" | "reviews">("overview");

  async function refreshCommunity() {
    const [r, c] = await Promise.all([getRating({ data: novel.id }), getComments({ data: novel.id })]);
    setRating(r);
    setComments(c);
  }

  useEffect(() => {
    refreshCommunity().catch(() => {});
  }, [novel.id]);

  const startChapter = novel.bookmark || 1;
  const chapters = novel.chapters || [];

  return (
    <PageWrap>
      <section className="grid gap-6 rounded-xl border border-cyan/15 bg-surface/80 p-4 sm:grid-cols-[180px_1fr] sm:p-6 md:grid-cols-[220px_1fr]">
        <div className="mx-auto aspect-3/4 w-32 overflow-hidden rounded-md border border-line sm:mx-0 sm:w-full">
          <CoverImage src={novel.cover_url} alt={safeText(novel.title, "Cover")} />
        </div>
        <div>
          <p className="text-[11px] font-semibold tracking-[0.18em] text-cyan uppercase">
            {safeText(novel.kind, "Story")} · {safeText(novel.status, "ongoing")}
          </p>
          <h1 className="font-display mt-1 text-3xl text-fg sm:text-4xl">{safeText(novel.title, "Untitled")}</h1>
          <p className="mt-1 text-sm text-muted">
            by{" "}
            <Link to="/author/$name" params={{ name: novel.author }} className="text-gold-2">
              {safeText(novel.author, "Unknown author")}
            </Link>
          </p>
          <div className="mt-3 flex flex-wrap gap-1.5">
            {(novel.genres || []).map((g) => (
              <Link key={g.slug} to="/catalog" search={{ genre: g.slug }}>
                <Badge tone="violet">{g.name}</Badge>
              </Link>
            ))}
            {(novel.tags || []).map((t) => (
              <Link key={t.slug} to="/catalog" search={{ tag: t.slug }}>
                <Badge>#{t.name}</Badge>
              </Link>
            ))}
          </div>
          <p className="mt-4 max-w-2xl text-sm leading-relaxed text-muted">
            {safeText(novel.description, "No description yet.")}
          </p>
          <div className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-4">
            {[
              [formatNumber(novel.views), "Views"],
              [formatRating(rating.average), "Rating"],
              [String(chapters.length), "Chapters"],
              [safeText(novel.rights_status, "authorized"), "Rights"],
            ].map(([v, l]) => (
              <div key={l} className="rounded-md border border-line bg-bg2 px-3 py-2">
                <b className="block text-fg">{v}</b>
                <span className="text-xs text-muted">{l}</span>
              </div>
            ))}
          </div>
          <div className="mt-4 flex flex-wrap gap-2">
            <Button asChild>
              <Link to="/read/$novelId/$chapterId" params={{ novelId: String(novel.id), chapterId: String(startChapter) }}>
                {novel.bookmark ? "Continue Reading" : "Start Reading"}
              </Link>
            </Button>
            <Button
              variant="secondary"
              onClick={async () => {
                try {
                  if (!user) {
                    void navigate({ to: "/login" });
                    return;
                  }
                  const d = await toggleLibrary({ data: novel.id });
                  setInLib(d.in_library);
                  toast.success(d.in_library ? "Added to library" : "Removed from library");
                } catch (e) {
                  toast.error(errMessage(e));
                }
              }}
            >
              {inLib ? "In Library" : "Add to Library"}
            </Button>
            <Button
              variant="ghost"
              onClick={async () => {
                try {
                  if (!user) {
                    void navigate({ to: "/login" });
                    return;
                  }
                  const d = await toggleFollow({ data: novel.id });
                  setFollowing(d.following);
                } catch (e) {
                  toast.error(errMessage(e));
                }
              }}
            >
              {following ? "Following" : "Follow"}
            </Button>
            <Button
              variant="ghost"
              onClick={async () => {
                try {
                  await navigator.clipboard.writeText(window.location.href);
                  toast.success("Link copied");
                } catch {
                  toast.error("Could not copy link");
                }
              }}
            >
              Share
            </Button>
            <Button
              variant="ghost"
              onClick={async () => {
                const reason = window.prompt("Why are you reporting this novel?", "spam");
                if (!reason) return;
                try {
                  if (!user) {
                    void navigate({ to: "/login" });
                    return;
                  }
                  await reportContent({ data: { reason, novelId: novel.id } });
                  toast.success("Report submitted for moderation.");
                } catch (e) {
                  toast.error(errMessage(e));
                }
              }}
            >
              Report
            </Button>
          </div>
        </div>
      </section>

      <div className="mt-6 flex gap-1 overflow-auto border-b border-line">
        {(
          [
            ["overview", "Description"],
            ["chapters", "Chapters"],
            ["comments", "Comments"],
            ["reviews", "Reviews"],
          ] as const
        ).map(([id, label]) => (
          <button
            key={id}
            type="button"
            className={`tab-btn ${tab === id ? "is-active" : ""}`}
            onClick={() => setTab(id)}
          >
            {label}
          </button>
        ))}
        <Link
          to="/novel/$id/chapters"
          params={{ id: String(novel.id) }}
          className="tab-btn"
        >
          Full list
        </Link>
      </div>

      {tab === "overview" ? (
      <section className="mt-6">
        <h2 className="font-display text-2xl text-fg">Synopsis</h2>
        <p className="mt-3 max-w-3xl text-sm leading-relaxed text-muted">
          {safeText(novel.description, "No description yet.")}
        </p>
      </section>
      ) : null}

      {tab === "chapters" ? (
      <section className="mt-6">
        <div className="mb-3 flex items-end justify-between">
          <div>
            <h2 className="font-display text-2xl text-fg">Chapters</h2>
            <p className="text-sm text-muted">{chapters.length} chapters in this world.</p>
          </div>
          <Link to="/novel/$id/chapters" params={{ id: String(novel.id) }} className="text-sm text-gold-2">
            View chapter list
          </Link>
        </div>
        <div className="grid gap-2">
          {chapters.slice(0, 20).map((ch) => (
            <Link
              key={ch.id}
              to="/read/$novelId/$chapterId"
              params={{ novelId: String(novel.id), chapterId: String(ch.chapter_number) }}
              className="grid grid-cols-[56px_1fr_auto] items-center gap-3 rounded-md border border-line bg-surface px-3 py-3 hover:border-violet/40"
            >
              <span className="font-semibold text-gold-2">{ch.chapter_number}</span>
              <span>
                <b className="block text-fg">{safeText(ch.title, "Chapter")}</b>
                <span className="text-xs text-muted">
                  {ch.is_locked ? `Locked · ${ch.ticket_cost} tickets` : "Free to read"}
                </span>
              </span>
              <span className="text-muted">{ch.is_locked ? "Locked" : "Read"}</span>
            </Link>
          ))}
        </div>
      </section>
      ) : null}

      {tab === "comments" || tab === "reviews" ? (
      <section className="mt-8" id="community">
        <h2 className="font-display text-2xl text-fg">Reader Community</h2>
        <p className="text-sm text-muted">Rate the novel, join the discussion, and report anything that needs attention.</p>
        <div className="mt-4 grid gap-4 md:grid-cols-2">
          <Panel>
            <h3 className="font-medium text-fg">Rate this novel</h3>
            <div className="mt-2 flex gap-1">
              {[1, 2, 3, 4, 5].map((i) => (
                <button
                  key={i}
                  type="button"
                  className={`min-h-11 min-w-11 text-lg ${i <= rating.user_rating ? "text-gold" : "text-subtle"}`}
                  onClick={async () => {
                    try {
                      if (!user) {
                        void navigate({ to: "/login" });
                        return;
                      }
                      const x = await rateNovel({ data: { novelId: novel.id, rating: i } });
                      setRating({ average: x.average, count: x.count, user_rating: i });
                    } catch (e) {
                      toast.error(errMessage(e));
                    }
                  }}
                  aria-label={`Rate ${i} stars`}
                >
                  ★
                </button>
              ))}
            </div>
            <p className="mt-1 text-sm text-muted">
              {formatRating(rating.average)} / 5 · {rating.count} {rating.count === 1 ? "rating" : "ratings"}
            </p>
          </Panel>
          <Panel>
            <h3 className="font-medium text-fg">Join the discussion</h3>
            <Textarea
              className="mt-2"
              maxLength={1000}
              value={body}
              onChange={(e) => setBody(e.target.value)}
              placeholder="Share your thoughts about this story..."
            />
            <div className="mt-2 flex items-center gap-2">
              <Button
                onClick={async () => {
                  try {
                    if (!body.trim()) return toast.error("Write a comment first.");
                    await postComment({ data: { novelId: novel.id, body, parentId: replyTo } });
                    setBody("");
                    setReplyTo(undefined);
                    await refreshCommunity();
                  } catch (e) {
                    toast.error(errMessage(e));
                  }
                }}
              >
                Post Comment
              </Button>
              <span className="text-xs text-subtle">Maximum 1,000 characters</span>
            </div>
          </Panel>
        </div>
        <div className="mt-4 grid gap-2">
          {comments.length ? (
            comments.map((c) => (
              <article key={c.id} className={`rounded-md border border-line bg-surface p-4 ${c.parent_id ? "ml-6" : ""}`}>
                <div className="flex justify-between text-sm">
                  <b className="text-fg">{safeText(c.username, "Reader")}</b>
                  <span className="text-subtle">{c.created_at}</span>
                </div>
                <p className="mt-2 text-sm text-muted">{c.body}</p>
                <div className="mt-2 flex gap-2">
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={async () => {
                      try {
                        const x = await likeComment({ data: c.id });
                        setComments((prev) => prev.map((p) => (p.id === c.id ? { ...p, likes: x.likes } : p)));
                      } catch (e) {
                        toast.error(errMessage(e));
                      }
                    }}
                  >
                    Like {c.likes}
                  </Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => {
                      setReplyTo(c.id);
                      setBody(`@${c.username} `);
                    }}
                  >
                    Reply
                  </Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={async () => {
                      const reason = window.prompt("Why are you reporting this comment?", "spam");
                      if (!reason) return;
                      try {
                        await reportContent({ data: { reason, commentId: c.id } });
                        toast.success("Report submitted for moderation.");
                      } catch (e) {
                        toast.error(errMessage(e));
                      }
                    }}
                  >
                    Report
                  </Button>
                </div>
              </article>
            ))
          ) : (
            <EmptyState title="No comments yet." body="Be the first reader to start the conversation." />
          )}
        </div>
      </section>
      ) : null}

      {novel.related?.length ? (
        <section className="mt-8">
          <h2 className="font-display mb-4 text-2xl text-fg">Related novels</h2>
          <StoryGrid novels={novel.related} empty={null} />
        </section>
      ) : null}
    </PageWrap>
  );
}
