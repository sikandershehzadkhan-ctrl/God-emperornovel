import { createFileRoute, Link } from "@tanstack/react-router";
import { PageWrap } from "@/components/layout/shell";
import { Button } from "@/components/ui/button";
import { EmptyState, PageHeader } from "@/components/ui/panel";
import { StoryGrid } from "@/components/novel/story-card";
import { listNovels } from "@/lib/imperial/catalog";

export const Route = createFileRoute("/trending")({
  head: () => ({ meta: [{ title: "Trending Now | Imperial Novel" }, { name: "description", content: "Discover currently trending stories in the Imperial Novel catalog." }] }),
  loader: () => listNovels({ data: { sort: "trending", limit: 24 } }),
  component: TrendingPage,
});

function TrendingPage() {
  const data = Route.useLoaderData();
  return (
    <PageWrap>
      <PageHeader
        title="Trending Now"
        sub="Ordered by lifetime published views, then rating. This is a catalog signal, not a fabricated trend score."
        actions={
          <Button variant="ghost" asChild>
            <Link to="/catalog" search={{ sort: "trending" }}>
              Catalog
            </Link>
          </Button>
        }
      />
      <StoryGrid novels={data.results} empty={<EmptyState title="No published novels yet." />} />
    </PageWrap>
  );
}
