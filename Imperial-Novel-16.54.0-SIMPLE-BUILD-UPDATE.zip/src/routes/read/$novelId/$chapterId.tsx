import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { BookMarked, BookOpenText, ChevronLeft, List, Minus, Plus, X } from "lucide-react";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { getChapter, saveProgress, unlockChapter } from "@/lib/imperial/reader";
import { setBookmark } from "@/lib/imperial/library";
import { cn, errMessage, safeText } from "@/lib/utils";

export const Route = createFileRoute("/read/$novelId/$chapterId")({
  loader: ({ params }) =>
    getChapter({
      data: { novelId: Number(params.novelId), chapterNumber: Number(params.chapterId) },
    }),
  head: ({ loaderData }) => ({
    meta: [{ title: `${safeText(loaderData?.chapter.title, "Reader")} | Imperial Novel` }, { name: "description", content: `Read ${safeText(loaderData?.chapter.title, "this chapter")} in the Imperial Novel reader.` }],
  }),
  component: ReaderPage,
});

const THEMES = [
  { id: "obsidian", label: "Imperial" },
  { id: "dark", label: "Dark" },
  { id: "midnight", label: "Midnight" },
  { id: "cosmic", label: "Cosmic" },
  { id: "sepia", label: "Sepia" },
  { id: "light", label: "Light" },
] as const;

function ReaderPage() {
  const data = Route.useLoaderData();
  const navigate = useNavigate();
  const { novel, chapter, chapters, previous, next } = data;
  const [open, setOpen] = useState(false);
  const [size, setSize] = useState(18);
  const [line, setLine] = useState(1.85);
  const [width, setWidth] = useState(760);
  const [theme, setTheme] = useState("obsidian");
  const [pct, setPct] = useState(0);
  const [saved, setSaved] = useState(false);
  const [focusMode, setFocusMode] = useState(false);

  useEffect(() => {
    setSize(Number(localStorage.getItem("imperial_font_size") || 18));
    setLine(Number(localStorage.getItem("imperial_line_height") || 1.85));
    setWidth(Number(localStorage.getItem("imperial_reader_width") || 760));
    setTheme(localStorage.getItem("imperial_reader_theme") || "obsidian");
    setFocusMode(localStorage.getItem("imperial_reader_focus") === "true");
  }, []);

  useEffect(() => {
    if (!chapter.unlocked) return;
    saveProgress({ data: { novelId: novel.id, chapterNumber: chapter.chapter_number } }).catch(() => {});
  }, [chapter.unlocked, chapter.chapter_number, novel.id]);

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      const target = event.target;
      if (target instanceof HTMLElement && (target.isContentEditable || ["INPUT", "TEXTAREA", "SELECT"].includes(target.tagName))) return;
      if (event.altKey || event.ctrlKey || event.metaKey || event.shiftKey) return;
      if (event.key === "ArrowLeft" && previous) {
        event.preventDefault();
        void navigate({ to: "/read/$novelId/$chapterId", params: { novelId: String(novel.id), chapterId: String(previous.chapter_number) } });
      }
      if (event.key === "ArrowRight" && next) {
        event.preventDefault();
        void navigate({ to: "/read/$novelId/$chapterId", params: { novelId: String(novel.id), chapterId: String(next.chapter_number) } });
      }
      if (event.key.toLowerCase() === "f") {
        setFocusMode((current) => {
          const updated = !current;
          localStorage.setItem("imperial_reader_focus", String(updated));
          return updated;
        });
      }
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [navigate, novel.id, previous, next]);

  useEffect(() => {
    const onScroll = () => {
      const max = Math.max(1, document.documentElement.scrollHeight - window.innerHeight);
      setPct(Math.min(100, Math.round((window.scrollY / max) * 100)));
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    onScroll();
    return () => window.removeEventListener("scroll", onScroll);
  }, [chapter.id]);

  const total = chapters.length;
  const novelPct = Math.min(100, Math.round((chapter.chapter_number / Math.max(total, 1)) * 100));

  return (
    <div className={`reader-shell min-h-dvh bg-bg ${focusMode ? "reader-focus-mode" : ""}`} data-theme={theme}>
      <div className="reader-bar sticky top-0 z-40 border-b border-line bg-bg/92 backdrop-blur-xl">
        <div className="mx-auto flex h-14 w-full max-w-[1050px] items-center gap-2 px-3">
          <Link
            to="/novel/$id/chapters"
            params={{ id: String(novel.id) }}
            className="inline-flex min-h-11 items-center gap-1 text-sm font-semibold text-cyan"
          >
            <ChevronLeft className="size-4" />
            Chapters
          </Link>
          <div className="min-w-0 flex-1 text-center">
            <b className="reader-title block truncate text-sm text-fg">{safeText(novel.title)}</b>
            <span className="text-[11px] text-muted">
              Chapter {chapter.chapter_number} of {total}
            </span>
          </div>
          <div className="flex gap-1">
            <button
              type="button"
              className="grid size-11 place-items-center rounded-md border border-line text-muted"
              aria-label="Smaller text"
              onClick={() => {
                const n = Math.max(14, size - 1);
                setSize(n);
                localStorage.setItem("imperial_font_size", String(n));
              }}
            >
              <Minus className="size-4" />
            </button>
            <button
              type="button"
              className="grid size-11 place-items-center rounded-md border border-line text-muted"
              aria-label="Larger text"
              onClick={() => {
                const n = Math.min(26, size + 1);
                setSize(n);
                localStorage.setItem("imperial_font_size", String(n));
              }}
            >
              <Plus className="size-4" />
            </button>
            <button
              type="button"
              className={`grid size-11 place-items-center rounded-md border border-line ${saved ? "text-gold" : "text-muted"}`}
              aria-label="Bookmark chapter"
              onClick={async () => {
                try {
                  await setBookmark({ data: { novelId: novel.id, chapterNumber: chapter.chapter_number } });
                  setSaved(true);
                  toast.success("Chapter bookmarked");
                } catch {
                  localStorage.setItem("readerBookmark:" + novel.id, String(chapter.chapter_number));
                  setSaved(true);
                }
              }}
            >
              <BookMarked className="size-4" />
            </button>
            <button
              type="button"
              className="grid size-11 place-items-center rounded-md border border-line text-muted"
              aria-label="Chapter list"
              aria-expanded={open}
              onClick={() => setOpen((v) => !v)}
            >
              <List className="size-4" />
            </button>
          </div>
        </div>
        <div className="mx-auto flex w-full max-w-[1050px] flex-wrap items-center gap-2 px-3 pb-2">
          {THEMES.map((t) => (
            <button
              key={t.id}
              type="button"
              className={cn("filter-chip !min-h-9 px-3", theme === t.id && "is-active")}
              onClick={() => {
                setTheme(t.id);
                localStorage.setItem("imperial_reader_theme", t.id);
              }}
            >
              {t.label}
            </button>
          ))}
          <div className="inline-flex items-center gap-1 rounded-md border border-line px-1" aria-label="Line spacing controls">
            <button type="button" className="min-h-9 min-w-9 rounded text-sm text-muted hover:text-fg" aria-label="Decrease line spacing" onClick={() => { const n = Math.max(1.4, Math.round((line - 0.1) * 10) / 10); setLine(n); localStorage.setItem("imperial_line_height", String(n)); }}>−</button>
            <span className="px-1 text-[11px] text-muted">Spacing</span>
            <button type="button" className="min-h-9 min-w-9 rounded text-sm text-muted hover:text-fg" aria-label="Increase line spacing" onClick={() => { const n = Math.min(2.4, Math.round((line + 0.1) * 10) / 10); setLine(n); localStorage.setItem("imperial_line_height", String(n)); }}>+</button>
          </div>
          <button
            type="button"
            className={cn("reader-focus-toggle filter-chip !min-h-9 px-3", focusMode && "is-active")}
            aria-pressed={focusMode}
            onClick={() => { const updated = !focusMode; setFocusMode(updated); localStorage.setItem("imperial_reader_focus", String(updated)); }}
          >
            <BookOpenText className="mr-1 inline size-4" /> {focusMode ? "Exit focus" : "Focus mode"}
          </button>
          {[640, 760, 920].map((w) => (
            <button
              key={w}
              type="button"
              className={cn("filter-chip !min-h-9 px-3", width === w && "is-active")}
              onClick={() => {
                setWidth(w);
                localStorage.setItem("imperial_reader_width", String(w));
              }}
            >
              {w === 640 ? "Narrow" : w === 760 ? "Comfort" : "Wide"}
            </button>
          ))}
        </div>
        <div className="reader-progress h-1 bg-surface-3">
          <span style={{ width: `${pct || novelPct}%` }} />
        </div>
      </div>

      {open ? (
        <aside className="fixed inset-y-0 right-0 z-50 w-[min(420px,92vw)] overflow-auto border-l border-line bg-surface p-4 shadow-lux">
          <div className="mb-3 flex items-center justify-between">
            <b className="text-fg">Chapter List</b>
            <button type="button" className="grid size-11 place-items-center text-muted" onClick={() => setOpen(false)}>
              <X className="size-4" />
            </button>
          </div>
          <div className="grid gap-1.5">
            {chapters.map((c) => (
              <Link
                key={c.id}
                to="/read/$novelId/$chapterId"
                params={{ novelId: String(novel.id), chapterId: String(c.chapter_number) }}
                className={`rounded-md border px-3 py-3 text-sm ${
                  c.chapter_number === chapter.chapter_number
                    ? "border-cyan/50 bg-cyan/10 text-fg"
                    : "border-line text-muted"
                }`}
                onClick={() => setOpen(false)}
              >
                Chapter {c.chapter_number} · {safeText(c.title)}
                {c.is_locked ? " · Locked" : ""}
              </Link>
            ))}
          </div>
        </aside>
      ) : null}

      <main className="mx-auto px-4 py-8" style={{ maxWidth: Math.max(320, width) }}>
        <div className="mb-3 flex justify-between text-[11px] text-muted">
          <span>{safeText(novel.author, "Imperial Novel")}</span>
          <span>
            {pct || novelPct}% through chapter · {novelPct}% through novel
          </span>
        </div>
        <article className="reader-article rounded-lg px-5 py-8 sm:px-12 sm:py-12">
          <h1 className="reader-title font-display text-center text-3xl text-fg">{safeText(chapter.title)}</h1>
          <div className="mx-auto my-5 h-0.5 w-16 rounded-full bg-violet" />
          {chapter.unlocked ? (
            <div
              className="reader-content mx-auto max-w-[70ch] text-fg"
              style={{ fontSize: size, lineHeight: line }}
            >
              {chapter.content}
            </div>
          ) : (
            <div className="mx-auto max-w-md py-10 text-center">
              <p className="text-[11px] font-semibold tracking-[0.2em] text-gold-2 uppercase">Authorized chapter</p>
              <h2 className="font-display mt-2 text-2xl text-fg">Chapter locked</h2>
              <p className="mt-2 text-sm text-muted">
                This chapter is available through Imperial Novel's authorized unlock system.
              </p>
              <p className="mt-4 text-2xl font-semibold text-gold-2">{chapter.ticket_cost}</p>
              <p className="text-xs text-subtle">tickets</p>
              <div className="mt-4 flex justify-center gap-2">
                <Button
                  onClick={async () => {
                    try {
                      await unlockChapter({ data: chapter.id });
                      toast.success("Chapter unlocked");
                      await navigate({
                        to: "/read/$novelId/$chapterId",
                        params: { novelId: String(novel.id), chapterId: String(chapter.chapter_number) },
                        reloadDocument: true,
                      });
                    } catch (e) {
                      toast.error(errMessage(e));
                    }
                  }}
                >
                  Unlock Chapter
                </Button>
                <Button variant="secondary" asChild>
                  <Link to="/tickets">Get Tickets</Link>
                </Button>
              </div>
            </div>
          )}
          <div className="mt-8 flex items-center justify-between gap-2">
            {previous ? (
              <Button variant="secondary" asChild>
                <Link
                  to="/read/$novelId/$chapterId"
                  params={{ novelId: String(novel.id), chapterId: String(previous.chapter_number) }}
                >
                  Previous
                </Link>
              </Button>
            ) : (
              <span />
            )}
            {next ? (
              <Button asChild>
                <Link
                  to="/read/$novelId/$chapterId"
                  params={{ novelId: String(novel.id), chapterId: String(next.chapter_number) }}
                >
                  Next
                </Link>
              </Button>
            ) : (
              <Button variant="secondary" asChild>
                <Link to="/novel/$id" params={{ id: String(novel.id) }}>
                  Novel Overview
                </Link>
              </Button>
            )}
          </div>
        </article>
      </main>
    </div>
  );
}
