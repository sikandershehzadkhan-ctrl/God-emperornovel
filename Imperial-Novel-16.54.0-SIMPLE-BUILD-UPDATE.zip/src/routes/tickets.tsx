import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { PageWrap, RequireAuth } from "@/components/layout/shell";
import { Button } from "@/components/ui/button";
import { Field, Input } from "@/components/ui/input";
import { Badge, EmptyState, PageHeader, Panel } from "@/components/ui/panel";
import { getTickets, submitDonation } from "@/lib/imperial/tickets";
import { PATRON_TIERS } from "@/lib/imperial/types";
import { errMessage, formatNumber } from "@/lib/utils";

export const Route = createFileRoute("/tickets")({
  head: () => ({ meta: [{ title: "Tickets | Imperial Novel" }, { name: "description", content: "Review your Imperial Novel ticket balance and ticket-related activity." }] }),
  component: () => (
    <RequireAuth>
      <TicketsPage />
    </RequireAuth>
  ),
});

function TicketsPage() {
  const [data, setData] = useState<Awaited<ReturnType<typeof getTickets>> | null>(null);
  const [amount, setAmount] = useState("500");
  const [reference, setReference] = useState("");
  const [tier, setTier] = useState("bronze");

  async function load() {
    setData(await getTickets());
  }

  useEffect(() => {
    load().catch(() => setData(null));
  }, []);

  if (!data) {
    return (
      <PageWrap>
        <div className="h-10 w-40 animate-pulse rounded-md bg-surface-3" />
      </PageWrap>
    );
  }

  return (
    <PageWrap>
      <PageHeader
        eyebrow="Patronage"
        title="Tickets & Support"
        sub="Suggested patronage amounts prefill EasyPaisa. Tickets are credited only after an administrator verifies the transfer."
      />
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {PATRON_TIERS.map((t) => (
          <button
            key={t.id}
            type="button"
            className={`patron-card text-left ${tier === t.id ? "is-selected" : ""}`}
            data-tier={t.id}
            onClick={() => {
              setTier(t.id);
              setAmount(String(t.pkr));
            }}
          >
            <p className="text-[11px] font-semibold tracking-[0.16em] text-cyan uppercase">{t.name}</p>
            <p className="font-display mt-1 text-2xl text-fg">PKR {formatNumber(t.pkr)}</p>
            <p className="mt-2 text-xs text-muted">{t.perks}</p>
            {tier === t.id ? <p className="mt-3 text-xs text-good">Selected for the form below</p> : null}
          </button>
        ))}
      </div>
      <p className="mt-3 text-xs text-subtle">Selecting a tier does not charge you. Submit a real EasyPaisa reference to request verification.</p>

      <div className="mt-6 grid gap-4 md:grid-cols-2">
        <Panel>
          <p className="text-xs text-muted">Current balance</p>
          <p className="font-display text-4xl text-gold-2">{formatNumber(data.tickets)}</p>
          <p className="mt-2 text-sm text-muted">Batch unlock sizes: 10, 25, 50 and 100 chapters.</p>
        </Panel>
        <Panel>
          <h2 className="font-display text-xl text-fg">EasyPaisa donation</h2>
          <p className="mt-1 text-sm text-muted">
            Send PKR to <b className="text-fg">{data.easypaisa}</b>, then submit the transaction reference. Status stays pending until verified.
          </p>
          <form
            className="mt-3 grid gap-3"
            onSubmit={async (e) => {
              e.preventDefault();
              try {
                const d = await submitDonation({ data: { amount: Number(amount), reference_id: reference } });
                toast.success(d.message);
                setReference("");
                await load();
              } catch (err) {
                toast.error(errMessage(err));
              }
            }}
          >
            <Field label="Amount (PKR)">
              <Input type="number" min={1} value={amount} onChange={(e) => setAmount(e.target.value)} />
            </Field>
            <Field label="Transaction / reference number">
              <Input value={reference} onChange={(e) => setReference(e.target.value)} required minLength={4} />
            </Field>
            <Button type="submit">Submit for verification</Button>
          </form>
        </Panel>
      </div>

      <h2 className="font-display mt-8 text-2xl text-fg">Ledger</h2>
      <div className="mt-3 grid gap-2">
        {data.ledger.length ? (
          data.ledger.map((x) => (
            <div key={x.id} className="flex items-center justify-between rounded-md border border-line bg-surface px-4 py-3">
              <div>
                <b className="text-fg">{x.reason}</b>
                <p className="text-xs text-muted">
                  {x.created_at} {x.reference ? `· ${x.reference}` : ""}
                </p>
              </div>
              <span className={x.delta > 0 ? "text-good" : "text-danger"}>
                {x.delta > 0 ? "+" : ""}
                {x.delta}
              </span>
            </div>
          ))
        ) : (
          <EmptyState title="No ticket transactions yet." body="Approved donations appear here after verification." />
        )}
      </div>

      <h2 className="font-display mt-8 text-2xl text-fg">Donations</h2>
      <div className="mt-3 grid gap-2">
        {data.donations.length ? (
          data.donations.map((d) => (
            <Panel key={d.id} className="flex items-center justify-between">
              <div>
                <b className="text-fg">PKR {formatNumber(d.amount)}</b>
                <p className="text-xs text-muted">{d.reference_id}</p>
              </div>
              <Badge tone={d.status === "approved" ? "good" : d.status === "rejected" ? "danger" : "gold"}>
                {d.status}
              </Badge>
            </Panel>
          ))
        ) : (
          <EmptyState title="No donation records." body="Submitted references stay pending until an administrator reviews them." />
        )}
      </div>
    </PageWrap>
  );
}
