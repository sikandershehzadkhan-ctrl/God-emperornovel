import { createFileRoute, Link } from "@tanstack/react-router";
import { PageWrap } from "@/components/layout/shell";
import { PageHeader, Panel } from "@/components/ui/panel";
import { CoverImage } from "@/components/novel/story-card";
import { getTierList } from "@/lib/imperial/community";
import { formatRating, safeText } from "@/lib/utils";

export const Route = createFileRoute("/tier-list")({
  head: () => ({ meta: [{ title: "Tier List | Imperial Novel" }, { name: "description", content: "Explore community story tiers and rankings on Imperial Novel." }] }),
  loader: () => getTierList(),
  component: TierPage,
});

function TierPage() {
  const { tiers } = Route.useLoaderData();
  const names: Record<string, string> = { S: "S Tier", A: "A Tier", B: "B Tier", C: "C Tier" };
  return (
    <PageWrap>
      <PageHeader
        title="Tier List"
        sub="A discovery view based on published ratings and activity. It is not an official quality judgment."
      />
      <div className="grid gap-4">
        {Object.entries(tiers).map(([k, items]) => (
          <Panel key={k}>
            <h2 className="font-display text-2xl text-fg">{names[k] || k}</h2>
            <div className="mt-3 grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
              {items.length ? (
                items.map((n) => (
                  <Link
                    key={n.id}
                    to="/novel/$id"
                    params={{ id: String(n.id) }}
                    className="grid grid-cols-[58px_1fr] items-center gap-3 rounded-md border border-line bg-bg2 p-2"
                  >
                    <div className="h-[76px] overflow-hidden rounded-sm">
                      <CoverImage src={n.cover_url} alt="" />
                    </div>
                    <span>
                      <b className="block text-sm text-fg">{safeText(n.title)}</b>
                      <span className="text-[11px] text-muted">
                        {safeText(n.author)} · ★ {formatRating(n.rating)}
                      </span>
                    </span>
                  </Link>
                ))
              ) : (
                <p className="text-sm text-muted">No novels here yet.</p>
              )}
            </div>
          </Panel>
        ))}
      </div>
    </PageWrap>
  );
}
