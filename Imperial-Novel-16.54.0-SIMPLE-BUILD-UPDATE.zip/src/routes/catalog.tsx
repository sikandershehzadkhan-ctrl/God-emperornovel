import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { PageWrap } from "@/components/layout/shell";
import { Button } from "@/components/ui/button";
import { EmptyState, PageHeader } from "@/components/ui/panel";
import { Input } from "@/components/ui/input";
import { StoryGrid } from "@/components/novel/story-card";
import { listGenres, listNovels } from "@/lib/imperial/catalog";
import { CATEGORIES } from "@/lib/imperial/types";
import type { NovelCard } from "@/lib/imperial/types";
import { cn } from "@/lib/utils";

export type CatalogSearch = {
  q?: string;
  sort?: string;
  status?: string;
  genre?: string;
  tag?: string;
  kind?: string;
  language?: string;
  category?: string;
  author?: string;
  min_rating?: string;
  page?: number;
};

function parseSearch(s: Record<string, unknown>): CatalogSearch {
  return {
    q: typeof s.q === "string" ? s.q : undefined,
    sort: typeof s.sort === "string" ? s.sort : undefined,
    status: typeof s.status === "string" ? s.status : undefined,
    genre: typeof s.genre === "string" ? s.genre : undefined,
    tag: typeof s.tag === "string" ? s.tag : undefined,
    kind: typeof s.kind === "string" ? s.kind : undefined,
    language: typeof s.language === "string" ? s.language : undefined,
    category: typeof s.category === "string" ? s.category : undefined,
    author: typeof s.author === "string" ? s.author : undefined,
    min_rating: typeof s.min_rating === "string" ? s.min_rating : undefined,
    page: s.page ? Math.max(1, Number(s.page) || 1) : undefined,
  };
}

export const Route = createFileRoute("/catalog")({
  validateSearch: parseSearch,
  loaderDeps: ({ search }) => search,
  loader: async ({ deps: search }) => {
    const [novels, genres] = await Promise.all([
      listNovels({
        data: {
          q: search.q,
          sort: search.sort || "updated",
          status: search.status,
          genre: search.genre,
          tag: search.tag,
          kind: search.kind,
          language: search.language,
          category: search.category,
          author: search.author,
          min_rating: search.min_rating ? Number(search.min_rating) : 0,
          page: search.page || 1,
          limit: 24,
        },
      }),
      listGenres(),
    ]);
    return { ...novels, genres };
  },
  head: () => ({ meta: [{ title: "Catalog | Imperial Novel" }, { name: "description", content: "Browse the Imperial Novel catalog of original and authorized stories." }] }),
  component: CatalogPage,
});

function Chip({
  active,
  search,
  children,
}: {
  active: boolean;
  search: CatalogSearch;
  children: React.ReactNode;
}) {
  return (
    <Link to="/catalog" search={search} className={cn("filter-chip", active && "is-active")}>
      {children}
    </Link>
  );
}

function CatalogPage() {
  const search = Route.useSearch();
  const initial = Route.useLoaderData();
  const navigate = useNavigate({ from: "/catalog" });
  const [rows, setRows] = useState<NovelCard[]>(initial.results);
  const [limit, setLimit] = useState(initial.limit);
  const [term, setTerm] = useState(search.q || "");
  const [authorTerm, setAuthorTerm] = useState(search.author || "");
  const [languageTerm, setLanguageTerm] = useState(search.language || "");
  const page = search.page || 1;
  const sort = search.sort || "updated";

  useEffect(() => {
    setRows(initial.results);
    setLimit(initial.limit);
    setTerm(search.q || "");
    setAuthorTerm(search.author || "");
    setLanguageTerm(search.language || "");
  }, [initial, search.q, search.author, search.language]);

  const count = rows.length;
  const label = count
    ? `Showing ${count} ${count === 1 ? "story" : "stories"} · Page ${page}`
    : "No stories found";

  const base: CatalogSearch = { ...search, page: undefined };
  const liveGenres = initial.genres.filter((g) => g.n > 0);

  return (
    <PageWrap>
      <PageHeader
        eyebrow="Discover"
        title="Discover"
        sub="Search original, licensed and authorized stories. Filter by genre, status, type and catalog activity."
      />
      <section aria-labelledby="quick-paths-title" className="mb-5 rounded-xl border border-cyan/15 bg-surface/70 p-4 sm:p-5">
        <div className="flex flex-col gap-1 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="text-[11px] font-semibold tracking-[0.16em] text-cyan uppercase">Choose your next read</p>
            <h2 id="quick-paths-title" className="font-display mt-1 text-xl text-fg">Quick discovery paths</h2>
          </div>
          <Link to="/random" className="min-h-11 inline-flex items-center text-sm font-semibold text-cyan underline-offset-4 hover:underline">
            Surprise me <span aria-hidden="true" className="ml-1">↗</span>
          </Link>
        </div>
        <p className="mt-1 text-sm text-muted">Jump straight into fresh updates, complete journeys, long reads or highly rated stories.</p>
        <div className="mt-3 flex flex-wrap gap-2">
          <Chip active={sort === "updated" && !search.status && !search.kind} search={{ ...base, sort: "updated", status: undefined, kind: undefined, page: undefined }}>
            Freshly Updated
          </Chip>
          <Chip active={search.status === "completed"} search={{ ...base, status: "completed", page: undefined }}>
            Completed Stories
          </Chip>
          <Chip active={sort === "chapters"} search={{ ...base, sort: "chapters", page: undefined }}>
            Long Reads
          </Chip>
          <Chip active={sort === "rating" && search.min_rating === "4"} search={{ ...base, sort: "rating", min_rating: "4", page: undefined }}>
            Highly Rated
          </Chip>
          <Chip active={search.kind === "original"} search={{ ...base, kind: "original", page: undefined }}>
            Original Worlds
          </Chip>
          <Chip active={sort === "trending"} search={{ ...base, sort: "trending", page: undefined }}>
            Trending Now
          </Chip>
        </div>
      </section>
      <div className="discover-shell">
        <aside className="discover-side glass-panel rounded-xl p-4">
          <p className="text-[11px] font-semibold tracking-[0.16em] text-cyan uppercase">Browse</p>
          <Link to="/" className="mt-2 block rounded-md px-3 py-2 text-sm text-muted hover:bg-violet/20 hover:text-fg">
            Home
          </Link>
          <Link to="/catalog" search={{ sort: "trending" }} className="block rounded-md px-3 py-2 text-sm text-muted hover:bg-violet/20 hover:text-fg">
            Trending
          </Link>
          <Link to="/for-you" className="block rounded-md px-3 py-2 text-sm text-muted hover:bg-violet/20 hover:text-fg">
            For You
          </Link>
          <Link to="/leaderboard" className="block rounded-md px-3 py-2 text-sm text-muted hover:bg-violet/20 hover:text-fg">
            Rankings
          </Link>
          <Link to="/library" className="block rounded-md px-3 py-2 text-sm text-muted hover:bg-violet/20 hover:text-fg">
            Library
          </Link>
          <p className="mt-4 text-[11px] font-semibold tracking-[0.16em] text-cyan uppercase">Genres</p>
          {liveGenres.slice(0, 12).map((g) => (
            <Link
              key={g.slug}
              to="/catalog"
              search={{ ...base, genre: g.slug, page: undefined }}
              className={cn(
                "flex items-center justify-between rounded-md px-3 py-2 text-sm",
                search.genre === g.slug ? "bg-violet/25 text-fg" : "text-muted hover:bg-violet/20 hover:text-fg",
              )}
            >
              <span>{g.name}</span>
              <span className="text-[11px] text-subtle">{g.n}</span>
            </Link>
          ))}
        </aside>

        <div>
          <section className="glass-panel rounded-xl p-4">
            <form
              className="flex flex-col gap-2 sm:flex-row"
              onSubmit={(e) => {
                e.preventDefault();
                void navigate({ search: { ...base, q: term.trim() || undefined, author: authorTerm.trim() || undefined, language: languageTerm.trim() || undefined, page: undefined } });
              }}
            >
              <Input
                value={term}
                onChange={(e) => setTerm(e.target.value)}
                placeholder="Search titles and alternate titles..."
                aria-label="Search titles and alternate titles"
              />
              <Input
                value={authorTerm}
                onChange={(e) => setAuthorTerm(e.target.value)}
                placeholder="Author name"
                aria-label="Filter by author"
              />
              <Input
                value={languageTerm}
                onChange={(e) => setLanguageTerm(e.target.value)}
                placeholder="Language (e.g. English)"
                aria-label="Filter by language"
              />
              <Button type="submit">Apply filters</Button>
            </form>

            <div className="mt-4">
              <p className="mb-2 text-[11px] font-semibold tracking-[0.14em] text-muted uppercase">Sort</p>
              <div className="flex flex-wrap gap-2">
                {[
                  ["updated", "Recently Updated"],
                  ["newest", "Newest"],
                  ["trending", "Trending"],
                  ["views", "Most Viewed"],
                  ["rating", "Top Rated"],
                  ["chapters", "Most Chapters"],
                ].map(([value, chipLabel]) => (
                  <Chip key={value} active={sort === value} search={{ ...base, sort: value, page: undefined }}>
                    {chipLabel}
                  </Chip>
                ))}
              </div>
            </div>

            <div className="mt-4">
              <p className="mb-2 text-[11px] font-semibold tracking-[0.14em] text-muted uppercase">Minimum rating</p>
              <div className="flex flex-wrap gap-2">
                <Chip active={!search.min_rating} search={{ ...base, min_rating: undefined, page: undefined }}>Any rating</Chip>
                <Chip active={search.min_rating === "3"} search={{ ...base, min_rating: "3", page: undefined }}>3★ and up</Chip>
                <Chip active={search.min_rating === "4"} search={{ ...base, min_rating: "4", page: undefined }}>4★ and up</Chip>
                <Chip active={search.min_rating === "4.5"} search={{ ...base, min_rating: "4.5", page: undefined }}>4.5★ and up</Chip>
              </div>
            </div>

            <div className="mt-4">
              <p className="mb-2 text-[11px] font-semibold tracking-[0.14em] text-muted uppercase">Status</p>
              <div className="flex flex-wrap gap-2">
                <Chip active={!search.status} search={{ ...base, status: undefined, page: undefined }}>
                  Any
                </Chip>
                <Chip active={search.status === "ongoing"} search={{ ...base, status: "ongoing", page: undefined }}>
                  Ongoing
                </Chip>
                <Chip active={search.status === "completed"} search={{ ...base, status: "completed", page: undefined }}>
                  Completed
                </Chip>
              </div>
            </div>

            <div className="mt-4">
              <p className="mb-2 text-[11px] font-semibold tracking-[0.14em] text-muted uppercase">Type</p>
              <div className="flex flex-wrap gap-2">
                <Chip active={!search.kind} search={{ ...base, kind: undefined, page: undefined }}>
                  All types
                </Chip>
                <Chip active={search.kind === "original"} search={{ ...base, kind: "original", page: undefined }}>
                  Original
                </Chip>
                <Chip active={search.kind === "fanfiction"} search={{ ...base, kind: "fanfiction", page: undefined }}>
                  Fanfiction
                </Chip>
              </div>
            </div>

            <div className="mt-4 lg:hidden">
              <p className="mb-2 text-[11px] font-semibold tracking-[0.14em] text-muted uppercase">Genre</p>
              <div className="flex flex-wrap gap-2">
                <Chip active={!search.genre} search={{ ...base, genre: undefined, page: undefined }}>
                  All genres
                </Chip>
                {liveGenres.slice(0, 16).map((g) => (
                  <Chip
                    key={g.slug}
                    active={search.genre === g.slug}
                    search={{ ...base, genre: g.slug, page: undefined }}
                  >
                    {g.name}
                  </Chip>
                ))}
              </div>
            </div>

            <div className="mt-4">
              <p className="mb-2 text-[11px] font-semibold tracking-[0.14em] text-muted uppercase">Category</p>
              <div className="flex flex-wrap gap-2">
                <Chip active={!search.category} search={{ ...base, category: undefined, page: undefined }}>
                  All worlds
                </Chip>
                {CATEGORIES.map((c) => (
                  <Chip
                    key={c.slug}
                    active={search.category === c.slug}
                    search={{ ...base, category: c.slug, page: undefined }}
                  >
                    {c.name}
                  </Chip>
                ))}
              </div>
            </div>

            <div className="mt-4 flex flex-wrap gap-2">
              <Button variant="ghost" type="button" onClick={() => navigate({ search: {} })}>
                Clear
              </Button>
              <Button variant="ghost" asChild>
                <Link to="/genres">Browse Genres</Link>
              </Button>
              <Button variant="ghost" asChild>
                <Link to="/tags">Browse Tags</Link>
              </Button>
              <Button variant="ghost" asChild>
                <Link to="/search">Advanced Search</Link>
              </Button>
            </div>
          </section>

          <p className="mt-5 mb-3 text-sm font-semibold text-fg">{label}</p>
          {rows.length ? (
            <StoryGrid novels={rows} variant="catalog" empty={null} />
          ) : (
            <EmptyState
              kind="search"
              title="No novels matched this selection."
              body="Try another title, genre, tag, status, type or rating. Only original, licensed and authorized works appear here."
            >
              <Button asChild>
                <Link to="/catalog">Reset Catalog</Link>
              </Button>
              <Button variant="secondary" asChild>
                <Link to="/genres">Browse Genres</Link>
              </Button>
            </EmptyState>
          )}

          <div className="mt-6 flex justify-center gap-2">
            {page > 1 ? (
              <Button variant="secondary" onClick={() => navigate({ search: { ...search, page: page - 1 } })}>
                Previous
              </Button>
            ) : null}
            {rows.length === limit ? (
              <Button onClick={() => navigate({ search: { ...search, page: page + 1 } })}>Next</Button>
            ) : null}
          </div>
        </div>
      </div>
    </PageWrap>
  );
}
