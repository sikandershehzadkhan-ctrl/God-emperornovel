import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { PageWrap } from "@/components/layout/shell";
import { PageHeader, Panel } from "@/components/ui/panel";
import { getLeaderboard } from "@/lib/imperial/community";
import { formatNumber, formatRating, safeText } from "@/lib/utils";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/leaderboard")({
  head: () => ({ meta: [{ title: "Leaderboard | Imperial Novel" }, { name: "description", content: "Explore community rankings and popular stories on Imperial Novel." }] }),
  component: LeaderboardPage,
});

function LeaderboardPage() {
  const [period, setPeriod] = useState("weekly");
  const [data, setData] = useState<Awaited<ReturnType<typeof getLeaderboard>> | null>(null);
  useEffect(() => {
    getLeaderboard({ data: period }).then(setData).catch(() => setData(null));
  }, [period]);
  return (
    <PageWrap>
      <PageHeader
        title="Rankings"
        sub="All-time uses lifetime views. Weekly and monthly count only novel opens recorded since this log began."
      />
      <div className="mb-4 flex gap-2 border-b border-line" role="tablist" aria-label="Ranking period">
        {["weekly", "monthly", "all"].map((p) => (
          <button
            key={p}
            type="button"
            role="tab"
            aria-selected={period === p}
            className={cn(
              "min-h-11 px-3 text-sm capitalize",
              period === p ? "border-b-2 border-gold-2 text-gold-2" : "text-muted",
            )}
            onClick={() => setPeriod(p)}
          >
            {p === "all" ? "All Time" : p}
          </button>
        ))}
      </div>
      {data?.note ? <p className="mb-4 text-sm text-muted">{data.note}</p> : null}
      <h2 className="font-display text-2xl text-fg">Top Novels</h2>
      <div className="mt-3 grid gap-3 md:grid-cols-2">
        {(data?.novels || []).length ? (
          data!.novels.map((n, i) => (
          <Panel key={n.id}>
            <span className="inline-flex min-w-10 items-center justify-center rounded-md border border-line bg-bg2 px-2 py-1 text-sm font-semibold text-gold-2">
              #{i + 1}
            </span>
            <h3 className="mt-2 font-display text-xl text-fg">{safeText(n.title)}</h3>
            <p className="text-sm text-muted">{safeText(n.author)}</p>
            <p className="mt-1 text-xs text-subtle">
              ★ {formatRating(n.rating)} ·{" "}
              {formatNumber("window_views" in n && period !== "all" ? Number(n.window_views) : n.views)}{" "}
              {period === "all" ? "lifetime views" : "recorded opens"} · {n.chapter_count} ch.
            </p>
            <Link to="/novel/$id" params={{ id: String(n.id) }} className="mt-2 inline-block text-sm text-gold-2">
              Open Novel
            </Link>
          </Panel>
          ))
        ) : (
          <p className="text-sm text-muted">No recorded activity in this window yet.</p>
        )}
      </div>
      <h2 className="font-display mt-8 text-2xl text-fg">Top Authors</h2>
      <div className="mt-3 grid gap-3 md:grid-cols-2">
        {(data?.authors || []).map((x, i) => (
          <Panel key={x.author}>
            <span className="text-sm font-semibold text-gold-2">#{i + 1}</span>
            <h3 className="font-display text-xl text-fg">{safeText(x.author)}</h3>
            <p className="text-xs text-muted">
              {x.novels} novels · ★ {formatRating(x.rating)} · {formatNumber(x.views)}{" "}
              {period === "all" ? "lifetime views" : "recorded opens"}
            </p>
            <Link to="/author/$name" params={{ name: x.author }} className="text-sm text-gold-2">
              View stories
            </Link>
          </Panel>
        ))}
      </div>
    </PageWrap>
  );
}
