import { createFileRoute, Link, useRouter } from "@tanstack/react-router";
import { useState } from "react";
import { GROK_PROVIDERS, authClient, authEnabled, signIn } from "@/lib/auth/client";
import { Button } from "@/components/ui/button";
import { Field, Input } from "@/components/ui/input";
import { Panel } from "@/components/ui/panel";
import { errMessage } from "@/lib/utils";

export const Route = createFileRoute("/signup")({
  head: () => ({ meta: [{ title: "Create account | Imperial Novel" }, { name: "description", content: "Create an Imperial Novel account to build your library and participate." }] }),
  component: Signup,
});

function Signup() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    if (password !== confirm) {
      setError("Passwords do not match");
      return;
    }
    setBusy(true);
    try {
      const { error: err } = await authClient.signUp.email({
        email,
        password,
        name: username.trim() || email.split("@")[0] || "reader",
      });
      if (err) throw new Error(err.message || "Registration failed");
      await router.invalidate();
      await router.navigate({ to: "/profile" });
    } catch (err) {
      setError(errMessage(err, "Unable to create account."));
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="mx-auto w-full max-w-md px-4 py-12">
      <Panel className="p-6">
        <p className="text-[11px] font-semibold tracking-[0.2em] text-gold-2 uppercase">Imperial Account</p>
        <h1 className="font-display mt-2 text-3xl text-fg">Create account</h1>
        <p className="mt-1 text-sm text-muted">Join the Imperial reading realm.</p>
        {authEnabled ? (
          <div className="mt-5 grid gap-2">
            {GROK_PROVIDERS.map((p) => (
              <Button
                key={p.providerId}
                type="button"
                variant="secondary"
                onClick={() => signIn(p.providerId, { callbackURL: "/profile" })}
              >
                Continue with {p.label}
              </Button>
            ))}
          </div>
        ) : null}
        <div className="my-5 flex items-center gap-3 text-xs text-subtle">
          <span className="h-px flex-1 bg-line" />
          or email
          <span className="h-px flex-1 bg-line" />
        </div>
        <form className="grid gap-3" onSubmit={onSubmit}>
          <Field label="Email">
            <Input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="email" />
          </Field>
          <Field label="Username">
            <Input required minLength={3} value={username} onChange={(e) => setUsername(e.target.value)} />
          </Field>
          <Field label="Password">
            <Input
              type="password"
              required
              minLength={8}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              autoComplete="new-password"
            />
          </Field>
          <Field label="Confirm Password">
            <Input type="password" required minLength={8} value={confirm} onChange={(e) => setConfirm(e.target.value)} />
          </Field>
          {error ? <p className="text-sm text-danger">{error}</p> : null}
          <Button type="submit" disabled={busy}>
            {busy ? "Creating…" : "Register"}
          </Button>
        </form>
        <p className="mt-4 text-sm text-muted">
          Already registered?{" "}
          <Link to="/login" className="text-gold-2">
            Sign in
          </Link>
        </p>
      </Panel>
    </div>
  );
}
