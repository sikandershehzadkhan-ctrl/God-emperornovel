import { createFileRoute, Link } from "@tanstack/react-router";
import { Dices, ListOrdered, Medal, Vote } from "lucide-react";
import { PageWrap } from "@/components/layout/shell";
import { Button } from "@/components/ui/button";
import { EmptyState, PageHeader } from "@/components/ui/panel";
import { StoryGrid } from "@/components/novel/story-card";
import { listNovels } from "@/lib/imperial/catalog";
import { listOpenRequests } from "@/lib/imperial/community";

export const Route = createFileRoute("/community")({
  head: () => ({ meta: [{ title: "Community | Imperial Novel" }, { name: "description", content: "Discover community activity, novel discussions and reader requests on Imperial Novel." }] }),
  loader: async () => {
    const [novels, requests] = await Promise.all([
      listNovels({ data: { sort: "trending", limit: 12 } }),
      listOpenRequests().catch(() => []),
    ]);
    return { novels, requests };
  },
  component: CommunityPage,
});

function CommunityPage() {
  const data = Route.useLoaderData();
  const cards = [
    { to: "/leaderboard", icon: Medal, title: "Leaderboard", sub: "Weekly, monthly and all-time activity." },
    { to: "/tier-list", icon: ListOrdered, title: "Tier List", sub: "Browse S, A, B and C story tiers." },
    { to: "/vote", icon: Vote, title: "Vote Novels", sub: "Support requests the community wants to see." },
    { to: "/random", icon: Dices, title: "Random Novel", sub: "Let the Imperial library choose." },
  ];
  return (
    <PageWrap>
      <PageHeader
        eyebrow="The Court"
        title="Community"
        sub="Discuss stories, discover readers, and help shape the Imperial catalog."
      />
      <div className="grid grid-cols-2 gap-2 lg:grid-cols-4">
        {cards.map((c) => {
          const Icon = c.icon;
          return (
            <Link
              key={c.to}
              to={c.to}
              className="rounded-xl border border-line bg-surface/80 p-4 transition-colors hover:border-cyan/40"
            >
              <Icon className="size-5 text-cyan" />
              <h3 className="mt-2 font-medium text-fg">{c.title}</h3>
              <p className="text-xs text-muted">{c.sub}</p>
            </Link>
          );
        })}
      </div>

      <section className="mt-8">
        <div className="mb-4 flex items-end justify-between">
          <div>
            <h2 className="font-display text-2xl text-fg">Open Requests</h2>
            <p className="text-sm text-muted">Community votes on titles they want authorized into the catalog.</p>
          </div>
          <Button variant="ghost" asChild>
            <Link to="/vote">Vote →</Link>
          </Button>
        </div>
        {data.requests.length ? (
          <div className="grid gap-2">
            {data.requests.slice(0, 6).map((r) => (
              <div key={r.id} className="flex items-center justify-between rounded-lg border border-line bg-surface/80 px-4 py-3">
                <div className="min-w-0">
                  <p className="truncate text-sm font-medium text-fg">{r.source_host || r.url}</p>
                  <p className="truncate text-xs text-muted">{r.url}</p>
                </div>
                <span className="ml-3 text-sm text-cyan">{r.votes} votes</span>
              </div>
            ))}
          </div>
        ) : (
          <EmptyState
            title="No open requests yet."
            body="Readers can submit and vote on catalog requests from the vote desk."
          >
            <Button asChild>
              <Link to="/requests">Open requests</Link>
            </Button>
          </EmptyState>
        )}
      </section>

      <section className="mt-8">
        <div className="mb-4 flex items-end justify-between">
          <div>
            <h2 className="font-display text-2xl text-fg">Trending Stories</h2>
            <p className="text-sm text-muted">Popular stories and fresh activity.</p>
          </div>
          <Button variant="ghost" asChild>
            <Link to="/catalog" search={{ sort: "trending" }}>
              View all
            </Link>
          </Button>
        </div>
        <StoryGrid novels={data.novels.results} empty={<p className="text-sm text-muted">No published novels yet.</p>} />
      </section>
    </PageWrap>
  );
}