import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { PageWrap, RequireAuth } from "@/components/layout/shell";
import { EmptyState, PageHeader, Panel } from "@/components/ui/panel";
import { getLibrary } from "@/lib/imperial/library";
import { safeText } from "@/lib/utils";

export const Route = createFileRoute("/bookmarks")({
  head: () => ({ meta: [{ title: "Bookmarks | Imperial Novel" }, { name: "description", content: "Review and manage your saved novels on Imperial Novel." }] }),
  component: () => (
    <RequireAuth>
      <BookmarksPage />
    </RequireAuth>
  ),
});

function BookmarksPage() {
  const [rows, setRows] = useState<Array<{ id: number; title: string; chapter_number?: number }>>([]);
  useEffect(() => {
    getLibrary()
      .then((d) => setRows(d.bookmarks as typeof rows))
      .catch(() => setRows([]));
  }, []);
  return (
    <PageWrap>
      <PageHeader title="Bookmarks" sub="Saved chapter positions across your library." />
      {rows.length ? (
        <div className="grid gap-2">
          {rows.map((x) => (
            <Panel key={x.id} className="flex items-center justify-between gap-3">
              <div>
                <b className="text-fg">{safeText(x.title)}</b>
                <p className="text-sm text-muted">Chapter {x.chapter_number}</p>
              </div>
              <Link
                to="/read/$novelId/$chapterId"
                params={{ novelId: String(x.id), chapterId: String(x.chapter_number || 1) }}
                className="text-sm font-semibold text-gold-2"
              >
                Open
              </Link>
            </Panel>
          ))}
        </div>
      ) : (
        <EmptyState title="No bookmarked chapters yet." />
      )}
    </PageWrap>
  );
}
