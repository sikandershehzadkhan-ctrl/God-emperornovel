import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { PageWrap, RequireAuth } from "@/components/layout/shell";
import { Button } from "@/components/ui/button";
import { EmptyState, PageHeader } from "@/components/ui/panel";
import { listNotifications, markNotificationsRead } from "@/lib/imperial/community";
import { errMessage, safeText } from "@/lib/utils";

export const Route = createFileRoute("/notifications")({
  head: () => ({ meta: [{ title: "Notifications | Imperial Novel" }, { name: "description", content: "Review account and reading notifications on Imperial Novel." }] }),
  component: () => (
    <RequireAuth>
      <NotificationsPage />
    </RequireAuth>
  ),
});

function NotificationsPage() {
  const [rows, setRows] = useState<Awaited<ReturnType<typeof listNotifications>>>([]);
  async function load() {
    setRows(await listNotifications());
  }
  useEffect(() => {
    load().catch(() => setRows([]));
  }, []);
  return (
    <PageWrap>
      <PageHeader
        title="Notifications"
        sub="Updates about chapters, follows, requests and your Imperial account."
        actions={
          <Button
            variant="ghost"
            onClick={async () => {
              try {
                await markNotificationsRead();
                await load();
              } catch (e) {
                toast.error(errMessage(e));
              }
            }}
          >
            Mark all as read
          </Button>
        }
      />
      {rows.length ? (
        <div className="grid gap-2">
          {rows.map((x) => (
            <div
              key={x.id}
              className={`rounded-md border px-4 py-3 ${x.read_at ? "border-line bg-surface" : "border-gold/30 bg-gold/5"}`}
            >
              <b className="text-fg">{safeText(x.title)}</b>
              <p className="text-sm text-muted">{x.body}</p>
              <p className="text-xs text-subtle">{x.created_at}</p>
            </div>
          ))}
        </div>
      ) : (
        <EmptyState title="No notifications yet." />
      )}
    </PageWrap>
  );
}
