import { createFileRoute, redirect } from "@tanstack/react-router";

export const Route = createFileRoute("/register")({
  head: () => ({ meta: [{ title: "Registration Redirect | Imperial Novel" }, { name: "description", content: "Create an Imperial Novel account to access your library and reader features." }, { name: "robots", content: "noindex,follow" }] }),
  beforeLoad: () => {
    throw redirect({ to: "/signup" });
  },
});
