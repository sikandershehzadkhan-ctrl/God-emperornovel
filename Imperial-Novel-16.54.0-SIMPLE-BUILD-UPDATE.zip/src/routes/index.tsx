import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { BookOpen, Gamepad2, Heart, Sparkles, Swords, Tags, Telescope, Tv, Users, Wand2 } from "lucide-react";
import { useEffect, useState } from "react";
import { AuthorCta, PageWrap, PatronageStrip } from "@/components/layout/shell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { EmptyState } from "@/components/ui/panel";
import { FeaturedStory, StoryGrid } from "@/components/novel/story-card";
import { getHomeData } from "@/lib/imperial/catalog";
import { getLibrary, getMadeForYou } from "@/lib/imperial/library";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import type { NovelCard } from "@/lib/imperial/types";
import { BRAND_LINE, CATEGORIES } from "@/lib/imperial/types";
import { formatNumber } from "@/lib/utils";

export const Route = createFileRoute("/")({
  head: () => ({ meta: [{ title: "Home | Imperial Novel" }, { name: "description", content: "Discover original, licensed and authorized novels in the Imperial Novel reading realm." }] }),
  loader: () => getHomeData(),
  component: Home,
});

function idsKey(novels: NovelCard[]) {
  return novels.map((n) => n.id).join(",");
}

function Section({
  eyebrow,
  title,
  sub,
  to,
  hrefLabel,
  search,
  children,
}: {
  eyebrow: string;
  title: string;
  sub: string;
  to: string;
  hrefLabel: string;
  search?: Record<string, string>;
  children: React.ReactNode;
}) {
  return (
    <section className="home-section mt-8 sm:mt-10">
      <div className="mb-3 flex items-end justify-between gap-3 sm:mb-4">
        <div className="min-w-0">
          <p className="text-[11px] font-semibold tracking-[0.2em] text-cyan uppercase">{eyebrow}</p>
          <h2 className="font-display text-[1.8rem] leading-tight font-semibold text-fg sm:text-3xl">{title}</h2>
          <p className="mt-1 text-xs leading-relaxed text-muted sm:text-sm">{sub}</p>
        </div>
        <Link
          to={to}
          search={search}
          className="inline-flex min-h-11 shrink-0 items-center justify-center rounded-md px-3 text-sm font-semibold text-cyan"
        >
          {hrefLabel}
        </Link>
      </div>
      {children}
    </section>
  );
}

const WORLD_ICONS = {
  "anime-manga": Tv,
  games: Gamepad2,
  "drama-tv": Heart,
  "fantasy-worlds": Wand2,
  "original-fiction": Sparkles,
  fanfiction: Swords,
} as const;

function Home() {
  const data = Route.useLoaderData();
  const navigate = useNavigate();
  const { user } = useCurrentUserState();
  const [continueReading, setContinueReading] = useState<NovelCard[]>([]);
  const [forYou, setForYou] = useState<NovelCard[]>([]);
  const [query, setQuery] = useState("");

  useEffect(() => {
    getMadeForYou()
      .then((d) => setForYou(d.results || []))
      .catch(() => setForYou(data.picks));
  }, [data.picks]);

  useEffect(() => {
    if (!user) {
      setContinueReading([]);
      return;
    }
    getLibrary()
      .then((d) => setContinueReading(d.history.slice(0, 6)))
      .catch(() => setContinueReading([]));
  }, [user]);

  const featured = data.featured[0] || data.trending[0] || data.updated[0];
  const featuredRow = (data.featured.length ? data.featured : data.trending).slice(0, 5);
  const trending = data.trending.filter((n) => n.id !== featured?.id);
  const updated = idsKey(data.updated) === idsKey(data.trending) ? [] : data.updated;
  const newest = idsKey(data.newest) === idsKey(data.trending) || idsKey(data.newest) === idsKey(data.updated) ? [] : data.newest;
  const picks =
    idsKey(data.picks) === idsKey(data.trending) || idsKey(data.picks) === idsKey(data.newest) ? [] : data.picks;
  const recommended = forYou.filter((n) => n.id !== featured?.id).slice(0, 8);
  const stats = data.stats || { novels: 0, chapters: 0, authors: 0, genres: 0 };
  const tags = (data.tags || []).filter((t) => t.n > 0).slice(0, 12);

  return (
    <div className="home-page">
      <PageWrap className="pt-3 pb-6 sm:pt-4 sm:pb-8">
        <section className="imperial-hero">
          <div className="imperial-hero-inner">
            <p className="text-[11px] font-semibold tracking-[0.22em] text-cyan uppercase">{BRAND_LINE}</p>
            <h1 className="font-display mt-3 text-4xl leading-[0.94] font-semibold text-fg sm:text-6xl">
              IMPERIAL
              <span className="block text-violet-2">NOVEL</span>
            </h1>
            <p className="mt-4 max-w-md text-sm leading-relaxed text-muted sm:text-base">
              Infinite worlds. Legendary stories. Your empire. Original, licensed and authorized novels in a cinematic reading realm.
            </p>
            <form
              className="mt-5 hidden max-w-md flex-col gap-2 sm:flex sm:flex-row"
              onSubmit={(e) => {
                e.preventDefault();
                const q = query.trim();
                void navigate({ to: "/search", search: { q: q || undefined } });
              }}
            >
              <Input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search novels, authors, tags..."
                aria-label="Search stories"
                className="bg-bg/70"
              />
              <Button type="submit" className="min-h-11">
                Search
              </Button>
            </form>
            <div className="mt-4 flex flex-wrap gap-2">
              {featured ? (
                <Button asChild>
                  <Link
                    to="/read/$novelId/$chapterId"
                    params={{ novelId: String(featured.id), chapterId: "1" }}
                  >
                    Start Reading
                  </Link>
                </Button>
              ) : (
                <Button asChild>
                  <Link to="/catalog">Start Reading</Link>
                </Button>
              )}
              <Button variant="success" asChild>
                <Link to="/catalog">Explore Catalog</Link>
              </Button>
            </div>
          </div>
          <aside className="hero-realm">
            <img src="/imperial-character.png" alt="" className="hero-realm-art" />
            <p className="font-story text-xl leading-snug text-fg">“Not just a novel… a new world awaits you.”</p>
            <dl className="mt-4 grid grid-cols-2 gap-2 text-xs">
              <div className="rounded-md border border-line bg-bg/50 px-2 py-2">
                <dt className="text-subtle">Novels</dt>
                <dd className="font-semibold text-fg">{formatNumber(stats.novels)}</dd>
              </div>
              <div className="rounded-md border border-line bg-bg/50 px-2 py-2">
                <dt className="text-subtle">Chapters</dt>
                <dd className="font-semibold text-fg">{formatNumber(stats.chapters)}</dd>
              </div>
              <div className="rounded-md border border-line bg-bg/50 px-2 py-2">
                <dt className="text-subtle">Authors</dt>
                <dd className="font-semibold text-fg">{formatNumber(stats.authors)}</dd>
              </div>
              <div className="rounded-md border border-line bg-bg/50 px-2 py-2">
                <dt className="text-subtle">Genres</dt>
                <dd className="font-semibold text-fg">{formatNumber(stats.genres)}</dd>
              </div>
            </dl>
            <p className="mt-3 text-[10px] tracking-[0.16em] text-cyan uppercase">Live catalog · {BRAND_LINE}</p>
          </aside>
        </section>

        <div className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-4">
          {[
            [formatNumber(stats.novels), "Published novels", BookOpen],
            [formatNumber(stats.chapters), "Published chapters", Sparkles],
            [formatNumber(stats.authors), "Authors in catalog", Users],
            [formatNumber(stats.genres), "Genres", Tags],
          ].map(([value, label, Icon]) => {
            const StatIcon = Icon as typeof BookOpen;
            return (
              <div key={String(label)} className="stat-chip">
                <StatIcon className="mb-1 size-4 text-cyan" />
                <b className="font-display text-xl text-fg sm:text-2xl">{value as string}</b>
                <span className="text-[11px] text-muted">{label as string}</span>
              </div>
            );
          })}
        </div>
        <p className="mt-2 text-[11px] text-subtle">Counts are live catalog totals, not marketing estimates.</p>

        <div className="mt-5 grid grid-cols-3 gap-2 sm:grid-cols-6">
          {CATEGORIES.map((c) => {
            const Icon = WORLD_ICONS[c.slug as keyof typeof WORLD_ICONS] || Telescope;
            return (
              <Link key={c.slug} to="/catalog" search={{ category: c.slug }} className="world-chip">
                <Icon className="size-4 text-cyan" />
                <span className="px-1 text-center text-[11px] font-medium leading-tight">{c.name}</span>
              </Link>
            );
          })}
        </div>

        {continueReading.length > 0 ? (
          <Section eyebrow="Resume" title="Continue Reading" sub="Pick up the chapter you left." to="/history" hrefLabel="History →">
            <StoryGrid novels={continueReading} empty={null} />
          </Section>
        ) : null}

        {featured ? (
          <Section
            eyebrow="The Imperial Catalog"
            title="Featured Novels"
            sub="Hand-selected original and authorized works."
            to="/catalog"
            search={{ sort: "rating" }}
            hrefLabel="View all →"
          >
            <FeaturedStory novel={featured} />
            {featuredRow.filter((n) => n.id !== featured.id).length > 0 ? (
              <div className="mt-4">
                <StoryGrid novels={featuredRow.filter((n) => n.id !== featured.id)} empty={null} />
              </div>
            ) : null}
          </Section>
        ) : null}

        <Section
          eyebrow="Rising Across the Realm"
          title="Trending Now"
          sub="Stories drawing the most attention in the live catalog."
          to="/catalog"
          search={{ sort: "trending" }}
          hrefLabel="View all →"
        >
          <StoryGrid
            novels={trending}
            empty={<EmptyState title="The Imperial catalog is waiting for its first published stories." />}
          />
        </Section>

        {updated.length > 0 ? (
          <Section
            eyebrow="Fresh from the Realm"
            title="Recently Updated"
            sub="Fresh chapters and newly updated worlds."
            to="/catalog"
            search={{ sort: "updated" }}
            hrefLabel="Browse latest →"
          >
            <StoryGrid novels={updated} empty={null} />
          </Section>
        ) : null}

        {picks.length > 0 ? (
          <Section
            eyebrow="Editor"
            title="Highly Rated"
            sub="Highest rated works currently in the catalog."
            to="/catalog"
            search={{ sort: "rating" }}
            hrefLabel="Top rated →"
          >
            <StoryGrid novels={picks} empty={null} />
          </Section>
        ) : null}

        {newest.length > 0 ? (
          <Section
            eyebrow="New"
            title="New Releases"
            sub="Recently added original and authorized works."
            to="/catalog"
            search={{ sort: "newest" }}
            hrefLabel="Newest →"
          >
            <StoryGrid novels={newest} empty={null} />
          </Section>
        ) : null}

        {recommended.length > 0 ? (
          <Section
            eyebrow="For You"
            title="Recommended"
            sub="Based on the public catalog and your library, when signed in."
            to="/for-you"
            hrefLabel="See all →"
          >
            <StoryGrid novels={recommended} empty={null} />
          </Section>
        ) : null}

        <section className="home-section mt-8 sm:mt-10">
          <div className="mb-4">
            <p className="text-[11px] font-semibold tracking-[0.2em] text-cyan uppercase">Taxonomy</p>
            <h2 className="font-display text-2xl font-semibold text-fg">Popular Genres</h2>
          </div>
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-5">
            {data.genres
              .filter((g) => g.n > 0)
              .slice(0, 10)
              .map((g) => (
                <Link
                  key={g.slug}
                  to="/catalog"
                  search={{ genre: g.slug }}
                  className="min-h-11 rounded-lg border border-line bg-surface/80 px-4 py-4 transition-colors hover:border-cyan/40"
                >
                  <div className="font-medium text-fg">{g.name}</div>
                  <div className="text-xs text-muted">
                    {g.n} {g.n === 1 ? "story" : "stories"}
                  </div>
                </Link>
              ))}
          </div>
        </section>

        {tags.length > 0 ? (
          <section className="home-section mt-8 sm:mt-10">
            <p className="text-[11px] font-semibold tracking-[0.2em] text-cyan uppercase">Signals</p>
            <h2 className="font-display text-2xl font-semibold text-fg">Popular Tags</h2>
            <div className="mt-4 flex flex-wrap gap-2">
              {tags.map((t) => (
                <Link key={t.slug} to="/catalog" search={{ tag: t.slug }} className="filter-chip">
                  #{t.name} · {t.n}
                </Link>
              ))}
            </div>
          </section>
        ) : null}

        <div className="mt-8 grid gap-4 lg:grid-cols-2">
          <PatronageStrip />
          <AuthorCta />
        </div>

        <section className="home-section mt-8 rounded-xl border border-line bg-surface/80 p-5 sm:mt-10">
          <p className="text-[11px] font-semibold tracking-[0.2em] text-cyan uppercase">Community</p>
          <h2 className="font-display mt-1 text-2xl text-fg">Join the Imperial reading court.</h2>
          <p className="mt-1 max-w-xl text-sm text-muted">
            Rank stories, vote on requests, and follow authors. Only published, rights-eligible works appear in the public catalog.
          </p>
          <div className="mt-4 flex flex-wrap gap-2">
            <Button variant="secondary" asChild>
              <Link to="/community">Community hub</Link>
            </Button>
            <Button variant="ghost" asChild>
              <Link to="/vote">Vote novels</Link>
            </Button>
          </div>
        </section>
      </PageWrap>
    </div>
  );
}