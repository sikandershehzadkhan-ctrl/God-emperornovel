import { createFileRoute, Link } from "@tanstack/react-router";
import { PageWrap } from "@/components/layout/shell";
import { Badge, EmptyState, PageHeader } from "@/components/ui/panel";
import { listTags } from "@/lib/imperial/catalog";

export const Route = createFileRoute("/tags")({
  head: () => ({ meta: [{ title: "Tags | Imperial Novel" }, { name: "description", content: "Explore story tags and discover related novels on Imperial Novel." }] }),
  loader: () => listTags(),
  component: TagsPage,
});

function TagsPage() {
  const tags = Route.useLoaderData();
  return (
    <PageWrap>
      <PageHeader title="Tags" sub="Browse story themes and fandom-friendly classifications." />
      {tags.length ? (
        <div className="flex flex-wrap gap-2">
          {tags.map((t) => (
            <Link key={t.slug} to="/catalog" search={{ tag: t.slug }}>
              <Badge tone="violet">
                #{t.name} · {t.n}
              </Badge>
            </Link>
          ))}
        </div>
      ) : (
        <EmptyState title="No tags yet." />
      )}
    </PageWrap>
  );
}
