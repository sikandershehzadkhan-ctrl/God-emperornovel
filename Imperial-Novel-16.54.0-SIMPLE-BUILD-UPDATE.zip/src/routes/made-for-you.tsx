import { createFileRoute, redirect } from "@tanstack/react-router";

export const Route = createFileRoute("/made-for-you")({
  head: () => ({ meta: [{ title: "Recommendations Redirect | Imperial Novel" }, { name: "description", content: "Explore story recommendations on Imperial Novel." }, { name: "robots", content: "noindex,follow" }] }),
  beforeLoad: () => {
    throw redirect({ to: "/for-you" });
  },
});
