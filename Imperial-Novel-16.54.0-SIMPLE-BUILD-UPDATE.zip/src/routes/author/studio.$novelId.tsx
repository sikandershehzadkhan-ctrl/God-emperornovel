import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { PageWrap, RequireAuth } from "@/components/layout/shell";
import { Button } from "@/components/ui/button";
import { Field, Input, Select, Textarea } from "@/components/ui/input";
import { Badge, PageHeader, Panel } from "@/components/ui/panel";
import { getStudioNovel, publishChapter, saveChapter, submitNovel, updateNovel } from "@/lib/imperial/author";
import { errMessage, safeText } from "@/lib/utils";

export const Route = createFileRoute("/author/studio/$novelId")({
  head: () => ({ meta: [{ title: "Manuscript | Imperial Novel" }, { name: "description", content: "Edit and manage your author manuscript in Imperial Novel." }] }),
  component: () => (
    <RequireAuth>
      <Manuscript />
    </RequireAuth>
  ),
});

function Manuscript() {
  const { novelId } = Route.useParams();
  const id = Number(novelId);
  const [pack, setPack] = useState<Awaited<ReturnType<typeof getStudioNovel>> | null>(null);
  const [title, setTitle] = useState("");
  const [chTitle, setChTitle] = useState("");
  const [content, setContent] = useState("");
  const [chNum, setChNum] = useState(1);
  const [locked, setLocked] = useState(false);
  const [cost, setCost] = useState(1);
  const [editing, setEditing] = useState<number | undefined>();
  const words = useMemo(() => content.trim().split(/\s+/).filter(Boolean).length, [content]);

  async function load() {
    const d = await getStudioNovel({ data: id });
    setPack(d);
    setTitle(d.novel.title);
    setChNum((d.chapters.at(-1)?.chapter_number || 0) + 1);
  }

  useEffect(() => {
    load().catch((e) => toast.error(errMessage(e)));
  }, [id]);

  if (!pack) {
    return (
      <PageWrap>
        <p className="text-sm text-muted">Loading manuscript…</p>
      </PageWrap>
    );
  }

  return (
    <PageWrap>
      <PageHeader
        title={safeText(pack.novel.title)}
        sub={`Status: ${pack.novel.publication_status} · Rights: ${pack.novel.rights_status}`}
        actions={<Badge>{pack.novel.publication_status}</Badge>}
      />
      <div className="grid gap-4 lg:grid-cols-2">
        <Panel>
          <h2 className="font-display text-xl text-fg">Metadata</h2>
          <form
            className="mt-3 grid gap-3"
            onSubmit={async (e) => {
              e.preventDefault();
              try {
                const d = await updateNovel({ data: { id, title, description: pack.novel.description } });
                toast.success(d.message);
                await load();
              } catch (err) {
                toast.error(errMessage(err));
              }
            }}
          >
            <Field label="Title">
              <Input value={title} onChange={(e) => setTitle(e.target.value)} />
            </Field>
            <Field label="Synopsis">
              <Textarea
                defaultValue={pack.novel.description}
                onBlur={(e) => {
                  pack.novel.description = e.target.value;
                }}
              />
            </Field>
            <div className="flex flex-wrap gap-2">
              <Button type="submit">Save draft</Button>
              <Button
                type="button"
                variant="secondary"
                onClick={async () => {
                  try {
                    const d = await submitNovel({ data: id });
                    toast.success(d.message);
                    await load();
                  } catch (err) {
                    toast.error(errMessage(err));
                  }
                }}
              >
                Submit for review
              </Button>
            </div>
          </form>
        </Panel>
        <Panel>
          <h2 className="font-display text-xl text-fg">{editing ? "Edit chapter" : "New chapter"}</h2>
          <p className="text-xs text-muted">{words} words</p>
          <form
            className="mt-3 grid gap-3"
            onSubmit={async (e) => {
              e.preventDefault();
              try {
                const d = await saveChapter({
                  data: {
                    id: editing,
                    novel_id: id,
                    chapter_number: chNum,
                    title: chTitle,
                    content,
                    is_locked: locked,
                    ticket_cost: cost,
                  },
                });
                toast.success(d.message);
                setEditing(undefined);
                setChTitle("");
                setContent("");
                await load();
              } catch (err) {
                toast.error(errMessage(err));
              }
            }}
          >
            <div className="grid grid-cols-2 gap-2">
              <Field label="Number">
                <Input type="number" min={1} value={chNum} onChange={(e) => setChNum(Number(e.target.value))} />
              </Field>
              <Field label="Ticket cost">
                <Input type="number" min={0} value={cost} onChange={(e) => setCost(Number(e.target.value))} />
              </Field>
            </div>
            <Field label="Title">
              <Input value={chTitle} onChange={(e) => setChTitle(e.target.value)} required />
            </Field>
            <Field label="Manuscript">
              <Textarea className="min-h-48" value={content} onChange={(e) => setContent(e.target.value)} required />
            </Field>
            <label className="flex items-center gap-2 text-sm text-muted">
              <input type="checkbox" checked={locked} onChange={(e) => setLocked(e.target.checked)} />
              Locked chapter
            </label>
            <Button type="submit">Save chapter</Button>
          </form>
        </Panel>
      </div>
      <h2 className="font-display mt-8 text-2xl text-fg">Chapters</h2>
      <div className="mt-3 grid gap-2">
        {pack.chapters.map((c) => (
          <div key={c.id} className="flex flex-wrap items-center justify-between gap-2 rounded-md border border-line bg-surface px-4 py-3">
            <div>
              <b className="text-fg">
                {c.chapter_number}. {safeText(c.title)}
              </b>
              <p className="text-xs text-muted">
                {c.publication_status} · {c.is_locked ? `${c.ticket_cost} tickets` : "free"}
              </p>
            </div>
            <div className="flex gap-2">
              <Button
                size="sm"
                variant="ghost"
                onClick={() => {
                  setEditing(c.id);
                  setChNum(c.chapter_number);
                  setChTitle(c.title);
                  setContent(c.content);
                  setLocked(c.is_locked);
                  setCost(c.ticket_cost);
                }}
              >
                Edit
              </Button>
              <Button
                size="sm"
                variant="secondary"
                onClick={async () => {
                  try {
                    const next = c.publication_status === "published" ? "draft" : "published";
                    const d = await publishChapter({ data: { id: c.id, publication_status: next } });
                    toast.success(d.message);
                    await load();
                  } catch (err) {
                    toast.error(errMessage(err));
                  }
                }}
              >
                {c.publication_status === "published" ? "Unpublish" : "Publish"}
              </Button>
            </div>
          </div>
        ))}
      </div>
    </PageWrap>
  );
}
