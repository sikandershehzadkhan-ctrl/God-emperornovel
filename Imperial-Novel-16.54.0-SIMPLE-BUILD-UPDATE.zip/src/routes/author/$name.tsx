import { createFileRoute, Link } from "@tanstack/react-router";
import { PageWrap } from "@/components/layout/shell";
import { EmptyState, PageHeader } from "@/components/ui/panel";
import { StoryGrid } from "@/components/novel/story-card";
import { listNovels } from "@/lib/imperial/catalog";
import { safeText } from "@/lib/utils";

export const Route = createFileRoute("/author/$name")({
  loader: ({ params }) => listNovels({ data: { author: params.name, limit: 50 } }),
  head: ({ params }) => ({ meta: [{ title: `${params.name} | Imperial Novel` }, { name: "description", content: `Explore stories and author information for ${params.name} on Imperial Novel.` }] }),
  component: AuthorPublic,
});

function AuthorPublic() {
  const { name } = Route.useParams();
  const data = Route.useLoaderData();
  const author = data.results[0]?.author || name;
  if (!data.results.length) {
    return (
      <PageWrap>
        <EmptyState
          title="Author not found"
          body={`No published stories are currently associated with ${safeText(name)}.`}
        >
          <Link to="/catalog" className="text-gold-2">
            Browse the Catalog
          </Link>
        </EmptyState>
      </PageWrap>
    );
  }
  return (
    <PageWrap>
      <PageHeader title={safeText(author)} sub={`${data.results.length} published ${data.results.length === 1 ? "story" : "stories"} in the Imperial catalog.`} />
      <StoryGrid novels={data.results} empty={null} />
    </PageWrap>
  );
}
