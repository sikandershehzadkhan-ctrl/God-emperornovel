import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { PageWrap, RequireAuth } from "@/components/layout/shell";
import { Button } from "@/components/ui/button";
import { Field, Input, Select, Textarea } from "@/components/ui/input";
import { Badge, EmptyState, PageHeader, Panel } from "@/components/ui/panel";
import { createNovel, listAuthorNovels } from "@/lib/imperial/author";
import { aiAvailable, createAiProject, listAiProjects, runAiTool } from "@/lib/imperial/ai";
import { CATEGORIES } from "@/lib/imperial/types";
import { errMessage, formatNumber, formatRating, safeText } from "@/lib/utils";

export const Route = createFileRoute("/author/")({
  head: () => ({ meta: [{ title: "Author Studio | Imperial Novel" }, { name: "description", content: "Create and manage authorized manuscripts with Imperial Novel Author Studio." }] }),
  component: () => (
    <RequireAuth>
      <AuthorStudio />
    </RequireAuth>
  ),
});

function AuthorStudio() {
  const [novels, setNovels] = useState<Awaited<ReturnType<typeof listAuthorNovels>> | null>(null);
  const [aiOn, setAiOn] = useState(false);
  const [projects, setProjects] = useState<Awaited<ReturnType<typeof listAiProjects>>>([]);
  const [tool, setTool] = useState("ideas");
  const [prompt, setPrompt] = useState("");
  const [result, setResult] = useState("");
  const [title, setTitle] = useState("");
  const [author, setAuthor] = useState("");
  const [description, setDescription] = useState("");
  const [evidence, setEvidence] = useState("");
  const [category, setCategory] = useState("original-fiction");

  async function load() {
    const d = await listAuthorNovels();
    setNovels(d);
    const avail = await aiAvailable();
    setAiOn(avail.available);
    try {
      setProjects(await listAiProjects());
    } catch {
      setProjects([]);
    }
  }

  useEffect(() => {
    load().catch(() => setNovels({ profile: null as never, novels: [] }));
  }, []);

  return (
    <PageWrap>
      <PageHeader
        title="Author Studio"
        sub="A professional publishing desk for drafts, chapters, rights evidence and optional AI assistance."
        actions={
          <Button variant="secondary" asChild>
            <Link to="/author/studio">Chapter desk</Link>
          </Button>
        }
      />
      {novels ? (
        <div className="mb-6 grid grid-cols-2 gap-2 lg:grid-cols-4">
          {[
            [String(novels.novels.length), "Manuscripts"],
            [formatNumber(novels.novels.reduce((s, n) => s + (n.views || 0), 0)), "Catalog views"],
            [String(novels.novels.reduce((s, n) => s + (n.chapter_count || 0), 0)), "Chapters"],
            [novels.novels.filter((n) => n.publication_status === "published").length, "Published"],
          ].map(([v, l]) => (
            <div key={String(l)} className="stat-chip">
              <b className="font-display text-2xl text-fg">{v}</b>
              <span className="text-[11px] text-muted">{l}</span>
            </div>
          ))}
        </div>
      ) : null}
      <div className="grid gap-4 lg:grid-cols-2">
        <Panel>
          <h2 className="font-display text-xl text-fg">Create novel</h2>
          <form
            className="mt-3 grid gap-3"
            onSubmit={async (e) => {
              e.preventDefault();
              try {
                const d = await createNovel({
                  data: {
                    title,
                    author,
                    description,
                    rights_evidence: evidence,
                    category,
                    rights_status: "original",
                  },
                });
                toast.success(d.message);
                setTitle("");
                setDescription("");
                await load();
              } catch (err) {
                toast.error(errMessage(err));
              }
            }}
          >
            <Field label="Title">
              <Input value={title} onChange={(e) => setTitle(e.target.value)} required />
            </Field>
            <Field label="Author name">
              <Input value={author} onChange={(e) => setAuthor(e.target.value)} placeholder="Pen name" />
            </Field>
            <Field label="Category">
              <Select value={category} onChange={(e) => setCategory(e.target.value)}>
                {CATEGORIES.map((c) => (
                  <option key={c.slug} value={c.slug}>
                    {c.name}
                  </option>
                ))}
              </Select>
            </Field>
            <Field label="Synopsis">
              <Textarea value={description} onChange={(e) => setDescription(e.target.value)} />
            </Field>
            <Field label="Rights evidence">
              <Textarea
                value={evidence}
                onChange={(e) => setEvidence(e.target.value)}
                placeholder="Original work statement, license, or authorization notes."
              />
            </Field>
            <Button type="submit">Create draft</Button>
          </form>
        </Panel>
        <Panel className="system-panel">
          <h2 className="font-display text-xl text-fg">AI Author Studio</h2>
          {aiOn ? (
            <>
              <p className="mt-1 text-sm text-muted">Optional writing assistance. Calls are user-initiated and original-only.</p>
              <form
                className="mt-3 grid gap-3"
                onSubmit={async (e) => {
                  e.preventDefault();
                  try {
                    let projectId = projects[0]?.id;
                    if (!projectId) {
                      const p = await createAiProject({ data: { name: "Studio notebook", premise: prompt } });
                      projectId = p.id;
                    }
                    const d = await runAiTool({ data: { project_id: projectId, tool, prompt } });
                    if (!d.ok) {
                      toast.error(d.error);
                      return;
                    }
                    setResult(d.text);
                    await load();
                  } catch (err) {
                    toast.error(errMessage(err));
                  }
                }}
              >
                <Select value={tool} onChange={(e) => setTool(e.target.value)}>
                  {[
                    "ideas",
                    "world",
                    "character",
                    "plot",
                    "outline",
                    "write",
                    "rewrite",
                    "grammar",
                    "continuity",
                    "lore",
                    "summary",
                    "expand",
                  ].map((t) => (
                    <option key={t} value={t}>
                      {t}
                    </option>
                  ))}
                </Select>
                <Textarea value={prompt} onChange={(e) => setPrompt(e.target.value)} placeholder="Brief the editor…" />
                <Button type="submit">Run tool</Button>
              </form>
              {result ? <pre className="mt-3 max-h-64 overflow-auto whitespace-pre-wrap text-sm text-muted">{result}</pre> : null}
            </>
          ) : (
            <p className="mt-2 text-sm text-muted">
              AI Author Studio is unavailable in this environment. No server-side model key is configured. Manual drafting
              still works.
            </p>
          )}
        </Panel>
      </div>

      <h2 className="font-display mt-8 text-2xl text-fg">Your manuscripts</h2>
      {novels?.novels.length ? (
        <div className="mt-3 grid gap-3 md:grid-cols-2">
          {novels.novels.map((n) => (
            <Panel key={n.id}>
              <div className="flex items-start justify-between gap-2">
                <h3 className="font-display text-xl text-fg">{safeText(n.title)}</h3>
                <Badge tone={n.publication_status === "published" ? "good" : "gold"}>{n.publication_status}</Badge>
              </div>
              <p className="text-sm text-muted">{safeText(n.author)}</p>
              <p className="mt-1 text-xs text-subtle">
                {n.chapter_count} chapters · {n.published_chapters} live · ★ {formatRating(n.rating)} ·{" "}
                {formatNumber(n.views)} views
              </p>
              {n.review_feedback ? <p className="mt-2 text-sm text-warning">{n.review_feedback}</p> : null}
              <Button className="mt-3" variant="secondary" asChild>
                <Link to="/author/studio/$novelId" params={{ novelId: String(n.id) }}>
                  Open manuscript
                </Link>
              </Button>
            </Panel>
          ))}
        </div>
      ) : (
        <EmptyState className="mt-3" title="No manuscripts yet." body="Create a draft to enter the publishing desk." />
      )}
    </PageWrap>
  );
}
