import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { PageWrap, RequireAuth } from "@/components/layout/shell";
import { EmptyState, PageHeader, Panel } from "@/components/ui/panel";
import { listAuthorNovels } from "@/lib/imperial/author";
import { safeText } from "@/lib/utils";

export const Route = createFileRoute("/author/studio")({
  head: () => ({ meta: [{ title: "Chapter Studio | Imperial Novel" }, { name: "description", content: "Manage your chapters and drafts in Imperial Novel Author Studio." }] }),
  component: () => (
    <RequireAuth>
      <StudioIndex />
    </RequireAuth>
  ),
});

function StudioIndex() {
  const [novels, setNovels] = useState<Awaited<ReturnType<typeof listAuthorNovels>>["novels"]>([]);
  useEffect(() => {
    listAuthorNovels()
      .then((d) => setNovels(d.novels))
      .catch(() => setNovels([]));
  }, []);
  return (
    <PageWrap>
      <PageHeader title="Chapter Studio" sub="Choose a manuscript to edit chapters, lock tickets and publish." />
      {novels.length ? (
        <div className="grid gap-3">
          {novels.map((n) => (
            <Link key={n.id} to="/author/studio/$novelId" params={{ novelId: String(n.id) }}>
              <Panel className="hover:border-violet/40">
                <h3 className="font-display text-xl text-fg">{safeText(n.title)}</h3>
                <p className="text-sm text-muted">
                  {n.chapter_count} chapters · {n.publication_status}
                </p>
              </Panel>
            </Link>
          ))}
        </div>
      ) : (
        <EmptyState title="Create a novel first." body="The chapter desk opens after a manuscript exists." />
      )}
    </PageWrap>
  );
}
