import { createFileRoute } from "@tanstack/react-router";
import { PageWrap } from "@/components/layout/shell";
import { EmptyState, PageHeader } from "@/components/ui/panel";
import { StoryGrid } from "@/components/novel/story-card";
import { getMadeForYou } from "@/lib/imperial/library";

export const Route = createFileRoute("/for-you")({
  head: () => ({ meta: [{ title: "Made For You | Imperial Novel" }, { name: "description", content: "Explore story recommendations and discover your next read on Imperial Novel." }] }),
  loader: () => getMadeForYou(),
  component: ForYouPage,
});

function ForYouPage() {
  const data = Route.useLoaderData();
  return (
    <PageWrap>
      <PageHeader
        title="For You"
        sub="Catalog suggestions from your reading history and public ratings. This is not an AI recommendation engine."
      />
      <p className="mb-4 text-sm text-muted">
        {data.basis === "shared-genres"
          ? "Stories that share genres with novels you have opened, then rating and views."
          : data.basis === "catalog-rating"
            ? "You have not opened enough stories yet. Showing highly rated catalog stories you have not opened."
            : "Showing popular catalog stories. Sign in so opened novels can shape this list."}
      </p>
      <StoryGrid novels={data.results} empty={<EmptyState title="No recommendations yet." />} />
    </PageWrap>
  );
}
