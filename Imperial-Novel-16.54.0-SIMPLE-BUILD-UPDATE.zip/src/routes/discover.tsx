import { createFileRoute, redirect } from "@tanstack/react-router";

export const Route = createFileRoute("/discover")({
  head: () => ({ meta: [{ title: "Discover | Imperial Novel" }, { name: "description", content: "Browse stories in the Imperial Novel catalog." }, { name: "robots", content: "noindex,follow" }] }),
  beforeLoad: () => {
    throw redirect({ to: "/catalog" });
  },
});
