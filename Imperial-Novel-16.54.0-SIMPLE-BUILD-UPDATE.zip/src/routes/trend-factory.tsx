import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { PageWrap, RequireAuth } from "@/components/layout/shell";
import { Button } from "@/components/ui/button";
import { Field, Input, Select, Textarea } from "@/components/ui/input";
import { Badge, EmptyState, PageHeader, Panel } from "@/components/ui/panel";
import {
  advanceTrendCandidate,
  createTrendCandidate,
  listTrendCandidates,
  type TrendFactoryStage,
  type TrendRightsStatus,
} from "@/lib/imperial/trend-factory";
import { errMessage } from "@/lib/utils";

export const Route = createFileRoute("/trend-factory")({
  head: () => ({ meta: [{ title: "Trend Factory | Imperial Novel" }, { name: "description", content: "Review rights-first trend discovery and author outreach in Imperial Novel." }] }),
  component: () => <RequireAuth><TrendFactoryPage /></RequireAuth>,
});

const stageLabels: Record<TrendFactoryStage, string> = {
  trend: "Trend captured",
  analyzed: "Analyzed",
  author_discovered: "Author discovered",
  invite_ready: "Invitation prepared",
  rights_review: "Rights review",
  review: "Editorial review",
  linked_to_novel: "Linked to novel",
  published: "Published record",
  rejected: "Rejected",
};
const eligibleRights: TrendRightsStatus[] = ["original", "public_domain", "licensed", "authorized"];

function TrendFactoryPage() {
  const [items, setItems] = useState<Awaited<ReturnType<typeof listTrendCandidates>>>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [title, setTitle] = useState("");
  const [url, setUrl] = useState("");
  const [signal, setSignal] = useState("");
  const [author, setAuthor] = useState("");
  const [authorUrl, setAuthorUrl] = useState("");
  const [notes, setNotes] = useState("");
  const [error, setError] = useState("");

  async function load() {
    try {
      setError("");
      setItems(await listTrendCandidates());
    } catch (err) {
      setError(errMessage(err, "Administrator access required."));
    } finally {
      setLoading(false);
    }
  }
  useEffect(() => { void load(); }, []);

  async function addCandidate(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setSaving(true);
    try {
      await createTrendCandidate({ data: {
        trend_title: title, trend_url: url, trend_signal: signal,
        author_name: author, author_profile_url: authorUrl, notes,
      } });
      setTitle(""); setUrl(""); setSignal(""); setAuthor(""); setAuthorUrl(""); setNotes("");
      toast.success("Trend metadata saved. No source chapters were copied.");
      await load();
    } catch (err) {
      toast.error(errMessage(err));
    } finally {
      setSaving(false);
    }
  }

  async function advance(item: (typeof items)[number], stage: TrendFactoryStage) {
    let rights_status: TrendRightsStatus | undefined;
    let rights_evidence: string | undefined;
    let novel_id: number | undefined;
    if (stage === "review") {
      const chosen = window.prompt("Rights status: original, public_domain, licensed, or authorized", item.rights_status === "unknown" ? "authorized" : item.rights_status);
      if (!chosen || !eligibleRights.includes(chosen as TrendRightsStatus)) {
        toast.error("Choose an eligible rights status. Nothing was changed."); return;
      }
      rights_status = chosen as TrendRightsStatus;
      rights_evidence = window.prompt("Rights evidence URL or concise evidence details (required)", item.rights_evidence || "") || "";
      if (rights_evidence.trim().length < 8) { toast.error("Meaningful rights evidence is required."); return; }
    }
    if (stage === "linked_to_novel") {
      const chosen = window.prompt("Enter the existing Imperial Novel ID. The novel must have its own rights evidence.");
      if (!chosen || !/^\d+$/.test(chosen)) return;
      novel_id = Number(chosen);
    }
    try {
      await advanceTrendCandidate({ data: { id: item.id, stage, rights_status, rights_evidence, novel_id } });
      toast.success(stage === "invite_ready"
        ? "Invitation preparation marked ready. No email or external message was sent."
        : stage === "published"
          ? "Workflow record marked published. The linked novel was not published by this action."
          : "Trend Factory stage updated.");
      await load();
    } catch (err) {
      toast.error(errMessage(err));
    }
  }

  return (
    <PageWrap>
      <PageHeader
        eyebrow="Rights-first discovery"
        title="Trend Factory"
        sub="Trend → Analyze → Discover Author → Prepare Invitation → Rights Review → Editorial Review → Link an approved novel. Metadata only, no chapter-body ingestion."
      />
      <Panel className="mb-6">
        <h2 className="font-display text-xl text-fg">Capture a trend signal</h2>
        <p className="mt-1 text-sm text-muted">Store a public source link and discovery notes. This does not crawl the source, contact an author, or import copyrighted chapters.</p>
        <form className="mt-4 grid gap-3 md:grid-cols-2" onSubmit={addCandidate}>
          <Field label="Trend / story title"><Input required minLength={2} maxLength={180} value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Story or trend name" /></Field>
          <Field label="Public source URL"><Input required type="url" value={url} onChange={(e) => setUrl(e.target.value)} placeholder="https://example.com/story" /></Field>
          <Field label="Trend signal"><Input value={signal} onChange={(e) => setSignal(e.target.value)} placeholder="Why it is trending, evidence or public metadata" /></Field>
          <Field label="Author name (optional)"><Input value={author} onChange={(e) => setAuthor(e.target.value)} placeholder="Author / creator" /></Field>
          <Field label="Author profile URL (optional)"><Input type="url" value={authorUrl} onChange={(e) => setAuthorUrl(e.target.value)} placeholder="https://example.com/author" /></Field>
          <Field label="Internal notes (optional)"><Input value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Discovery notes, no copied chapters" /></Field>
          <div className="md:col-span-2"><Button type="submit" disabled={saving}>{saving ? "Saving…" : "Capture trend"}</Button></div>
        </form>
      </Panel>

      {error ? <Panel><p className="text-sm text-muted">{error}</p><Button className="mt-3" variant="secondary" onClick={() => void load()}>Retry</Button></Panel> : null}
      <div className="mb-3 flex items-center justify-between gap-3">
        <h2 className="font-display text-2xl text-fg">Discovery pipeline</h2>
        <Button variant="ghost" onClick={() => void load()}>Refresh</Button>
      </div>
      {loading ? <Panel><p className="text-sm text-muted">Loading rights-first pipeline…</p></Panel> : items.length === 0 ? (
        <EmptyState title="No trend candidates yet" body="Capture a public trend signal above to begin the review pipeline." />
      ) : (
        <div className="grid gap-3">
          {items.map((item) => {
            const next = item.stage === "rejected" || item.stage === "published" ? undefined : ({
              trend: "analyzed", analyzed: "author_discovered", author_discovered: "invite_ready",
              invite_ready: "rights_review", rights_review: "review", review: "linked_to_novel",
              linked_to_novel: "published",
            } as Partial<Record<TrendFactoryStage, TrendFactoryStage>>)[item.stage];
            return <Panel key={item.id}>
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2"><Badge tone={item.stage === "published" ? "good" : item.stage === "rights_review" ? "gold" : "violet"}>{stageLabels[item.stage]}</Badge><Badge>{item.rights_status.replaceAll("_", " ")}</Badge></div>
                  <h3 className="mt-2 break-words font-display text-xl text-fg">{item.trend_title}</h3>
                  <a className="mt-1 block break-all text-xs text-cyan underline" href={item.trend_url} target="_blank" rel="noopener noreferrer">{item.trend_url}</a>
                  {item.author_name ? <p className="mt-2 text-sm text-muted">Author: {item.author_name}{item.author_profile_url ? ` · ${item.author_profile_url}` : ""}</p> : null}
                  {item.trend_signal ? <p className="mt-2 text-sm text-muted">Signal: {item.trend_signal}</p> : null}
                  {item.rights_evidence ? <p className="mt-2 break-words text-xs text-subtle">Rights evidence: {item.rights_evidence}</p> : null}
                  {item.notes ? <p className="mt-2 text-xs text-subtle">Notes: {item.notes}</p> : null}
                  {item.novel_id ? <p className="mt-2 text-xs text-muted">Linked Imperial Novel ID: {item.novel_id}</p> : null}
                </div>
                <div className="flex flex-wrap gap-2">
                  {next ? <Button size="sm" onClick={() => void advance(item, next)}>{next === "invite_ready" ? "Prepare invitation" : next === "rights_review" ? "Start rights review" : next === "review" ? "Submit rights for review" : next === "linked_to_novel" ? "Link novel" : next === "published" ? "Complete workflow" : `Advance: ${stageLabels[next]}`}</Button> : null}
                  {item.stage !== "published" && item.stage !== "rejected" ? <Button size="sm" variant="ghost" onClick={() => void advance(item, "rejected")}>Reject</Button> : null}
                </div>
              </div>
            </Panel>;
          })}
        </div>
      )}
      <p className="mt-6 text-xs text-subtle">Invitation preparation is not delivery. Publishing this workflow record never publishes a novel. A linked novel must pass the separate Imperial Novel rights and editorial publishing checks.</p>
    </PageWrap>
  );
}
