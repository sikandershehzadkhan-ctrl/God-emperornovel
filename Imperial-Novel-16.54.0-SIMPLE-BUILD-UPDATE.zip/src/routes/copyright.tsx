import { createFileRoute } from "@tanstack/react-router";
import { PageWrap } from "@/components/layout/shell";
import { PageHeader, Panel } from "@/components/ui/panel";

export const Route = createFileRoute("/copyright")({
  head: () => ({ meta: [{ title: "Copyright | Imperial Novel" }, { name: "description", content: "Learn how Imperial Novel handles copyright, rights evidence and content concerns." }] }),
  component: () => (
    <PageWrap>
      <PageHeader title="Copyright" sub="Rights-first publishing on Imperial Novel." />
      <Panel className="max-w-3xl space-y-3 text-sm leading-relaxed text-muted">
        <p>
          The public catalog exposes published works only. New manuscripts begin as drafts. Publication requires an
          eligible rights status. Non-original works require rights evidence.
        </p>
        <p>Report suspected infringement from a novel page. Administrators review reports from the Command Center.</p>
      </Panel>
    </PageWrap>
  ),
});
