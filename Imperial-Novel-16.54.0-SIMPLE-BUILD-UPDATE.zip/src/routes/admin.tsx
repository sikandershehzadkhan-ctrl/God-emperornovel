import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { PageWrap, RequireAuth } from "@/components/layout/shell";
import { Button } from "@/components/ui/button";
import { Select } from "@/components/ui/input";
import { Badge, PageHeader, Panel } from "@/components/ui/panel";
import {
  adminConnectors,
  adminCreditTickets,
  adminDonations,
  adminPublishing,
  adminReports,
  adminRequests,
  adminReviewDonation,
  adminSetPublication,
  adminSetRole,
  adminStats,
  adminUsers,
} from "@/lib/imperial/admin";
import { errMessage, formatNumber } from "@/lib/utils";

export const Route = createFileRoute("/admin")({
  head: () => ({ meta: [{ title: "Command Center | Imperial Novel" }, { name: "description", content: "Restricted administration tools for authorized Imperial Novel administrators." }] }),
  component: () => (
    <RequireAuth>
      <AdminPage />
    </RequireAuth>
  ),
});

function AdminPage() {
  const [tab, setTab] = useState("overview");
  const [stats, setStats] = useState<Awaited<ReturnType<typeof adminStats>> | null>(null);
  const [users, setUsers] = useState<Awaited<ReturnType<typeof adminUsers>>>([]);
  const [novels, setNovels] = useState<Awaited<ReturnType<typeof adminPublishing>>>([]);
  const [dons, setDons] = useState<Awaited<ReturnType<typeof adminDonations>>>([]);
  const [reqs, setReqs] = useState<Awaited<ReturnType<typeof adminRequests>>>([]);
  const [reports, setReports] = useState<Awaited<ReturnType<typeof adminReports>>>([]);
  const [connectors, setConnectors] = useState<Awaited<ReturnType<typeof adminConnectors>>>([]);
  const [error, setError] = useState("");

  async function load() {
    try {
      setError("");
      const s = await adminStats();
      setStats(s);
      setUsers(await adminUsers());
      setNovels(await adminPublishing());
      setDons(await adminDonations());
      setReqs(await adminRequests());
      setReports(await adminReports());
      setConnectors(await adminConnectors());
    } catch (e) {
      setError(errMessage(e, "Administrator access required."));
    }
  }

  useEffect(() => {
    load();
  }, []);

  if (error) {
    return (
      <PageWrap>
        <PageHeader title="Command Center" sub={error} />
      </PageWrap>
    );
  }

  const tabs = ["overview", "users", "publishing", "donations", "requests", "reports", "connectors"];

  return (
    <PageWrap>
      <PageHeader title="Command Center" sub="Server-side administration for catalog, users, donations and connectors." />
      <div className="mb-6 flex gap-1 overflow-auto border-b border-line">
        {tabs.map((t) => (
          <button
            key={t}
            type="button"
            className={`min-h-11 px-3 text-sm capitalize ${tab === t ? "border-b-2 border-gold-2 text-gold-2" : "text-muted"}`}
            onClick={() => setTab(t)}
          >
            {t}
          </button>
        ))}
      </div>

      {tab === "overview" && stats ? (
        <div className="grid grid-cols-2 gap-3 md:grid-cols-3">
          {[
            ["Users", stats.users],
            ["Novels", stats.novels],
            ["Chapters", stats.chapters],
            ["Pending donations", stats.pendingDonations],
            ["Pending requests", stats.pendingRequests],
            ["Open reports", stats.openReports],
          ].map(([l, v]) => (
            <Panel key={String(l)}>
              <p className="text-xs text-muted">{l}</p>
              <p className="font-display text-3xl text-fg">{v}</p>
            </Panel>
          ))}
        </div>
      ) : null}

      {tab === "users" ? (
        <div className="grid gap-2">
          {users.map((u) => (
            <Panel key={u.user_id} className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <b className="text-fg">{u.username}</b>
                <p className="text-xs text-muted">
                  {u.role} · {formatNumber(u.tickets)} tickets {u.banned ? "· banned" : ""}
                </p>
              </div>
              <div className="flex gap-2">
                <Select
                  defaultValue={u.role}
                  onChange={async (e) => {
                    try {
                      await adminSetRole({ data: { user_id: u.user_id, role: e.target.value as never } });
                      toast.success("Role updated");
                      await load();
                    } catch (err) {
                      toast.error(errMessage(err));
                    }
                  }}
                >
                  <option value="user">user</option>
                  <option value="author">author</option>
                  <option value="moderator">moderator</option>
                  <option value="admin">admin</option>
                </Select>
                <Button
                  size="sm"
                  variant="secondary"
                  onClick={async () => {
                    const n = Number(window.prompt("Credit tickets", "10"));
                    if (!n) return;
                    try {
                      await adminCreditTickets({ data: { user_id: u.user_id, amount: n } });
                      await load();
                    } catch (err) {
                      toast.error(errMessage(err));
                    }
                  }}
                >
                  Credit
                </Button>
              </div>
            </Panel>
          ))}
        </div>
      ) : null}

      {tab === "publishing" ? (
        <div className="grid gap-2">
          {novels.map((n) => (
            <Panel key={n.id} className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <b className="text-fg">{n.title}</b>
                <p className="text-xs text-muted">
                  {n.author} · {n.rights_status} · {n.chapter_count} ch.
                </p>
              </div>
              <div className="flex items-center gap-2">
                <Badge>{n.publication_status}</Badge>
                <Select
                  defaultValue={n.publication_status}
                  onChange={async (e) => {
                    try {
                      await adminSetPublication({ data: { id: n.id, publication_status: e.target.value } });
                      toast.success("Publication updated");
                      await load();
                    } catch (err) {
                      toast.error(errMessage(err));
                    }
                  }}
                >
                  <option value="draft">draft</option>
                  <option value="review">review</option>
                  <option value="published">published</option>
                  <option value="archived">archived</option>
                </Select>
              </div>
            </Panel>
          ))}
        </div>
      ) : null}

      {tab === "donations" ? (
        <div className="grid gap-2">
          {dons.map((d) => (
            <Panel key={d.id} className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <b className="text-fg">
                  {d.username} · PKR {formatNumber(d.amount)}
                </b>
                <p className="text-xs text-muted">{d.reference_id}</p>
              </div>
              {d.status === "pending" ? (
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    onClick={async () => {
                      try {
                        await adminReviewDonation({ data: { id: d.id, status: "approved" } });
                        await load();
                      } catch (e) {
                        toast.error(errMessage(e));
                      }
                    }}
                  >
                    Approve
                  </Button>
                  <Button
                    size="sm"
                    variant="danger"
                    onClick={async () => {
                      try {
                        await adminReviewDonation({ data: { id: d.id, status: "rejected" } });
                        await load();
                      } catch (e) {
                        toast.error(errMessage(e));
                      }
                    }}
                  >
                    Reject
                  </Button>
                </div>
              ) : (
                <Badge>{d.status}</Badge>
              )}
            </Panel>
          ))}
        </div>
      ) : null}

      {tab === "requests" ? (
        <div className="grid gap-2">
          {reqs.map((r) => (
            <Panel key={r.id}>
              <b className="text-fg">{r.username}</b>
              <p className="truncate text-sm text-muted">{r.url}</p>
              <Badge className="mt-2">{r.status}</Badge>
            </Panel>
          ))}
        </div>
      ) : null}

      {tab === "reports" ? (
        <div className="grid gap-2">
          {reports.map((r) => (
            <Panel key={r.id}>
              <b className="text-fg">{r.reason}</b>
              <p className="text-sm text-muted">{r.details}</p>
              <Badge className="mt-2">{r.status}</Badge>
            </Panel>
          ))}
        </div>
      ) : null}

      {tab === "connectors" ? (
        <div className="grid gap-2">
          {connectors.map((c) => (
            <Panel key={c.id} className="flex items-center justify-between">
              <div>
                <b className="text-fg">{c.name}</b>
                <p className="text-xs text-muted">{c.base_url}</p>
              </div>
              <Badge tone={c.enabled ? "good" : "gold"}>{c.rights_status}</Badge>
            </Panel>
          ))}
        </div>
      ) : null}
    </PageWrap>
  );
}
