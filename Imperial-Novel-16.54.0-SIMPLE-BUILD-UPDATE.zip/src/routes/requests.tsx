import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { PageWrap, RequireAuth } from "@/components/layout/shell";
import { Button } from "@/components/ui/button";
import { Field, Input } from "@/components/ui/input";
import { Badge, PageHeader, Panel } from "@/components/ui/panel";
import { getMyRequests, submitRequest } from "@/lib/imperial/community";
import { errMessage } from "@/lib/utils";

export const Route = createFileRoute("/requests")({
  head: () => ({ meta: [{ title: "Requests | Imperial Novel" }, { name: "description", content: "View and manage reader requests on Imperial Novel." }] }),
  component: () => (
    <RequireAuth>
      <RequestsPage />
    </RequireAuth>
  ),
});

function RequestsPage() {
  const [data, setData] = useState<Awaited<ReturnType<typeof getMyRequests>> | null>(null);
  const [url, setUrl] = useState("");
  const [title, setTitle] = useState("");

  async function load() {
    setData(await getMyRequests());
  }
  useEffect(() => {
    load().catch(() => setData(null));
  }, []);

  return (
    <PageWrap>
      <PageHeader title="Request a New Novel" sub="Three free requests each week, then ticket pricing applies." />
      <Panel className="max-w-xl">
        <p className="text-sm text-muted">
          Used {data?.used ?? 0} / {data?.limit ?? 3} free requests this week.
        </p>
        <form
          className="mt-3 grid gap-3"
          onSubmit={async (e) => {
            e.preventDefault();
            try {
              const d = await submitRequest({ data: { url, title } });
              toast.success(`${d.message} Cost: ${d.cost} tickets.`);
              setUrl("");
              setTitle("");
              await load();
            } catch (err) {
              toast.error(errMessage(err));
            }
          }}
        >
          <Field label="Title (optional)">
            <Input value={title} onChange={(e) => setTitle(e.target.value)} />
          </Field>
          <Field label="Novel URL">
            <Input value={url} onChange={(e) => setUrl(e.target.value)} placeholder="https://example.com/novel/..." required />
          </Field>
          <Button type="submit">Submit Request</Button>
        </form>
      </Panel>
      <div className="mt-6 grid gap-2">
        {(data?.rows || []).map((r) => (
          <Panel key={r.id} className="flex items-center justify-between gap-3">
            <div className="min-w-0">
              <p className="truncate text-sm text-fg">{r.url}</p>
              <p className="text-xs text-muted">{r.source_host}</p>
            </div>
            <Badge>{r.status}</Badge>
          </Panel>
        ))}
      </div>
    </PageWrap>
  );
}
