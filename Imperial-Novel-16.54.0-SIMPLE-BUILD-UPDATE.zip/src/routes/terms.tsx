import { createFileRoute } from "@tanstack/react-router";
import { PageWrap } from "@/components/layout/shell";
import { PageHeader, Panel } from "@/components/ui/panel";

export const Route = createFileRoute("/terms")({
  head: () => ({ meta: [{ title: "Terms | Imperial Novel" }, { name: "description", content: "Read the terms for using Imperial Novel and its author tools." }] }),
  component: () => (
    <PageWrap>
      <PageHeader title="Terms" sub="Use of the Imperial Novel library and author tools." />
      <Panel className="max-w-3xl space-y-3 text-sm leading-relaxed text-muted">
        <p>
          Publish only original, public-domain, licensed or otherwise authorized work. Fanfiction must identify its
          fandom and remains subject to takedown.
        </p>
        <p>
          OmniPortal does not bypass authentication, paywalls, CAPTCHAs, robots controls or other access restrictions.
          Connector imports are metadata-only until an administrator enables an authorized source.
        </p>
        <p>Tickets unlock authorized chapters. Donations are credited only after manual verification.</p>
      </Panel>
    </PageWrap>
  ),
});
