import { createFileRoute, Link } from "@tanstack/react-router";
import { PageWrap } from "@/components/layout/shell";
import { EmptyState, PageHeader, Panel } from "@/components/ui/panel";
import { listGenres } from "@/lib/imperial/catalog";

export const Route = createFileRoute("/genres")({
  head: () => ({ meta: [{ title: "Genres | Imperial Novel" }, { name: "description", content: "Explore story genres available in the Imperial Novel catalog." }] }),
  loader: () => listGenres(),
  component: GenresPage,
});

function GenresPage() {
  const genres = Route.useLoaderData();
  return (
    <PageWrap>
      <PageHeader title="Genres" sub="Enter a genre and let the catalog narrow the realm for you." />
      {genres.length ? (
        <div className="grid grid-cols-2 gap-3 md:grid-cols-3 lg:grid-cols-4">
          {genres.map((g) => (
            <Link key={g.slug} to="/catalog" search={{ genre: g.slug }}>
              <Panel className="h-full transition-colors hover:border-violet/40">
                <h3 className="font-display text-xl text-fg">{g.name}</h3>
                <p className="mt-1 text-sm text-muted">
                  {g.n} {g.n === 1 ? "story" : "stories"}
                </p>
              </Panel>
            </Link>
          ))}
        </div>
      ) : (
        <EmptyState title="No genres yet." />
      )}
    </PageWrap>
  );
}
