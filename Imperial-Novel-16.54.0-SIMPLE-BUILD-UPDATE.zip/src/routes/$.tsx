import { createFileRoute, Link } from "@tanstack/react-router";
import { PageWrap } from "@/components/layout/shell";
import { Button } from "@/components/ui/button";
import { EmptyState } from "@/components/ui/panel";

export const Route = createFileRoute("/$")({
  head: () => ({ meta: [{ title: "Not found | Imperial Novel" }, { name: "description", content: "The requested page could not be found. Return to the Imperial Novel catalog." }] }),
  component: NotFound,
});

function NotFound() {
  return (
    <PageWrap className="py-16">
      <EmptyState
        kind="error"
        title="We could not find that realm."
        body="The page you requested does not exist. Return to the library or search the catalog."
      >
        <Button asChild>
          <Link to="/">Return Home</Link>
        </Button>
        <Button variant="secondary" asChild>
          <Link to="/catalog">Explore Catalog</Link>
        </Button>
        <Button variant="ghost" asChild>
          <Link to="/search">Search Stories</Link>
        </Button>
      </EmptyState>
    </PageWrap>
  );
}