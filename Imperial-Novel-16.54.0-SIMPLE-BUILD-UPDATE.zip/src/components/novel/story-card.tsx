import { Link } from "@tanstack/react-router";
import { Star } from "lucide-react";
import type { NovelCard } from "@/lib/imperial/types";
import { cn, formatNumber, formatRating, safeText } from "@/lib/utils";
import { Badge } from "@/components/ui/panel";

export function CoverImage({
  src,
  alt,
  className,
}: {
  src?: string | null;
  alt: string;
  className?: string;
}) {
  const url = src && src.trim() ? src : "/covers/ascendant.jpg";
  return (
    <img
      src={url}
      alt={alt}
      loading="lazy"
      className={cn("h-full w-full object-cover", className)}
    />
  );
}

function CardMeta({ novel }: { novel: NovelCard }) {
  const title = safeText(novel.title, "Untitled");
  return (
    <>
      <h3 className="font-story truncate text-base font-semibold text-fg">{title}</h3>
      <p className="truncate text-xs text-muted">{safeText(novel.author, "Unknown author")}</p>
      <div className="mt-2 flex flex-wrap items-center gap-2 text-[11px] text-subtle">
        <span className="inline-flex items-center gap-1 text-gold-2">
          <Star className="size-3" />
          {formatRating(novel.rating)}
        </span>
        <span>{formatNumber(novel.chapter_count)} ch.</span>
        <span>{formatNumber(novel.views)} views</span>
      </div>
      <div className="mt-2 flex flex-wrap gap-1">
        {(novel.genres || []).slice(0, 2).map((g) => (
          <Badge key={g.slug} tone="violet">
            {g.name}
          </Badge>
        ))}
      </div>
      <span className="mt-3 inline-flex text-[11px] font-semibold text-cyan">Read Now</span>
    </>
  );
}

export function StoryCard({ novel, className }: { novel: NovelCard; className?: string }) {
  const title = safeText(novel.title, "Untitled");
  return (
    <Link
      to="/novel/$id"
      params={{ id: String(novel.id) }}
      className={cn("story-card group block", className)}
    >
      <div className="relative aspect-3/4 overflow-hidden bg-bg2">
        <CoverImage
          src={novel.cover_url}
          alt={`${title} cover`}
          className="transition-transform duration-300 group-hover:scale-[1.04]"
        />
        <span className="absolute top-2 left-2 rounded-full border border-cyan/25 bg-bg/80 px-2 py-0.5 text-[10px] font-semibold tracking-wide text-cyan capitalize">
          {safeText(novel.status, "ongoing")}
        </span>
        {novel.featured ? (
          <span className="absolute top-2 right-2 rounded-full border border-gold/30 bg-bg/80 px-2 py-0.5 text-[10px] font-semibold text-gold-2">
            Featured
          </span>
        ) : null}
      </div>
      <div className="p-3">
        <CardMeta novel={novel} />
      </div>
    </Link>
  );
}

export function CatalogCard({ novel }: { novel: NovelCard }) {
  const title = safeText(novel.title, "Untitled");
  return (
    <Link to="/novel/$id" params={{ id: String(novel.id) }} className="story-card group block">
      <div className="relative aspect-3/4 overflow-hidden bg-bg2">
        <CoverImage
          src={novel.cover_url}
          alt={`${title} cover`}
          className="transition-transform duration-300 group-hover:scale-[1.04]"
        />
        <span className="absolute top-2 left-2 rounded-full border border-cyan/25 bg-bg/80 px-2 py-0.5 text-[10px] font-semibold tracking-wide text-cyan capitalize">
          {safeText(novel.status, "ongoing")}
        </span>
        {novel.featured ? (
          <span className="absolute top-2 right-2 rounded-full border border-gold/30 bg-bg/80 px-2 py-0.5 text-[10px] font-semibold text-gold-2">
            Featured
          </span>
        ) : null}
      </div>
      <div className="p-3">
        <CardMeta novel={novel} />
      </div>
    </Link>
  );
}

export function FeaturedStory({ novel }: { novel: NovelCard }) {
  const title = safeText(novel.title, "Untitled");
  return (
    <Link
      to="/novel/$id"
      params={{ id: String(novel.id) }}
      className="featured-story group grid overflow-hidden rounded-xl border border-cyan/20 bg-surface/80 shadow-soft transition-[border-color,transform] duration-200 hover:-translate-y-0.5 hover:border-cyan/40 sm:grid-cols-[180px_1fr] md:grid-cols-[220px_1fr]"
    >
      <div className="relative aspect-3/4 overflow-hidden bg-bg2 sm:aspect-auto sm:min-h-[260px]">
        <CoverImage src={novel.cover_url} alt={`${title} cover`} />
      </div>
      <div className="flex flex-col justify-center p-4 sm:p-6">
        <p className="text-[11px] font-semibold tracking-[0.2em] text-cyan uppercase">Featured Novel</p>
        <h3 className="font-display mt-1 text-2xl text-fg sm:text-4xl">{title}</h3>
        <p className="mt-1 text-sm text-muted">{safeText(novel.author, "Unknown author")}</p>
        <p className="mt-3 line-clamp-3 text-sm leading-relaxed text-muted">
          {safeText(novel.description, "No description yet.")}
        </p>
        <div className="mt-4 flex flex-wrap gap-3 text-xs text-subtle">
          <span className="text-gold-2">★ {formatRating(novel.rating)}</span>
          <span>{formatNumber(novel.chapter_count)} chapters</span>
          <span>{formatNumber(novel.views)} views</span>
          <span className="capitalize">{safeText(novel.status, "ongoing")}</span>
        </div>
        <span className="cta-primary mt-4 inline-flex w-fit min-h-11 items-center rounded-md px-4 text-xs font-semibold">
          Start Reading
        </span>
      </div>
    </Link>
  );
}

export function StoryGrid({
  novels,
  empty,
  variant = "home",
}: {
  novels: NovelCard[];
  empty: React.ReactNode;
  variant?: "home" | "catalog";
}) {
  if (!novels.length) return <>{empty}</>;
  const Card = variant === "catalog" ? CatalogCard : StoryCard;
  const single = novels.length === 1;
  return (
    <div
      className={cn(
        "grid gap-4",
        single
          ? `${variant === "catalog" ? "catalog-story-grid" : "home-story-grid"} single`
          : variant === "catalog"
            ? "catalog-story-grid multi grid-cols-2 md:grid-cols-3 xl:grid-cols-4"
            : "home-story-grid multi grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5",
      )}
    >
      {novels.map((n) => (
        <Card key={n.id} novel={n} />
      ))}
    </div>
  );
}