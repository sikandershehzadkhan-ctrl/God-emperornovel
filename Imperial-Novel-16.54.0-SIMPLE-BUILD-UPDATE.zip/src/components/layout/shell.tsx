import { Link, Outlet, useNavigate, useRouterState } from "@tanstack/react-router";
import {
  Bell,
  BookOpen,
  Compass,
  Crown,
  Home,
  Library,
  MoreHorizontal,
  Sparkles,
  Menu,
  X,
  PenLine,
  Search,
  Ticket,
  UserRound,
} from "lucide-react";
import { useEffect, useState } from "react";
import { SignedIn, UserButton } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { getOptionalProfile } from "@/lib/imperial/profile";
import { APP_VERSION, BRAND_LINE } from "@/lib/imperial/types";
import { cn, formatNumber } from "@/lib/utils";
import { Input } from "@/components/ui/input";

type Me = Awaited<ReturnType<typeof getOptionalProfile>>;

function applyPrefs() {
  if (typeof document === "undefined") return;
  const reduced = localStorage.getItem("imperial_reduced_motion") === "true";
  const contrast = localStorage.getItem("imperial_high_contrast") === "true";
  document.documentElement.dataset.reducedMotion = reduced ? "true" : "false";
  document.documentElement.dataset.highContrast = contrast ? "true" : "false";
}

function NavLink({
  to,
  search,
  children,
  className,
  active,
}: {
  to: string;
  search?: Record<string, string>;
  children: React.ReactNode;
  className?: string;
  active?: boolean;
}) {
  return (
    <Link
      to={to}
      search={search}
      className={cn(
        "inline-flex min-h-11 items-center rounded-md px-2.5 py-2 text-sm text-muted transition-colors duration-150 hover:bg-violet/20 hover:text-fg",
        active && "bg-violet/25 text-fg shadow-[0_0_18px_rgb(59_130_246/0.12)]",
        className,
      )}
    >
      {children}
    </Link>
  );
}

function AuthSlot({ me }: { me: Me }) {
  const { user, isPending } = useCurrentUserState();
  if (isPending) {
    return <div className="size-9 animate-pulse rounded-full bg-surface-3" />;
  }
  if (!user) {
    return (
      <Link
        to="/login"
        className="inline-flex min-h-11 items-center rounded-md border border-cyan/30 px-3 text-sm font-semibold text-fg hover:border-cyan/60"
      >
        Sign in
      </Link>
    );
  }
  return (
    <div className="flex items-center gap-2">
      {me ? (
        <Link
          to="/tickets"
          className="hidden min-h-11 items-center rounded-full border border-gold/30 bg-gold/10 px-3 text-xs font-semibold text-gold-2 sm:inline-flex"
        >
          <Ticket className="mr-1.5 size-3.5" />
          {formatNumber(me.tickets)} tickets
        </Link>
      ) : null}
      <UserButton />
    </div>
  );
}

export function Shell() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const searchSort = useRouterState({
    select: (s) => {
      const search = s.location.search as { sort?: string };
      return search?.sort;
    },
  });
  const isReader = pathname.startsWith("/read/");
  const { user } = useCurrentUserState();
  const [me, setMe] = useState<Me>(null);
  const [q, setQ] = useState("");
  const [more, setMore] = useState(false);
  const [mobileMenu, setMobileMenu] = useState(false);
  const [online, setOnline] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    applyPrefs();
  }, []);

  useEffect(() => {
    if (!more && !mobileMenu) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        setMore(false);
        setMobileMenu(false);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [more, mobileMenu]);

  useEffect(() => {
    const sync = () => setOnline(navigator.onLine);
    sync();
    window.addEventListener("online", sync);
    window.addEventListener("offline", sync);
    return () => {
      window.removeEventListener("online", sync);
      window.removeEventListener("offline", sync);
    };
  }, []);

  useEffect(() => {
    let alive = true;
    getOptionalProfile()
      .then((p) => {
        if (alive) setMe(p);
      })
      .catch(() => {
        if (alive) setMe(null);
      });
    return () => {
      alive = false;
    };
  }, [user?.id]);

  const active = (path: string) => pathname === path || pathname.startsWith(path + "/");

  if (isReader) {
    return (
      <div className="imperial-shell">
        {!online ? <p className="offline-banner px-4 py-2 text-center text-sm">You are offline. Cached reading still works on this device.</p> : null}
        <Outlet />
      </div>
    );
  }

  return (
    <div className="imperial-shell">
      <a className="imperial-skip-link" href="#imperial-main-content">Skip to main content</a>
      {!online ? (
        <p className="offline-banner px-4 py-2 text-center text-sm">You are offline. Retry when the connection returns.</p>
      ) : null}
      <header className="sticky top-0 z-40 border-b border-cyan/10 bg-bg/78 backdrop-blur-xl">
        <div className="mx-auto flex h-[66px] w-full max-w-[1440px] items-center gap-2 px-3 sm:h-[72px] sm:gap-3 sm:px-6 sm:px-6">
          <button
            type="button"
            className="imperial-menu-trigger grid size-10 shrink-0 place-items-center rounded-xl border border-line text-fg transition hover:border-cyan/50 hover:bg-violet/15 lg:hidden"
            aria-label={mobileMenu ? "Close navigation menu" : "Open navigation menu"}
            aria-controls="imperial-mobile-menu"
            aria-expanded={mobileMenu}
            onClick={() => setMobileMenu((open) => !open)}
          >
            {mobileMenu ? <X className="size-5" /> : <Menu className="size-5" />}
          </button>
          <Link to="/" className="imperial-brand flex min-w-0 items-center gap-2.5" onClick={() => setMobileMenu(false)}>
            <img
              src="/imperial-novel-crest.svg"
              alt="Imperial Novel crest"
              className="size-10 shrink-0 object-contain sm:size-11"
            />
            <span className="min-w-0">
              <b className="font-display block text-sm tracking-[0.12em] text-fg">IMPERIAL NOVEL</b>
              <small className="hidden text-[9px] tracking-[0.18em] text-cyan uppercase sm:block">{BRAND_LINE}</small>
            </span>
          </Link>
          <nav className="ml-2 hidden min-w-0 flex-1 items-center gap-0 overflow-x-auto lg:flex" aria-label="Primary">
            <NavLink to="/" active={pathname === "/"}>
              Home
            </NavLink>
            <NavLink to="/catalog" active={(active("/catalog") || active("/discover")) && searchSort !== "trending"}>
              Discover
            </NavLink>
            <NavLink
              to="/catalog"
              search={{ sort: "trending" }}
              className="hidden xl:inline-flex"
              active={pathname.startsWith("/catalog") && searchSort === "trending"}
            >
              Trending
            </NavLink>
            <NavLink to="/for-you" className="hidden xl:inline-flex" active={active("/for-you")}>
              For You
            </NavLink>
            <NavLink to="/leaderboard" className="hidden xl:inline-flex" active={active("/leaderboard")}>
              Rankings
            </NavLink>
            <NavLink to="/library" active={active("/library")}>
              Library
            </NavLink>
            <NavLink to="/community" active={active("/community")}>
              Community
            </NavLink>
            <NavLink to="/author" active={active("/author")}>
              Author
            </NavLink>
            <div className="relative">
              <button
                type="button"
                className={cn(
                  "inline-flex min-h-11 items-center rounded-md px-3 text-sm text-muted hover:bg-violet/20 hover:text-fg",
                  more && "bg-violet/25 text-fg",
                )}
                aria-expanded={more}
                aria-haspopup="menu"
                onClick={() => setMore((v) => !v)}
              >
                More
                <MoreHorizontal className="ml-1 size-4" />
              </button>
              {more ? (
                <div className="absolute top-full left-0 z-50 mt-1 min-w-48 rounded-lg border border-line bg-surface p-2 shadow-lux" role="menu">
                  {(
                    [
                      ["/catalog", { sort: "trending" }, "Trending", true],
                      ["/for-you", undefined, "For You", true],
                      ["/leaderboard", undefined, "Rankings", true],
                      ["/genres", undefined, "Genres", false],
                      ["/omniportal", undefined, "OmniPortal", false],
                      ["/tickets", undefined, "Tickets", false],
                      ["/settings", undefined, "Settings", false],
                    ] as const
                  ).map(([to, search, label, wideHidden]) => (
                    <Link
                      key={label}
                      to={to}
                      search={search}
                      role="menuitem"
                      className={cn(
                        "block rounded-md px-3 py-2 text-sm text-muted hover:bg-violet/20 hover:text-fg",
                        wideHidden && "xl:hidden",
                      )}
                      onClick={() => setMore(false)}
                    >
                      {label}
                    </Link>
                  ))}
                  {me?.role === "admin" ? (
                    <>
                      <Link
                        to="/trend-factory"
                        className="block rounded-md px-3 py-2 text-sm text-cyan hover:bg-violet/20"
                        onClick={() => setMore(false)}
                      >
                        Trend Factory
                      </Link>
                      <Link
                        to="/admin"
                        className="block rounded-md px-3 py-2 text-sm text-gold-2 hover:bg-violet/20"
                        onClick={() => setMore(false)}
                      >
                        Command
                      </Link>
                    </>
                  ) : null}
                </div>
              ) : null}
            </div>
          </nav>
          <div className="ml-auto flex items-center gap-1.5">
            <form
              className="hidden md:block"
              onSubmit={(e) => {
                e.preventDefault();
                const term = q.trim();
                void navigate({ to: "/search", search: { q: term || undefined } });
              }}
            >
              <label className="sr-only" htmlFor="header-search">
                Search novels, authors, tags
              </label>
              <Input
                id="header-search"
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="Search novels, authors, tags..."
                className="h-11 w-52 min-h-11 lg:w-64"
              />
            </form>
            <Link
              to="/search"
              aria-label="Search"
              className="grid size-11 place-items-center rounded-md border border-line text-muted hover:border-cyan/40 hover:text-fg md:hidden"
            >
              <Search className="size-4" />
            </Link>
            <SignedIn>
              <Link
                to="/notifications"
                aria-label="Notifications"
                className="relative grid size-11 place-items-center rounded-md border border-line text-muted hover:border-cyan/40 hover:text-fg"
              >
                <Bell className="size-4" />
                {me && "unread" in me && Number(me.unread) > 0 ? (
                  <span className="absolute top-2 right-2 size-1.5 rounded-full bg-cyan" />
                ) : null}
              </Link>
            </SignedIn>
            <AuthSlot me={me} />
          </div>
        </div>
      </header>

      {mobileMenu ? (
        <div
          className="imperial-mobile-menu-layer lg:hidden"
          onMouseDown={(event) => {
            if (event.target === event.currentTarget) setMobileMenu(false);
          }}
        >
          <nav id="imperial-mobile-menu" className="imperial-mobile-menu" aria-label="Main navigation" aria-modal="true" role="dialog">
            <div className="flex items-center justify-between border-b border-line px-5 py-4">
              <div className="flex items-center gap-3">
                <img src="/imperial-novel-crest.svg" alt="" className="size-11" />
                <div>
                  <p className="font-display text-sm tracking-[0.13em] text-fg">IMPERIAL NOVEL</p>
                  <p className="mt-0.5 text-[9px] tracking-[0.2em] text-cyan">READ • CREATE • CONQUER</p>
                </div>
              </div>
              <button type="button" className="grid size-10 place-items-center rounded-xl border border-line" aria-label="Close navigation menu" onClick={() => setMobileMenu(false)}>
                <X className="size-5" />
              </button>
            </div>
            <div className="grid grid-cols-2 gap-2 p-4">
              {[
                { to: "/", label: "Home", icon: Home },
                { to: "/catalog", label: "Discover", icon: Compass },
                { to: "/catalog", label: "Trending", icon: MoreHorizontal, search: { sort: "trending" } },
                { to: "/for-you", label: "For You", icon: Sparkles },
                { to: "/leaderboard", label: "Rankings", icon: Crown },
                { to: "/library", label: "Library", icon: Library },
                { to: "/community", label: "Community", icon: UserRound },
                { to: "/author", label: "Create stories", icon: PenLine },
                { to: "/genres", label: "Genres & tags", icon: BookOpen },
                { to: "/tickets", label: "Tickets & support", icon: Ticket },
                { to: "/notifications", label: "Notifications", icon: Bell },
                { to: "/settings", label: "Settings", icon: UserRound },
              ].map((item) => {
                const Icon = item.icon;
                return (
                  <Link
                    key={item.label}
                    to={item.to}
                    search={"search" in item ? item.search : undefined}
                    onClick={() => setMobileMenu(false)}
                    className={cn("imperial-mobile-menu-item", active(item.to) && "is-active")}
                  >
                    <Icon className="size-4 text-cyan" />
                    <span>{item.label}</span>
                  </Link>
                );
              })}
            </div>
            {me?.role === "admin" ? (
              <div className="mx-4 mb-4 grid grid-cols-2 gap-2 border-t border-line pt-4">
                <Link to="/trend-factory" onClick={() => setMobileMenu(false)} className="imperial-mobile-menu-item"><Compass className="size-4 text-cyan" />Trend Factory</Link>
                <Link to="/admin" onClick={() => setMobileMenu(false)} className="imperial-mobile-menu-item"><Crown className="size-4 text-violet-2" />Admin Command</Link>
              </div>
            ) : null}
            <div className="mx-4 mb-4 rounded-xl border border-cyan/15 bg-cyan/[0.04] p-3">
              <p className="text-xs font-semibold text-fg">A universe of stories.</p>
              <p className="mt-1 text-xs leading-relaxed text-muted">Discover worlds, follow authors, and build your own legendary archive.</p>
            </div>
          </nav>
        </div>
      ) : null}

      <main id="imperial-main-content" tabIndex={-1} className="flex-1">
        <Outlet />
      </main>

      <footer className="site-footer mt-auto pb-[calc(5.25rem+env(safe-area-inset-bottom))] lg:pb-10">
        <div className="mx-auto grid w-full max-w-[1440px] gap-8 px-4 py-10 sm:px-6 md:grid-cols-[1.4fr_1fr_1fr_1fr]">
          <div>
            <div className="flex items-center gap-3">
              <img src="/imperial-novel-crest.svg" alt="Imperial Novel crest" className="size-11 object-contain" />
              <div>
                <p className="font-display text-lg tracking-[0.16em] text-fg">IMPERIAL NOVEL</p>
                <p className="text-[10px] tracking-[0.18em] text-cyan uppercase">{BRAND_LINE}</p>
              </div>
            </div>
            <p className="mt-3 max-w-sm text-sm text-muted">
              Original, licensed and authorized stories in a cinematic imperial archive.
            </p>
            <p className="mt-3 font-story text-sm text-violet-2 italic">
              “A single story can change the fate of an entire world.”
            </p>
            <p className="mt-2 text-xs text-subtle">Version {APP_VERSION}</p>
          </div>
          <nav className="grid gap-2 text-sm text-muted">
            <p className="text-xs font-semibold tracking-[0.16em] text-fg uppercase">Discover</p>
            <Link to="/" className="hover:text-cyan">Home</Link>
            <Link to="/catalog" className="hover:text-cyan">Catalog</Link>
            <Link to="/library" className="hover:text-cyan">Library</Link>
            <Link to="/community" className="hover:text-cyan">Community</Link>
            <Link to="/leaderboard" className="hover:text-cyan">Rankings</Link>
          </nav>
          <nav className="grid gap-2 text-sm text-muted">
            <p className="text-xs font-semibold tracking-[0.16em] text-fg uppercase">Support</p>
            <Link to="/tickets" className="hover:text-cyan">Tickets & EasyPaisa</Link>
            <Link to="/author" className="hover:text-cyan">Author Studio</Link>
            <Link to="/omniportal" className="hover:text-cyan">OmniPortal</Link>
            <Link to="/privacy" className="hover:text-cyan">Privacy</Link>
            <Link to="/terms" className="hover:text-cyan">Terms</Link>
            <Link to="/copyright" className="hover:text-cyan">Copyright</Link>
            <Link to="/faq" className="hover:text-cyan">FAQ</Link>
            <button type="button" className="text-left hover:text-cyan" onClick={() => window.dispatchEvent(new Event("imperial:cookie-settings"))}>Cookie preferences</button>
          </nav>
          <div className="text-sm text-muted">
            <p className="text-xs font-semibold tracking-[0.16em] text-fg uppercase">The realm</p>
            <p className="mt-2">Different worlds. Infinite stories. One empire.</p>
            <p className="mt-4 text-xs text-subtle">© 2026 Imperial Novel</p>
          </div>
        </div>
      </footer>

      <nav
        className="fixed inset-x-0 bottom-0 z-50 flex border-t border-line bg-bg/92 px-1 pt-1 pb-[env(safe-area-inset-bottom)] backdrop-blur-xl lg:hidden"
        aria-label="Mobile"
      >
        {[
          { to: "/", label: "Home", icon: Home, match: (p: string) => p === "/" },
          {
            to: "/catalog",
            label: "Discover",
            icon: Compass,
            match: (p: string) => p.startsWith("/catalog") || p.startsWith("/genres") || p.startsWith("/discover"),
          },
          {
            to: "/library",
            label: "Library",
            icon: Library,
            match: (p: string) => p.startsWith("/library") || p.startsWith("/history") || p.startsWith("/bookmarks"),
          },
          { to: "/author", label: "Create", icon: PenLine, match: (p: string) => p.startsWith("/author") },
          {
            to: "/community",
            label: "Community",
            icon: UserRound,
            match: (p: string) =>
              p.startsWith("/community") || p.startsWith("/profile") || p.startsWith("/login") || p.startsWith("/tickets"),
          },
        ].map((item) => {
          const Icon = item.icon;
          const on = item.match(pathname);
          return (
            <Link
              key={item.to}
              to={item.to}
              className={cn(
                "flex min-h-12 flex-1 flex-col items-center justify-center gap-0.5 rounded-md text-[10px] font-medium",
                on ? "bg-violet/25 text-cyan" : "text-muted",
              )}
            >
              <Icon className="size-4" />
              {item.label}
            </Link>
          );
        })}
      </nav>
    </div>
  );
}

export function RequireAuth({ children }: { children: React.ReactNode }) {
  const { user, isPending } = useCurrentUserState();
  if (isPending) {
    return (
      <div className="mx-auto w-full max-w-[1440px] px-4 py-10">
        <div className="h-10 w-48 animate-pulse rounded-md bg-surface-3" />
        <div className="mt-6 grid grid-cols-2 gap-4 md:grid-cols-4">
          <div className="aspect-3/4 animate-pulse rounded-lg bg-surface-3" />
          <div className="aspect-3/4 animate-pulse rounded-lg bg-surface-3" />
          <div className="aspect-3/4 animate-pulse rounded-lg bg-surface-3" />
          <div className="aspect-3/4 animate-pulse rounded-lg bg-surface-3" />
        </div>
      </div>
    );
  }
  if (!user) {
    return (
      <div className="mx-auto w-full max-w-lg px-4 py-16 text-center">
        <Crown className="mx-auto size-8 text-gold" />
        <h1 className="font-display mt-4 text-3xl text-fg">Sign in to continue</h1>
        <p className="mt-2 text-sm text-muted">Your library, tickets and writing studio sync to your Imperial account.</p>
        <div className="mt-6 flex justify-center gap-2">
          <Link
            to="/login"
            className="cta-primary inline-flex min-h-11 items-center rounded-md px-4 text-sm font-semibold"
          >
            Sign in
          </Link>
          <Link
            to="/signup"
            className="inline-flex min-h-11 items-center rounded-md border border-line px-4 text-sm font-semibold text-fg"
          >
            Create account
          </Link>
        </div>
      </div>
    );
  }
  return <>{children}</>;
}

export function PageWrap({ children, className }: { children: React.ReactNode; className?: string }) {
  return (
    <div className={cn("mx-auto w-full max-w-[1440px] px-4 pt-6 pb-10 sm:px-6 lg:px-8", className)}>{children}</div>
  );
}

export function PatronageStrip() {
  return (
    <section className="relative overflow-hidden rounded-xl border border-cyan/20 bg-surface/80 p-5 sm:flex sm:items-center sm:justify-between sm:gap-6 sm:p-6">
      <div>
        <p className="text-[11px] font-semibold tracking-[0.2em] text-cyan uppercase">Patronage & Support</p>
        <h2 className="font-display mt-1 text-2xl text-fg">Help keep this archive alive.</h2>
        <p className="mt-1 max-w-xl text-sm text-muted">
          Tickets and EasyPaisa donations stay pending until an administrator verifies the transfer. Nothing is marked paid until then.
        </p>
      </div>
      <Link to="/tickets" className="cta-primary mt-4 inline-flex min-h-11 items-center rounded-md px-4 text-sm font-semibold sm:mt-0">
        <Ticket className="mr-2 size-4" />
        Support Imperial Novel
      </Link>
    </section>
  );
}

export function AuthorCta() {
  return (
    <section className="rounded-xl border border-line bg-surface/80 p-5 sm:flex sm:items-center sm:justify-between sm:p-6">
      <div>
        <p className="text-[11px] font-semibold tracking-[0.2em] text-gold-2 uppercase">Author Studio</p>
        <h2 className="font-display mt-1 text-2xl text-fg">Write, manage, and publish.</h2>
        <p className="mt-1 max-w-xl text-sm text-muted">
          Draft novels, evidence rights, and open the chapter desk. AI tools appear only when a real key is configured.
        </p>
      </div>
      <Link to="/author" className="cta-ghost mt-4 inline-flex min-h-11 items-center rounded-md px-4 text-sm font-semibold sm:mt-0">
        <BookOpen className="mr-2 size-4" />
        Open Studio
      </Link>
    </section>
  );
}
