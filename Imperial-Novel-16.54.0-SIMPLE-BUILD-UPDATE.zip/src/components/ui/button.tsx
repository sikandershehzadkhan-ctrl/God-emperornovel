import { cva, type VariantProps } from "class-variance-authority";
import { Slot } from "@radix-ui/react-slot";
import type { ButtonHTMLAttributes } from "react";
import { cn } from "@/lib/utils";

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 rounded-md text-sm font-semibold transition-[color,background-color,border-color,transform,box-shadow] duration-150 ease-out disabled:pointer-events-none disabled:opacity-50 focus-visible:outline-none active:scale-[0.98]",
  {
    variants: {
      variant: {
        primary:
          "cta-primary text-primary-fg hover:brightness-110",
        secondary:
          "cta-ghost text-fg hover:border-cyan/50 hover:text-fg",
        ghost:
          "border border-line bg-transparent text-muted hover:border-cyan/40 hover:text-fg",
        gold: "border border-gold-3 bg-gold text-bg hover:bg-gold-2",
        success: "cta-explore text-primary-fg hover:brightness-110",
        outline: "border border-cyan/35 bg-transparent text-fg hover:bg-cyan/10",
        danger: "border border-danger/40 bg-danger/15 text-danger hover:bg-danger/25",
      },
      size: {
        md: "min-h-11 px-4",
        sm: "min-h-9 px-3 text-xs",
        lg: "min-h-12 px-5",
        icon: "size-11 p-0",
      },
    },
    defaultVariants: { variant: "primary", size: "md" },
  },
);

export type ButtonProps = ButtonHTMLAttributes<HTMLButtonElement> &
  VariantProps<typeof buttonVariants> & { asChild?: boolean };

export function Button({ className, variant, size, asChild, ...props }: ButtonProps) {
  const Comp = asChild ? Slot : "button";
  return <Comp className={cn(buttonVariants({ variant, size }), className)} {...props} />;
}

export { buttonVariants };
