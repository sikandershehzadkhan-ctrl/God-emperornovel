import type { HTMLAttributes } from "react";
import { BookOpen, Compass, TriangleAlert, WifiOff } from "lucide-react";
import { cn } from "@/lib/utils";

export function Panel({ className, ...props }: HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={cn(
        "rounded-lg border border-line bg-surface/80 p-5 shadow-soft backdrop-blur-md",
        className,
      )}
      {...props}
    />
  );
}

export function Badge({
  children,
  tone = "default",
  className,
}: {
  children: React.ReactNode;
  tone?: "default" | "gold" | "violet" | "good" | "danger" | "cyan";
  className?: string;
}) {
  const tones = {
    default: "border-line bg-surface-2 text-muted",
    gold: "border-gold/30 bg-gold/10 text-gold-2",
    violet: "border-violet/30 bg-violet/10 text-violet-2",
    good: "border-good/30 bg-good/10 text-good",
    cyan: "border-cyan/30 bg-cyan/10 text-cyan",
    danger: "border-danger/30 bg-danger/10 text-danger",
  } as const;
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full border px-2.5 py-0.5 text-[11px] font-semibold tracking-wide",
        tones[tone],
        className,
      )}
    >
      {children}
    </span>
  );
}

export function EmptyState({
  title,
  body,
  children,
  className,
  kind = "empty",
}: {
  title: string;
  body?: string;
  children?: React.ReactNode;
  className?: string;
  kind?: "empty" | "error" | "offline" | "search";
}) {
  const Icon = kind === "error" ? TriangleAlert : kind === "offline" ? WifiOff : kind === "search" ? Compass : BookOpen;
  return (
    <div className={cn("state-card", className)}>
      <Icon className="size-8 text-cyan" />
      <h2 className="font-display text-2xl font-semibold text-fg">{title}</h2>
      {body ? <p className="mx-auto max-w-lg text-sm text-muted">{body}</p> : null}
      {children ? <div className="mt-2 flex flex-wrap justify-center gap-2">{children}</div> : null}
    </div>
  );
}

export function Skeleton({ className }: { className?: string }) {
  return <div className={cn("animate-pulse rounded-md bg-surface-3", className)} />;
}

export function PageHeader({
  eyebrow = "Imperial Library",
  title,
  sub,
  actions,
}: {
  eyebrow?: string;
  title: string;
  sub?: string;
  actions?: React.ReactNode;
}) {
  return (
    <header className="mb-6 flex flex-wrap items-end justify-between gap-4">
      <div className="min-w-0">
        <p className="text-[11px] font-semibold tracking-[0.22em] text-cyan uppercase">{eyebrow}</p>
        <h1 className="font-display mt-1 text-3xl font-semibold tracking-tight text-fg sm:text-4xl">{title}</h1>
        {sub ? <p className="mt-2 max-w-2xl text-sm text-muted">{sub}</p> : null}
      </div>
      {actions ? <div className="flex flex-wrap gap-2">{actions}</div> : null}
    </header>
  );
}