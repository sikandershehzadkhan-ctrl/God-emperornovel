import { useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";

type Consent = {
  necessary: true;
  analytics: boolean;
  marketing: boolean;
  savedAt: string;
};

const STORAGE_KEY = "imperial-novel-cookie-consent-v1";

function readConsent(): Consent | null {
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    const value = JSON.parse(raw) as Partial<Consent>;
    if (value.necessary !== true || typeof value.analytics !== "boolean" || typeof value.marketing !== "boolean") return null;
    return value as Consent;
  } catch {
    return null;
  }
}

export function CookieConsent() {
  const [consent, setConsent] = useState<Consent | null>(null);
  const [ready, setReady] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [analytics, setAnalytics] = useState(false);
  const [marketing, setMarketing] = useState(false);

  useEffect(() => {
    const saved = readConsent();
    setConsent(saved);
    setAnalytics(saved?.analytics ?? false);
    setMarketing(saved?.marketing ?? false);
    setReady(true);
    const openSettings = () => setSettingsOpen(true);
    window.addEventListener("imperial:cookie-settings", openSettings);
    return () => window.removeEventListener("imperial:cookie-settings", openSettings);
  }, []);

  function save(nextAnalytics: boolean, nextMarketing: boolean) {
    const value: Consent = {
      necessary: true,
      analytics: nextAnalytics,
      marketing: nextMarketing,
      savedAt: new Date().toISOString(),
    };
    try { window.localStorage.setItem(STORAGE_KEY, JSON.stringify(value)); } catch { /* privacy controls still work for this session */ }
    setConsent(value);
    setAnalytics(nextAnalytics);
    setMarketing(nextMarketing);
    setSettingsOpen(false);
    // Let optional integrations react to consent without forcing a provider on.
    window.dispatchEvent(new CustomEvent("imperial:consent-changed", { detail: value }));
  }

  if (!ready) return null;
  const visible = !consent || settingsOpen;
  if (!visible) return null;

  return (
    <div className="cookie-consent-layer" role="region" aria-label="Cookie and privacy preferences" aria-live="polite">
      <section className="cookie-consent-panel" aria-labelledby="cookie-consent-title">
        <div className="cookie-consent-mark" aria-hidden="true">✦</div>
        <div className="cookie-consent-copy">
          <p className="cookie-consent-eyebrow">IMPERIAL PRIVACY</p>
          <h2 id="cookie-consent-title">Your realm. Your choices.</h2>
          <p>Imperial Novel uses essential storage to keep the website secure and remember your preferences. Optional analytics and marketing storage remain off unless you choose to enable them. See our <Link to="/privacy">Privacy Policy</Link>.</p>
          {settingsOpen && (
            <div className="cookie-preference-options">
              <label><input type="checkbox" checked disabled /> <span><strong>Essential</strong><small>Required for security, login and core site functions.</small></span></label>
              <label><input type="checkbox" checked={analytics} onChange={(e) => setAnalytics(e.currentTarget.checked)} /> <span><strong>Analytics</strong><small>Allows optional usage measurement if an analytics provider is configured.</small></span></label>
              <label><input type="checkbox" checked={marketing} onChange={(e) => setMarketing(e.currentTarget.checked)} /> <span><strong>Marketing</strong><small>Allows optional marketing storage if a marketing provider is configured.</small></span></label>
            </div>
          )}
        </div>
        <div className="cookie-consent-actions">
          <button type="button" className="cookie-button cookie-button-primary" onClick={() => save(true, true)}>Accept all</button>
          <button type="button" className="cookie-button" onClick={() => save(false, false)}>Reject optional</button>
          <button type="button" className="cookie-button cookie-button-subtle" onClick={() => settingsOpen ? save(analytics, marketing) : setSettingsOpen(true)}>{settingsOpen ? "Save choices" : "Customize"}</button>
        </div>
      </section>
    </div>
  );
}

export function CookieSettingsLink() {
  return <button type="button" className="cookie-settings-link" onClick={() => window.dispatchEvent(new Event("imperial:cookie-settings"))}>Cookie preferences</button>;
}
