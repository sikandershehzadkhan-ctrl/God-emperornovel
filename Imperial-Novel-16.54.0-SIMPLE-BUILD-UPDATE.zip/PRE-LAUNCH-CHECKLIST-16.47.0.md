# Imperial Novel 16.47.0 — Production Pre-Launch Checklist

## Source changes
- [x] Application D1 queries resolve the current TanStack Start request and its registered binding.
- [x] Nitro middleware registers both request identities when available.
- [x] Cloudflare session verification resolves the request-scoped Cloudflare environment and uses the D1-backed Better Auth adapter.
- [x] Node/PGLite auth remains isolated from the Cloudflare build and missing bindings fail closed.
- [x] Regression tests cover request binding isolation and auth environment registration.

## Checks completed locally
- [x] Script suite: 261 passed, 0 failed.
- [x] Cloudflare readiness test suite: 6 passed, 0 failed.
- [x] D1 middleware/context tests: 9 passed, 0 failed.
- [x] Cloudflare source readiness: 17/17 source checks passed; two external prerequisites remain.

## Required before release
- [x] D1 auth schema migration tests: 6 passed, 0 failed.
- [ ] Network-enabled CI completes `npm ci`, dependency preflight, full `npm test`, typecheck, lint, npm audit, and Cloudflare build.
- [ ] Secret scanner runs against full Git history in CI; the exported workspace only allowed a working-tree scan (0 findings).
- [ ] Regenerate and verify missing registry integrity metadata without changing locked dependency versions or graph.
- [ ] Create a dedicated staging D1 database and configure only staging secrets/variables.
- [ ] Verify request identity matching in the actual Cloudflare/Nitro runtime.
- [ ] Verify D1-backed sign-in/session/logout, user isolation, admin bootstrap, tickets, EasyPaisa approval, chapter unlocks, rights review, headers, rate limits, backup/restore, and rollback in staging.

## Safety
Production Worker `god-emperornovel` and production D1 `god-emperornovel-db` remain out of scope. No production deployment or migration is authorized.

**NOT PRODUCTION READY until all required CI and staging checks pass.**
