# Imperial Novel 16.46.0 — Resilient Dependency Recovery

## Changes made
- Added an explicit npm registry and bounded fetch retry configuration to GitHub Actions.
- Added three bounded attempts for registry metadata refresh and `npm ci`; CI fails closed with a clear diagnostic if packages still cannot be installed.
- Kept the locked package versions unchanged and retained integrity-only lockfile drift verification.
- Added regression tests for the CI retry/fail-closed contract.
- Updated application and seed version markers to `16.46.0`.

## Verified results in this workspace
- `node --test 'scripts/**/*.test.mjs'`: **259 passed, 0 failed**.
- `node --experimental-sqlite --test scripts/d1-auth-schema.test.mjs`: **6 passed, 0 failed**.
- `npm run audit:prelaunch`: **28 required assets checked, 0 route metadata notes; pass**.
- `node scripts/cloudflare-readiness.mjs`: **16/16 source checks pass**, with 2 external release blockers.
- Dependency declaration and lockfile check confirms `jose@6.2.9` and `@tanstack/react-start@1.168.60` are declared and locked.

## Confirmed blockers
The environment cannot resolve `registry.npmjs.org` (`EAI_AGAIN`). As a result:
- `npm test`: script tests and D1 schema tests pass, but the runtime test phase has **41 passing tests and 2 test modules that fail to load** because `@tanstack/react-start` and `jose` are absent.
- `npm run typecheck`: blocked by missing `@types/node` and `vite/client`.
- `npm run lint`: blocked because ESLint is not installed.
- `npm run build:cloudflare`: blocked because Vite is not installed.
- `npm audit --audit-level=high`: blocked because the npm audit endpoint cannot be reached.
- `node scripts/verify-dependencies.mjs`: correctly fails closed and lists six missing packages.

The source package does not include `node_modules`, which is expected. The missing packages must be installed from the registry before the full application checks can pass. The new CI retries help with transient registry failures but cannot cure persistent DNS/network outages.

## Remaining external release blockers
1. Run the workflow in network-enabled GitHub Actions and require successful dependency install, full tests, typecheck, lint, npm audit, and Cloudflare build.
2. Cloudflare account owner must create a separate staging D1 database and configure staging-only secrets/variables.
3. Verify auth/session/logout/admin restrictions, tickets, donation approval, chapter unlocks, rights review, security headers, rate limits, backup/restore and rollback on isolated staging.

## Safety
No GitHub push, production deployment, production migration, or remote credential change was performed. The live Worker `god-emperornovel` and production D1 database `god-emperornovel-db` remain untouched.

**Release decision: NOT PRODUCTION READY.**
