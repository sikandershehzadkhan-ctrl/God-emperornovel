# Imperial Novel 16.47.0 — Request-scoped Cloudflare database and auth context

## Changes made
- Fixed the application SQL adapter so `queryD1()` and `batchD1()` resolve the current TanStack Start request and use the D1 binding registered by the Nitro middleware. Calls outside a valid request scope still fail closed rather than opening PGLite.
- Cloudflare middleware now registers both `event.web.request` and `event.req.original` when present, covering Nitro's two possible request identities.
- Added request-scoped Cloudflare environment registration so `verify.server.ts` can resolve the same request's D1 binding and create the D1-backed Better Auth instance when verifying sessions.
- Changed server-side auth verification to dynamically load the Node/PGLite auth module only for non-Cloudflare requests. The Cloudflare build uses its aliasable Node-auth stub and loads the D1 auth module for requests with registered Cloudflare bindings.
- Added regression tests for request isolation, both Nitro request identities, and Cloudflare auth environment registration.
- Expanded the read-only Cloudflare source readiness check from 16 to 17 checks.

## Checks completed locally
- `node --test 'scripts/**/*.test.mjs'`: **261 passed, 0 failed**.
- `node --test scripts/cloudflare-readiness.test.mjs`: **6 passed, 0 failed**.
- `node --experimental-strip-types --test server/middleware/imperial-d1.test.ts src/lib/db/d1-context.test.ts`: **9 passed, 0 failed**.
- `node scripts/cloudflare-readiness.mjs`: **17/17 source checks passed**; exit status 2 is intentional because two external release prerequisites remain.
- `node --experimental-sqlite --test scripts/d1-auth-schema.test.mjs`: **6 passed, 0 failed**.

## Not verified yet
- `npm test` reaches the TypeScript runtime-test phase after the script suite and SQLite schema suite pass, but two test modules cannot load because `@tanstack/react-start` and `jose` are not installed; the remaining runtime phase reports 43 passing tests and 2 failed-to-load modules.
- TypeScript typecheck is blocked by missing `@types/node` and `vite/client`; the Cloudflare build is blocked because Vite is not installed; lint is blocked because ESLint is not installed. The dependency preflight identifies six missing packages. A network-enabled `npm ci` is still required after the earlier `EAI_AGAIN registry.npmjs.org` failure.
- Request identity equivalence, D1-backed Better Auth session creation/lookup, and complete application behavior still require a dependency-backed build and isolated Cloudflare staging test.
- The lockfile still requires registry-provided integrity metadata for `drizzle-orm@0.45.2`; no hash was fabricated.
- The working-tree secret scan found **0 high-confidence patterns**, but repository-history scanning is unavailable in this exported workspace. CI must run the scan with full Git history. `check:auth` also remains indeterminate without a running dev server, which is expected for this offline source-only session.

## External release blockers
1. Restore npm registry access and run CI install, full tests, typecheck, lint, audit, and Cloudflare build.
2. Create a separate staging D1 database and set staging-only bindings/secrets.
3. Verify sign-in/session/logout, profile ownership, admin restrictions, ticket purchase/unlock, EasyPaisa manual approval, rights review, security headers, rate limiting, and rollback in isolated staging.

## Safety
No GitHub push, production deployment, production migration, or remote credential change was performed. The live Worker `god-emperornovel` and production D1 database `god-emperornovel-db` remain untouched.

**Release decision: NOT PRODUCTION READY.**
