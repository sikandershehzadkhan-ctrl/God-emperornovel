# Imperial Novel 12.0

- Full reading-platform experience layer.
- Persistent reader font size, theme and width preferences.
- Reader keyboard shortcuts: `+`, `-`, `0`, `Esc`.
- URL-aware catalog search.
- Mobile search field.
- Rights-aware badges and source presentation on novel detail pages.
- Expanded novel statistics.
- Accessibility skip link.
- Responsive catalog toolbar and reader controls.
- Preserves existing authentication, D1 database, library, tickets, requests, OmniPortal and Agent Nexus architecture.
- Legal/rights-aware design: original, licensed or authorized content only; no access-control bypassing.
