# Imperial Novel 15.0

## Fixes
- Fixed `/history` so it renders a dedicated Reading History page instead of the Library page.
- Added authenticated `GET /api/history` for recent reading history.
- Fixed `/following` to use a dedicated Following renderer and `/api/follows` data.
- Added clear empty states for History and Following.
- Reduced Account initial API work by using the profile endpoint directly instead of a separate `/api/me` request.
- Added cache-busting for the application JavaScript to reduce stale-page behavior after deployment.

## Luxury icon update
- Replaced the previous crown mark with the supplied Imperial crown icon.
- Replaced the previous search glyph with the supplied Imperial search icon.
- No other visual direction was intentionally changed.

## Preserved
- Worker: `god-emperornovel`
- D1 database: `god-emperornovel-db`
- Multi-page 14.0 architecture
- Authentication, tickets, batch unlocks, library, comments, ratings, follows, recommendations, requests and rights-aware OmniPortal behavior.
- Legal architecture: only original, licensed or otherwise authorized content/integrations; no bypassing access controls, paywalls, CAPTCHAs or DRM.
