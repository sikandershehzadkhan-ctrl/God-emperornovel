# Imperial Novel 10.1

- Refined the approved Imperial Novel visual language using the supplied character sheet as the hero-art direction.
- Added responsive desktop Imperial Hall navigation and a cleaner discovery layout.
- Added the supplied character artwork to the hero section.
- Improved mobile hero composition, touch spacing and bottom navigation.
- Kept existing authentication, D1, catalog, library, request, ticket, reader, OmniPortal, agent and admin functionality.
- Kept the Worker target `imperial-novel` and public branding `Imperial Novel`.
