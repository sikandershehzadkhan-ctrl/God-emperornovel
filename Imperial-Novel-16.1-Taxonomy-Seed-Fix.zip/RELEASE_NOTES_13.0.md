# Imperial Novel 13.0

Production functionality upgrade built on 12.0.

- Version bumped to 13.0.0 while preserving Worker `god-emperornovel` and D1 binding.
- Added authenticated ticket ledger endpoint.
- Added personalized/fallback recommendation endpoint.
- Added followed-novels endpoint.
- Added authenticated profile statistics endpoint.
- Added Ticket History and Recommendations controls to the account experience.
- Preserved rights-aware OmniPortal behavior and access-control protections.
- Preserved existing catalog, reader, authentication, library, requests, donations, comments, ratings, notifications and admin APIs.
