# Imperial Novel 10.0

## Major UI redesign
- Rebranded the public platform as **Imperial Novel** / **Imperial NovelVerse**.
- Worker target renamed to `imperial-novel`, producing the new workers.dev hostname when deployed.
- Completely redesigned responsive interface inspired by modern web-novel catalog patterns, while keeping original styling and code.
- Desktop: spacious catalog + right-side discovery rail, stronger hierarchy, compact cards and sticky navigation.
- Mobile: dedicated mobile search, 2-column novel grid, simplified header, touch-friendly controls and fixed bottom navigation.
- Preserved existing account, library, request, OmniPortal, agent, ticket, reader and admin functionality/IDs.
- Updated PWA branding and site metadata.
