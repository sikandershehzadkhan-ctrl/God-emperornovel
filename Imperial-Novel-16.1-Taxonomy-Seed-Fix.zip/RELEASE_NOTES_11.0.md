# Imperial Novel 11.0

Major experience upgrade built on the existing 10.2 production architecture.

- Preserves Worker name `god-emperornovel` and existing D1 database.
- Imperial Novel branding and emperor artwork retained.
- Mobile-first and desktop responsive experience layer.
- Quick discovery bar for updated, trending, batch unlocks and OmniPortal.
- Improved catalog empty states and reset controls.
- Enhanced card hover treatment and panel depth.
- Reader progress indicator and improved mobile reader behavior.
- Existing authentication, library, requests, tickets, comments, ratings, OmniPortal, agents and admin APIs preserved.
- Rights-aware connector architecture remains unchanged: no bypassing access controls, paywalls, CAPTCHAs or robots restrictions.
