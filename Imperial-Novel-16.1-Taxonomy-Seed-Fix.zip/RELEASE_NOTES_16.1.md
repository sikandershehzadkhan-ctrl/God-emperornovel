# Imperial Novel 16.1

## Taxonomy seed fix
- Automatically seeds the master Genres and Tags catalog during core database initialization.
- Expanded the normalized taxonomy across fantasy, cultivation, urban, historical, sci-fi, game, fanfiction, fandom, romance, kingdom/empire building, character and story-structure tags.
- Seeding is idempotent and never overwrites existing custom entries.

## Rights
The taxonomy is an original normalized classification system based on common genre/classification concepts. It does not copy protected site code or story content.
