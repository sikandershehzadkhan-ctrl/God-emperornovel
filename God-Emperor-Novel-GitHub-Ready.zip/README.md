# GOD-EMPEROR NOVEL — FINAL CLOUDFLARE BUILD

This package is the final deployable application package for the requested platform architecture. It is **not a static-only prototype**.

## Included and working
- Cloudflare Worker API
- Cloudflare D1 schema/migration
- Real registration, login and logout
- HttpOnly Secure session cookies
- User roles
- Server-side ticket balances
- Single chapter unlock
- Batch chapter unlock: 10 / 25 / 50 / 100
- Unlock transaction records
- Novel/chapter catalog
- Genre and tag taxonomy
- Search
- Fanfiction/original classification
- Bookmarks/history API
- Donation submission and admin approval
- EasyPaisa destination shown as 03154329984
- Admin control center
- Admin user/ticket management
- Admin donation management
- Connector registry
- HTTPS + hostname allowlist for connectors
- Audit logs
- Cloudflare Assets frontend
- Seed catalog for first deployment
- Responsive mobile UI
- Basic security headers/session design

## DEPLOY TO YOUR EXISTING workers.dev SITE

1. Install Wrangler:
   npm install -g wrangler

2. Login:
   wrangler login

3. Create D1:
   wrangler d1 create god-emperornovel-db

4. Put the returned database_id into wrangler.toml.

5. Apply migration:
   wrangler d1 migrations apply god-emperornovel-db --remote

6. Set a long random setup secret:
   wrangler secret put SETUP_SECRET

7. Deploy:
   wrangler deploy

The deployment URL will be your Worker URL. If your existing Worker name is `god-emperornovel`, Wrangler will deploy the new version there.

## INITIALIZE

POST `/api/setup` once, with header:
`x-setup-secret: YOUR_SECRET`

JSON:
{
  "admin_username": "admin",
  "admin_email": "YOUR_EMAIL",
  "admin_password": "A_LONG_UNIQUE_PASSWORD"
}

After initialization, remove/disable the setup endpoint in a later hardened release or rotate the secret and restrict access.

## CONNECTORS / OMNIPORTAL

The connector registry is real database-backed infrastructure. It deliberately does NOT scrape or copy arbitrary third-party sites.

Set the environment variable:
`CONNECTOR_HOST_ALLOWLIST=api.example.com,feed.example.org`

Then add authorized HTTPS API/feed endpoints through the Admin dashboard.

Only connect sources whose API/feed/content terms give you permission to use them. The application stores source URL, connector status and rights status so imported content can be governed.

## EASYPAISA

Public/manual donation destination:
`03154329984`

The app records donation amount + reference ID and gives administrators an approval workflow.

Automatic EasyPaisa verification is intentionally NOT fabricated. It requires an authorized merchant/payment API and credentials. Add those as Cloudflare secrets and implement the provider's documented webhook/API when you have merchant access.

## 1M+ VISITORS

Cloudflare Workers can serve globally, but 1M+ visitors is a scale target, not a guarantee from code alone.

For a real high-traffic launch:
- enable Cloudflare caching where safe
- use R2 for cover/image assets
- add Queues for connector/import jobs
- add Turnstile/rate limiting
- add email verification/password reset
- monitor Worker/D1 usage and limits
- create backups/export strategy
- add a dedicated search index for a very large catalog
- use migrations for every schema change
- configure custom domain and DNS
- load test before launch

## IMPORTANT

No website can truthfully contain working credentials for your private Cloudflare account or an EasyPaisa merchant account without you supplying/authorizing them. Never put Cloudflare API tokens, payment secrets, or passwords into `public/index.html`.

This build also does not copy proprietary code or unauthorized copyrighted catalogs from Fictionzone, WTR-Lab, TomatoMTL, Faloo, Qidian, or other sites. Use authorized APIs/feeds or content you own/have permission to publish.
