const j=(d,s=200,h={})=>new Response(JSON.stringify(d),{status:s,headers:{"content-type":"application/json;charset=UTF-8","cache-control":"no-store",...h}});
const now=()=>Math.floor(Date.now()/1000);
const b64=a=>btoa(String.fromCharCode(...new Uint8Array(a))).replaceAll("+","-").replaceAll("/","_").replaceAll("=","");
const digest=async s=>b64(await crypto.subtle.digest("SHA-256",new TextEncoder().encode(s)));
const rnd=n=>{const a=new Uint8Array(n);crypto.getRandomValues(a);return b64(a)};
const slug=s=>String(s).toLowerCase().trim().replace(/[^a-z0-9]+/g,"-").replace(/^-|-$/g,"");
const cookies=h=>Object.fromEntries((h||"").split(";").map(x=>x.trim()).filter(Boolean).map(x=>{let i=x.indexOf("=");return[i<0?x: x.slice(0,i),decodeURIComponent(i<0?"":x.slice(i+1))]}));
const phash=async(p,s)=>digest(p+":"+s);
async function user(req,env){
  const c=cookies(req.headers.get("cookie")); if(!c.session)return null;
  const th=await digest(c.session);
  const u=await env.DB.prepare("SELECT u.id,u.username,u.email,u.role,u.tickets,u.banned,s.expires_at FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=?").bind(th).first();
  if(!u||u.banned||u.expires_at<now())return null; return u;
}
const auth=u=>u?null:j({error:"Authentication required"},401);
const admin=u=>u?.role==="admin"?null:j({error:"Administrator access required"},403);
const body=async r=>await r.json().catch(()=>({}));
const log=async(env,u,a,d)=>{try{await env.DB.prepare("INSERT INTO audit_logs(user_id,action,details) VALUES(?,?,?)").bind(u?.id||null,a,d||"").run()}catch{}};

async function seed(env){
 const genres=["Action","Adventure","Fantasy","Romance","Harem","Cultivation","Xianxia","Wuxia","Isekai","Reincarnation","System","Sci-Fi","Mystery","Horror","Historical","Comedy","Drama","Fanfiction"];
 const tags=["System","Isekai","Reincarnation","Transmigration","Crossover","Self Insert","Alternate Universe","Multiverse","Dragon","Empire","Magic","Academy","Strong MC","Slow Burn","Fanfiction","Anime","Manga","Manhwa","Manhua","Game","K-Drama","C-Drama","Time Travel","Overpowered MC"];
 for(const x of genres)await env.DB.prepare("INSERT OR IGNORE INTO genres(name,slug) VALUES(?,?)").bind(x,slug(x)).run();
 for(const x of tags)await env.DB.prepare("INSERT OR IGNORE INTO tags(name,slug) VALUES(?,?)").bind(x,slug(x)).run();
 const n=await env.DB.prepare("SELECT id FROM novels LIMIT 1").first();
 if(!n){
  const r=await env.DB.prepare("INSERT INTO novels(title,alt_titles,author,description,status,kind,language,rights_status) VALUES(?,?,?,?,?,?,?,?)").bind("God-Emperor's Infinite Ascension","Infinite Ascension","Sikander Shehzad","A cosmic system, an empire, and an infinite path upward.","ongoing","original","English","original").run();
  const id=r.meta.last_row_id;
  for(let i=1;i<=120;i++)await env.DB.prepare("INSERT INTO chapters(novel_id,chapter_number,title,content,is_locked,ticket_cost) VALUES(?,?,?,?,?,?)").bind(id,i,`Chapter ${i}: The Imperial Awakening`,`<p><strong>God-Emperor Novel</strong></p><p>This seeded chapter is placeholder content for deployment testing. Replace it with content you own or have permission to publish.</p><p>The story continues beyond the mortal page.</p>`,i>1,i<=10?2.934:2.999).run();
  for(const x of await env.DB.prepare("SELECT id FROM genres WHERE slug IN ('fantasy','action','isekai','system','fanfiction')").all())await env.DB.prepare("INSERT OR IGNORE INTO novel_genres VALUES(?,?)").bind(id,x.id).run();
  for(const x of await env.DB.prepare("SELECT id FROM tags WHERE slug IN ('system','isekai','empire','strong-mc','multiverse')").all())await env.DB.prepare("INSERT OR IGNORE INTO novel_tags VALUES(?,?)").bind(id,x.id).run();
 }
}
async function setup(req,env){
 if(req.headers.get("x-setup-secret")!==env.SETUP_SECRET)return j({error:"Invalid setup secret"},403);
 await seed(env); const b=await body(req);
 if(b.admin_email&&b.admin_password){
  const salt=rnd(16), hp=await phash(b.admin_password,salt);
  await env.DB.prepare("INSERT OR IGNORE INTO users(username,email,password_hash,role,verified) VALUES(?,?,?,?,1)").bind(b.admin_username||"admin",b.admin_email.toLowerCase(),hp+":"+salt,"admin").run();
 }
 return j({ok:true,message:"Database initialized"});
}
async function api(req,env){
 const u=new URL(req.url),p=u.pathname,m=req.method;
 if(p==="/api/health")return j({ok:true,service:"God-Emperor Novel",time:new Date().toISOString()});
 if(p==="/api/setup"&&m==="POST")return setup(req,env);
 if(p==="/api/auth/register"&&m==="POST"){let b=await body(req);if(!b.username||!b.email||!b.password||b.password.length<8)return j({error:"Username, email and password of 8+ characters are required"},400);let salt=rnd(16),hp=await phash(b.password,salt);try{await env.DB.prepare("INSERT INTO users(username,email,password_hash) VALUES(?,?,?)").bind(b.username.trim(),b.email.trim().toLowerCase(),hp+":"+salt).run()}catch{return j({error:"Username or email already exists"},409)}return j({ok:true})}
 if(p==="/api/auth/login"&&m==="POST"){let b=await body(req),x=await env.DB.prepare("SELECT * FROM users WHERE email=?").bind((b.email||"").toLowerCase()).first();if(!x)return j({error:"Invalid credentials"},401);let [hp,salt]=(x.password_hash||"").split(":");if(await phash(b.password||"",salt)!==hp)return j({error:"Invalid credentials"},401);let token=rnd(32);await env.DB.prepare("INSERT INTO sessions(token_hash,user_id,expires_at) VALUES(?,?,?)").bind(await digest(token),x.id,now()+2592000).run();return j({ok:true,user:{id:x.id,username:x.username,email:x.email,role:x.role,tickets:x.tickets} },200,{"set-cookie":`session=${encodeURIComponent(token)}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=2592000`})}
 if(p==="/api/auth/logout"&&m==="POST"){let c=cookies(req.headers.get("cookie"));if(c.session)await env.DB.prepare("DELETE FROM sessions WHERE token_hash=?").bind(await digest(c.session)).run();return j({ok:true},200,{"set-cookie":"session=; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=0"})}
 if(p==="/api/me"){return j({user:u?{id:u.id,username:u.username,email:u.email,role:u.role,tickets:u.tickets}:null})}
 if(p==="/api/genres")return j((await env.DB.prepare("SELECT * FROM genres ORDER BY name").all()).results);
 if(p==="/api/tags")return j((await env.DB.prepare("SELECT * FROM tags ORDER BY name").all()).results);
 if(p==="/api/novels"){
  let q=(new URL(req.url)).searchParams, term=(q.get("q")||"").toLowerCase(), genre=q.get("genre"),tag=q.get("tag");
  let sql="SELECT n.*,GROUP_CONCAT(DISTINCT g.name) genres,GROUP_CONCAT(DISTINCT t.name) tags FROM novels n LEFT JOIN novel_genres ng ON ng.novel_id=n.id LEFT JOIN genres g ON g.id=ng.genre_id LEFT JOIN novel_tags nt ON nt.novel_id=n.id LEFT JOIN tags t ON t.id=nt.tag_id WHERE 1=1",a=[];
  if(term){sql+=" AND (LOWER(n.title) LIKE ? OR LOWER(n.author) LIKE ? OR LOWER(n.description) LIKE ?)";let z="%"+term+"%";a.push(z,z,z)}
  if(genre){sql+=" AND n.id IN(SELECT ng.novel_id FROM novel_genres ng JOIN genres g ON g.id=ng.genre_id WHERE g.slug=?)";a.push(genre)}
  if(tag){sql+=" AND n.id IN(SELECT nt.novel_id FROM novel_tags nt JOIN tags t ON t.id=nt.tag_id WHERE t.slug=?)";a.push(tag)}
  sql+=" GROUP BY n.id ORDER BY n.updated_at DESC LIMIT 100";return j((await env.DB.prepare(sql).bind(...a).all()).results)
 }
 let nm=p.match(/^\/api\/novels\/(\d+)$/);
 if(nm){let n=await env.DB.prepare("SELECT * FROM novels WHERE id=?").bind(nm[1]).first();if(!n)return j({error:"Novel not found"},404);await env.DB.prepare("UPDATE novels SET views=views+1 WHERE id=?").bind(n.id).run();let [c,g,t]=await Promise.all([env.DB.prepare("SELECT id,chapter_number,title,is_locked,ticket_cost FROM chapters WHERE novel_id=? ORDER BY chapter_number").bind(n.id).all(),env.DB.prepare("SELECT g.* FROM genres g JOIN novel_genres ng ON ng.genre_id=g.id WHERE ng.novel_id=?").bind(n.id).all(),env.DB.prepare("SELECT t.* FROM tags t JOIN novel_tags nt ON nt.tag_id=t.id WHERE nt.novel_id=?").bind(n.id).all()]);return j({...n,chapters:c.results,genres:g.results,tags:t.results})}
 let cm=p.match(/^\/api\/chapters\/(\d+)$/);
 if(cm){let c=await env.DB.prepare("SELECT * FROM chapters WHERE id=?").bind(cm[1]).first();if(!c)return j({error:"Chapter not found"},404);let open=!c.is_locked||u?.role==="admin";if(u&&!open)open=!!await env.DB.prepare("SELECT 1 FROM unlocks WHERE user_id=? AND chapter_id=?").bind(u.id,c.id).first();return j({id:c.id,novel_id:c.novel_id,chapter_number:c.chapter_number,title:c.title,is_locked:!!c.is_locked,unlocked:open,content:open?c.content:null,ticket_cost:c.ticket_cost})}
 let cu=p.match(/^\/api\/chapters\/(\d+)\/unlock$/);
 if(cu&&m==="POST"){let e=auth(u);if(e)return e;let c=await env.DB.prepare("SELECT * FROM chapters WHERE id=?").bind(cu[1]).first();if(!c)return j({error:"Chapter not found"},404);if(!c.is_locked)return j({ok:true});if(await env.DB.prepare("SELECT 1 FROM unlocks WHERE user_id=? AND chapter_id=?").bind(u.id,c.id).first())return j({ok:true});if(Number(u.tickets)<Number(c.ticket_cost))return j({error:"Insufficient tickets",tickets:u.tickets,cost:c.ticket_cost},402);await env.DB.batch([env.DB.prepare("UPDATE users SET tickets=tickets-? WHERE id=? AND tickets>=?").bind(c.ticket_cost,u.id,c.ticket_cost),env.DB.prepare("INSERT INTO unlocks(user_id,chapter_id,cost) VALUES(?,?,?)").bind(u.id,c.id,c.ticket_cost)]);await log(env,u,"chapter_unlock",`chapter=${c.id};cost=${c.ticket_cost}`);let nu=await env.DB.prepare("SELECT tickets FROM users WHERE id=?").bind(u.id).first();return j({ok:true,tickets:nu.tickets})}
 let bu=p.match(/^\/api\/novels\/(\d+)\/batch-unlock$/);
 if(bu&&m==="POST"){let e=auth(u);if(e)return e;let b=await body(req),count=Math.min(Math.max(Number(b.count||10),1),100);if(![10,25,50,100].includes(count))return j({error:"Batch size must be 10, 25, 50 or 100"},400);let start=Math.max(1,Number(b.start_chapter||1));let cs=(await env.DB.prepare("SELECT * FROM chapters WHERE novel_id=? AND chapter_number>=? AND chapter_number<? ORDER BY chapter_number LIMIT ?").bind(bu[1],start,start+count,count).all()).results;let locked=cs.filter(c=>c.is_locked),cost=locked.reduce((s,c)=>s+Number(c.ticket_cost),0);if(Number(u.tickets)<cost)return j({error:"Insufficient tickets",tickets:u.tickets,cost,available:locked.length,chapters:cs.length},402);let stm=[env.DB.prepare("UPDATE users SET tickets=tickets-? WHERE id=?").bind(cost,u.id)];for(let c of locked)stm.push(env.DB.prepare("INSERT OR IGNORE INTO unlocks(user_id,chapter_id,cost) VALUES(?,?,?)").bind(u.id,c.id,c.ticket_cost));stm.push(env.DB.prepare("INSERT INTO unlock_batches(user_id,novel_id,start_chapter,end_chapter,requested_count,cost) VALUES(?,?,?,?,?,?)").bind(u.id,bu[1],start,start+cs.length-1,cs.length,cost));await env.DB.batch(stm);let nu=await env.DB.prepare("SELECT tickets FROM users WHERE id=?").bind(u.id).first();return j({ok:true,tickets:nu.tickets,unlocked:locked.length,cost})}
 if(p==="/api/donations"&&m==="POST"){let e=auth(u);if(e)return e;let b=await body(req),amount=Number(b.amount);if(!amount||amount<=0||!b.reference_id)return j({error:"Amount and transaction/reference ID are required"},400);await env.DB.prepare("INSERT INTO donations(user_id,amount,reference_id) VALUES(?,?,?)").bind(u.id,amount,String(b.reference_id).slice(0,120)).run();return j({ok:true,status:"pending"})}
 if(p==="/api/bookmark"&&m==="POST"){let e=auth(u);if(e)return e;let b=await body(req);await env.DB.prepare("INSERT INTO bookmarks(user_id,novel_id,chapter_number) VALUES(?,?,?) ON CONFLICT(user_id,novel_id) DO UPDATE SET chapter_number=excluded.chapter_number,updated_at=CURRENT_TIMESTAMP").bind(u.id,b.novel_id,Number(b.chapter_number||1)).run();return j({ok:true})}
 if(p==="/api/history"&&m==="POST"){let e=auth(u);if(e)return e;let b=await body(req);await env.DB.prepare("INSERT INTO history(user_id,novel_id,chapter_number) VALUES(?,?,?) ON CONFLICT(user_id,novel_id) DO UPDATE SET chapter_number=excluded.chapter_number,updated_at=CURRENT_TIMESTAMP").bind(u.id,b.novel_id,Number(b.chapter_number||1)).run();return j({ok:true})}
 if(p.startsWith("/api/admin/")){
  let e=admin(u);if(e)return e;
  if(p==="/api/admin/stats")return j({users:(await env.DB.prepare("SELECT COUNT(*) c FROM users").first()).c,novels:(await env.DB.prepare("SELECT COUNT(*) c FROM novels").first()).c,chapters:(await env.DB.prepare("SELECT COUNT(*) c FROM chapters").first()).c,pendingDonations:(await env.DB.prepare("SELECT COUNT(*) c FROM donations WHERE status='pending'").first()).c,connectors:(await env.DB.prepare("SELECT COUNT(*) c FROM connectors").first()).c});
  if(p==="/api/admin/users")return j((await env.DB.prepare("SELECT id,username,email,role,tickets,verified,banned,created_at FROM users ORDER BY id DESC LIMIT 500").all()).results);
  if(p==="/api/admin/tickets"&&m==="POST"){let b=await body(req);await env.DB.prepare("UPDATE users SET tickets=tickets+? WHERE id=?").bind(Number(b.amount),Number(b.user_id)).run();await log(env,u,"ticket_credit",`user=${b.user_id};amount=${b.amount}`);return j({ok:true})}
  if(p==="/api/admin/donations"&&m==="GET")return j((await env.DB.prepare("SELECT d.*,u.username,u.email FROM donations d LEFT JOIN users u ON u.id=d.user_id ORDER BY d.id DESC LIMIT 500").all()).results);
  let dm=p.match(/^\/api\/admin\/donations\/(\d+)$/);if(dm&&m==="PATCH"){let b=await body(req);if(!["pending","approved","rejected"].includes(b.status))return j({error:"Invalid status"},400);await env.DB.prepare("UPDATE donations SET status=? WHERE id=?").bind(b.status,dm[1]).run();if(b.status==="approved"){let d=await env.DB.prepare("SELECT * FROM donations WHERE id=?").bind(dm[1]).first();let credit=Number(b.tickets||Math.max(0,Number(d.amount)));if(credit)await env.DB.prepare("UPDATE users SET tickets=tickets+? WHERE id=?").bind(credit,d.user_id)}return j({ok:true})}
  if(p==="/api/admin/connectors"&&m==="GET")return j((await env.DB.prepare("SELECT * FROM connectors ORDER BY id DESC").all()).results);
  if(p==="/api/admin/connectors"&&m==="POST"){let b=await body(req);let x;try{x=new URL(b.base_url)}catch{return j({error:"Invalid URL"},400)}if(x.protocol!=="https:")return j({error:"HTTPS only"},400);let allow=(env.CONNECTOR_HOST_ALLOWLIST||"").split(",").map(x=>x.trim()).filter(Boolean);if(!allow.includes(x.hostname))return j({error:"Host is not on CONNECTOR_HOST_ALLOWLIST"},403);await env.DB.prepare("INSERT INTO connectors(name,base_url,type,rights_status) VALUES(?,?,?,?)").bind(b.name,x.href,b.type||"json",b.rights_status||"pending").run();return j({ok:true})}
  let dc=p.match(/^\/api\/admin\/connectors\/(\d+)\/toggle$/);if(dc&&m==="POST"){await env.DB.prepare("UPDATE connectors SET enabled=1-enabled WHERE id=?").bind(dc[1]).run();return j({ok:true})}
 }
 return env.ASSETS.fetch(req);
}
export default {async fetch(req,env){try{return await api(req,env)}catch(e){console.error(e);return j({error:"Internal server error"},500)}}};
